---
navigation:
  title: AE2 Helpers
  position: 70
---

**ae2helpers**는 Applied Energistics 2의 자동 제작 구성을 더 간편하고 효율적으로 만드는 편의성 애드온입니다.

# 주요 기능

**1. Crafting Result Import Card**
**Pattern Provider**에 장착하는 전용 업그레이드입니다.
* **기능:** Pattern Provider가 같은 면을 통해 기계에 재료를 **전달**하고 완성된 결과물을 **회수**할 수 있습니다.
* **장점:** 단순한 가공 기계에서 별도의 Import Bus와 추가 채널을 설치할 필요가 없습니다.
* 결과물을 인접 기계로 자동 출력하지 않는 기계에서만 필요하거나 유용합니다.

**2. Automatic Recipe Insertion**
**Crafting Terminal**의 제작 과정을 개선합니다.
* **기능:** 터미널에서 제작법의 자동 제작을 요청하면 Ghost Item이 표시되며 제작 격자가 대기 상태가 됩니다.
* **장점:** Crafting CPU가 작업을 완료하는 즉시 재료가 제작 격자에 **자동으로 삽입**됩니다. 제작법을 다시 눌러 전송할 필요가 없습니다.
