---
navigation:
  title: FTB Industrial Contraptions
  icon: ftbic:advanced_machine_block
  position: 0
---

# <Color id="gold">FTB Industrial Contraptions</Color>

<Column alignItems="center" fullWidth={true}>
  # <Color id="gold">FTB Industrial Contraptions</Color>

  <ItemImage id="advanced_machine_block" scale="2" />

  전력 생산, 광석 가공, 원자력 기술, 후반 장비를 다루는 기술 모드입니다. 전용 에너지 네트워크에서 전력을 **<EnergyUnit />** 단위로 측정합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">여기서 시작하세요</Color>
</Column>

* <ItemImage id="iron_furnace" scale="0.75"/> [시작하기](getting_started.md): 첫 Machine Block, Generator, Cable
* <ItemImage id="lv_cable" scale="0.75"/> [에너지 네트워크](energy/index.md): <EnergyUnit />, 전압 등급, 배선, 저장
* <ItemImage id="basic_generator" scale="0.75"/> [발전기](generators/index.md): 연료, 열, 태양, 바람을 <EnergyUnit />로 변환

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">목차</Color>
</Column>

<ItemImage id="minecraft:air" scale="0.5"/>
<Row>
<Column>

* <ItemImage id="advanced_alloy" scale="0.75"/> [재료](materials/index.md)
* <ItemImage id="lv_cable" scale="0.75"/> [에너지 네트워크](energy/index.md)
* <ItemImage id="basic_generator" scale="0.75"/> [발전기](generators/index.md)
* <ItemImage id="macerator" scale="0.75"/> [기계](machines/index.md)

</Column>
<Column>

* <ItemImage id="nuclear_reactor" scale="0.75"/> [원자력](nuclear/index.md)
* <ItemImage id="quantum_chestplate" scale="0.75"/> [전력 갑옷](armor/index.md)
* <ItemImage id="overclocker_upgrade" scale="0.75"/> [업그레이드](upgrades/index.md)
* <ItemImage id="teleporter" scale="0.75"/> [기타 장치](utilities/index.md)

</Column>
</Row>
