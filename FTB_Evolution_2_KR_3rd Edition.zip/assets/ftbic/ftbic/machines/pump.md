---
navigation:
  title: Pump
  icon: ftbic:pump
  parent: machines/index.md
  position: 11
item_ids:
  - ftbic:pump
  - ftbic:exfluid
---

# <Color id="gold">Pump</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="pump" scale="2" />

  파이프를 스스로 연장하는 유체 채굴기입니다. 파이프를 수직으로 내려 Lava, Water 또는 모드에서 추가한 유체 웅덩이를 배수하고, 내부의 Bucket 128개 분량 탱크에 저장합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="pump" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">작동 방식</Color>
</Column>

* 블록 위에 설치하세요. 유체에 닿을 때까지 공기나 교체 가능한 블록을 지나 아래쪽으로 파이프를 연장합니다.
* 유체 블록 하나를 채굴하는 데 40틱, 파이프를 한 칸 내리는 데 10틱이 걸립니다.
* 기본적으로 무한 유체 생성 악용을 막기 위해 배수한 유체 자리를 <ItemLink id="exfluid" />로 바꿉니다. 빈 구멍을 남기고 싶다면 설정에서 비활성화하세요.
* 옆면에 파이프나 <ItemLink id="fluid_cell" />을 연결하여 유체를 내보내세요.

**성능:** HV 등급, 에너지 저장량 <Energy config="machines.pump_capacity" />, 소비량 <Energy config="machines.pump_use" rate="true" />.
