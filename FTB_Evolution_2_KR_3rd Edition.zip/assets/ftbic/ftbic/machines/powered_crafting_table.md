---
navigation:
  title: Powered Crafting Table
  icon: ftbic:powered_crafting_table
  parent: machines/index.md
  position: 10
item_ids:
  - ftbic:powered_crafting_table
---

# <Color id="gold">Powered Crafting Table</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="powered_crafting_table" scale="2" />

  3×3 제작 패턴을 고정하는 자동 제작대입니다. 인벤토리의 재료를 소비해 결과물을 생산하며, 제작 1회당 <ZapMode>1 zap</ZapMode><FEMode><Energy config="machines.powered_crafting_table_use" /></FEMode>을 소비합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="powered_crafting_table" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

**성능:** LV 등급, 에너지 저장량 <Energy config="machines.powered_crafting_table_capacity" />, 제작 1회당 <ZapMode>1 zap</ZapMode><FEMode><Energy config="machines.powered_crafting_table_use" /></FEMode> 소비.

출력용 Hopper와 연결해 재료를 투입하고 제작된 아이템을 꺼내도록 설정하세요. 바닐라와 모드 제작법을 포함해 모양이 있는 제작법과 무형 제작법 모두 지원합니다.

**JEI**에서 제작 격자로 아이템을 끌어다 놓아 [입력 슬롯 필터](side_configuration.md)를 지정하거나 **L** 패널을 사용하세요. 가상 아이템 지정은 실제 재료가 소비된 뒤에도 각 재료 슬롯의 배치를 유지합니다. Configuration Card로 다른 Powered Crafting Table에 필터를 복사할 수 있지만 실제 재료는 별도로 공급해야 합니다.
