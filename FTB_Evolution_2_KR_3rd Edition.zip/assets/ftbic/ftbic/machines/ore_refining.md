---
navigation:
  title: 광석 정제
  icon: ftbic:ore_washer
  parent: machines/index.md
  position: 4
item_ids:
  - ftbic:ore_washer
  - ftbic:advanced_ore_washer
  - ftbic:crushed_ore
  - ftbic:washed_ore
  - ftbic:refined_concentrate
---

# 광석 정제

전체 공정을 거치면 지원되는 금속의 **Raw Ore 1개당 Ingot 5개**, **Ore Block 1개당 Ingot 15개**를 얻습니다. Fortune 마법부여는 가공 전에 채굴한 Raw Ore 수량에 영향을 줍니다. 데이터팩으로 기본값을 변경할 수 있습니다.

## 처리 공정

1. **Macerator:** Ore Block 1개 → **Raw Ore 3개**
2. **Macerator:** Raw Ore 1개 → **Crushed Ore 2개**
3. **Ore Washer:** **Crushed Ore 2개 + 물 1,000 mB** → **Washed Ore 3개**
4. **Centrifuge:** **Washed Ore 3개** → **Refined Concentrate 5개**
5. **화로 종류 무관:** Concentrate 1개 → **Ingot 1개**

Raw Ore Block도 Macerator에 바로 넣을 수 있습니다. 블록 1개가 **Crushed Ore 18개**로 바뀌며, Raw Ore 9개를 각각 분쇄한 결과와 같습니다.

Ore Block 1개에서 시작하면 **Raw Ore 3개, Crushed Ore 6개, Washed Ore 9개, Concentrate 15개, Ingot 15개**를 얻습니다. 이 전체 묶음을 세척하려면 물 Bucket 3개가 필요합니다.

Crushed Ore와 Washed Ore를 직접 제련하면 각각 1개당 Ingot 1개를 얻습니다. 짧은 공정을 사용하면 분쇄까지만 진행할 경우 **Raw Ore당 Ingot 2개**, 세척까지 진행할 경우 **Raw Ore당 Ingot 3개**를 얻습니다. Ingot과 일반 Dust는 정제 공정에 다시 투입할 수 없습니다.

## Ore Washer

<RecipeFor id="ftbic:ore_washer" />

Ore Washer는 LV 전력을 사용하며 각 탱크의 용량은 **16,000 mB**입니다. 기본 제작법은 왼쪽 입력 탱크를 사용하고, 오른쪽 탱크는 사용자 제작법의 유체 출력에 사용할 수 있습니다. Bucket, Fluid Cell 또는 유체 자동화 장치로 물을 넣으세요. **I/O**에서 유체와 아이템 입출력 면을 각각 설정할 수 있습니다.

기본 소비량은 **<Energy config="machines.ore_washer_use" rate="true" />**이며 업그레이드 전 세척 1회에 **20초**가 걸립니다. 기본 Macerator는 분쇄 1회에 10초, Raw Ore Block 1개에 90초가 걸립니다. 기본 Centrifuge는 정제 1회에 30초가 걸립니다. 기계 설정과 재료 정의에 따라 달라질 수 있습니다.

아이템 묶음 전체, 충분한 유체와 전력, 모든 출력물을 담을 공간이 준비되어야 가공합니다. [Batch Feeder](batch_feeder.md)로 Crushed Ore 2개와 물 Bucket 1개를 함께 공급할 수 있습니다.

### Advanced Ore Washer

<RecipeFor id="ftbic:advanced_ore_washer" />

MV 등급입니다. 소비량 <Energy config="machines.advanced_ore_washer_use" rate="true" />, 에너지 저장량 <Energy config="machines.advanced_ore_washer_capacity" />입니다. Ore Washer와 제작법·속도·탱크 구성이 같지만 <ItemLink id="parallel_processing_upgrade" />를 장착할 수 있습니다. 병렬 세척 1회마다 Crushed Ore 2개와 물 1,000 mB가 각각 필요합니다.

## 재료와 자동화

FTBIC는 공통 원재료 및 Ingot 태그에서 금속을 찾아 제련 관계를 검증합니다. Ore 태그가 있으면 Ore→Raw Ore 제작법이, Raw Ore 저장 블록 태그가 있으면 블록 분쇄 제작법이 활성화됩니다. 매핑이 누락되거나 충돌하면 모드팩 제작자가 재료 정의를 추가해야 합니다. 보석이나 특수한 가공 체계는 자동으로 금속으로 취급하지 않습니다.

재료마다 이름과 색상이 구분되는 중간 가공품이 있습니다. 같은 재료는 정상적으로 겹쳐 쌓이고 다른 재료는 섞이지 않습니다. JEI에서 감지된 변형과 제작법을 확인하세요. 정확한 재료 종류를 기계 입력 잠금 또는 Batch Feeder의 가상 슬롯으로 끌어다 놓으세요.

색상은 먼저 데이터팩의 덮어쓰기 값을, 다음으로 알려진 재료 색상표를 사용하며, 낯선 금속은 선택된 Ingot 텍스처를 참고합니다. 리소스팩을 다시 불러오면 추출한 색상도 갱신됩니다. 툴팁의 재료 ID로 색상이 비슷한 재료를 구분할 수 있습니다.

재료 정의에는 Centrifuge 부산물을 최대 2종 추가할 수 있습니다. 아이템 출력물이 서로 다른 3종인 제작법에는 **Advanced Centrifuge**가 필요합니다. 자동 감지는 보조 금속을 임의로 추정해 추가하지 않습니다.
