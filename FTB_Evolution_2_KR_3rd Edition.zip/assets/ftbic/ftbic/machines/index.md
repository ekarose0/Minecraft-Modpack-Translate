---
navigation:
  title: 기계
  icon: ftbic:macerator
  position: 30
---

# <Color id="gold">기계</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="macerator" scale="2" />

  FTBIC의 제작법 처리 기계는 인벤토리, 제작법 처리 주기, 에너지 저장 공간, 최대 4개의 **업그레이드** 슬롯을 공통으로 사용합니다. 고급형은 저장 공간이 더 크고 처리량도 높습니다. Batch Feeder 같은 보조 기계에는 별도의 조작 기능이 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">기계 공통 구조</Color>
</Column>

제작법을 처리하는 기계에는 다음 기능이 공통으로 제공됩니다.

* **에너지 저장 공간:** GUI 오른쪽에 표시됩니다.
* **진행 표시줄:** 제작법 처리 틱에 따라 채워지며, 기본값은 제작법당 200틱입니다.
* **업그레이드 슬롯:** <ItemLink id="overclocker_upgrade" />, <ItemLink id="energy_storage_upgrade" />, <ItemLink id="transformer_upgrade" />, <ItemLink id="ejector_upgrade" />를 장착할 수 있습니다.
* **[측면 설정](side_configuration.md):** I/O 버튼으로 아이템·유체·에너지 입출력 면을 개별 설정합니다.
* **[입력 슬롯 잠금](side_configuration.md):** L 버튼으로 가상 아이템 지정을 유지합니다.

모든 LV 기계는 <ItemLink id="machine_block" /> 외장과 제작법별 핵심 부품으로 만듭니다. 예를 들어 Macerator에는 <ItemLink id="electronic_circuit" />와 Flint, Stone이 필요합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
