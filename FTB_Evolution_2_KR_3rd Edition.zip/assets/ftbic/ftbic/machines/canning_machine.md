---
navigation:
  title: Canning Machine
  icon: ftbic:canning_machine
  parent: machines/index.md
  position: 8
item_ids:
  - ftbic:canning_machine
  - ftbic:advanced_canning_machine
  - ftbic:empty_can
  - ftbic:canned_food
---

# <Color id="gold">Canning Machine</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="canning_machine" scale="2" />

  음식을 <ItemLink id="canned_food" />으로 포장해 효율적으로 보관하고, 스프레이 페인트 캔에 염료를 채우며, <ItemLink id="uranium_fuel_rod" /> 카트리지를 조립하는 기계입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="canning_machine" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="empty_can" />
  ### <Color id="aqua">Empty Can</Color>
</Row>

Tin Plate를 찍어 만든 캔입니다. 모든 통조림 제작법에 사용하는 용기입니다.

<RecipeFor id="empty_can" />

<Row>
  <ItemImage id="canned_food" />
  ### <Color id="aqua">Canned Food</Color>
</Row>

음식 아이템과 Empty Can을 사용합니다. 통조림은 더 많이 겹쳐 쌓을 수 있으며 원래 음식의 영양 수치를 그대로 유지합니다.
통조림을 먹으면 Empty Can을 돌려받습니다.

<Row>
  <ItemImage id="light_spray_paint_can" />
  ### <Color id="aqua">Spray Paint Cans</Color>
</Row>

<ItemLink id="empty_can" />에 염료를 채워 <ItemLink id="light_spray_paint_can" /> 또는 <ItemLink id="dark_spray_paint_can" />을 만듭니다. [스프레이 페인트](../utilities/spray_paint.md)를 참고하세요.

<ItemImage id="minecraft:air" scale="0.25"/>

**성능:** LV 등급, 에너지 저장량 <Energy config="machines.canning_machine_capacity" />, 소비량 <Energy config="machines.canning_machine_use" rate="true" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_canning_machine" />
  ### <Color id="aqua">Advanced Canning Machine</Color>
</Row>

MV 등급입니다. 소비량 <Energy config="machines.advanced_canning_machine_use" rate="true" />, 에너지 저장량 <Energy config="machines.advanced_canning_machine_capacity" />입니다. 제작법과 속도는 동일하지만 <ItemLink id="parallel_processing_upgrade" />를 장착할 수 있습니다.

<RecipeFor id="advanced_canning_machine" />
