---
navigation:
  title: Compressor
  icon: ftbic:compressor
  parent: machines/index.md
  position: 4
item_ids:
  - ftbic:compressor
  - ftbic:advanced_compressor
  - ftbic:protein_bar
---

# <Color id="gold">Compressor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="compressor" scale="2" />

  재료를 압축해 밀도가 높은 형태로 만듭니다. Carbon은 <ItemLink id="carbon_plate" />로, Copper Plate는 <ItemLink id="dense_copper_plate" />로, Snowball은 Ice로, Dust 묶음은 보석으로 가공할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="compressor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">주요 압축 제작법</Color>
</Column>

* <ItemLink id="carbon_fibers" /> → <ItemLink id="carbon_plate" />
* Copper Plate 9개 → <ItemLink id="dense_copper_plate" /> (<ItemLink id="nuclear_reactor" /> 제작에 사용)
* <ItemLink id="industrial_grade_metal" /> 제작 (<ItemLink id="mixed_metal_blend" /> 사용)
* Snowball → Ice
* Diamond Dust → Diamond
* <ItemLink id="compressed_coal_ball" /> (Diamond 재활용 공정의 5분짜리 단계)
* Beef → <ItemLink id="protein_bar" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_compressor" />
  ### <Color id="aqua">Advanced Compressor</Color>
</Row>

MV 등급입니다. 소비량 <Energy config="machines.advanced_compressor_use" rate="true" />, 에너지 저장량 <Energy config="machines.advanced_compressor_capacity" />입니다. 제작법과 속도는 동일하며 <ItemLink id="parallel_processing_upgrade" />를 장착할 수 있습니다.

<RecipeFor id="advanced_compressor" />
