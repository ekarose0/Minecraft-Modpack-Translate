---
navigation:
  title: Macerator
  icon: ftbic:macerator
  parent: machines/index.md
  position: 3
item_ids:
  - ftbic:macerator
  - ftbic:advanced_macerator
---

# <Color id="gold">Macerator</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="macerator" scale="2" />

  [광석 정제 공정](ore_refining.md)의 시작 단계입니다. 지원되는 Ore Block 1개는 **Raw Ore 3개**, Raw Ore 1개는 **Crushed Ore 2개**, Raw Ore Block 1개는 **Crushed Ore 18개**로 가공합니다. Ingot을 Dust로, Cobblestone을 Sand로 분쇄할 수도 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="macerator" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">중요한 이유</Color>
</Column>

* 지원되는 Ore Block 1개 → **Raw Ore 3개** → **Crushed Ore 6개**. 세척과 원심분리를 거치면 **Ingot 15개**를 얻습니다.
* Ingot → Dust 1개 (재활용 또는 추가 가공용)
* Cobblestone → Sand, Gravel → Flint 등

<RecipesFor id="ftbic:coal_dust" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_macerator" />
  ### <Color id="aqua">Advanced Macerator</Color>
</Row>

MV 등급의 고급형입니다. 에너지 저장량 <Energy config="machines.advanced_macerator_capacity" />, 소비량 <Energy config="machines.advanced_macerator_use" rate="true" />입니다. 제작법 처리 속도는 같지만 <ItemLink id="parallel_processing_upgrade" />를 장착할 수 있습니다.

<RecipeFor id="advanced_macerator" />
