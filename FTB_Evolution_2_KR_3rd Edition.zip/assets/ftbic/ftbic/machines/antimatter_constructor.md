---
navigation:
  title: Antimatter Constructor
  icon: ftbic:antimatter_constructor
  parent: machines/index.md
  position: 13
item_ids:
  - ftbic:antimatter_constructor
  - ftbic:antimatter
  - ftbic:antimatter_crystal
---

# <Color id="gold">Antimatter Constructor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="antimatter_constructor" scale="2" />

  최종 단계의 기계입니다. <ItemLink id="antimatter" />와 <ItemLink id="antimatter_crystal" />을 생산하며, 이 재료들은 <ItemLink id="quantum_helmet" /><ZapMode>과 <ItemLink id="iv_rectifier" /> 계열</ZapMode>의 제작에 사용됩니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="antimatter_constructor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">작동 방식</Color>
</Column>

* **등급:** IV
* **에너지 저장량:** <Energy config="machines.antimatter_constructor_capacity" />
* 원시 에너지로부터 Antimatter 연료를 천천히 축적합니다. 지속적인 IV 등급 전력 공급이 필요하므로 Nuclear Reactor나 여러 대의 <ItemLink id="ev_solar_panel" />을 준비하세요.
* 일시적으로 출력을 배가하는 "Boost" 아이템을 받을 수 있습니다(`antimatter_boost` 제작법 참고).

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="antimatter_crystal" />
  ### <Color id="aqua">Antimatter Crystal</Color>
</Row>

압축된 Antimatter의 보석 형태로, 후반 제작법에 직접 사용합니다.

<RecipeFor id="antimatter_crystal" />
