---
navigation:
  title: Centrifuge
  icon: ftbic:centrifuge
  parent: machines/index.md
  position: 7
item_ids:
  - ftbic:centrifuge
  - ftbic:advanced_centrifuge
---

# <Color id="gold">Centrifuge</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="centrifuge" scale="2" />

  재료를 구성 성분으로 분리합니다. Quartz나 Sand에서 <ItemLink id="ftbic:silicon_gem" />을 추출하고, Gravel과 Flint를 가공하며, Slime과 Magma 재료도 처리합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="centrifuge" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">주요 분리 제작법</Color>
</Column>

* Quartz 또는 Sand → <ItemLink id="ftbic:silicon_gem" />
* Gravel → Flint
* Glowstone → Glowstone Dust
* Magma Cream → Slime Ball (Blaze Powder가 추가로 나올 확률 있음)
* Blaze Rod와 Ice를 사용한 Small Coolant Cell 제작

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_centrifuge" />
  ### <Color id="aqua">Advanced Centrifuge</Color>
</Row>

MV 등급입니다. 소비량 <Energy config="machines.advanced_centrifuge_use" rate="true" />, 에너지 저장량 <Energy config="machines.advanced_centrifuge_capacity" />으로 같은 속도의 분리 제작법을 처리합니다. **아이템 출력 슬롯 3개**와 **유체 출력 탱크 1개**가 있습니다. 아이템 결과물이 세 종류인 제작법에는 이 기계가 필요합니다.

<RecipeFor id="advanced_centrifuge" />

## 유체 처리

두 Centrifuge 모두 왼쪽에 **16,000 mB 입력 탱크**, 오른쪽에 별도의 **16,000 mB 출력 탱크**가 있습니다. 각 탱크에는 한 번에 한 종류의 유체만 담을 수 있습니다.

분리 제작법은 아이템, 유체 또는 둘 다를 입력으로 사용하고, 아이템, 유체 또는 둘 다를 출력할 수 있습니다. 일반 Centrifuge의 아이템 출력 슬롯은 2개이고 Advanced Centrifuge는 3개입니다. 두 기계 모두 아이템 재료 1종과 유체 재료 1종을 받으며, 제작법당 유체 결과물은 최대 1종입니다.

유체 파이프를 연결하거나 Bucket 또는 Fluid Cell을 기계에 사용해 유체를 옮기세요. 용기는 출력 탱크에서 유체를 채우거나 입력 탱크에 유체를 비울 수 있습니다. [I/O 설정](side_configuration.md)의 유체 탭에서 각 면을 **Input**, **Output**, **Input/Output**으로 지정하세요. 탱크에 마우스를 올리면 유체 종류와 양이 표시됩니다.

필요한 입력 재료가 모두 준비되고 아이템·유체 출력 공간이 충분할 때만 가공합니다. 출력 탱크가 가득 찼거나 다른 유체가 들어 있으면 작업이 중단됩니다. 아이템만 사용하는 기존 제작법은 탱크가 비어 있어도 작동합니다.

**Advanced Centrifuge**는 **Lava 1,000 mB**(Bucket 1개)를 분리하여 **<ItemLink id="ftbic:tin_nugget" /> 2개**, **<ItemLink id="minecraft:copper_nugget" /> 1개**, **<ItemLink id="minecraft:gold_nugget" /> 1개를 얻을 25% 확률**을 제공합니다. 아이템 입력은 필요하지 않습니다. Tin Nugget 9개로 Tin Ingot 1개를 만들거나, 주괴 1개를 Nugget 9개로 분해할 수 있습니다.

## 광석 정제

**Washed Ore 3개를 Refined Concentrate 5개**로 가공한 뒤 각각 제련하면 주괴 5개를 얻습니다. 전체 공정과 자동화는 [광석 정제](ore_refining.md)를 참고하세요.
