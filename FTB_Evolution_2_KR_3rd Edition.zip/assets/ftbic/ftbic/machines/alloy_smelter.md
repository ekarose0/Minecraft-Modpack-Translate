---
navigation:
  title: Alloy Smelter
  icon: ftbic:alloy_smelter
  parent: machines/index.md
  position: 14
item_ids:
  - ftbic:alloy_smelter
---

# <Color id="gold">Alloy Smelter</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="alloy_smelter" scale="2" />

  재료를 최대 3종까지 넣는 합금 기계입니다. Dust나 중간 가공품을 만들지 않고도 주괴를 조합하여 Bronze, Electrum, Invar, Constantan, Steel, Enderium, Netherite, Advanced Alloy 같은 합금을 생산합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="alloy_smelter" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">슬롯 구성과 재료 중복 제한</Color>
</Column>

Alloy Smelter에는 **입력 슬롯 3개**와 **출력 슬롯 1개**가 있습니다. 입력 슬롯 하나에는 같은 종류의 재료를 원하는 수량만큼 넣을 수 있습니다. 제작법의 수량은 여러 슬롯의 합계가 아니라 해당 슬롯에 쌓인 개수를 기준으로 판정합니다.

슬롯에는 **동일한 아이템 중복 배치 제한**이 있습니다. 한 슬롯에 넣은 아이템은 다른 두 슬롯에 넣을 수 없습니다. `Gold 2개`가 한 슬롯에 있어야 하는 제작법에서 재료를 여러 슬롯으로 나누는 실수를 막기 위한 규칙입니다. Gold Ingot 4개는 1번 슬롯에 모두 넣어야 하며, 1번에 2개와 2번에 2개로 나눠 넣을 수 없습니다.

입력 재료가 여러 제작법에 해당하면 **재료 종류가 가장 많은 제작법**을 우선합니다. 세 슬롯을 모두 채우면 두 종류만 사용하는 제작법보다 세 종류를 사용하는 합금 제작법이 우선됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">합금 제작법</Color>
</Column>

<Row>
  <ItemImage id="bronze_ingot" />
  ### <Color id="aqua">Bronze</Color>
</Row>

Copper 3개 + Tin 1개 → Bronze Ingot 4개.

<Row>
  <ItemImage id="electrum_ingot" />
  ### <Color id="aqua">Electrum</Color>
</Row>

Silver 1개 + Gold 1개 → Electrum Ingot 2개.

<Row>
  <ItemImage id="invar_ingot" />
  ### <Color id="aqua">Invar</Color>
</Row>

Iron 2개 + Nickel 1개 → Invar Ingot 3개.

<Row>
  <ItemImage id="constantan_ingot" />
  ### <Color id="aqua">Constantan</Color>
</Row>

Copper 1개 + Nickel 1개 → Constantan Ingot 2개.

<Row>
  <ItemImage id="steel_ingot" />
  ### <Color id="aqua">Steel</Color>
</Row>

<ItemLink id="industrial_grade_metal" /> 1개 + Coal 1개 **또는** Charcoal 1개 → Steel Ingot 1개. Steel은 Advanced Alloy 제작의 핵심 재료입니다. 아래 <ItemLink id="advanced_alloy" /> 제작법을 참고하세요.

<Row>
  <ItemImage id="minecraft:netherite_ingot" />
  ### <Color id="aqua">Netherite</Color>
</Row>

Gold 2개 + Netherite Scrap 2개 → Netherite Ingot 1개. 바닐라의 Diamond 장비와 Netherite Ingot을 사용하는 대장장이 업그레이드 단계를 거치지 않고 주괴를 생산합니다.

<Row>
  <ItemImage id="enderium_ingot" />
  ### <Color id="aqua">Enderium</Color>
</Row>

Lead 3개 + Diamond Dust 1개 + Ender Pearl 2개 → Enderium Ingot 2개. Enderium Ingot을 만드는 유일한 방법이며, 일반 제작대 조합법은 없습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Advanced Alloy</Color>
</Column>

Alloy Smelter는 Steel을 사용하는 세 가지 제작법으로 <ItemLink id="advanced_alloy" />를 생산합니다. **모든 제작법에 Steel이 필요합니다.** 먼저 Industrial Grade Metal과 Coal 또는 Charcoal을 합금해 Steel을 만드세요.

* Steel 1개 + Bronze 2개 + Aluminum 1개 → Advanced Alloy 1개
* Steel 1개 + Electrum 1개 + Aluminum 1개 → Advanced Alloy 1개
* Steel 1개 + Invar 2개 + Aluminum 1개 → Advanced Alloy 1개

<RecipesFor id="advanced_alloy" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">성능</Color>
</Column>

* **등급:** MV (중전압 입력)
* **에너지 저장량:** <Energy config="machines.alloy_smelter_capacity" />
* **에너지 소비량:** <Energy config="machines.alloy_smelter_use" rate="true" /> (<ItemLink id="advanced_powered_furnace" />의 3배)
* **기본 처리 시간:** 제작법당 200틱 (<ItemLink id="overclocker_upgrade" />로 변경 가능)

<ItemImage id="minecraft:air" scale="0.25"/>
