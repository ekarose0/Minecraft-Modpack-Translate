---
navigation:
  title: Extruder
  icon: ftbic:extruder
  parent: machines/index.md
  position: 5
item_ids:
  - ftbic:extruder
  - ftbic:advanced_extruder
---

# <Color id="gold">Extruder</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="extruder" scale="2" />

  금속을 **Ingot**, **Plate**, **Rod** 형태로 가공합니다. 제작에 필요한 주괴·판·막대를 대량 생산하는 공정의 중심 기계입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="extruder" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">제작법 종류</Color>
</Column>

Extruder는 제작법에 따라 다음 세 가지 출력 방식으로 가공합니다.

* **Ingot:** Dust 2개 → Ingot 1개
* **Plate:** Ingot 1개 → Plate 1개
* **Rod:** Ingot 1개 → Rod 2개

설정에서 비활성화하지 않았다면 FTB Materials에 등록된 모든 금속에 세 가지 제작법이 있습니다. Gear, Wire, 기계 부품 제작에 쓰는 Plate와 Rod도 대부분 이 기계에서 생산합니다.

<ItemImage id="minecraft:air" scale="0.25"/>

**성능:** LV 등급, 에너지 저장량 <Energy config="machines.extruder_capacity" />, 소비량 <Energy config="machines.extruder_use" rate="true" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_extruder" />
  ### <Color id="aqua">Advanced Extruder</Color>
</Row>

MV 등급입니다. 소비량 <Energy config="machines.advanced_extruder_use" rate="true" />, 에너지 저장량 <Energy config="machines.advanced_extruder_capacity" />입니다. 제작법과 속도는 동일하며 <ItemLink id="parallel_processing_upgrade" />를 장착할 수 있습니다.

<RecipeFor id="advanced_extruder" />
