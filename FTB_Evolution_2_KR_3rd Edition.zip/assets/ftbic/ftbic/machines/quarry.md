---
navigation:
  title: Quarry
  icon: ftbic:quarry
  parent: machines/index.md
  position: 12
item_ids:
  - ftbic:quarry
  - ftbic:landmark
---

# <Color id="gold">Quarry</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quarry" scale="2" />

  <ItemLink id="landmark" /> 기둥 두 개로 지정한 직사각형 영역을 채굴합니다. 채굴한 아이템은 내부 인벤토리에 저장되며 Hopper나 Ejector로 꺼낼 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="quarry" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">설치 방법</Color>
</Column>

1. 채굴할 영역의 서로 마주 보는 모서리에 <ItemLink id="landmark" /> 기둥 두 개를 설치합니다.
2. 한쪽 Landmark에 인접하게 Quarry를 설치합니다.
3. HV 전력을 공급하면 아래쪽으로 채굴을 시작합니다.
4. 블록 하나를 채굴하는 데 8틱, 채굴 헤드를 한 칸 이동하는 데 2틱이 걸립니다. 유체는 누출 방지를 위해 <ItemLink id="exfluid" />로 대체됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>

**성능:** HV 등급, 에너지 저장량 <Energy config="machines.quarry_capacity" />, 소비량 <Energy config="machines.quarry_use" rate="true" />.

Quarry는 고급형이 없는 몇 안 되는 기계입니다. 대신 <ItemLink id="overclocker_upgrade" />를 장착해 채굴 속도를 높이세요.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">곡괭이 슬롯</Color>
</Column>

Quarry에는 일시정지 버튼과 배터리 슬롯 사이에 곡괭이 슬롯이 있습니다. `#minecraft:pickaxes` 태그가 있는 아이템을 넣을 수 있습니다. 곡괭이를 장착하면 해당 도구로 블록을 채굴한 것처럼 처리하므로 곡괭이의 모든 마법부여가 채굴 결과물에 적용됩니다.

- **Silk Touch**가 붙은 <ItemLink id="minecraft:diamond_pickaxe" />는 Stone, Raw Ore, Glass, Spawner 등을 원형 그대로 채굴합니다.
- **Fortune III**가 붙은 <ItemLink id="minecraft:diamond_pickaxe" />는 플레이어가 직접 채굴했을 때와 같은 방식으로 보석, Redstone, Lapis의 드롭 수량을 늘립니다.
- **Efficiency**는 레벨당 채굴 속도를 10% 높이며, <ItemLink id="overclocker_upgrade" /> 효과와 곱연산으로 중첩됩니다. Efficiency V는 틱당 전력 소비량을 유지하면서 Quarry를 1.5배 빠르게 만들어 블록당 에너지 소비량을 약 1/3 줄입니다.
- Unbreaking 같은 다른 마법부여는 효과가 없습니다. Quarry는 도구 내구도에 의존하지 않습니다.

기본 설정에서는 곡괭이 내구도가 감소하지 않습니다. 바닐라처럼 블록을 하나 채굴할 때마다 내구도 1을 소모하려면 `ftbic-common.toml`에서 `quarry_pickaxe_takes_damage = true`로 설정하세요. 곡괭이가 부서지면 슬롯이 비워지고 도구를 사용하지 않는 기본 드롭 방식으로 돌아갑니다.

## 선택적 채굴

<ItemLink id="quarry_filter_upgrade" />를 장착하면 Quarry가 선택한 블록만 채굴하도록 설정할 수 있습니다. Quarry 화면 옆의 **F** 버튼을 눌러 설정하세요.

* 블록 슬롯 9개에서 설치된 블록 종류를 선택합니다. 커서에 블록을 든 채 슬롯을 클릭하거나 JEI에서 블록을 끌어다 놓으세요. 우클릭 또는 Shift+클릭하면 설정이 지워집니다.
* `c:ores/iron`처럼 **블록 태그** ID를 최대 3개 입력한 뒤 Enter를 누르세요. Quarry는 채굴하기 전에 블록을 검사하므로 아이템 태그가 아닌 블록 태그를 사용해야 합니다.
* **Whitelist**는 일치하는 블록만 채굴하고 **Blacklist**는 일치하는 블록을 제외합니다. 등록된 항목이 없으면 두 모드 모두 블록 종류를 제한하지 않습니다.
* **Ore-only**는 `#c:ores`에 속한 블록만 채굴합니다. 선택한 모드와 등록 항목 조건이 함께 적용됩니다.

필터는 월드에 설치된 블록을 기준으로 작동하므로 Silk Touch나 Fortune 곡괭이를 사용해도 어떤 블록이 조건에 일치하는지는 바뀌지 않습니다. Quarry는 원하지 않는 Stone을 부수지 않고 그 아래의 대상 Ore를 찾습니다. 일치하는 블록이 없는 세로줄은 에너지를 사용하지 않고 건너뜁니다. 전체 영역을 검사해도 일치하는 블록이 없으면 일시정지합니다. 규칙을 추가하거나 변경한 뒤 일시정지를 해제하면 다시 탐색합니다.

Quarry Filter Upgrade는 Quarry 한 대당 하나만 장착할 수 있습니다. 업그레이드를 제거해도 필터 설정은 저장되지만 장착한 동안에만 필터가 적용됩니다. Configuration Card로 설정을 다른 Quarry에 복사할 수 있으나, 대상 Quarry에도 별도의 업그레이드가 필요합니다.

<RecipeFor id="quarry_filter_upgrade" />
