---
navigation:
  title: Hydroponic Accelerator
  icon: ftbic:hydroponic_accelerator
  parent: machines/index.md
  position: 5
item_ids:
  - ftbic:hydroponic_accelerator
  - ftbic:advanced_hydroponic_accelerator
---

# Hydroponic Accelerator

<ItemImage id="hydroponic_accelerator" scale="2" float="right"/>

<RecipeFor id="hydroponic_accelerator" />

**Seed** 슬롯에 씨앗을 넣고 **Soil** 슬롯에 허용된 블록을 넣으세요. 흙은 기계 안에 남으며 소모되지 않습니다. 물과 전력을 공급하면 작물이 자랍니다. 제작법에서 씨앗을 반환하는 경우 씨앗은 Seed 슬롯에 남아 계속 재배되고, 여분의 씨앗만 출력되므로 씨앗 하나로 무기한 가동할 수 있습니다. 출력 슬롯에는 수확물, 반환된 씨앗, 선택적인 부산물이 각각 분리되어 보관됩니다. 기본 Wheat 제작법은 Dirt에서 보통 속도로, Moss에서 **1.25배 속도**로 작동합니다. JEI에서 제작법별 Soil 종류와 성장 속도를 확인할 수 있습니다.

기본 기계에는 재배용 Seed·Soil 슬롯 한 쌍과 출력 슬롯 3개가 있습니다. 물탱크 용량은 16,000 mB이며, 기본 재배 1회에 물 250 mB를 소비합니다. **I/O**에서 아이템·유체·에너지 입출력 면을 설정하세요. **L** 버튼으로 Seed와 Soil 슬롯을 정확한 아이템으로 잠글 수 있으며, JEI에서 아이템을 끌어다 놓아 가상 잠금을 지정할 수도 있습니다. 가상 잠금은 필터일 뿐 재료를 공급하지 않습니다.

## 돌연변이 모드

Advanced Hydroponic Accelerator만 **Growth**와 **Mutation** 모드를 전환할 수 있습니다. 교배할 두 구역에 부모 씨앗을 각각 하나씩 넣으세요. 각 부모는 해당 Soil에서 유효한 성장 제작법이 있어야 합니다. JEI에서 교배 조합과 성공 확률을 확인할 수 있습니다. 교배에 성공하면 부모 씨앗을 각각 1개 소비하고 표시된 돌연변이 아이템을 생산합니다. 실패하면 두 부모 씨앗을 돌려줍니다. 결과와 관계없이 시간·물·에너지를 소비하며, 가능한 결과물 중 하나라도 출력 공간이 부족하면 대기합니다.

## 고급 수경 재배 촉진기

<ItemImage id="advanced_hydroponic_accelerator" scale="2" float="right"/>

<RecipeFor id="advanced_hydroponic_accelerator" />

고급 기계에는 서로 독립된 **Seed·Soil 슬롯 4쌍**과 출력 슬롯 12개가 있습니다. 각 구역은 수확물·씨앗·부산물 출력 슬롯을 따로 사용합니다. 각 입력 쌍에 별도의 가상 잠금과 작물을 지정할 수 있습니다. 물탱크 용량은 32,000 mB입니다. 활성 구역마다 전력을 별도로 사용하므로 최대 단일 구역의 4배를 소비합니다. <ItemLink id="parallel_processing_upgrade" />도 지원하며, 장착하면 같은 재배 주기 동안 각 구역의 Seed 슬롯에 있는 씨앗 수만큼 최대 4개를 재배하고 그 배수만큼 물과 전력을 소비합니다.

Mutation 모드에서는 **1번+2번** 및 **3번+4번** 구역이 독립된 교배 조합 두 개를 이룹니다. 부모마다 별도의 Soil을 사용하며 더 느린 Soil이 교배 속도를 결정합니다. 실패한 부모 씨앗은 각각 해당 구역의 씨앗 출력 슬롯으로 돌아갑니다. 모드, 잠금, 진행 상태는 월드를 저장해도 유지됩니다.
