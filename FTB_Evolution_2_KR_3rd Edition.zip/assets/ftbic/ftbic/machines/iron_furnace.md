---
navigation:
  title: Iron Furnace
  icon: ftbic:iron_furnace
  parent: machines/index.md
  position: 1
item_ids:
  - ftbic:iron_furnace
---

# <Color id="gold">Iron Furnace</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iron_furnace" scale="2" />

  Coal 1개로 **아이템 12개**를 제련하는 비전기식 화로입니다. 바닐라보다 효율이 50% 높습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="iron_furnace" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* 바닐라 화로에서 사용하는 모든 연료를 사용할 수 있습니다.
* 전기를 사용하기 전의 과도기용 기계입니다. <ItemLink id="powered_furnace" />를 제작하면 Iron Furnace는 더 이상 필요하지 않습니다. 전력이나 별도의 진행 단계가 필요하지 않습니다.
* 업그레이드를 장착할 수 없습니다.

**JEI**에서 아이템을 입력 슬롯이나 연료 슬롯으로 끌어다 놓으면 유지되는 가상 필터를 설정할 수 있습니다. 가상 아이템은 실제 아이템을 생성하지 않습니다. 커서가 비었을 때 빈 가상 아이템을 우클릭하거나, 잠긴 슬롯에 아이템이 들어 있을 때 Shift+우클릭하면 필터가 제거됩니다. 아이템 데이터까지 일치해야 하며 Hopper로 넣는 아이템에도 필터가 적용됩니다.
