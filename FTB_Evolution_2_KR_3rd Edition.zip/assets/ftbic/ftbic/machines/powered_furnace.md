---
navigation:
  title: Powered Furnace
  icon: ftbic:powered_furnace
  parent: machines/index.md
  position: 2
item_ids:
  - ftbic:powered_furnace
  - ftbic:advanced_powered_furnace
---

# <Color id="gold">Powered Furnace</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="powered_furnace" scale="2" />

  바닐라의 모든 제련 제작법을 처리하는 전기 화로입니다. 소비량 <Energy config="machines.powered_furnace_use" rate="true" />, 에너지 저장량 <Energy config="machines.powered_furnace_capacity" />, LV 등급입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="powered_furnace" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_powered_furnace" />
  ### <Color id="aqua">Advanced Powered Furnace</Color>
</Row>

MV 등급의 고급형입니다. 에너지 저장량 <Energy config="machines.advanced_powered_furnace_capacity" />, 소비량 <Energy config="machines.advanced_powered_furnace_use" rate="true" />입니다. 제작법과 속도는 동일하며 <ItemLink id="parallel_processing_upgrade" />를 장착할 수 있습니다.

<RecipeFor id="advanced_powered_furnace" />

바닐라의 모든 제련 제작법과 모드에서 추가한 제련 제작법을 지원합니다. <ItemLink id="overclocker_upgrade" />로 처리량을 더 높일 수 있습니다.
