---
navigation:
  title: Mechanical Elytra
  icon: ftbic:mechanical_elytra
  parent: armor/index.md
  position: 3
item_ids:
  - ftbic:mechanical_elytra
---

# <Color id="gold">Mechanical Elytra</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="mechanical_elytra" scale="2" />

  Iron Chestplate 수준의 방어력과 전용 날개 텍스처를 가진 전력식 Elytra입니다. 낮에 하늘이 트인 곳에서 자동으로 충전되며, 에너지가 남아 있으면 활공할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="mechanical_elytra" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* 용량: **<Energy config="equipment.mechanical_elytra_capacity" />**.
* 자동 충전 속도: 낮에 하늘이 트인 곳에서 착용하고 있을 때 <Energy config="equipment.mechanical_elytra_recharge" rate="true" />입니다. 활공 중에는 충전되지 않습니다. 완전히 방전된 상태에서 충전하려면 약 40분이 걸립니다.
* <ItemLink id="charge_pad" /> 또는 Battery Box에서도 충전할 수 있습니다.
* Chestplate 슬롯을 사용하므로 전력 갑옷의 Chestplate와 동시에 착용할 수 없습니다. 활공 중 웅크리기 키를 누르면 감속합니다.
