---
navigation:
  title: Carbon Armor
  icon: ftbic:carbon_chestplate
  parent: armor/index.md
  position: 1
item_ids:
  - ftbic:carbon_helmet
  - ftbic:carbon_chestplate
  - ftbic:carbon_leggings
  - ftbic:carbon_boots
---

# <Color id="gold">Carbon Armor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="carbon_chestplate" scale="2" />

  초반에 사용하는 전력 갑옷 세트입니다. 내구도를 소모하는 대신 흡수한 피해 1당 <Energy config="equipment.armor_damage_energy" />를 소비합니다. Chestplate의 에너지 용량은 **<Energy config="equipment.carbon_armor_capacity" />**입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="carbon_helmet" />
  ### <Color id="aqua">Carbon Helmet</Color>
</Row>

<RecipeFor id="carbon_helmet" />

<Row>
  <ItemImage id="carbon_chestplate" />
  ### <Color id="aqua">Carbon Chestplate</Color>
</Row>

세트 전체에서 사용하는 에너지를 저장합니다.

<RecipeFor id="carbon_chestplate" />

<Row>
  <ItemImage id="carbon_leggings" />
  ### <Color id="aqua">Carbon Leggings</Color>
</Row>

<RecipeFor id="carbon_leggings" />

<Row>
  <ItemImage id="carbon_boots" />
  ### <Color id="aqua">Carbon Boots</Color>
</Row>

<RecipeFor id="carbon_boots" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

충전된 Chestplate가 없으면 다른 부위는 방어 효과를 제공하지 않습니다. 잔여 에너지가 적으면 해당 에너지로 감당할 수 있는 피해만 흡수합니다.
