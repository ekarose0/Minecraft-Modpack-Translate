---
navigation:
  title: 전력 갑옷
  icon: ftbic:quantum_chestplate
  position: 50
---

# <Color id="gold">전력 갑옷</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quantum_chestplate" scale="2" />

  FTBIC 갑옷은 **<EnergyUnit />**를 소비하여 피해를 흡수하고 비행합니다. 세트 전체의 에너지는 Chestplate에 저장됩니다. 장비 내구도는 감소하지 않지만, 해당 Chestplate가 없거나 에너지가 바닥나면 방어 효과가 사라집니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">충전</Color>
</Column>

Chestplate를 착용한 채 전력이 공급되는 <ItemLink id="charge_pad" /> 위에 서거나, Charge Pad의 충전 슬롯 4개 중 하나에 Chestplate를 넣으세요. 다른 갑옷 부위에는 에너지가 저장되지 않습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
