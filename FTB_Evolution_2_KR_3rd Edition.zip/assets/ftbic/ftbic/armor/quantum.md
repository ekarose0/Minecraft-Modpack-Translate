---
navigation:
  title: Quantum Armor
  icon: ftbic:quantum_chestplate
  parent: armor/index.md
  position: 2
item_ids:
  - ftbic:quantum_helmet
  - ftbic:quantum_chestplate
  - ftbic:quantum_leggings
  - ftbic:quantum_boots
---

# <Color id="gold">Quantum Armor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quantum_chestplate" scale="2" />

  최종 단계의 전력 갑옷입니다. Carbon Armor와 같은 방식으로 피해를 막지만, **<Energy config="equipment.quantum_armor_capacity" />**의 에너지 저장량과 비행 기능을 갖추고 EV 등급의 충전 속도로 피해를 완전히 흡수할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="quantum_helmet" />
  ### <Color id="aqua">Quantum Helmet</Color>
</Row>

<RecipeFor id="quantum_helmet" />

<Row>
  <ItemImage id="quantum_chestplate" />
  ### <Color id="aqua">Quantum Chestplate</Color>
</Row>

세트 전체의 에너지를 저장합니다. 충전된 상태에서 점프 키를 두 번 누르면 공중에 떠서 비행할 수 있습니다. 체공 시 <Energy config="equipment.armor_flight_energy" rate="true" />를 소비합니다. Chestplate는 활공도 지원하며, 활공 중 점프 키를 누르면 가속하고 웅크리기 키를 누르면 감속합니다.

<RecipeFor id="quantum_chestplate" />

<Row>
  <ItemImage id="quantum_leggings" />
  ### <Color id="aqua">Quantum Leggings</Color>
</Row>

<RecipeFor id="quantum_leggings" />

<Row>
  <ItemImage id="quantum_boots" />
  ### <Color id="aqua">Quantum Boots</Color>
</Row>

<RecipeFor id="quantum_boots" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* Chestplate는 체공하거나 활공할 때 <Energy config="equipment.armor_flight_energy" rate="true" />를 소비합니다. 활공 중 가속과 감속에는 추가 에너지가 필요합니다.
* 피해를 흡수할 때는 저장된 에너지만 소비합니다. 장비 내구도는 감소하지 않지만, Chestplate의 에너지가 없으면 방어 효과도 없습니다.
* <ItemLink id="charge_pad" />를 <ItemLink id="ev_battery_box" /> 위에 설치하면 그 위에 서는 것만으로 세트 전체를 빠르게 충전할 수 있습니다.
