---
navigation:
  title: 시작하기
  icon: ftbic:iron_furnace
  parent: index.md
  position: 1
---

# <Color id="gold">시작하기</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iron_furnace" scale="2" />

  FTB Industrial Contraptions를 시작하려면 Rubber, Copper, 그리고 첫 Machine Block부터 준비해야 합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">1단계: Rubber</Color>
</Column>

Slime을 사냥하거나 Slime 농장을 만든 다음, Slime Ball을 **제련**하면 개당 **Rubber 8개**를 얻습니다. Slime Ball 몇 개만 있어도 초반에 필요한 케이블을 충분히 제작할 수 있습니다.

Rubber는 이 모드의 거의 모든 케이블과 기계 제작에 사용됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">2단계: Iron Furnace</Color>
</Column>

전기를 사용하기 전에는 연료로 작동하는 업그레이드 화로를 사용하여 바닐라보다 효율적으로 제련할 수 있습니다.

<Row>
  <ItemImage id="iron_furnace" />
  ### <Color id="aqua">Iron Furnace</Color>
</Row>

<RecipeFor id="iron_furnace" />

Coal 1개로 **아이템 12개**를 제련합니다(바닐라는 8개). Copper와 Tin을 모으는 동안 사용하기 좋은 첫 기계입니다.

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">3단계: 회로와 Machine Block</Color>
</Column>

<Row>
  <ItemImage id="machine_block" />
  ### <Color id="aqua">Machine Block</Color>
</Row>

모든 LV 등급 기계의 제작법에 들어가는 기본 외장 부품입니다.

<RecipeFor id="machine_block" />

<Row>
  <ItemImage id="electronic_circuit" />
  ### <Color id="aqua">Electronic Circuit</Color>
</Row>

Iron Plate에 Copper Wire와 Redstone을 조합합니다. 거의 모든 LV 등급 장치에 필요합니다.

<RecipeFor id="electronic_circuit" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">4단계: 첫 전력 생산</Color>
</Column>

<ItemLink id="basic_generator" />를 만들고 <ItemLink id="lv_cable" />로 <ItemLink id="macerator" /> 또는 <ItemLink id="powered_furnace" />에 연결하면 전기를 사용할 준비가 끝납니다.

<RecipeFor id="basic_generator" />

지원되는 Raw Ore 1개를 분쇄하면 **Crushed Ore 2개**가 나오며, 이를 제련하면 주괴 2개를 얻습니다. [Ore Washer와 Centrifuge](machines/ore_refining.md)를 추가하면 **Raw Ore 1개당 주괴 5개**, **Ore Block 1개당 주괴 15개**까지 생산할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">진행 단계 한눈에 보기</Color>
</Column>

1. **LV**: Basic Generator, 초기 기계, Macerator, Powered Furnace
2. **MV**: Solar Panel, 광석 가공 라인(Dust → Plate/Gear/Rod)
3. **HV**: 고급 기계, Compressor, Extruder, Roller
4. **EV**: Nuclear Reactor, Quantum 장비, Teleporter
5. **IV / 최종 단계**: Antimatter, Mechanical Elytra, 완전 자동화

다음으로 [에너지 네트워크](energy/index.md) 문서를 읽어 **등급**, **전압**, 낮은 등급 케이블에 과도한 전력을 공급했을 때 발생하는 문제를 알아보세요.
