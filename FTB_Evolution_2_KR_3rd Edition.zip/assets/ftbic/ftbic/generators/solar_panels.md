---
navigation:
  title: Solar Panels
  icon: ftbic:hv_solar_panel
  parent: generators/index.md
  position: 3
item_ids:
  - ftbic:lv_solar_panel
  - ftbic:mv_solar_panel
  - ftbic:hv_solar_panel
  - ftbic:ev_solar_panel
---

# <Color id="gold">Solar Panels</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_solar_panel" scale="2" />

  Solar Panel은 발전하려면 **하늘이 직접 보여야** 하고 **낮**이어야 합니다. 밤이거나 위가 가려져 있으면 전력을 생산하지 않습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="lv_solar_panel" />
  ### <Color id="aqua">LV Solar Panel</Color>
</Row>

<Energy config="machines.lv_solar_panel_output" rate="true" />를 낮 동안 생산합니다. 저장량: <Energy config="machines.lv_solar_panel_capacity" times="60" />. 초반용 Solar Panel입니다.

<RecipeFor id="lv_solar_panel" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="mv_solar_panel" />
  ### <Color id="aqua">MV Solar Panel</Color>
</Row>

<Energy config="machines.mv_solar_panel_output" rate="true" />를 낮 동안 생산합니다. 저장량: <Energy config="machines.mv_solar_panel_capacity" times="60" />.

<RecipeFor id="mv_solar_panel" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="hv_solar_panel" />
  ### <Color id="aqua">HV Solar Panel</Color>
</Row>

<Energy config="machines.hv_solar_panel_output" rate="true" />를 낮 동안 생산합니다. 저장량: <Energy config="machines.hv_solar_panel_capacity" times="60" />.

<RecipeFor id="hv_solar_panel" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="ev_solar_panel" />
  ### <Color id="aqua">EV Solar Panel</Color>
</Row>

<Energy config="machines.ev_solar_panel_output" rate="true" />를 낮 동안 생산합니다. 저장량: <Energy config="machines.ev_solar_panel_capacity" times="60" />. 이 모드에서 가장 높은 Solar Panel 출력입니다.

<RecipeFor id="ev_solar_panel" />
