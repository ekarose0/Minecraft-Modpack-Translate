---
navigation:
  title: Geothermal Generator
  icon: ftbic:geothermal_generator
  parent: generators/index.md
  position: 2
item_ids:
  - ftbic:geothermal_generator
---

# <Color id="gold">Geothermal Generator</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="geothermal_generator" scale="2" />

  내부 8,000 mB 탱크에서 **Lava**를 소비하여 **<Energy config="machines.geothermal_generator_output" rate="true" />**를 생산합니다. Basic Generator보다 출력이 두 배이며, Nether Portal로 Lava를 공급하거나 근처 Lava Lake를 이용하면 재생 가능한 발전원으로 사용할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="geothermal_generator" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Lava 공급</Color>
</Column>

* Lava Bucket으로 블록을 우클릭하면 1,000 mB를 채웁니다.
* <ItemLink id="pump" />나 유체를 운반할 수 있는 Cable/Pipe로 Lava를 공급할 수도 있습니다.
* 내부 저장 공간에 여유가 있으면 틱당 Lava 1 mB를 소비하므로, Bucket 1개로 <Energy config="machines.geothermal_generator_output" times="1000" />를 생산합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">성능</Color>
</Column>

* **등급:** LV
* **내부 저장량:** <Energy config="machines.geothermal_generator_capacity" />
* **탱크:** 8,000 mB
* **출력:** <Energy config="machines.geothermal_generator_output" rate="true" />
