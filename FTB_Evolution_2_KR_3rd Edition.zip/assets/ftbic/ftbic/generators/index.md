---
navigation:
  title: 발전기
  icon: ftbic:basic_generator
  position: 20
---

# <Color id="gold">발전기</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="basic_generator" scale="2" />

  재생 가능한 발전기 4종, 연소식 발전기 1종, Nuclear Reactor를 통해 모드의 모든 발전 단계를 충당할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">출력 비교</Color>
</Column>

| 발전기 | 등급 | 출력 | 조건 |
|-----------|------|--------|-----------|
| <ItemLink id="basic_generator" /> | LV | <Energy config="machines.basic_generator_output" rate="true" /> | 연료가 연소하는 동안 |
| <ItemLink id="geothermal_generator" /> | LV | <Energy config="machines.geothermal_generator_output" rate="true" /> | 탱크에 Lava 필요 |
| <ItemLink id="wind_mill" /> | LV | <ZapMode>0.3~6.5 z/t</ZapMode><FEMode><Energy config="machines.wind_mill_min_output" rate="true" /> ~ <Energy config="machines.wind_mill_max_output" rate="true" /></FEMode> | 설치 높이에 따라 변동 |
| <ItemLink id="lv_solar_panel" /> | LV | <Energy config="machines.lv_solar_panel_output" rate="true" /> | 낮, 하늘 노출 |
| <ItemLink id="mv_solar_panel" /> | MV | <Energy config="machines.mv_solar_panel_output" rate="true" /> | 낮, 하늘 노출 |
| <ItemLink id="hv_solar_panel" /> | HV | <Energy config="machines.hv_solar_panel_output" rate="true" /> | 낮, 하늘 노출 |
| <ItemLink id="ev_solar_panel" /> | EV | <Energy config="machines.ev_solar_panel_output" rate="true" /> | 낮, 하늘 노출 |
| <ItemLink id="nuclear_reactor" /> | 최대 IV | <Energy zaps="1000" rate="true" /> 이상 | 배치 구조에 따라 변동 |

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
