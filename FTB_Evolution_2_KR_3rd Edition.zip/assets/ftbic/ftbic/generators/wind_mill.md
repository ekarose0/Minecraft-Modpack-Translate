---
navigation:
  title: Wind Mill
  icon: ftbic:wind_mill
  parent: generators/index.md
  position: 4
item_ids:
  - ftbic:wind_mill
---

# <Color id="gold">Wind Mill</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="wind_mill" scale="2" />

  설치 높이에 따라 출력이 변하는 발전기입니다. 해수면 근처에서는 **<ZapMode>0.3 z/t</ZapMode><FEMode><Energy config="machines.wind_mill_min_output" rate="true" /></FEMode>**, 건축 높이 제한 부근에서는 **<ZapMode>6.5 z/t</ZapMode><FEMode><Energy config="machines.wind_mill_max_output" rate="true" /></FEMode>**까지 생산합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="wind_mill" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">설치 조건</Color>
</Column>

* 유효 최소 높이는 **Y=64**입니다. 그보다 낮으면 발전하지 않습니다.
* 출력은 Y=64부터 **Y=319**까지 선형으로 증가합니다.
* 날개 주변에 빈 공간이 필요합니다. 벽이 바람의 흐름을 막습니다.
* **비**가 오면 출력이 1.2배가 됩니다.
* **뇌우**가 오면 출력이 1.5배가 됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

상시 전력을 보충하는 데 유용하며, 높은 건축물을 지을 이유가 됩니다. 산 위에 Wind Mill 10~20개를 기둥 형태로 설치하면 초반 MV 등급에 안정적인 전력을 공급할 수 있습니다.
