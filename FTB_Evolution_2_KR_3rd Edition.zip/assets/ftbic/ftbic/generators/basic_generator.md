---
navigation:
  title: Basic Generator
  icon: ftbic:basic_generator
  parent: generators/index.md
  position: 1
item_ids:
  - ftbic:basic_generator
---

# <Color id="gold">Basic Generator</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="basic_generator" scale="2" />

  첫 발전원입니다. 고체 연료를 태워 **<Energy config="machines.basic_generator_output" rate="true" />**를 생산하는 소형 화로형 엔진입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="basic_generator" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">성능</Color>
</Column>

* **등급:** LV (출력 <Energy config="machines.basic_generator_output" rate="true" />)
* **내부 저장량:** <Energy config="machines.basic_generator_capacity" />
* **연료 슬롯:** 1스택

유일한 인벤토리 슬롯에 연료를 넣으세요. Generator는 연료가 소진될 때까지 계속 연소합니다. 저장 공간이 가득 차도 **멈추지 않으므로**, 낭비를 피하려면 <ItemLink id="lv_battery_box" />에 바로 연결하는 것이 좋습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">사용 가능한 연료</Color>
</Column>

아래 연료만 사용할 수 있으며, 슬롯에는 다른 아이템이 들어가지 않습니다. Lava Bucket이나 Blaze Rod 같은 다른 화로 연료는 넣을 수 없습니다.

* Coal과 Charcoal: 1,600틱
* Coal Block: 16,000틱
* Log와 Plank: 300틱
* Sapling, Stick, Sugar Cane: 100틱
* Cactus: 200틱
* <ItemLink id="scrap" />: 400틱. 제작 비용에 비해 효율이 좋은 연료입니다.

<RecipesFor id="scrap" />
