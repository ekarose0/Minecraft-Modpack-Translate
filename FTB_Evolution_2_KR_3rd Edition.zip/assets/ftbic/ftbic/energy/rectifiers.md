---
navigation:
  title: 에너지 정류기
  icon: ftbic:mv_rectifier
  parent: energy/index.md
  position: 4
item_ids:
  - ftbic:lv_rectifier
  - ftbic:mv_rectifier
  - ftbic:hv_rectifier
  - ftbic:ev_rectifier
  - ftbic:iv_rectifier
---

# <Color id="gold">에너지 정류기</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_rectifier" scale="2" />

  FTBIC Cable과 Generator는 이미 FE를 받는 블록으로 **FE를 직접 공급**할 수 있습니다. 바닐라 Quarry, Mekanism 기계 또는 다른 FE 소비 모드를 가동하는 데 Rectifier가 필요하지 않습니다.

  <ZapMode>

  반대로 FE 발전원에서 FTBIC 기계나 네트워크로 전력을 **입력**하려면 Rectifier가 **필요합니다**. FTBIC 기계는 FE를 직접 받지 못하며, Rectifier가 들어온 FE를 zap으로 바꾸는 단방향 변환기 역할을 합니다.

  </ZapMode>

  <FEMode>

  **전체 FE 모드**가 활성화되어 Rectifier가 숨겨지고 제작할 수 없습니다. 모든 FTBIC 기계가 각 면에서 FE를 직접 받습니다. FE 입력은 기계의 입력 한도까지만 허용되며 과부하로 기계가 타지 않습니다.

  </FEMode>
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<ZapMode>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">작동 방식</Color>
</Column>

Rectifier는 방향이 정해진 장치입니다. **FE 면**은 인접한 FE 발전 케이블, Generator 또는 저장 블록에서 Forge Energy를 받습니다. 나머지 면은 변환한 전력을 zap 형태로 FTBIC 네트워크에 출력합니다.

기본 변환 비율은 **1 zap = 8 FE**이며 설정에서 바꿀 수 있습니다. 각 등급의 Rectifier는 해당 전압 등급의 전송량에 맞춰 변환합니다.

| 정류기 | zap 전송량 |
|-----------|----------|
| LV | <Energy config="energy.lv_transfer_rate" rate="true" /> |
| MV | <Energy config="energy.mv_transfer_rate" rate="true" /> |
| HV | <Energy config="energy.hv_transfer_rate" rate="true" /> |
| EV | <Energy config="energy.ev_transfer_rate" rate="true" /> |
| IV | <Energy config="energy.iv_transfer_rate" rate="true" /> |

FTBIC Generator로 **FE** 기계에만 전력을 공급하려면 Rectifier를 생략해도 됩니다. 모든 FTBIC Cable과 기계의 출력 면에서 FE를 직접 공급합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

</ZapMode>

<Row>
  <ItemImage id="lv_rectifier" />
  ### <Color id="aqua">LV Energy Rectifier</Color>
</Row>

<RecipeFor id="lv_rectifier" fallbackText="전체 FE 모드가 활성화되어 있으면 제작할 수 없습니다." />

<Row>
  <ItemImage id="mv_rectifier" />
  ### <Color id="aqua">MV Energy Rectifier</Color>
</Row>

<RecipeFor id="mv_rectifier" fallbackText="전체 FE 모드가 활성화되어 있으면 제작할 수 없습니다." />

<Row>
  <ItemImage id="hv_rectifier" />
  ### <Color id="aqua">HV Energy Rectifier</Color>
</Row>

<RecipeFor id="hv_rectifier" fallbackText="전체 FE 모드가 활성화되어 있으면 제작할 수 없습니다." />

<Row>
  <ItemImage id="ev_rectifier" />
  ### <Color id="aqua">EV Energy Rectifier</Color>
</Row>

<RecipeFor id="ev_rectifier" fallbackText="전체 FE 모드가 활성화되어 있으면 제작할 수 없습니다." />

<Row>
  <ItemImage id="iv_rectifier" />
  ### <Color id="aqua">IV Energy Rectifier</Color>
</Row>

<RecipeFor id="iv_rectifier" fallbackText="전체 FE 모드가 활성화되어 있으면 제작할 수 없습니다." />
