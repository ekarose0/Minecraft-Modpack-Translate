---
navigation:
  title: Charge Pad
  icon: ftbic:charge_pad
  parent: energy/index.md
  position: 5
item_ids:
  - ftbic:charge_pad
---

# <Color id="gold">Charge Pad</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="charge_pad" scale="2" />

  플레이어가 위에 서 있기만 하면 착용하거나 소지한 전력 아이템을 충전하는 평평한 블록입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="charge_pad" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">사용법</Color>
</Column>

* 어느 면으로든 전력을 연결할 수 있으며 최대 **IV** 등급의 입력을 받습니다.
* 내부 저장량: <Energy config="machines.charge_pad_capacity" />.
* 위에 서 있으면 착용 중인 갑옷(<ItemLink id="carbon_chestplate" />, <ItemLink id="quantum_chestplate" />, <ItemLink id="mechanical_elytra" />)과 인벤토리의 배터리를 충전합니다.
* Charge Pad 화면을 열면 Carbon 및 Quantum Chestplate를 포함해 최대 4개의 충전식 아이템을 넣어 충전할 수 있습니다.
* 위에 서서 충전하거나 슬롯의 아이템을 충전할 때 모두 내부 에너지 저장량을 사용합니다.

탐험을 마칠 때마다 빠르게 충전하려면 플레이어용 충전 지점에 <ItemLink id="ev_battery_box" />와 함께 설치하세요.
