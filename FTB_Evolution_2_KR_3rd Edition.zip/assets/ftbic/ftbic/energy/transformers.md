---
navigation:
  title: Transformers
  icon: ftbic:mv_transformer
  parent: energy/index.md
  position: 3
item_ids:
  - ftbic:lv_transformer
  - ftbic:mv_transformer
  - ftbic:hv_transformer
  - ftbic:ev_transformer
---

# <Color id="gold">Transformers</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="mv_transformer" scale="2" />

  Transformer는 높은 전압 등급을 낮은 등급으로 **강압**합니다. 승압은 할 수 없습니다. 각 Transformer에는 상위 등급 면 1개와 하위 등급 면 5개가 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

Transformer 없이 HV 전력을 LV 기계에 연결하면 즉시 타버립니다. Transformer는 N등급 전력을 바로 아래 등급의 전송량에 맞춰 나눠 공급합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="lv_transformer" />
  ### <Color id="aqua">LV Transformer</Color>
</Row>

MV(<Energy config="energy.mv_transfer_rate" rate="true" />)에서 LV(<Energy config="energy.lv_transfer_rate" rate="true" />)로 강압합니다.

<RecipeFor id="lv_transformer" />

<Row>
  <ItemImage id="mv_transformer" />
  ### <Color id="aqua">MV Transformer</Color>
</Row>

HV(<Energy config="energy.hv_transfer_rate" rate="true" />)에서 MV(<Energy config="energy.mv_transfer_rate" rate="true" />)로 강압합니다.

<RecipeFor id="mv_transformer" />

<Row>
  <ItemImage id="hv_transformer" />
  ### <Color id="aqua">HV Transformer</Color>
</Row>

EV(<Energy config="energy.ev_transfer_rate" rate="true" />)에서 HV(<Energy config="energy.hv_transfer_rate" rate="true" />)로 강압합니다.

<RecipeFor id="hv_transformer" />

<Row>
  <ItemImage id="ev_transformer" />
  ### <Color id="aqua">EV Transformer</Color>
</Row>

IV(<Energy config="energy.iv_transfer_rate" rate="true" />)에서 EV(<Energy config="energy.ev_transfer_rate" rate="true" />)로 강압합니다.

<RecipeFor id="ev_transformer" />
