---
navigation:
  title: Batteries & Battery Boxes
  icon: ftbic:hv_battery
  parent: energy/index.md
  position: 2
item_ids:
  - ftbic:single_use_battery
  - ftbic:lv_battery
  - ftbic:mv_battery
  - ftbic:hv_battery
  - ftbic:ev_battery
  - ftbic:creative_battery
  - ftbic:lv_battery_box
  - ftbic:mv_battery_box
  - ftbic:hv_battery_box
  - ftbic:ev_battery_box
  - ftbic:industrial_bank_cell
  - ftbic:industrial_bank_port
  - ftbic:energy_crystal
---

# <Color id="gold">Batteries & Battery Boxes</Color>

## <Color id="gold">산업용 배터리 뱅크</Color>

<ItemLink id="industrial_bank_cell" />과 <ItemLink id="industrial_bank_port" />를 서로 마주 보게 설치하면 하나의 배터리 뱅크가 형성됩니다. Cell을 추가할 때마다 저장 용량이 늘어나며, Port는 외부에 노출된 면으로 에너지를 받거나 공급합니다. 연결 지점이 더 필요하면 Port를 추가하세요. Cell이나 Port를 우클릭하면 충전량, 총용량, 구성 블록 수를 확인할 수 있습니다. Port 화면에는 뱅크에서 배터리와 기타 에너지 아이템을 충전하는 **충전** 슬롯 4개도 있습니다. Port의 측면 설정으로 입력과 출력 방향을 제한할 수 있습니다.

Cell 하나의 용량은 <Energy config="energy.bank_cell_capacity" />입니다. Port 하나는 최대 <Energy config="energy.bank_port_transfer" rate="true" />까지 자동 출력하고, 한 번의 입력 처리에서도 같은 양까지 받습니다. 들어온 에너지는 연결된 Cell로 이동하므로 Port는 계속 전력을 받을 수 있습니다. 두 값과 뱅크당 탐색할 최대 블록 수는 서버 설정으로 조절합니다. 뱅크를 분리해도 에너지는 각 Cell에 남으며, 다시 연결하면 통합된 충전량이 표시됩니다. 인접한 뱅크 외장은 하나로 이어진 모습으로 표시됩니다.

웅크린 채 Port를 우클릭하면 외형이 **Port**(기본 연결 표시), **Gauge**, **Basic**(Cell처럼 단순한 강철 외형) 순으로 바뀝니다. 이 설정은 Port마다 개별적으로 저장되며 월드를 다시 불러와도 유지됩니다. 외형을 바꿔도 에너지 입출력에는 영향을 주지 않습니다. 선택한 형태는 잠시 단축바 위에 표시됩니다.

Gauge는 빛나는 막대로 뱅크 전체의 충전 비율을 보여줍니다. 같은 평면에 이웃한 Port들을 Gauge로 설정하면 더 넓거나 높은 표시판을 만들 수 있습니다. 직사각형 Gauge Port 배열은 표시판 전체의 아래쪽부터 차오릅니다. Basic 또는 Port 형태, 빈 공간, 가려진 면, 모서리는 표시를 끊습니다. 불규칙한 Gauge 배열은 작은 직사각형 표시판 여러 개로 나뉩니다.

<RecipeFor id="industrial_bank_cell" />
<RecipeFor id="industrial_bank_port" />

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_battery_box" scale="2" />

  Battery는 휴대용 에너지 저장 장치입니다. Battery Box는 네트워크의 완충 장치로, 배터리를 넣어 충전한 뒤 꺼내 휴대용 장비에 사용할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">휴대용 배터리</Color>
</Column>

<Row>
  <ItemImage id="single_use_battery" />
  ### <Color id="aqua">Single Use Battery</Color>
</Row>

저렴한 일회용 배터리입니다. 용량은 <Energy config="energy.single_use_battery_capacity" />이며, 비상용으로는 좋지만 전력망 구축에는 적합하지 않습니다.

<RecipeFor id="single_use_battery" />

<Row>
  <ItemImage id="lv_battery" />
  ### <Color id="aqua">LV Battery</Color>
</Row>

<Energy config="energy.lv_battery_capacity" />를 저장하는 LV 등급의 첫 충전식 배터리입니다.

<RecipeFor id="lv_battery" />

<Row>
  <ItemImage id="mv_battery" />
  ### <Color id="aqua">MV Battery</Color>
</Row>

용량은 <Energy config="energy.mv_battery_capacity" />입니다. <ItemLink id="energy_crystal" />을 사용해 LV Battery를 업그레이드합니다.

<RecipeFor id="mv_battery" />

<Row>
  <ItemImage id="hv_battery" />
  ### <Color id="aqua">HV Battery</Color>
</Row>

용량은 <Energy config="energy.hv_battery_capacity" />입니다. 중후반 휴대용 장비에 전력을 공급합니다.

<RecipeFor id="hv_battery" />

<Row>
  <ItemImage id="ev_battery" />
  ### <Color id="aqua">EV Battery</Color>
</Row>

용량은 <Energy config="energy.ev_battery_capacity" />입니다. 이 모드에서 가장 큰 휴대용 배터리입니다.

<RecipeFor id="ev_battery" />

<Row>
  <ItemImage id="creative_battery" />
  ### <Color id="aqua">Creative Battery</Color>
</Row>

무한한 에너지를 제공합니다. 크리에이티브 모드 전용입니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">배터리 박스</Color>
</Column>

Battery Box의 왼쪽에는 **방전** 슬롯, 오른쪽에는 **충전** 슬롯이 있습니다. 충전된 배터리를 방전 슬롯에 넣으면 박스에 전력을 공급하고, 빈 배터리나 다른 에너지 아이템을 충전 슬롯에 넣으면 충전합니다. 각 박스에는 등급에 맞는 내부 에너지 저장 공간도 있습니다.

**I/O**를 열고 **Energy**를 선택한 뒤, 전력을 내보낼 면을 **Output**으로 설정하세요. 여러 면을 Output으로 지정할 수 있습니다. 전력을 받을 면은 **Input**, 양방향은 **Both**, 연결 해제는 **Disabled**로 설정합니다. **Default**는 앞면 출력, 나머지 면 입력이라는 기본 구성을 유지합니다. 출력 역할을 바꾸면 해당 면의 텍스처도 입력용 또는 출력용으로 바뀝니다. LV, MV, HV, EV Battery Box 모두 같은 방식으로 설정합니다.

<Row>
  <ItemImage id="lv_battery_box" />
  ### <Color id="aqua">LV Battery Box (<Energy config="energy.lv_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="lv_battery_box" />

<Row>
  <ItemImage id="mv_battery_box" />
  ### <Color id="aqua">MV Battery Box (<Energy config="energy.mv_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="mv_battery_box" />

<Row>
  <ItemImage id="hv_battery_box" />
  ### <Color id="aqua">HV Battery Box (<Energy config="energy.hv_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="hv_battery_box" />

<Row>
  <ItemImage id="ev_battery_box" />
  ### <Color id="aqua">EV Battery Box (<Energy config="energy.ev_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="ev_battery_box" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="energy_crystal" />
  ### <Color id="aqua">Energy Crystal</Color>
</Row>

Diamond와 Redstone을 압축해 만든 블록입니다. MV 이상 등급의 배터리와 고용량 장치 제작에 필요합니다.

<RecipeFor id="energy_crystal" />
