---
navigation:
  title: Cables
  icon: ftbic:mv_cable
  parent: energy/index.md
  position: 1
item_ids:
  - ftbic:lv_cable
  - ftbic:mv_cable
  - ftbic:hv_cable
  - ftbic:ev_cable
  - ftbic:iv_cable
  - ftbic:superconducting_cable
  - ftbic:burnt_cable
  - ftbic:lv_reinforced_cable
  - ftbic:mv_reinforced_cable
  - ftbic:hv_reinforced_cable
  - ftbic:ev_reinforced_cable
  - ftbic:iv_reinforced_cable
  - ftbic:burnt_reinforced_cable
---

# <Color id="gold">Cables</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_cable" scale="2" />

  Cable은 발전기, 소비 장치, 배터리를 하나의 네트워크로 연결합니다. 연결된 케이블을 따라 에너지가 즉시 이동하며, 설정된 **최대 케이블 길이**(기본값 300)를 초과할 수 없습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="lv_cable" />
  ### <Color id="aqua">LV Cable (<Energy config="energy.lv_transfer_rate" rate="true" />)</Color>
</Row>

Rubber로 절연한 Copper Cable입니다. Basic Generator, Macerator, Powered Furnace에 사용하는 기본 케이블입니다.

<RecipeFor id="lv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="mv_cable" />
  ### <Color id="aqua">MV Cable (<Energy config="energy.mv_transfer_rate" rate="true" />)</Color>
</Row>

절연된 Gold Wire입니다. MV Transformer와 중간 등급 기계 사이에 사용합니다.

<RecipeFor id="mv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="hv_cable" />
  ### <Color id="aqua">HV Cable (<Energy config="energy.hv_transfer_rate" rate="true" />)</Color>
</Row>

절연된 Iron Wire입니다. 고급 기계와 Nuclear Reactor의 초기 출력 구간에 필요합니다.

<RecipeFor id="hv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="ev_cable" />
  ### <Color id="aqua">EV Cable (<Energy config="energy.ev_transfer_rate" rate="true" />)</Color>
</Row>

절연된 Iridium Wire입니다. Teleporter, Antimatter Constructor, Quantum 장비용 Charge Pad에 전력을 공급합니다.

<RecipeFor id="ev_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="iv_cable" />
  ### <Color id="aqua">IV Cable (<Energy config="energy.iv_transfer_rate" rate="true" />)</Color>
</Row>

고출력 Reactor 설계와 최종 단계 Antimatter 생산 라인에 사용하는 Glass Cable입니다.

<RecipeFor id="iv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="superconducting_cable" />
  ### <Color id="aqua">Superconducting Cable (무제한 <EnergyUnit rate="true" />)</Color>
</Row>

제작대에서 **IV Glass Cable 2개**, **Redstone Dust 1개**, **Glowstone Dust 1개**를 조합하면 **Superconducting Cable 2개**를 얻습니다.

Superconducting Cable에는 전송량 제한이 없으며 과부하로 타지 않습니다. 다만 기계 자체의 입력·출력 제한과 설정된 최대 케이블 길이는 그대로 적용됩니다. Superconducting Cable끼리 연결해야 하며, 서로 다른 케이블 등급을 직접 연결할 수는 없습니다.

전력이 전송되는 동안 노출된 중심부를 따라 청록색 빛이 흐릅니다. 공급원이 전력 공급을 멈추거나 대상의 저장 공간이 가득 차면 빛이 사라집니다. 전송을 받지 못한 분기 구간은 어둡게 유지됩니다. 셰이더가 없어도 발광 효과가 표시됩니다.

<RecipeFor id="superconducting_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="burnt_cable" />
  ### <Color id="aqua">Burnt Cable</Color>
</Row>

전압이 너무 높으면 케이블이 이 상태로 변합니다. 부수고 올바른 등급의 케이블로 교체한 다음, 타버린 잔해를 분쇄하여 <ItemLink id="scrap" />으로 재활용하세요.

<RecipeFor id="scrap" fallbackText="Burnt Cable을 제작대에 넣으면 Scrap을 얻습니다." />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">강화 케이블</Color>

  <ItemImage id="lv_reinforced_cable" scale="2" />

  <ItemLink id="reinforced_stone" />만큼 단단한 완전한 블록이면서 해당 등급의 전력을 전달합니다. 격납벽에 틈을 내지 않고 케이블을 **통과**시키는 데 사용하세요. 등급별 색상은 일반 케이블과 같습니다.
</Column>

강화 케이블은 같은 등급의 일반 케이블에 연결되므로 벽을 통과하는 구간에 Transformer가 필요하지 않습니다. 과부하가 걸리면 약한 Burnt Cable 대신 <ItemLink id="burnt_reinforced_cable" />(중심부가 그을린 강화석 블록)로 변하므로 격납 구조가 유지됩니다.

<Row>
  <ItemImage id="lv_reinforced_cable" />
  ### <Color id="aqua">Reinforced LV Cable (<Energy config="energy.lv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="lv_reinforced_cable" />

<Row>
  <ItemImage id="mv_reinforced_cable" />
  ### <Color id="aqua">Reinforced MV Cable (<Energy config="energy.mv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="mv_reinforced_cable" />

<Row>
  <ItemImage id="hv_reinforced_cable" />
  ### <Color id="aqua">Reinforced HV Cable (<Energy config="energy.hv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="hv_reinforced_cable" />

<Row>
  <ItemImage id="ev_reinforced_cable" />
  ### <Color id="aqua">Reinforced EV Cable (<Energy config="energy.ev_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="ev_reinforced_cable" />

<Row>
  <ItemImage id="iv_reinforced_cable" />
  ### <Color id="aqua">Reinforced IV Cable (<Energy config="energy.iv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="iv_reinforced_cable" />

<Row>
  <ItemImage id="burnt_reinforced_cable" />
  ### <Color id="aqua">Burnt Reinforced Cable</Color>
</Row>

과부하로 변형된 강화 케이블입니다. Wither와 Ender Dragon의 공격에도 파괴되지 않아 격납벽 역할은 계속하지만, 더 이상 전기를 전달하지 않습니다. 올바른 등급의 새 강화 케이블로 교체하세요.
