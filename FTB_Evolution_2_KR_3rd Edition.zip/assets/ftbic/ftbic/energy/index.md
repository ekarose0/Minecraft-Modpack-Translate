---
navigation:
  title: 에너지 네트워크
  icon: ftbic:lv_cable
  position: 10
---

# <Color id="gold">에너지 네트워크</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="lv_cable" scale="2" />

  <ZapMode>

  FTBIC는 자체 에너지 단위인 **zap**을 사용합니다. 모든 Cable, Battery, Machine은 내부적으로 zap을 사용합니다. FTBIC Generator와 Cable은 FE를 소비하는 기계에 직접 전력을 공급할 수 있습니다. 반대로 FE를 FTBIC 기계에 **입력**하려면 <ItemLink id="lv_rectifier" />가 필요합니다.

  </ZapMode>

  <FEMode>

  **전체 FE 모드**가 활성화되어 FTBIC가 Forge Energy(FE)를 사용합니다. 모든 GUI, 툴팁, JEI 페이지, Jade 표시에서 에너지가 FE로 표시됩니다. FTBIC 블록은 다른 모드와 FE를 직접 주고받습니다. Generator와 Cable은 다른 모드 기계에 FE를 공급하고, FTBIC 기계는 모든 면에서 FE를 받으므로 Rectifier가 필요하지 않습니다.

  </FEMode>

  FTBIC가 Cable을 통해 FE 소비 장치에 전력을 공급할 때는 Cable 등급의 전송량 제한이 적용됩니다. 수천 FE/t를 소비하는 FE 기계에 LV Cable을 연결해도 <Energy config="energy.lv_transfer_rate" rate="true" /><ZapMode>에 해당하는 FE</ZapMode>만 전달하므로 Cable이 과부하로 타지 않습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">전압 등급</Color>
</Column>

모든 Cable과 Block은 다섯 가지 전압 등급 중 하나를 가집니다. 해당 등급의 허용치를 초과하는 전력을 공급하면 **타버립니다**.

| 등급 | 약어 | 전송량 | 주요 용도 |
|------|--------|---------------|-------------|
| 낮음     | **LV** | <Energy config="energy.lv_transfer_rate" rate="true" /> | 첫 Generator, 초기 기계 |
| 중간     | **MV** | <Energy config="energy.mv_transfer_rate" rate="true" /> | 광석 가공 라인 |
| 높음     | **HV** | <Energy config="energy.hv_transfer_rate" rate="true" /> | 고급 기계 |
| 극한     | **EV** | <Energy config="energy.ev_transfer_rate" rate="true" /> | 원자력, Teleporter, Quantum |
| 최고     | **IV** | <Energy config="energy.iv_transfer_rate" rate="true" /> | Antimatter, 최종 단계 |

**기본 원칙:** 연결된 발전기 또는 소비 장치 중 가장 높은 등급에 맞춰 Cable을 선택하세요. <ItemLink id="lv_transformer" /> 계열 블록으로 전압을 더 낮은 등급으로 내릴 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">과부하와 Fuse</Color>
</Column>

너무 높은 전압을 받은 Cable은 <ItemLink id="burnt_cable" />로 변합니다. 기계도 녹아버리며, <ItemLink id="fuse" />로 수리할 때까지 타버린 외장 상태로 남습니다.

<FEMode>

FE 입력 자체로는 어떤 장치도 타지 않습니다. 다른 모드에서 FTBIC 기계로 FE를 보내면 기계가 자체 입력 한도만큼 받고 나머지는 거부합니다. 하지만 FTBIC Cable에서 발생한 과전압은 여전히 LV·MV 기계, Battery Box, Transformer를 태울 수 있습니다.

</FEMode>

타버린 Cable은 <ItemLink id="scrap" />으로 재활용할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
