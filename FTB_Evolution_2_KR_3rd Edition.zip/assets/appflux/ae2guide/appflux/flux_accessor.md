---
navigation:
  parent: appflux/appflux-index.md
  title: Flux Accessor
  icon: appflux:flux_accessor
categories:
- flux accessor
item_ids:
- appflux:flux_accessor
- appflux:part_flux_accessor
---

# Flux Accessor

<Row>
<BlockImage id="appflux:flux_accessor" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/flux_accessor.snbt"></ImportStructure>
</GameScene>
</Row>

Flux Accessor는 ME 네트워크에 저장된 에너지를 입력하거나 출력할 수 있습니다. 기본적으로 입출력량에 제한이 없으며, Appflux 설정 파일에서 제한을 변경할 수 있습니다.

빠른 모드와 일반 모드가 있습니다. 빠른 모드는 매 틱마다 에너지를 출력하므로 많이 사용하면 서버에 지연이 발생할 수 있습니다. 일반 모드는 대상 장치에 저장된 에너지량에 따라 출력을 조절하므로 이러한 지연 문제를 줄일 수 있습니다.

* 주의: 여기서 말하는 '에너지'는 [FE Storage Cells](./flux_cells.md)에 저장된 FE를 뜻합니다. [Energy Cells](ae2:items-blocks-machines/energy_cells.md)에 저장된 에너지와는 다릅니다.
