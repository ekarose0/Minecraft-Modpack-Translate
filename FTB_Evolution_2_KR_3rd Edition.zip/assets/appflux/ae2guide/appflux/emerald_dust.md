---
navigation:
  parent: appflux/appflux-index.md
  title: Emerald Dust
  icon: appflux:emerald_dust
categories:
- flux materials
item_ids:
- appflux:emerald_dust
---

# Emerald Dust

<Row>
<ItemImage id="appflux:emerald_dust" scale="4"></ItemImage>
</Row>

에메랄드를 가루 형태로 가공한 재료입니다.
