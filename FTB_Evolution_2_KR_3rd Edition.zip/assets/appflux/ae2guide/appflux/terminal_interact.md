---
navigation:
  parent: appflux/appflux-index.md
  title: Terminal Interactions
categories:
- flux tricks
---

# 터미널에서 에너지 다루기

터미널에는 저장된 에너지가 *초록색 유체*처럼 표시됩니다.

![FE_GUI](../pic/fe_terminal.png)

하지만 실제 유체가 아니므로 양동이로 담을 수는 없습니다.

배터리나 전동 도구처럼 에너지를 저장하는 용기를 사용하면 이 에너지를 넣거나 꺼낼 수 있습니다.

![FE_GUI2](../pic/fe_terminal2.png)
