---
navigation:
    title: Applied Flux
    position: 70
---

# 에너지를 셀에 저장하세요!

Applied Flux(Appflux)를 이용하면 AE 시스템으로 전력망을 관리할 수 있습니다.

## Flux Cells
<CategoryIndex category="flux cells"></CategoryIndex>

## 재료
<CategoryIndex category="flux materials"></CategoryIndex>

## Flux Accessor
<CategoryIndex category="flux accessor"></CategoryIndex>

## 활용법
<CategoryIndex category="flux tricks"></CategoryIndex>
