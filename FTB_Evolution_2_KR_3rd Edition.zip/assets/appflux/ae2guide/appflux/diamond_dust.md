---
navigation:
  parent: appflux/appflux-index.md
  title: Diamond Dust
  icon: appflux:diamond_dust
categories:
- flux materials
item_ids:
- appflux:diamond_dust
---

# Diamond Dust

<Row>
<ItemImage id="appflux:diamond_dust" scale="4"></ItemImage>
</Row>

다이아몬드를 가루 형태로 가공한 재료입니다.
