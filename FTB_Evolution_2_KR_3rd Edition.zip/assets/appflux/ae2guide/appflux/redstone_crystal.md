---
navigation:
  parent: appflux/appflux-index.md
  title: Redstone Crystal
  icon: appflux:redstone_crystal
categories:
- flux materials
item_ids:
- appflux:redstone_crystal
- appflux:charged_redstone
- appflux:charged_redstone_block
---

# Redstone Crystal

<Row>
<ItemImage id="appflux:redstone_crystal" scale="4"></ItemImage>
<ItemImage id="appflux:charged_redstone" scale="4"></ItemImage>
</Row>
<Row>
<BlockImage id="appflux:charged_redstone_block" scale="4"></BlockImage>
</Row>

*"Pow ah!!"*

Redstone은 에너지를 저장하기에 좋은 매개체이지만, 입자가 너무 느슨하게 결합되어 있어 그대로는 셀에 넣을 수 없습니다.

Redstone Block을 Fluix Crystal 및 Glowstone과 결합하면 Redstone Crystal로 결정화됩니다. 이 결정은 공간을 거의 차지하지 않으면서도 많은 양의 에너지를 저장할 수 있습니다.
