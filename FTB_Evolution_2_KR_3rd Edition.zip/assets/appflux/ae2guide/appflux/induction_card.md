---
navigation:
  parent: appflux/appflux-index.md
  title: Induction Card
  icon: appflux:induction_card
categories:
- flux accessor
item_ids:
- appflux:induction_card
---

# Induction Card

<Row>
<ItemImage id="appflux:induction_card" scale="4"></ItemImage>
</Row>

Induction Card를 사용하면 <ItemLink id="ae2:pattern_provider" /> 또는 <ItemLink id="ae2:interface" />에 <ItemLink id="appflux:flux_accessor" />의 기능을 부여하여 에너지를 입력하거나 출력할 수 있습니다.
