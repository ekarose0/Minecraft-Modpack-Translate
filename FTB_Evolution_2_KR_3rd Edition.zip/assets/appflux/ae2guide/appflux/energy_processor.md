---
navigation:
  parent: appflux/appflux-index.md
  title: Energy Processor
  icon: appflux:energy_processor
categories:
- flux materials
item_ids:
- appflux:energy_processor
- appflux:printed_energy_processor
- appflux:energy_processor_press
---

# Energy Processor

<Row>
<ItemImage id="appflux:energy_processor" scale="4"></ItemImage>
<ItemImage id="appflux:energy_processor_press" scale="4"></ItemImage>
<ItemImage id="appflux:printed_energy_processor" scale="4"></ItemImage>
</Row>

Energy Processor는 ME 시스템에서 에너지의 흐름을 관리하는 데 사용됩니다. 모든 에너지 장치는 에너지를 전달하기 위해 Energy Processor가 필요합니다.
