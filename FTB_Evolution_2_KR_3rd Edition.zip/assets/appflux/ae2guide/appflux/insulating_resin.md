---
navigation:
  parent: appflux/appflux-index.md
  title: Insulating Resin
  icon: appflux:insulating_resin
categories:
- flux materials
item_ids:
- appflux:insulating_resin
- appflux:harden_insulating_resin
---

# Insulating Resin

<Row>
<ItemImage id="appflux:insulating_resin" scale="4"></ItemImage>
<ItemImage id="appflux:harden_insulating_resin" scale="4"></ItemImage>
</Row>

Insulating Resin은 저장된 에너지가 누출되는 것을 막아줍니다. FE Cell Housing 제작에 필요한 필수 재료입니다.
