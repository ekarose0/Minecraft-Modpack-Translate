---
navigation:
  parent: appflux/appflux-index.md
  title: Mark FE
categories:
- flux tricks
---

# 설정 슬롯에 FE 표시하기

<ItemLink id="ae2:export_bus"/>로 에너지를 출력하려면 설정 슬롯에 FE를 지정해야 합니다.

에너지 저장 용기를 들고 해당 슬롯을 우클릭하면 FE를 표시할 수 있습니다.

![FE_MARK](../pic/fe_mark.png)
