---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Magnet Card
  icon: ae2wtlib:magnet_card
  position: 220
categories:
- ae2wtlib
item_ids:
- ae2wtlib:magnet_card
---

# Magnet Card

<ItemImage id="ae2wtlib:magnet_card" scale="3" />

<ItemLink id="ae2wtlib:magnet_card" />는 <ItemLink id="ae2:wireless_crafting_terminal" />에 장착하는 [Upgrade Card](ae2:items-blocks-machines/upgrade_cards.md)입니다.
<ItemLink id="ae2:wireless_crafting_terminal" />에 자석 기능을 추가하며, GUI에서 켜거나 끄고 필터를 설정할 수 있습니다.
자석 기능을 전환하는 단축키도 있습니다.

<ItemLink id="ae2wtlib:magnet_card" />의 기능은 두 가지입니다.

1. 더 넓은 범위의 아이템을 줍습니다(설정 가능, 기본값 16).
2. 주운 아이템을 인벤토리 대신 ME 시스템에 넣습니다.

두 기능은 각각 따로 켜거나 끌 수 있으며, 줍기 필터와 저장 필터도 별도로 설정할 수 있습니다.
각 필터는 허용 목록 또는 차단 목록으로 지정할 수 있습니다.

## 제작법

<RecipeFor id="ae2wtlib:magnet_card" />
