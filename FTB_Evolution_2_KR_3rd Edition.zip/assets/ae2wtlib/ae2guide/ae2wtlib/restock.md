---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Restocking
  position: 110
categories:
- ae2wtlib
---

# Restocking

Restock 기능을 켜면 <ItemLink id="ae2:wireless_crafting_terminal" />이 사용한 아이템을 ME 시스템에서 자동으로 보충합니다.

GUI 또는 단축키로 기능을 켤 수 있습니다.

활성화하면 사용 중인 아이템 스택을 최대 수량으로 유지하려고 합니다. 대부분의 아이템은 64개입니다.
부족한 아이템은 ME 시스템에서 꺼내고,
추가로 주워서 남는 아이템은 ME 시스템에 다시 넣습니다.
따라서 블록을 몇 개 설치했다가 다시 캐더라도, <ItemLink id="ae2wtlib:magnet_card" />가 없어도 아이템이 다른 슬롯으로 넘쳐 들어가지 않습니다.

사용하기 전부터 아이템이 **1개만 들어 있던 스택은 보충하지 않습니다.**

핫바의 아이템 수량 표시도 바뀝니다.
네트워크에 있는 수량과 실제 핫바에 있는 수량을 합산하여 보여줍니다.

이 기능은 Wireless Access Point의 범위 안에 있거나 터미널이 [양자 연결](quantum_bridge_card.md)되어 있을 때만 작동합니다.

크리에이티브 모드에서는 아이템이 소모되지 않으므로 자동으로 비활성화됩니다.

블록 설치, 음식 섭취, 활 발사 등 대부분의 동작에서는 정상적으로 보충됩니다.
다만 다른 모드의 동작 등 일부 행동은 감지하지 못해 사용한 아이템이 보충되지 않을 수 있습니다.
