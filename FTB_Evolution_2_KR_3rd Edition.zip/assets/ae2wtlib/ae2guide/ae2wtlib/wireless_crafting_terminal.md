---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Wireless Crafting Terminal
  icon: ae2:wireless_crafting_terminal
  position: 100
categories:
- ae2wtlib
item_ids:
  - ae2:wireless_crafting_terminal
---

# Wireless Crafting Terminal

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" />은 <ItemLink id="ae2:crafting_terminal" />의 [무선 버전](wireless_terminals.md)입니다.
AE2WTLib는 ME 네트워크에서 아이템을 자동 [보충](restock.md)하는 기능과 Pick Block으로 네트워크의 아이템을 가져오는 기능을 추가합니다.
<ItemLink id="ae2wtlib:magnet_card" />를 장착하면 자석 기능도 사용할 수 있습니다.

다른 [Wireless Terminals](wireless_terminals.md)과 합쳐 <ItemLink id="ae2wtlib:wireless_universal_terminal" />을 만들 수 있습니다.

AE2WTLib는 Minecraft의 `Pick Block` 기능을 확장합니다. 인벤토리에 해당 아이템이 없으면 네트워크에서 가져옵니다.
현재 슬롯이 가득 찬 경우 아이템을 네트워크에 저장하려고 시도하기도 합니다.

## 사용자 인터페이스

[Terminals](ae2:items-blocks-machines/terminals.md) 문서를 참고하세요.

## 업그레이드

<ItemLink id="ae2:wireless_crafting_terminal" />에는 다음 [업그레이드](ae2:items-blocks-machines/upgrade_cards.md)를 사용할 수 있습니다.

*   <ItemLink id="ae2:energy_card" /> 배터리 용량을 늘립니다.
*   <ItemLink id="ae2wtlib:quantum_bridge_card" /> 차원에 관계없이 거리 제한 없이 접속하고 ME 네트워크에서 자동 충전할 수 있게 합니다. 
*   <ItemLink id="ae2wtlib:magnet_card" /> 자석 기능을 추가합니다.

## 제작법

<RecipeFor id="ae2:wireless_crafting_terminal" />
