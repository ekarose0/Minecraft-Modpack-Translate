---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: AE2WTLib Wireless Terminals
  icon: ae2wtlib:wireless_universal_terminal
  position: 10
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_pattern_encoding_terminal
  - ae2wtlib:wireless_pattern_access_terminal
---

# Wireless Terminals

<ItemGrid>
  <ItemIcon id="ae2wtlib:wireless_universal_terminal" />
  <ItemIcon id="ae2:wireless_crafting_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_encoding_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_access_terminal" />
</ItemGrid>

모든 AE2WTLib Wireless Terminal은 <ItemLink id="ae2:energy_card" /> 외에도 <ItemLink id="ae2wtlib:quantum_bridge_card" />로 업그레이드할 수 있으며,
<ItemLink id="ae2wtlib:wireless_universal_terminal" />로 합칠 수도 있습니다.

AE2의 <ItemLink id="ae2:wireless_terminal" />처럼 단축키로 열 수 있고, Curios API를 지원하는 모드가 설치되어 있다면 Curios 슬롯에 장착할 수도 있습니다.

Wireless Terminal은 일반 <ItemLink id="ae2:wireless_terminal" />처럼 <ItemLink id="ae2:wireless_access_point" />를 통해 연결할 수 있습니다.

## Wireless Universal Terminal

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" />은 여러 Wireless Terminal을 하나의 아이템으로 합친 것입니다.

## Wireless Crafting Terminal

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" />은 Crafting Terminal의 무선 버전입니다.
기본 AE2에 비해 몇 가지 [추가 기능](wireless_crafting_terminal.md)이 있습니다.

## Wireless Pattern Encoding Terminal

<ItemImage id="ae2wtlib:wireless_pattern_encoding_terminal" scale="3" />

<ItemLink id="ae2:pattern_encoding_terminal" />의 무선 버전입니다.

<RecipeFor id="ae2wtlib:wireless_pattern_encoding_terminal" />

## Wireless Pattern Access Terminal

<ItemImage id="ae2wtlib:wireless_pattern_access_terminal" scale="3" />

<ItemLink id="ae2:pattern_access_terminal" />의 무선 버전입니다.

<RecipeFor id="ae2wtlib:wireless_pattern_access_terminal" />

## 애드온 터미널

다른 애드온에서 추가된 대부분의 무선 터미널도 <ItemLink id="ae2wtlib:wireless_universal_terminal" />과 함께 사용할 수 있습니다.

## Universal Terminal에 결합할 수 없는 터미널

<ItemLink id="ae2:wireless_terminal" />은 <ItemLink id="ae2wtlib:wireless_universal_terminal" />에 결합할 수 없습니다.
<ItemLink id="ae2:wireless_crafting_terminal" />보다 추가적인 이점이 없기 때문입니다.
또한 <ItemLink id="ae2wtlib:quantum_bridge_card" />도 사용할 수 없습니다.
