---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Quantum Bridge Card
  icon: ae2wtlib:quantum_bridge_card
  position: 210
categories:
- ae2wtlib
item_ids:
- ae2wtlib:quantum_bridge_card
---

# Quantum Bridge Card

<ItemImage id="ae2wtlib:quantum_bridge_card" scale="3" />

Quantum Bridge Card는 [AE2WTLib Wireless Terminals](wireless_terminals.md)에 사용하는 [Upgrade Card](ae2:items-blocks-machines/upgrade_cards.md)입니다.
이를 사용하면 [Wireless Terminals](wireless_terminals.md)을 [Quantum Bridge](ae2:items-blocks-machines/quantum_bridge.md)에 연결할 수 있습니다.

Wireless Terminal에 Quantum Bridge Card와 <ItemLink id="ae2:quantum_entangled_singularity" />를 넣으세요.
짝이 되는 다른 Singularity는 네트워크에 연결된 [Quantum Bridge](ae2:items-blocks-machines/quantum_bridge.md)에 넣습니다.

이제 Wireless Terminal이 양자 연결되어 차원이 달라도 어디에서든 네트워크에 접속할 수 있습니다. 단, <ItemLink id="ae2:spatial_anchor" /> 등을 이용해 네트워크가 있는 청크가 로드되어 있어야 합니다.
터미널은 네트워크의 에너지로 자동 충전됩니다.
네트워크에 충분한 [에너지 저장량](ae2:items-blocks-machines/energy_cells.md)이 있는지 확인하세요.

## 제작법

<RecipeFor id="ae2wtlib:quantum_bridge_card" />
