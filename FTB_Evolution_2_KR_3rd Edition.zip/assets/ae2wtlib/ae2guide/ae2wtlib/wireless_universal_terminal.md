---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Wireless Universal Terminal
  icon: ae2wtlib:wireless_universal_terminal
  position: 20
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_universal_terminal
---

# Wireless Universal Terminal

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" />은 여러 [Wireless Terminals](wireless_terminals.md)을 하나로 합친 아이템입니다.

모든 [AE2WTLib Wireless Terminals](wireless_terminals.md)을 하나의 터미널로 결합할 수 있습니다.

AE2의 <ItemLink id="ae2:wireless_terminal" />은 <ItemLink id="ae2wtlib:wireless_universal_terminal" />에 ***결합할 수 없습니다.***


## 사용자 인터페이스

<ItemLink id="ae2wtlib:wireless_universal_terminal" />은 터미널 화면에 전환 버튼을 추가합니다.
좌클릭하면 다음 [Wireless Terminal](wireless_terminals.md)로, 우클릭하면 이전 터미널로 전환합니다.


## 업그레이드

<ItemLink id="ae2wtlib:wireless_universal_terminal" />에는 결합된 [Wireless Terminals](wireless_terminals.md)이 지원하는 업그레이드를 사용할 수 있습니다.
터미널 하나를 결합할 때마다 업그레이드 슬롯이 2개 추가됩니다.

## 에너지 저장량

터미널을 결합하면 에너지 저장 용량도 합쳐집니다.
따라서 터미널 2개를 결합한 <ItemLink id="ae2wtlib:wireless_universal_terminal" />은 일반 [Wireless Terminal](wireless_terminals.md)의 두 배에 해당하는 에너지를 저장할 수 있습니다.
