# 이미지 디렉터리

이 디렉터리에는 RecursiveAE2PatternProvider의 AE2 가이드에서 사용하는 이미지가 들어 있습니다. 