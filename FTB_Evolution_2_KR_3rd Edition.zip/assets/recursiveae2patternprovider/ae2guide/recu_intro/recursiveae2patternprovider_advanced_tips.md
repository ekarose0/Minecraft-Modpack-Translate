---
navigation:
  parent: recu_intro/recu_intro-index.md
  icon:
  title: 고급 팁
categories:
  - recursive_patterns
---

# Recursive AE2 Pattern Provider

## 🔧 고급 팁

### 터미널 작업 효율화
- Pattern Encoding Terminal에서 **Recursive Pattern Toggle**을 사용하면 추가 제작 재료를 인벤토리에 가지고 다니지 않고도 재귀 패턴을 연속으로 만들 수 있습니다.
- 전환 버튼은 Crafting Pattern 전용이며 Processing 또는 Smithing 모드로 바꾸면 자동으로 숨겨집니다.
- **설정 가능한 GUI 버튼**: 재귀 패턴을 제작대 제작법으로만 만들도록 제한하려면 설정 파일에서 `enableEncodingGuiToggle = false`로 지정하세요.

### 재귀 깊이 설정
- **깊이 1**: 직접 필요한 재료만 생성합니다(예: Chest 제작에 필요한 Planks).
- **깊이 3**: 재료, 그 재료의 하위 재료, 원목까지 생성합니다(대부분의 구성에 권장).
- **무제한(-1)**: 원재료까지 모든 하위 제작 관계를 처리합니다.
- **비활성화(0)**: 기본 AE2의 동작 방식으로 돌아갑니다.

### Pattern Provider 구성과 성능
- 재귀 패턴은 Molecular Assembler에 연결된 Pattern Provider에 넣으세요.
- 자동 생성된 하위 패턴은 상위 패턴의 대체 설정(아이템·유체 대체)을 이어받습니다.
- 대형 모드팩에서는 네트워크의 패턴 색인 시간이 지나치게 길어지지 않도록 재귀 깊이를 적절히 제한하세요.