---
navigation:
  parent: recu_intro/recu_intro-index.md
  icon:
  title: 사용 예시
categories:
  - recursive_patterns
---

# Recursive AE2 Pattern Provider

## 💡 사용 예시

### 기존 AE2 방식
Iron Pickaxe를 자동 제작하려면 기존에는 다음 패턴을 직접 인코딩하고 등록해야 했습니다.
1. Iron Pickaxe 패턴
2. Stick 패턴
3. Wood Plank 패턴(원목에서 제작)
4. Iron Ingot 제련 패턴(Raw Iron에서 제작)
5. 모든 하위 제작법을 Pattern Provider에 직접 등록해야 합니다.

### Recursive AE2 Pattern Provider를 사용하는 경우
1. **Pattern Encoding Terminal**을 열고 **Recursive Pattern**을 활성화한 다음 Iron Pickaxe 패턴 하나만 인코딩합니다.
2. 생성한 패턴을 Pattern Provider에 넣습니다.
3. **필요한 하위 패턴이 모두 자동으로 생성됩니다!**

이 모드는 판자, 막대기, 중간 재료에 이르는 제작 관계를 추적하므로 네트워크를 간결하게 유지하고 반복적인 패턴 제작을 줄여 줍니다.