---
navigation:
  parent: recu_intro/recu_intro-index.md
  icon:
  title: 주요 기능
categories:
  - recursive_patterns
---

# Recursive AE2 Pattern Provider

## ✨ 주요 기능

### 🎯 패턴 자동 생성
- **지능형 의존성 처리**: 누락된 재료 제작 패턴을 필요할 때 자동으로 생성합니다.
- **재귀 처리**: 설정된 최대 깊이까지 재료 의존 관계를 추적합니다.
- **제작법 탐색**: 실제로 제작 가능한 유효한 제작법에 대해서만 패턴을 생성합니다.
- **범용 지원**: 일반 제작 재료의 하위 패턴을 생성합니다.
- **호환 모드**: AE2, Extended AE2, Advanced AE, ExtendedAE-Plus를 지원합니다.

### ⚙️ GUI 통합
- **터미널에서 직접 전환**: Pattern Encoding Terminal의 전용 버튼으로 재귀 기능을 켜거나 끕니다(`enableEncodingGuiToggle`에서 설정 가능).
- **제작 패턴 전용**: Crafting Pattern 인코딩 화면에 통합되며 다른 패턴 모드에서는 버튼이 표시되지 않습니다.
- **대체 제작 방식**: 제작대에서 기존 패턴을 변환할 수도 있습니다(`Pattern + Iron Ingot`).

### 🎨 직관적인 표시
- **기본 툴팁과 조화**: AE2의 툴팁 디자인에 맞춰 `Recursive` 표시를 추가합니다.
- **재귀 설정 유지**: 터미널에서 패턴을 다시 인코딩해도 별도 조작 없이 재귀 설정이 유지됩니다.