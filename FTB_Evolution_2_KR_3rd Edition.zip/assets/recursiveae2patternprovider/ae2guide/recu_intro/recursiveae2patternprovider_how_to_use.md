---
navigation:
  parent: recu_intro/recu_intro-index.md
  icon:
  title: 사용 방법
categories:
  - recursive_patterns
---

# Recursive AE2 Pattern Provider

## 🎮 사용 방법

### 1단계: 재귀 패턴 인코딩

재귀 패턴은 **두 가지 방법**으로 만들 수 있습니다.

#### 방법 A: Pattern Encoding Terminal에서 직접 전환(권장)
1. **Pattern Encoding Terminal**을 엽니다.
2. **Crafting Pattern** 탭을 선택합니다.
3. 대체 설정 버튼 옆에 있는 **Recursive Pattern** 버튼을 **ON**(초록색 체크 표시)으로 바꿉니다.
4. 제작 격자에 제작법을 입력하고 **Encode Pattern**을 클릭합니다.
5. 인코딩된 패턴에 재귀 설정이 자동으로 추가됩니다.

> 💡 **참고**: Pattern Encoding Terminal의 전환 버튼은 설정 파일의 `enableEncodingGuiToggle`에서 활성화하거나 비활성화할 수 있습니다(기본값: `true`).

#### 방법 B: 제작대 제작법
1. 이미 인코딩된 일반 AE2 패턴을 제작대에 넣습니다.
2. 설정된 제작 재료(기본값: **Iron Ingot**)를 추가합니다.
3. 제작하면 재귀 버전으로 변환됩니다(`[AE2 Pattern] + [Recipe Item] → [Recursive Pattern]`).

*(제작대에서 재귀 설정을 제거하려면 재귀 패턴만 넣고 제작하세요: `[Recursive Pattern] → [Normal Pattern]`)*.

### 2단계: Pattern Provider에 설치
재귀 패턴을 Molecular Assembler에 연결된 **Pattern Provider**에 넣습니다.

### 3단계: 자동 생성! ✨
이 모드는 누락된 중간 재료에 필요한 패턴을 실시간으로 자동 생성합니다.
- **Sticks**(Iron Pickaxe 제작에 필요한 경우)
- **Wood Planks**(원목으로 막대기를 제작하는 경우)
- **제작 과정에서 빠진 모든 하위 제작 패턴!**

## 🔄 패턴 재인코딩과 설정 유지

기존 재귀 패턴을 Pattern Encoding Terminal에 다시 넣어 제작법이나 설정을 수정할 때는 다음과 같이 동작합니다.
- 다시 인코딩해도 **재귀 태그가 자동으로 유지됩니다.**
- 재귀 기능을 끄려는 경우가 아니라면 패턴을 다시 제작하거나 설정을 직접 전환할 필요가 없습니다.