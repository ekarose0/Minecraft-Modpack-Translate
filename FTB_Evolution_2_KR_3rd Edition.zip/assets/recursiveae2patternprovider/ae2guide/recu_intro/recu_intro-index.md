---
navigation:
  title: Recursive AE2 Pattern Provider
  icon:
  position: 100
---

# Recursive AE2 Pattern Provider

Recursive AE2 Pattern Provider 가이드에 오신 것을 환영합니다!
이 모드는 복잡한 제작법에 필요한 하위 패턴을 네트워크에서 자동으로 생성하여 AE2 자동 제작을 더욱 편리하게 만듭니다.

번거롭게 하위 패턴을 하나씩 만들지 않고도 여러 단계의 자동 제작을 구성할 수 있습니다.

## [✨ 주요 기능](recursiveae2patternprovider_key_features.md)

## [🎮 사용 방법](recursiveae2patternprovider_how_to_use.md)

## [💡 사용 예시](recursiveae2patternprovider_example.md)

## [🔧 고급 팁](recursiveae2patternprovider_advanced_tips.md)

문제가 발생했거나 필요한 기능이 있나요?
다음 링크에 제보해 주세요.
[GitHub](https://github.com/Lumengrid/RecursiveAE2PatternProvider)