---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    icon: ae2netanalyser:network_analyser
    title: ME Network Analyser
categories:
- tools
item_ids:
- ae2netanalyser:network_analyser
---

# ME 네트워크 분석

<ItemImage id="ae2netanalyser:network_analyser" scale="4"></ItemImage>

ME 네트워크에서 어떤 장치가 오프라인인지 찾기 어려웠던 적이 있으신가요? 또는 네트워크가 어떻게 작동하는지 확인하고 싶으신가요? 이럴 때 ME Network Analyser를 사용할 수 있습니다.

## 내 ME 네트워크에서는 무슨 일이 일어나고 있나요?

ME 네트워크에 연결된 블록, 케이블 또는 장치를 클릭하면 모든 장치의 상태와 서로 연결된 방식을 확인할 수 있습니다.

![overview](./pic/showoff.png)

색상과 모양은 서로 다른 상태를 나타냅니다.
- 파란색 큐브: 정상적인 ME 장치입니다. 채널이 충분하며 최대 8개 채널을 전달할 수 있습니다.
- 노란색 큐브: 정상적인 Dense ME 장치입니다. 채널이 충분하며 최대 32개 채널을 전달할 수 있습니다.
- 빨간색 큐브: 채널이 부족하여 오프라인 상태인 ME 장치입니다.
- 파란색 연결선: 최대 8개 채널을 전달할 수 있습니다.
- 노란색 연결선: 최대 32개 채널을 전달할 수 있습니다.
- 분홍색 연결선: ME P2P 연결을 나타냅니다.
- 숫자: 해당 연결선을 통해 전달되는 채널 수입니다.

실제 최대 채널 수는 ME Channel Mode 설정에 따라 달라집니다. 무제한 채널(Infinity Channel) 모드에서는 분석기에 채널 수가 표시되지 않습니다.

## 화면 표시 설정

설정 GUI에서 분석 모드와 색상을 변경할 수 있습니다.

![gui](./pic/gui.png)

ME Network Analyser에는 5가지 모드가 있습니다.
- Full: 네트워크의 모든 상태를 표시합니다.
- Nodes: 노드 상태만 표시합니다.
- Links: 연결선 상태만 표시합니다.
- No Number: 채널 수를 표시하지 않습니다.
- P2P: ME P2P 연결만 표시합니다.

노드나 연결선의 색상도 변경할 수 있습니다.

![gui2](./pic/color.png)
