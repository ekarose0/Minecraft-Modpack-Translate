---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    icon: ae2netanalyser:tick_analyser
    title: ME Tick Profiler
categories:
- tools
item_ids:
- ae2netanalyser:tick_analyser
---

# ME 틱 처리 시간 분석

<ItemImage id="ae2netanalyser:tick_analyser" scale="4"></ItemImage>

ME 네트워크가 매우 커지면 게임에 렉이 발생할 수 있지만, 네트워크 내부에서 원인을 찾기는 어렵습니다. ME Tick Profiler를 사용하면 어떤 장치가 지연을 일으키는지 쉽게 확인할 수 있습니다.

## 무엇이 게임에 렉을 일으키나요?

일부 AE 장치는 게임 틱마다 작업을 수행합니다. ME Tick Profiler는 이러한 작업에 필요한 시간(μs/tick)을 측정하고 월드에 수치를 표시하여, 처리 시간이 가장 오래 걸리는 장치를 찾도록 도와줍니다.

**멀티플레이어 서버에서는 악용을 방지하기 위해 OP 권한이 있어야 사용할 수 있습니다.**

![overview](./pic/tick_rate.png)

색상은 블록이 일으키는 지연 정도를 나타냅니다. 빨간색에 가까울수록 지연이 큽니다.

숫자는 해당 블록의 틱 처리 시간을 나타냅니다. TPS(초당 틱 수)가 20보다 낮아지면 게임이 느려집니다. 즉, 게임의 틱 처리 시간은 항상 50,000 μs/tick보다 짧아야 합니다.

일반적으로 대부분의 블록은 틱당 처리 시간이 100 μs보다 짧아야 하며, 그보다 길면 렉을 유발할 수 있습니다.

## 화면 표시 설정

설정 GUI에서 틱 처리 시간 범위별 월드 내 표시를 조절할 수 있습니다.

![gui](./pic/gui2.png)

초록색 점은 해당 틱 처리 시간 범위의 블록을 표시한다는 뜻입니다. 점을 클릭하여 표시 여부를 켜거나 끌 수 있습니다.
