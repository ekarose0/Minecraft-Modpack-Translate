---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cable 사용법
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# Cable

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

ME를 지원하는 기계끼리 인접해 있어도 네트워크를 구성할 수 있지만, 넓은 범위로 ME 네트워크를 확장할 때는 주로 Cable을 사용합니다.

색상이 다른 Cable끼리는 서로 연결되지 않으므로 인접한 Cable을 분리하여 [채널](../ae2-mechanics/channels.md)을 더 효율적으로 배분할 수 있습니다. 연결된 Terminal의 색상도 바뀌므로 모든 Terminal을 보라색으로 사용할 필요는 없습니다. Fluix Cable은 모든 색상과 연결됩니다.

주의: **채널은 Cable 색상과 아무 관련이 없습니다.** 색상은 Cable끼리의 연결을 제한할 뿐입니다.

## 중요한 참고 사항

**AE2를 처음 사용하고 채널에 익숙하지 않다면 가능한 곳에는 Smart Cable과 Dense Smart Cable을 사용하세요. 채널이 네트워크를 따라 어떻게 전달되는지 시각적으로 확인할 수 있어 작동 방식을 이해하기 쉽습니다.**

## 추가 참고 사항

**Cable은 아이템·유체·에너지 등을 운반하는 파이프가 아닙니다.** 내부 인벤토리가 없으며 Pattern Provider나 기계가 Cable 안으로 아이템을 밀어 넣는 것도 아닙니다. AE2 [장치](../ae2-mechanics/devices.md)를 하나의 네트워크로 연결하는 역할만 합니다.

## Glass Cable

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_glass_cable" />은 가장 간단한 Cable로 전력과 최대 8개의 [채널](../ae2-mechanics/channels.md)을 전달합니다. 기본 Fluix 색상을 포함해 총 17가지 색상이 있으며, 16종의 염료로 색을 바꿀 수 있습니다.

색상 Cable을 제작하려면 염료 하나를 같은 종류의 Cable 8개로 둘러싸세요. Cable의 색상은 달라도 되지만 Glass, Smart 등 종류는 같아야 합니다. 월드에서는 Forge 호환 페인트 브러시로도 칠할 수 있습니다.

색상 Cable과 Water Bucket을 조합하면 염료를 제거할 수 있습니다.

Cable에 Wool을 더해 <ItemLink id="fluix_covered_cable" />을 만들거나, [채널](../ae2-mechanics/channels.md) 상태를 쉽게 확인할 수 있는 <ItemLink id="fluix_smart_cable" />을 제작할 수 있습니다.

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## Covered Cable

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Covered Cable은 <ItemLink id="fluix_glass_cable" />에 비해 기능적인 이점은 없지만, 외관이 마음에 든다면 장식용으로 선택할 수 있습니다.

<ItemLink id="fluix_glass_cable" />과 같은 방식으로 색을 바꿀 수 있습니다. <ItemLink id="fluix_covered_cable" /> 4개를 Redstone, Glowstone과 조합하면 <ItemLink id="fluix_covered_dense_cable" />을 제작할 수 있습니다.

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

## Dense Cable

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

용량이 큰 Cable로, 일반 Cable의 8채널과 달리 32채널을 전달할 수 있습니다. 다만 Bus를 직접 부착할 수 없으므로 Bus나 Panel을 사용하려면 먼저 <ItemLink id="fluix_glass_cable" /> 또는 <ItemLink id="fluix_smart_cable" /> 같은 작은 Cable로 연결해야 합니다.

Dense Cable은 채널의 "최단 경로" 규칙에 일부 영향을 줍니다. 채널은 가장 가까운 Dense Cable까지 이동한 뒤, Dense Cable을 따라 Controller까지 최단 경로로 이동합니다.

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

## Smart Cable

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

Smart Cable은 <ItemLink id="fluix_covered_cable" />과 외형이 비슷하지만, Cable의 검은 줄을 따라 빛나는 선으로 채널 사용량을 보여주는 진단 기능이 있습니다. 일반 Smart Cable에서는 처음 4채널이 Cable 색상으로, 다음 4채널이 흰색 선으로 표시됩니다. Dense Smart Cable에서는 선 하나가 채널 4개를 나타냅니다.

<ItemLink id="controller" />가 있는 네트워크에서는 선이 채널의 실제 이동 경로를 나타냅니다.

Controller가 없는 임시 네트워크에서는 해당 Cable을 통과하는 채널 수가 아니라 네트워크 전체에서 사용 중인 채널 수가 표시됩니다.

Smart Cable도 <ItemLink id="fluix_glass_cable" />과 같은 방식으로 색을 바꿀 수 있습니다.

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />
