---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Controller
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# Controller

<BlockImage id="controller" p:state="online" scale="8" />

Controller는 [ME Network](../ae2-mechanics/me-network-connections.md)의 연결을 관리하는 중심 장치입니다.
Controller가 없는 네트워크는 임시 네트워크로 취급되며, [채널을 사용하는 장치](../ae2-mechanics/devices.md)를 최대 8개까지만 연결할 수 있습니다.

하나의 [ME Network](../ae2-mechanics/me-network-connections.md)에 Controller를 두 개 이상 별도로 설치할 수는 없습니다.

Controller는 각 면에서 [채널](../ae2-mechanics/channels.md)을 32개씩 제공합니다.

Controller 블록 하나를 작동하는 데 6 AE/t가 필요합니다.
각 블록에는 8,000 AE를 저장할 수 있지만, 큰 네트워크에서는 추가 에너지 저장 장치가 필요할 수 있습니다.
자세한 내용은 [에너지](../ae2-mechanics/energy.md) 페이지를 참고하세요.

여러 Controller 블록을 연결해 비교적 자유로운 형태의 다중 블록 구조를 만들 수 있습니다.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

다만 다음 규칙을 지켜야 합니다.

1. 같은 [ME Network](../ae2-mechanics/me-network-connections.md)의 Controller 블록은 모두 서로 이어져 있어야 합니다. 연결이 끊어지면 빨간색으로 변합니다.
2. 전체 크기는 7×7×7블록을 넘을 수 없습니다. 초과하면 빨간색으로 변합니다.
3. 한 Controller 블록에 인접한 Controller가 연속으로 2개 붙는 방향은 최대 한 축이어야 합니다. 규칙을 어기면 해당 블록이 비활성화되고 빨간색으로 변합니다.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

모든 규칙을 지키고 전력이 공급되면 Controller가 빛나면서 색상을 바꿉니다.

Controller를 우클릭하면 <ItemLink id="network_tool" />과 동일한 관리 화면이 열립니다.

## 제작법

<RecipeFor id="controller" />
