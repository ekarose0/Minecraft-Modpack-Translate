---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Inscriber
  icon: inscriber
  position: 310
categories:
- machines
item_ids:
- ae2:inscriber
---

# Inscriber

<BlockImage id="inscriber" scale="8" />

Inscriber는 회로와 [processors](processors.md)를 [Press](presses.md)로 압인하거나 여러 재료를 가루로 분쇄합니다. AE나 Fabric/Forge Energy(E/FE)를 모두 받을 수 있습니다. 방향별 입출력 모드를 사용하면 아이템을 투입한 면에 따라 서로 다른 슬롯에 들어갑니다. 자동화를 위해 <ItemLink id="certus_quartz_wrench" />로 회전할 수 있으며, 제작 결과물을 인접한 인벤토리로 자동 배출하도록 설정할 수도 있습니다.

입력 버퍼의 크기를 조절할 수 있습니다. 예를 들어 하나의 저장 공간에서 여러 Inscriber에 재료를 공급할 때 버퍼를 작게 설정하면 첫 번째 장치가 64개를 독점하지 않고 재료가 고르게 분배됩니다.

네 종류의 회로 Press는 [processors](processors.md)를 제작할 때 사용합니다.

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

Name Press를 사용하면 모루처럼 아이템에 이름을 붙일 수 있습니다. <ItemLink id="pattern_access_terminal" />의 장치를 구분하거나 표시할 때 유용합니다.

<ItemImage id="name_press" scale="4" />

## 설정

* 방향별 입출력 모드를 켜거나, 어느 면에서든 아이템을 넣으면 내부 필터가 자동으로 슬롯을 결정하게 할 수 있습니다. 방향별 입출력을 끈 경우 위아래 슬롯의 아이템을 자동으로 꺼낼 수 없습니다.
* 완성품을 인접 인벤토리로 자동 배출하도록 설정할 수 있습니다.
* 입력 버퍼 용량을 조절할 수 있습니다. 큰 버퍼는 수동으로 사용하는 Inscriber에, 작은 버퍼는 여러 대를 병렬로 자동화하는 데 적합합니다.

## 화면과 방향별 입출력

방향별 입출력 모드에서는 아이템을 넣거나 빼는 면에 따라 각 슬롯이 구분됩니다.

![Inscriber GUI](../assets/diagrams/inscriber_gui.png) ![Inscriber Sides](../assets/diagrams/inscriber_sides.png)

A. **위쪽 입력:** Inscriber 윗면에서 접근하며 아이템을 넣거나 꺼낼 수 있습니다.

B. **가운데 입력:** 왼쪽·오른쪽·앞쪽·뒤쪽 면에서 넣을 수 있지만 꺼낼 수는 없습니다.

C. **아래쪽 입력:** 아랫면에서 접근하며 아이템을 넣거나 꺼낼 수 있습니다.

D. **결과물:** 왼쪽·오른쪽·앞쪽·뒤쪽 면에서 꺼낼 수 있지만 아이템을 넣을 수는 없습니다.

## 간단한 자동화

방향별 입출력과 회전 기능을 활용하면 다음과 같이 Inscriber를 반자동화할 수 있습니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/inscriber_hopper_automation.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

방향별 입출력을 끈 경우에는 일반적인 아이템 배관으로 재료를 넣고 결과물을 빼도 됩니다.

## 업그레이드

Inscriber는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

*   <ItemLink id="speed_card" />

## 제작법

<RecipeFor id="inscriber" />
