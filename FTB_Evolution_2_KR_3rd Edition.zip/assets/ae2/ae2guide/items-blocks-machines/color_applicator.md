---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Color Applicator
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# Color Applicator

<ItemImage id="color_applicator" scale="4" />

Color Applicator는 [케이블](cables.md), 양털, 테라코타, 유리, 콘크리트처럼 색을 바꿀 수 있는 블록을 칠하는 도구입니다. [Paintball](paintballs.md) 또는 염료를 사용하며, 눈덩이로 케이블의 색이나 블록에 묻은 Paintball 얼룩을 지울 수 있습니다.

<ItemLink id="charger" />로 에너지를 다시 충전할 수 있습니다.

Color Applicator는 [저장 셀](storage_cells.md)처럼 물감을 저장합니다. <ItemLink id="me_chest" />의 저장 셀 슬롯에 도구를 넣으면 물감 저장 공간을 쉽게 채울 수 있습니다.

대상을 우클릭하면 현재 선택한 색을 적용합니다. Shift를 누른 채 마우스 휠을 돌리거나 대상이 없는 곳을 우클릭하면 색을 변경할 수 있습니다.

## 업그레이드

Color Applicator는 [업그레이드](upgrade_cards.md)를 지원하며 <ItemLink id="cell_workbench" />를 통해 장착합니다.

* <ItemLink id="equal_distribution_card" />: 종류마다 동일한 셀 바이트 공간을 배정하여 하나의 종류가 전체 용량을 차지하지 못하게 합니다.
* <ItemLink id="void_card" />: 셀 또는 해당 종류에 할당된 공간이 가득 찼을 때 들어오는 아이템을 삭제합니다. 파티션 설정에 주의하세요.
* <ItemLink id="energy_card" />: 배터리 용량을 늘립니다.

## 제작법

<RecipeFor id="color_applicator" />
