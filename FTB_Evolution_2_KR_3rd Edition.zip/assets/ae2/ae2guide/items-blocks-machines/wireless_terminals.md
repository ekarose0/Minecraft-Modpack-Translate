---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wireless Terminals
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
- ae2:wireless_crafting_terminal
---

# Wireless Terminal

<Row>
  <ItemImage id="wireless_terminal" scale="4" />

  <ItemImage id="wireless_crafting_terminal" scale="4" />
</Row>

Wireless Terminal은 일반 유선 [terminals](terminals.md)의 휴대용 버전입니다. 유선 장치와 화면이 같지만 <ItemLink id="view_cell" />을 넣는 슬롯 대신 [업그레이드 카드](upgrade_cards.md)을 넣는 슬롯이 있습니다.

네트워크와 연동하려면 해당 네트워크에 연결된 <ItemLink id="wireless_access_point" />의 오른쪽 위 슬롯(무선 단말기 그림과 아래쪽 화살표가 있는 슬롯)에 Terminal을 넣으세요.

작동하려면 <ItemLink id="wireless_access_point" />의 통신 범위 안에 있어야 합니다.

<ItemLink id="charger" />에서 에너지를 충전할 수 있습니다.

# Wireless Terminal

<ItemImage id="wireless_terminal" scale="4" />

기본 Terminal의 휴대용 버전입니다. [network's storage](../ae2-mechanics/import-export-storage.md)의 저장 내용을 확인하거나 이용하고, [자동 제작](../ae2-mechanics/autocrafting.md) 설비에 제작을 요청할 수 있습니다. <ItemLink id="wireless_access_point" />의 범위 안이라면 어디서든 작동합니다.

## 화면 구성

[terminals](terminals.md) 참고

## 업그레이드

Wireless Terminal은 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="energy_card" />: 배터리 용량을 늘립니다.

## 제작법

<RecipeFor id="wireless_terminal" />

# Wireless Crafting Terminal

<ItemImage id="wireless_crafting_terminal" scale="4" />

Wireless Crafting Terminal은 일반 Wireless Terminal과 설정 및 화면 구성은 같지만 제작대 칸이 추가됩니다. 이 칸은 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에서 재료를 자동으로 채웁니다. 결과물을 Shift+클릭할 때는 주의하세요.

## 화면 구성

[terminals](terminals.md) 참고

## 업그레이드

Wireless Crafting Terminal은 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="energy_card" />: 배터리 용량을 늘립니다.

## 제작법

<RecipeFor id="wireless_crafting_terminal" />
