---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial IO Port
  icon: spatial_io_port
  position: 210
categories:
- devices 
item_ids:
- ae2:spatial_io_port
---

# Spatial IO Port

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

Spatial IO Port는 [Spatial IO](../ae2-mechanics/spatial-io.md)에 사용하는 [Spatial Cell](spatial_cells.md)을 장착하고 공간 입출력 작업을 제어하는 장치입니다.

자동화를 원한다면 호퍼나 AE2 Bus 등 아이템 운송 장치를 사용해 Cell을 넣거나 꺼낼 수 있습니다.

## 제작법

<RecipeFor id="spatial_io_port" />
