---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Interface 사용법
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# Interface

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

Interface는 작은 Chest와 유체 탱크처럼 작동합니다. 슬롯에 설정한 재고 수량에 맞춰 [네트워크 저장소](../ae2-mechanics/import-export-storage.md)에서 아이템을 가져오거나 다시 돌려보냅니다. 이 작업을 게임 틱 한 번에 처리하려 하므로 틱당 최대 9스택을 채우거나 비울 수 있습니다. 빠른 아이템 파이프가 있다면 매우 빠른 입출력 수단입니다.

일반 유체 탱크는 대부분 한 종류만 저장하지만 Interface는 아이템뿐 아니라 유체도 최대 9종까지 저장할 수 있습니다. 기본적으로 추가 기능이 있는 Chest 또는 다중 유체 탱크이며, 네트워크에 연결하지 않으면 자동 재고 관리 기능을 비활성화할 수 있습니다. 여러 종류를 소량씩 보관할 때 유용합니다.

## Interface 내부 작동 원리

Interface는 사실상 매우 빠른 <ItemLink id="import_bus" />와 <ItemLink id="export_bus" />, 여러 <ItemLink id="level_emitter" />가 붙은 Chest/탱크라고 생각하면 됩니다.

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        요청한 재고 수량을 제어하는 여러 Level Emitter
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        요청한 재고 수량을 제어하는 여러 Level Emitter
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        게임 틱마다 1스택을 옮기는 고속 Import Bus 여러 개
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/import_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        게임 틱마다 1스택을 옮기는 고속 Export Bus 여러 개
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/export_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        독립된 내부 슬롯 9개
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## 다른 장치와의 특수 상호작용

Interface는 다른 AE2 [장치](../ae2-mechanics/devices.md)와 함께 사용할 때 특별한 기능을 제공합니다.

설정하지 않은 Interface에 <ItemLink id="storage_bus" />를 연결하면, Interface가 속한 [네트워크 저장소](../ae2-mechanics/import-export-storage.md) 전체를 Storage Bus 쪽 네트워크에 보여줍니다. 마치 거대한 Chest에 Storage Bus를 붙인 것과 같습니다. Interface 필터 슬롯에 유지할 아이템을 지정하면 이 기능은 비활성화됩니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

[서브네트워크](../ae2-mechanics/subnetworks.md)의 Interface는 Pattern Provider와도 특별하게 작동합니다. Interface가 설정되지 않았다면 Provider는 Interface의 내부 저장 공간을 거치지 않고 서브네트워크의 [저장소](../ae2-mechanics/import-export-storage.md)로 재료를 직접 보냅니다. 따라서 Interface에 제작 재료가 쌓이지 않으며, 저장 공간이 생길 때까지 다음 제작 묶음을 투입하지 않습니다.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface(전체 블록형이 아닌 평면형이어야 함)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Pattern Provider가 재료를 공급할 위치(여러 기계 또는 한 기계의 여러 면)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## 종류

Interface에는 일반형과 평면형/[케이블 부착형](../ae2-mechanics/cable-subparts.md) 두 종류가 있습니다. 종류에 따라 인벤토리에 접근할 수 있는 면과 네트워크를 연결하는 면이 달라집니다.

*   일반형 Interface는 모든 면에서 아이템을 넣고 꺼내거나 인벤토리에 접근할 수 있습니다. 대부분의 AE2 기계처럼 Cable 역할을 하여 모든 면으로 네트워크를 연결합니다.

*   평면형 Interface는 [케이블 부착형 부품](../ae2-mechanics/cable-subparts.md)이므로 같은 Cable에 여러 개를 설치할 수 있어 공간을 절약합니다. 앞면에서 아이템을 넣고 꺼내거나 인벤토리에 접근할 수 있지만, 그 면으로 네트워크 연결을 전달하지는 않습니다.

제작대에서 일반형과 평면형 Interface를 서로 전환할 수 있습니다.

## 설정

Interface 위쪽 슬롯은 내부에 유지할 아이템을 지정합니다. 슬롯에 아이템을 놓거나 JEI/REI에서 끌어다 놓으면 수량을 설정할 수 있는 렌치 아이콘이 나타납니다.

Bucket이나 Fluid Tank 같은 유체 용기를 들고 우클릭하면 용기 아이템 대신 내부 유체를 필터로 지정할 수 있습니다.

슬롯을 재고 유지 모드로 설정하면 외부 기계가 해당 슬롯에 다른 아이템을 넣는 것도 차단됩니다.

## Upgrades

Interface는 다음 [Upgrade Card](upgrade_cards.md)를 지원합니다.

*   <ItemLink id="fuzzy_card" /> 내구도에 따라 필터링하거나 아이템 NBT를 무시할 수 있습니다.
*   <ItemLink id="crafting_card" /> Interface가 필요한 아이템을 얻도록 [자동 제작](../ae2-mechanics/autocrafting.md) 시스템에 제작을 요청합니다. 제작을 요청하기 전에 저장소에 해당 아이템이 있는지 먼저 확인하여 가져옵니다.

## 우선순위

GUI 오른쪽 위의 렌치 아이콘을 눌러 우선순위를 설정할 수 있습니다. 우선순위가 높은 Interface가 낮은 Interface보다 먼저 아이템을 공급받습니다.

## 제작법

<Recipe id="network/blocks/interfaces_interface" />

<RecipeFor id="cable_interface" />
