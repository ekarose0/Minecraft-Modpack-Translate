---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Molecular Assembler
  icon: molecular_assembler
  position: 310
categories:
- machines
item_ids:
- ae2:molecular_assembler
---

# Molecular Assembler

<BlockImage id="molecular_assembler" scale="8" />

Molecular Assembler는 투입된 아이템을 이용해 인접한 <ItemLink id="pattern_provider" />가 지시한 작업이나 내부에 넣은 <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" />, <ItemLink id="stonecutting_pattern" />의 제작법을 수행합니다. 결과물은 인접한 인벤토리로 내보냅니다.

이 예시는 참나무 원목 1개를 참나무 판자 4개로 만드는 패턴을 넣은 Assembler입니다. 위쪽 호퍼로 원목을 보내면 판자를 제작해 아래쪽 호퍼로 배출합니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/standalone_assembler.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Molecular Assembler의 주요 용도

주요 용도는 <ItemLink id="pattern_provider" /> 옆에 설치해 자동 제작하는 것입니다. 이 경우 Pattern Provider는 재료와 함께 해당 패턴의 정보를 인접한 Assembler에 전달합니다. Assembler가 완성품을 인접한 인벤토리로 자동 배출하므로, Pattern Provider의 반환 슬롯에 결과물이 들어갑니다. 따라서 Pattern Provider 옆에 Assembler를 붙이는 것만으로 제작 패턴을 자동화할 수 있습니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 업그레이드

Molecular Assembler는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

*   <ItemLink id="speed_card" />

## 제작법

<RecipeFor id="molecular_assembler" />

## 주의사항

Optifine은 '인접 인벤토리로 결과물 내보내기' 기능을 망가뜨리므로 대부분의 Assembler 자동 제작 설비가 작동하지 않을 수 있습니다.
