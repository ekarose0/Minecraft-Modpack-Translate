---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Guide
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# Guide

<ItemImage id="guide" scale="8" />

### 지금 읽고 계신 AE2 가이드북입니다. AE2 사용법을 알아볼 때 활용하세요.

* 왼쪽 사이드바에서 목차를 확인할 수 있습니다.
* 여러 페이지에 조작 가능한 장면이 포함되어 있습니다. 장면 옆에 ![Plus](../assets/diagrams/plus.png) 및 ![Minus](../assets/diagrams/minus.png) 확대·축소 버튼이 있다면 카메라를 회전하거나 이동할 수 있습니다.
  왼쪽 버튼을 누른 채 드래그하면 회전하고, 오른쪽 버튼을 누른 채 드래그하면 화면이 이동합니다.

## 제작법

<RecipeFor id="guide" />
