---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Network Tool
  icon: network_tool
  position: 410
categories:
- tools
item_ids:
- ae2:network_tool
---

# Network Tool

<ItemImage id="network_tool" scale="4" />

Network Tool은 [Wrench](wrench.md)를 개조한 도구로, 네트워크 진단 정보를 표시하고 [업그레이드 카드](upgrade_cards.md)를 보관할 수 있습니다. 블록을 빠르게 분해하거나 케이블에서 [하위 부품](../ae2-mechanics/cable-subparts.md)를 떼어 내는 기능은 유지되지만, 블록 방향을 회전하지는 못합니다.

[업그레이드 카드](upgrade_cards.md)를 보관하는 슬롯이 9개 있으며, 도구가 인벤토리 어디에 있든 AE2 장치 화면에서 보관된 업그레이드 카드를 사용할 수 있습니다.

네트워크의 아무 부분이나 우클릭하면 <ItemLink id="controller" />를 우클릭했을 때와 비슷한 진단 창이 열립니다. 이 창에서는 다음 정보를 볼 수 있습니다.

* 네트워크에서 사용 중인 채널 수
* 에너지 단위를 AE 또는 E/FE로 표시할지 정하는 전체 설정
* 네트워크에 저장된 [에너지](../ae2-mechanics/energy.md)와 최대 저장 용량
* 네트워크로 유입되는 에너지와 소비되는 에너지
* 연결된 모든 [장치](../ae2-mechanics/devices.md) 및 구성 요소 목록

[서브네트워크](../ae2-mechanics/subnetworks.md)을 구성할 때 서로 다른 케이블이나 장치가 같은 네트워크에 속하는지 확인하는 데도 유용합니다.

## Facade 숨기기

Network Tool을 어느 손에든 들면 <ItemLink id="facade" />가 보이지 않게 됩니다.

Facade를 제거하지 않고도 뒤쪽 블록과 상호작용할 수 있습니다.

## 제작법

<RecipeFor id="network_tool" />
