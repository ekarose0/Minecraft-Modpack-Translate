---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Formation Plane
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# Formation Plane

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

Formation Plane은 블록을 설치하거나 아이템을 떨어뜨립니다. 넣기 전용 <ItemLink id="storage_bus" />처럼 작동하며, [장치](../ae2-mechanics/devices.md) 등이 아이템을 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에 넣을 때 <ItemLink id="import_bus" />와 <ItemLink id="interface" />에서처럼 해당 물품을 월드에 배치합니다.

<GameScene zoom="8" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

이 장치의 사용 방식은 [pipe subnets](../example-setups/pipe-subnet.md)의 Import Bus → Storage Bus 또는 Interface → Storage Bus 연결과 비슷합니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

이 [device](../ae2-mechanics/devices.md)은 [pipe subnets](../example-setups/pipe-subnet.md) 등의 구성에서 Storage Bus가 사용하는 방식을 활용합니다. 물품을 단순히 옮기지 않고 월드에 놓거나 블록으로 설치하려면 Storage Bus 대신 Formation Plane을 사용할 수 있습니다.

Formation Plane은 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

**청크 보호 구역에서 가짜 플레이어(Fake Player)를 반드시 허용하세요!**

## 필터

기본적으로 모든 아이템을 배치하거나 떨어뜨릴 수 있습니다. 필터 슬롯에 아이템을 등록하면 허용 목록으로 작동하여 지정한 물품만 배치합니다.

실제 아이템이 없어도 JEI/REI에서 아이템이나 유체를 필터 슬롯으로 끌어와 등록할 수 있습니다.

양동이나 유체 탱크를 들고 우클릭하면 용기 대신 내부 유체를 필터로 지정합니다.

## 우선순위

화면 오른쪽 위의 렌치 아이콘을 눌러 우선순위를 설정할 수 있습니다. 네트워크로 들어온 물품은 우선순위가 높은 저장 공간부터 사용합니다.

## 설정

* 블록을 월드에 설치할지, 아이템 형태로 떨어뜨릴지 선택할 수 있습니다.

## 업그레이드

Formation Plane은 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="capacity_card" />: 필터 슬롯 수를 늘립니다.
* <ItemLink id="fuzzy_card" />: 내구도에 따라 필터링하거나 NBT를 무시할 수 있습니다.
* <ItemLink id="inverter_card" />: 허용 목록을 차단 목록으로 전환합니다.

## 제작법

<RecipeFor id="formation_plane" />
