---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: View Cell
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# View Cell

<ItemImage id="view_cell" scale="2" />

View Cell은 [Terminal](terminals.md)에 표시할 아이템을 필터링하는 데 사용됩니다. <ItemLink id="cell_workbench" />에서 필터 대상을 지정할 수 있습니다.

예를 들어 Terminal에 특정 석재 건축 자재만 표시하고 싶다면 View Cell에 해당 자재들을 지정한 다음 Terminal에 넣으세요. 지정된 아이템만 표시됩니다.

View Cell의 필터는 합산 적용됩니다. 참나무 판자를 지정한 View Cell과 조약돌을 지정한 View Cell을 함께 넣으면 두 아이템이 모두 표시됩니다.

## 제작법

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />
