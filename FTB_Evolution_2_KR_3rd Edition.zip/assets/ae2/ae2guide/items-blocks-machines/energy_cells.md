---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Energy Cells
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# Energy Cell

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

Energy Cell은 네트워크의 [에너지](../ae2-mechanics/energy.md) 저장 용량을 늘립니다. 에너지를 비축해 두면 대량의 아이템을 넣거나 꺼낼 때 순간적으로 증가하는 소비량을 완화할 수 있습니다. 또한 태양광 발전의 야간처럼 발전이 중단되어도 네트워크를 유지하거나, [공간 저장](../ae2-mechanics/spatial-io.md)을 사용할 때 발생하는 매우 큰 순간 소비량을 감당할 수 있습니다.

## 충전 표시 막대

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

셀 측면의 막대 수는 저장된 에너지 비율을 나타냅니다.

* 25% 미만: 0칸
* 25~50%: 1칸
* 50~75%: 2칸
* 75~99%: 3칸
* 99% 초과: 4칸

## 셀 종류

* <ItemLink id="energy_cell" />: 최대 200,000 AE를 저장합니다. 일반적인 네트워크의 순간 전력 소비를 감당하기에 하나만으로도 대부분 충분합니다.
* <ItemLink id="dense_energy_cell" />: 최대 1,600,000 AE를 저장합니다. 저장된 전력으로 네트워크를 오래 운용하거나 대규모 [공간 저장](../ae2-mechanics/spatial-io.md) 시스템의 순간 소비량을 감당할 때 사용합니다.
* <ItemLink id="creative_energy_cell" />: 시험용 크리에이티브 아이템으로 무제한 전력을 공급합니다.

## 제작법

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>
