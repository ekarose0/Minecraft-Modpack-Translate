---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Crystal
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# Fluix Crystal

<ItemImage id="fluix_crystal" scale="4" />

*"Fluix Crystal은 에너지를 한 형태에서 다른 형태로 흡수·변환하는 독특한 능력을 지니며, 모든 Matter Energy 기술의 기반이 됩니다."*

AE2 블록과 [장치](../ae2-mechanics/devices.md), 아이템을 만드는 주요 재료 중 하나입니다. Nether Quartz, Redstone, <ItemLink id="charged_certus_quartz_crystal" />을 물에 던져 제작합니다.

<ItemLink id="formation_plane" />과 <ItemLink id="annihilation_plane" />을 사용하면 이 과정을 [자동화](../example-setups/throw-in-water-automation.md)할 수 있습니다.

## 제작법

<Row>
  <Recipe id="transform/fluix_crystals" />

  <Recipe id="transform/fluix_crystal" />

  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
