---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Memory Card
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# Memory Card

<ItemImage id="memory_card" scale="4" />

Memory Card는 AE2 [장치](../ae2-mechanics/devices.md) 사이에서 설정을 복사·붙여넣거나 [P2P Tunnel](p2p_tunnels.md)을 연결할 때 사용합니다. 장치에 [Upgrade Card](upgrade_cards.md) 설정을 붙여넣을 수도 있습니다.

- Shift+우클릭: 설정을 복사하거나 새로운 P2P 연결 주파수를 생성합니다.
- 우클릭: 저장된 설정, Upgrade Card 또는 연결 주파수를 붙여넣습니다.

## 제작법

<RecipeFor id="memory_card" />
