---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial Cells
  icon: spatial_storage_cell_128
  position: 410
categories:
- tools
item_ids:
- ae2:spatial_storage_cell_2
- ae2:spatial_storage_cell_16
- ae2:spatial_storage_cell_128
- ae2:spatial_cell_component_2
- ae2:spatial_cell_component_16
- ae2:spatial_cell_component_128
---

# Spatial Storage Cell

  <Row>
    <ItemImage id="spatial_storage_cell_2" scale="4" />

    <ItemImage id="spatial_storage_cell_16" scale="4" />

    <ItemImage id="spatial_storage_cell_128" scale="4" />
  </Row>

Spatial Storage Cell은 [공간 부피 저장](../ae2-mechanics/spatial-io.md)에 사용하며, <ItemLink id="spatial_io_port" />에 넣어 작동합니다.

일반 [저장 셀](../items-blocks-machines/storage_cells.md)과 달리 Spatial Storage Cell은 다시 포맷할 수 없습니다.

**한 번 사용한 Spatial Storage Cell은 초기화, 재포맷 또는 크기 변경이 불가능합니다.** 다른 크기의 공간을 저장하려면 새 셀을 제작하세요.

## 제작법

  <Row>
    <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_16_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_128_cubed_storage" />
  </Row>

# Housing

Spatial Component와 Housing을 결합하거나, Spatial Component 주위를 Housing 제작 재료로 둘러싸 셀을 만들 수 있습니다.

<Row>
  <Recipe id="network/cells/spatial_storage_cell_2_cubed" />

  <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />
</Row>

Housing 자체는 다음과 같이 제작합니다.

  <RecipeFor id="item_cell_housing" />

# Spatial Component

Spatial Component는 Spatial Storage Cell의 핵심 부품입니다. 등급이 올라갈 때마다 저장 가능한 공간의 부피가 8배씩 증가합니다.

  <Row>
    <RecipeFor id="spatial_cell_component_2" />

    <RecipeFor id="spatial_cell_component_16" />

    <RecipeFor id="spatial_cell_component_128" />
  </Row>
