---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Crystal Resonance Generator
  icon: crystal_resonance_generator
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:crystal_resonance_generator
---

# Crystal Resonance Generator

<BlockImage id="crystal_resonance_generator" scale="8" />

이 장치는 연료 없이 ME Network에 에너지를 공급합니다. 장치가 만들어 내는 결정 진동 때문에 네트워크 하나에 1대만 사용할 수 있습니다. 이 진동은 <ItemLink id="quartz_fiber" />를 통해서도 전달됩니다.

**발전 속도:** <ae2:ConfigValue name="crystalResonanceGeneratorRate"/> AE/t

## 제작법

<RecipeFor id="crystal_resonance_generator" />
