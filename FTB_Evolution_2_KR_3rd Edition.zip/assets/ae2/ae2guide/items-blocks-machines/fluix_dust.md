---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Dust
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# Fluix Dust

<ItemImage id="fluix_dust" scale="4" />

<ItemLink id="inscriber" />로 <ItemLink id="fluix_crystal" />을 분쇄해 얻는 가루입니다. 여러 AE2 기계와 부품 제작에 사용됩니다.

## 제작법

<RecipeFor id="fluix_dust" />
