---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Drive
  icon: drive
  position: 210
categories:
- devices
item_ids:
- ae2:drive
---

# ME Drive

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/drive.snbt" />
</GameScene>

ME Drive는 [device](../ae2-mechanics/devices.md)이며, [저장 셀](storage_cells.md)을 장착해 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에 사용할 수 있습니다. 저장 셀을 최대 10개까지 넣을 수 있습니다.

호퍼나 AE2 버스 등 일반적인 아이템 운송 수단으로 셀을 넣거나 꺼낼 수 있습니다.

<ItemLink id="certus_quartz_wrench" />를 사용해 방향을 회전할 수 있습니다.

## 셀 상태 표시등

Drive에 장착된 각 셀의 LED는 다음 상태를 표시합니다.

| 색상 | 상태 |
| :-- | :-- |
| 녹색 | 비어 있음 |
| 파란색 | 일부 내용물이 저장되어 있음 |
| 주황색 | [Types](../ae2-mechanics/bytes-and-types.md)가 가득 차서 새로운 종류를 추가할 수 없음 |
| 빨간색 | [Bytes](../ae2-mechanics/bytes-and-types.md)가 가득 차서 아이템을 더 넣을 수 없음 |
| 검은색 | 전원이 없거나 Drive에 [채널](../ae2-mechanics/channels.md)이 없음 |

## 우선순위

화면 오른쪽 위의 렌치 아이콘을 눌러 우선순위를 설정합니다. 네트워크에 들어온 아이템은 우선순위가 가장 높은 저장 공간부터 배치됩니다. 우선순위가 같다면 해당 아이템이 이미 들어 있는 저장 공간이 우선합니다. [파티션 설정](cell_workbench.md) 셀은 같은 우선순위의 다른 저장 공간과 비교할 때 그 아이템을 이미 보관하고 있는 것으로 취급됩니다. 아이템을 꺼낼 때는 우선순위가 가장 낮은 저장 공간부터 꺼냅니다. 따라서 입출력이 반복되면 높은 우선순위 저장 공간이 채워지고 낮은 우선순위 공간은 비워집니다.

## 제작법

<RecipeFor id="drive" />
