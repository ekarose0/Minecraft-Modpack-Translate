---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charger
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# Charger

<BlockImage id="charger" scale="8" />

Charger는 호환되는 도구와 <ItemLink id="certus_quartz_crystal" />를 충전하는 장치입니다.

윗면이나 아랫면에 AE2 [케이블](cables.md) 또는 다른 모드의 전력 케이블을 연결해 전원을 공급할 수 있습니다. AE와 Forge Energy(FE)를 모두 받습니다. 아이템은 어느 면에서나 넣고 뺄 수 있지만 완성품만 꺼낼 수 있어, 일반 Certus Quartz가 충전 전에 빠져나가지 않도록 별도 필터를 설정할 필요가 없습니다. 자동화할 때는 <ItemLink id="certus_quartz_wrench" />로 방향을 돌릴 수 있습니다.

<ItemLink id="charged_certus_quartz_crystal" />는 <ItemLink id="certus_quartz_crystal" />를 충전해 만들 수 있고, <ItemLink id="meteorite_compass" />는 <ItemLink id="minecraft:compass" />를 충전해 만들 수 있습니다.

수동으로 작동하려면 위나 아래에 <ItemLink id="crank" />를 부착하고 충전이 끝날 때까지 우클릭하세요.

[Fluix Researcher](fluix_researcher.md)의 작업대로도 사용됩니다.

## 간단한 자동화

장치의 방향을 바꿀 수 있으므로 다음과 같이 반자동 Charger를 구성할 수 있습니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 제작법

<RecipeFor id="charger" />
