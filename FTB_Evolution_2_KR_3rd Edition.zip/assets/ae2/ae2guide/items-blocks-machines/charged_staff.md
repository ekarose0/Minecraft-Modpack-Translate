---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charged Staff
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# Charged Staff

<ItemImage id="charged_staff" scale="4" />

Charged Staff는 끝에 <ItemLink id="charged_certus_quartz_crystal" />이 달린 막대기입니다. 공격할 때마다 300 AE를 소비하며 6의 피해를 줍니다.

<ItemLink id="charger" />를 사용해 에너지를 다시 충전할 수 있습니다.

## 제작법

<RecipeFor id="charged_staff" />
