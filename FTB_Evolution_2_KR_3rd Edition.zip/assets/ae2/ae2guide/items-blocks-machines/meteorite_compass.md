---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Meteorite Compass
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# Meteorite Compass

<ItemImage id="meteorite_compass" scale="4" />

Meteorite Compass는 가장 가까운 <ItemLink id="mysterious_cube" />의 위치를 가리킵니다. 따라서 가장 가까운 [운석](../ae2-mechanics/meteorites.md)을 찾는 데 사용할 수 있습니다. AE2를 시작할 때 가장 먼저 제작하면 좋은 아이템 중 하나입니다.

## 제작법

<RecipeFor id="meteorite_compass" />
