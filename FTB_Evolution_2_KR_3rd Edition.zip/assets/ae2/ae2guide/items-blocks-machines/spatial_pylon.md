---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial Pylon
  icon: spatial_pylon
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_pylon
---

# Spatial Pylon

<BlockImage id="spatial_pylon" p:powered_on="true" scale="8" />

Spatial Pylon은 [Spatial IO](../ae2-mechanics/spatial-io.md)에서 공간 필드를 형성하고 영향을 받을 영역의 크기를 지정하는 데 사용됩니다.

연속으로 연결된 Pylon 한 줄마다 [채널](../ae2-mechanics/channels.md) 1개를 사용합니다.

정상적으로 작동하려면 Pylon을 최소 2블록 이상 연속으로 설치해야 합니다.

## 제작법

<RecipeFor id="spatial_pylon" />
