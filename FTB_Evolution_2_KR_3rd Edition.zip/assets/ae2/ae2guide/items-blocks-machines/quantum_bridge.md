---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quantum Bridge
  icon: quantum_ring
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quantum_link
- ae2:quantum_ring
---

# Quantum Network Bridge

![A formed Quantum Network Bridge](../assets/diagrams/quantum_bridge_demonstration.png)

Quantum Network Bridge는 [네트워크](../ae2-mechanics/me-network-connections.md)를 사실상 거리 제한 없이, 심지어 다른 차원까지 확장합니다. 면마다 케이블을 어떻게 연결했든 합계 32채널을 전송할 수 있으므로 무선 [dense cable](cables.md#dense-cable)처럼 작동합니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_2.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="6 2 3">
        두 연결 지점 사이의 가상 케이블
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

주의: **양쪽 연결 지점 모두 게임에서 로드되어 있어야 합니다.** 거리가 멀다면 <ItemLink id="spatial_anchor" /> 또는 다른 청크 로딩 장치가 필요합니다.

# Quantum Ring

<BlockImage id="quantum_ring" scale="8" />

<ItemLink id="quantum_link" /> 주위에 Quantum Ring 블록 여덟 개를 배치하면 Quantum Network Bridge가 만들어집니다. <ItemLink id="quantum_ring" />와 직접 맞닿은 Quantum Ring 네 개만 네트워크에 연결할 수 있으며, 모서리의 네 블록에는 케이블을 연결할 수 없습니다. <ItemLink id="quantum_link" />를 중심에 배치하세요.

## 제작법

<RecipeFor id="quantum_ring" />

# Quantum Link Chamber

<BlockImage id="quantum_link" scale="8" />

<ItemLink id="quantum_ring" />로 이 블록을 둘러싸면 Quantum Network Bridge가 만들어집니다. 이 블록 자체에는 케이블을 연결할 수 없으며, 브리지가 완성되어야 네트워크의 일부로 인식됩니다.

내부에는 <ItemLink id="quantum_entangled_singularity" /> 하나만 보관할 수 있으며 자동화 장치로 접근할 수 있습니다.

## 제작법

<RecipeFor id="quantum_link" />
