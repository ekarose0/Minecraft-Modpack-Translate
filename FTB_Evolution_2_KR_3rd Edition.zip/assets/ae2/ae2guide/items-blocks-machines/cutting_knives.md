---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cutting Knives
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# Quartz Tools

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

Cutting Knife는 <ItemLink id="name_press" />와 <ItemLink id="cable_anchor" />를 제작할 때 사용합니다.

Name Press를 만들려면 Cutting Knife를 우클릭하고 금속 주괴를 넣으세요. 판에 새길 이름을 입력한 뒤 완성된 판을 꺼내면 됩니다.

## 제작법

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
