---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Level Emitter
  icon: level_emitter
  position: 220
categories:
- devices
item_ids:
- ae2:level_emitter
- ae2:energy_level_emitter
---

# Level Emitter

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/level_emitter.snbt" />
</GameScene>

Level Emitter는 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에 보관된 특정 아이템의 수량에 따라 레드스톤 신호를 출력합니다.

네트워크에 저장된 [에너지](../ae2-mechanics/energy.md)의 양에 따라 신호를 출력하는 다른 버전도 있습니다.

해당 아이템이 없어도 JEI/REI에서 아이템이나 유체를 슬롯으로 끌어와 설정할 수 있습니다.

양동이나 유체 탱크를 들고 우클릭하면 용기 아이템 대신 내부 유체를 필터로 설정합니다.

이 장치는 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

다른 [장치](../ae2-mechanics/devices.md)와 달리 Level Emitter에는 [채널](../ae2-mechanics/channels.md)이 **필요하지 않습니다**.

## 설정

* 지정 수량 "이상" 또는 "미만"일 때 신호를 내보내도록 설정할 수 있습니다.
* <ItemLink id="crafting_card" />를 장착하면 "제작 중일 때 레드스톤 신호 출력" 또는 "제작하도록 레드스톤 신호 출력"을 선택할 수 있습니다.

## 업그레이드

Level Emitter는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="fuzzy_card" />: 내구도별 필터를 설정하거나 아이템 NBT를 무시할 수 있습니다.
* <ItemLink id="crafting_card" />: 제작 관련 기능을 활성화합니다.

## 제작 기능

<ItemLink id="crafting_card" />를 장착하면 Emitter가 제작 모드로 전환됩니다.

이 모드에서는 두 옵션이 활성화됩니다.

첫 번째 "제작 중일 때 레드스톤 신호 출력" 옵션은 [자동 제작](../ae2-mechanics/autocrafting.md)가 <ItemLink id="pattern_provider" />를 통해 지정 아이템을 제작하는 동안 신호를 출력합니다. 실제로 사용 중일 때만 전력 소모가 큰 자동화 설비를 켜는 데 유용합니다.

두 번째 "제작하도록 레드스톤 신호 출력" 옵션은 무한 농장이나 일정 확률로 결과물을 만드는 기계처럼 생산량이 확정적이지 않은 설비에 유용합니다. Emitter의 필터에 등록한 아이템을 제작할 수 있는 가상 [pattern](patterns.md)을 만들어 [자동 제작](../ae2-mechanics/autocrafting.md)에서 사용하게 합니다. **같은 아이템을 제작하는 실제 패턴이 <ItemLink id="pattern_provider" />에 있으면 안 됩니다.**

이 가상 "패턴"은 재료를 정의하거나 고려하지 않습니다. 대신 "Emitter가 레드스톤 신호를 출력하면 언젠가 ME 시스템에 이 아이템이 들어올 것"이라고 알려 줍니다. 재료가 없는 무한 농장을 필요할 때 켜거나 일반 자동 제작으로 표현할 수 없는 [a system that handles recursive recipes](../example-setups/recursive-crafting-setup.md)을 활성화하는 데 사용합니다. 예를 들어 조약돌 복제기가 있다면 "조약돌 1개 → 조약돌 2개" 같은 생산을 연결할 수 있습니다.

## 제작법

<RecipeFor id="level_emitter" />

<RecipeFor id="energy_level_emitter" />
