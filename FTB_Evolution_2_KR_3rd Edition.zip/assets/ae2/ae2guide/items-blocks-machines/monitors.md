---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Monitors
  icon: storage_monitor
  position: 210
categories:
- devices
item_ids:
- ae2:storage_monitor
- ae2:conversion_monitor
---

# Monitor

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/monitors.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Monitor는 별도의 화면을 열지 않고도 특정 아이템이나 유체 한 종류의 정보를 표시하고 상호작용할 수 있는 장치입니다.

장착한 [cable](cables.md)의 색상을 그대로 따릅니다.

바닥이나 천장에 설치한 경우 <ItemLink id="certus_quartz_wrench" />로 방향을 회전할 수 있습니다.

Monitor는 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

# Storage Monitor

선택한 아이템이나 유체 및 그 수량을 표시합니다. 농장 근처 등에 설치하면 편리합니다.

[채널](../ae2-mechanics/channels.md)이 필요하지 **않습니다**.

조작 방법:

* 아이템을 들고 우클릭하거나 유체 용기를 들고 두 번 우클릭해 표시할 아이템·유체를 설정합니다.
* 빈손으로 우클릭해 설정을 지웁니다.
* 빈손으로 Shift+우클릭하면 설정을 잠급니다.

## 제작법

<RecipeFor id="storage_monitor" />

# Conversion Monitor

Conversion Monitor는 Storage Monitor와 비슷하지만 지정한 아이템을 네트워크에 넣거나 꺼낼 수도 있습니다.

지정한 아이템을 [자동 제작](../ae2-mechanics/autocrafting.md)할 수 있고 저장된 수량이 0이라면, 꺼내려고 할 때 대신 제작 수량을 지정하는 화면이 열립니다.

[채널](../ae2-mechanics/channels.md)이 **필요합니다**.

추가 조작 방법:

* 좌클릭하면 설정된 아이템 한 묶음을 꺼냅니다. 저장된 수량이 없으면 제작을 요청합니다.
* 아이템을 들고 우클릭하면 그 아이템을 넣습니다.
* 빈손으로 우클릭하면 인벤토리에 있는 해당 아이템을 모두 넣습니다.

## 제작법

<RecipeFor id="conversion_monitor" />
