---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Crafting CPU Multiblock (Storage, Coprocessor, Monitor, Unit)
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# Crafting CPU

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

Crafting CPU는 제작 요청과 작업을 관리합니다. 여러 단계로 이루어진 제작 작업을 진행하는 동안 중간 재료를 보관하며, 처리할 수 있는 작업 규모와 일부 작업 속도에 영향을 줍니다. 자세한 내용은 [자동 제작](../ae2-mechanics/autocrafting.md)을 참고하세요.

Crafting CPU 하나는 한 번에 작업 하나만 처리합니다. 따라서 Calculation Processor와 Smooth Stone 256개를 동시에 요청하려면 CPU 멀티블록 2개가 필요합니다.

플레이어 요청만 처리하거나 Export Bus·Interface 같은 자동화 요청만 처리하도록 설정할 수 있으며, 둘 다 허용할 수도 있습니다.

CPU를 우클릭하면 제작 상태 화면이 열려 현재 작업의 진행 상황을 확인할 수 있습니다.

## 설정

*   CPU는 플레이어 요청, <ItemLink id="crafting_card" />를 장착한 <ItemLink id="export_bus" /> 같은 자동화 요청 또는 둘 다 받도록 설정할 수 있습니다.

## 구조

Crafting CPU는 멀티블록 구조이며 빈 공간이 없는 직육면체로 구성해야 합니다. 여러 종류의 부품을 조합해 만듭니다.

CPU마다 Crafting Storage 블록이 최소 1개 필요합니다. 가장 작은 CPU는 1k Crafting Storage 하나만으로도 구성할 수 있습니다.

# Crafting Unit

<BlockImage id="crafting_unit" scale="4" />

(선택) Crafting Unit은 다른 부품이 부족할 때 CPU를 빈틈없는 직육면체로 채우는 데 사용합니다. 다른 CPU 부품을 제작할 때도 기본 재료로 사용됩니다.

<RecipeFor id="crafting_unit" />

# Crafting Storage

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />
</Row>

(필수) Crafting Storage는 표준 셀 용량인 1k, 4k, 16k, 64k, 256k로 제공됩니다. 제작에 사용되는 재료와 중간 결과물을 저장하므로, 재료가 많이 필요한 작업을 처리하려면 더 크거나 더 많은 Crafting Storage가 필요합니다.

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# Crafting Co-Processing Unit

<BlockImage id="crafting_accelerator" scale="4" />

(선택) Crafting Co-Processor는 CPU의 처리 틱을 빠르게 하여 <ItemLink id="pattern_provider" />가 재료 묶음을 더 자주 보내도록 합니다. 이를 통해 처리 속도가 빠른 기계에 재료를 원활히 공급할 수 있습니다. 예를 들어 Pattern Provider 주변에 <ItemLink id="molecular_assembler" />를 여러 개 배치하면 단일 Assembler보다 빠르게 재료를 공급하고 주변 Assembler에 작업을 분산할 수 있습니다.

일부 복잡한 제작법은 책장을 만들기 위해 판자와 책을 동시에 제작하는 것처럼 여러 단계를 병렬로 진행할 수 있습니다. CPU를 우클릭하거나 [Terminal](terminals.md)의 망치 아이콘으로 여는 제작 상태 화면에서는 이러한 단계가 "scheduled"로 표시됩니다. Co-Processor를 하나 추가할 때마다 한 단계를 더 병렬로 진행할 수 있으며, 진행 중인 단계는 "crafting"으로 표시됩니다. 다만 실제로는 병렬 단계 수보다 재료 공급 속도를 높이기 위해 더 많은 Co-Processor를 설치하는 경우가 많습니다.

<RecipeFor id="crafting_accelerator" />

# Crafting Monitor

<BlockImage id="crafting_monitor" scale="4" />

(선택) Crafting Monitor는 CPU가 현재 처리하는 작업을 표시합니다. <ItemLink id="color_applicator" />로 화면 색상을 바꿀 수 있습니다.

<RecipeFor id="crafting_monitor" />
