---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Ball
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# Matter Ball

<ItemImage id="matter_ball" scale="4" />

일반 물질을 뭉쳐 만든 구체입니다. <ItemLink id="matter_cannon" />의 탄약이나 [Paintball](paintballs.md) 제작에 사용할 수 있습니다.

<ItemLink id="condenser" />를 Matter Ball 모드로 설정한 뒤 아이템 또는 양동이 256개 분량의 물질을 투입하면 만들 수 있습니다.
