---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz Dust
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# Certus Quartz Dust

<ItemImage id="certus_quartz_dust" scale="4" />

<ItemLink id="inscriber" />로 <ItemLink id="certus_quartz_crystal" />을 분쇄해 얻는 가루입니다. 여러 AE2 재료와 부품 제작에 사용됩니다.

## 제작법

<RecipeFor id="certus_quartz_dust" />
