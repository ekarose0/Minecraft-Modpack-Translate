---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Sky Stone
  icon: sky_stone_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_stone_block
- ae2:smooth_sky_stone_block
---

# Sky Stone

<BlockImage id="sky_stone_block" scale="8" />

[운석](../ae2-mechanics/meteorites.md)을 구성하는 재료입니다. <ItemLink id="sky_stone_tank" />, <ItemLink id="not_so_mysterious_cube" />, <ItemLink id="cell_component_256k" />와 특히 중요한 <ItemLink id="controller" />의 제작법에 사용됩니다.

## 제작법

월드의 최대 건축 높이에서 <ItemLink id="annihilation_plane" />이 위쪽을 향하도록 설치하면 <ItemLink id="sky_dust" />를 얻을 수 있습니다.

<RecipeFor id="sky_stone_block" />

<RecipeFor id="smooth_sky_stone_block" />
