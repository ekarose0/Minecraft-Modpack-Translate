---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Export Bus
  icon: export_bus
  position: 220
categories:
- devices
item_ids:
- ae2:export_bus
---

# Export Bus

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/export_bus.snbt" />
</GameScene>

Export Bus는 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에서 아이템과 유체(애드온에 따라 다른 자원도 포함)를 가져와 맞닿은 인벤토리로 내보냅니다.

지연을 줄이기 위해 한동안 내보낼 물품이 없으면 느리게 작동하는 절전 상태로 전환됩니다. 전송에 성공하면 다시 가속하여 초당 네 번까지 작업합니다.

Export Bus는 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

## 필터

기본적으로 아무 아이템도 내보내지 않습니다. 필터 슬롯에 아이템을 등록하면 허용 목록이 되어 해당 아이템만 내보냅니다.

실제 물품이 없어도 JEI/REI에서 아이템이나 유체를 필터 슬롯으로 끌어와 등록할 수 있습니다.

양동이나 유체 탱크 같은 용기를 들고 우클릭하면 용기가 아닌 내부 유체가 필터로 등록됩니다.

## 업그레이드

Export Bus는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="capacity_card" />: 필터 슬롯 수를 늘립니다.
* <ItemLink id="speed_card" />: 한 번에 전송하는 양을 늘립니다.
* <ItemLink id="fuzzy_card" />: 내구도에 따라 필터링하거나 NBT를 무시할 수 있습니다.
* <ItemLink id="crafting_card" />: 필요한 아이템을 네트워크의 [자동 제작](../ae2-mechanics/autocrafting.md)에 제작 요청합니다. 이미 저장된 아이템을 먼저 사용하거나 언제나 새 제작을 요청하도록 설정할 수 있습니다.
* <ItemLink id="redstone_card" />: 높은 신호, 낮은 신호 또는 펄스마다 한 번 작동하는 레드스톤 제어 기능을 추가합니다.

## 전송 속도

| Acceleration Card 수 | 작업당 아이템 수 |
| :-- | :-- |
| 0 | 1 |
| 1 | 8 |
| 2 | 32 |
| 3 | 64 |
| 4 | 96 |

## 제작법

<RecipeFor id="import_bus" />
