---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz Block
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# Certus Quartz Block

<BlockImage id="quartz_block" scale="8" />

<ItemLink id="certus_quartz_crystal" />을 압축해 보관하는 블록입니다. [Budding Certus Block](budding_certus.md)이나 [장식용 Certus Block](decorative_certus.md)을 만드는 데도 사용할 수 있습니다.

## 제작법

<RecipeFor id="quartz_block" />
