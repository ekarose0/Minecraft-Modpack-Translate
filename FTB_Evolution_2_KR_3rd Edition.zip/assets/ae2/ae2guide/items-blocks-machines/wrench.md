---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wrenches
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# Wrenches

<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />

  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

Wrench는 AE2 장치, 기계, 기타 블록을 회전(우클릭)하거나 분해(Shift+우클릭)하는 데 사용합니다.
[하위 부품](../ae2-mechanics/cable-subparts.md)은 같은 블록의 다른 부품을 부수지 않고 케이블에서 떼어낼 수 있습니다. 케이블만 따로 제거하는 것도 가능합니다.

AE2 블록 중에는 회전할 수 있는 블록이 많습니다. 이 가이드에 회전 가능하다고 명시되어 있지 않아도 실제로 회전할 수 있습니다.

## 제작법

<Row>
  <RecipeFor id="certus_quartz_wrench" />

  <RecipeFor id="nether_quartz_wrench" />
</Row>
