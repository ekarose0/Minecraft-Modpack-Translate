---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Presses
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# Press

<ItemLink id="inscriber" />에서 사용하는 Press는 다섯 종류입니다.

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## Processor Press

Silicon, Logic, Calculation, Engineering Press는 [processors](processors.md) 제작에 사용합니다. 이 네 종류의 Press는 <ItemLink id="mysterious_cube" />를 부숴 얻을 수 있으며, 해당 블록은 [운석](../ae2-mechanics/meteorites.md)에서 발견할 수 있습니다. <ItemLink id="inscriber" />를 사용해 복제하는 것도 가능합니다.

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## Name Press

Name Press는 모루처럼 Inscriber에서 아이템에 이름을 붙이는 데 사용합니다. 한 번에 한 개 또는 두 개의 판을 사용할 수 있으며, 두 개를 사용하면 위쪽 슬롯 이름 다음에 아래쪽 슬롯 이름을 조합해 각인합니다.

제작하려면 <ItemLink id="certus_quartz_cutting_knife" /> 또는 <ItemLink id="nether_quartz_cutting_knife" />를 손에 든 채 우클릭하고 금속 주괴 하나를 넣으세요. 판에 새길 이름을 입력한 다음 완성된 판을 꺼내면 됩니다.
