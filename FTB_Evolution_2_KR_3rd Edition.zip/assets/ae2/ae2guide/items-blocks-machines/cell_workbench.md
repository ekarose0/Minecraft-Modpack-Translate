---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cell Workbench
  icon: cell_workbench
  position: 310
categories:
- machines
item_ids:
- ae2:cell_workbench
---

# Cell Workbench

<BlockImage id="cell_workbench" scale="8" />

Cell Workbench에서는 [저장 셀](storage_cells.md)과 <ItemLink id="view_cell" />의 설정을 변경할 수 있습니다.

[업그레이드 카드](upgrade_cards.md)를 장착하거나 저장할 아이템을 필터링하는 '파티션'을 설정할 수 있습니다.

실제로 해당 아이템이 없어도 JEI/REI에서 아이템이나 유체를 슬롯으로 끌어와 등록할 수 있습니다.

양동이나 유체 탱크 같은 유체 용기를 들고 우클릭하면 용기 아이템 대신 그 안의 유체가 필터로 등록됩니다.

## 설정

Cell Workbench 왼쪽 위에는 다음 버튼이 있습니다.

* 셀에 현재 저장된 내용으로 파티션 설정하기
* 셀의 파티션 설정 초기화하기
* 셀을 꺼내도 파티션 설정을 유지해 다른 셀에 설정 복사하기

## 제작법

<RecipeFor id="cell_workbench" />
