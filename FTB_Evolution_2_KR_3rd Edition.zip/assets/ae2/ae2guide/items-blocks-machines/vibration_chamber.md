---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Vibration Chamber
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# Vibration Chamber

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

네트워크에 [에너지](../ae2-mechanics/energy.md)를 공급하는 주된 방법은 <ItemLink id="energy_acceptor" />를 사용하는 것이지만, Vibration Chamber도 소량에서 중간 정도의 AE를 직접 생산할 수 있습니다.

기본 설정에서는 [업그레이드](upgrade_cards.md) 없이 틱당 40 AE를 생산합니다.

네트워크의 [에너지](../ae2-mechanics/energy.md) 저장 공간이 가득 차면 연료를 아끼기 위해 발전 속도를 줄입니다. 다만 완전히 정지하지는 않습니다.

## 설정

* 에너지 표시 단위를 AE 또는 E/FE로 바꾸는 전체 설정에 접근할 수 있습니다.

## 업그레이드

Vibration Chamber는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="energy_card" />: 효율을 카드당 50%씩, 최대 150% 높여 기본 효율의 250%까지 올립니다.
* <ItemLink id="speed_card" />: 연소 속도를 카드당 50%씩, 최대 150% 높여 기본 출력의 250%까지 증가시킵니다.

## 설정 파일

Vibration Chamber의 특성은 `.minecraft\` 폴더 안에 있는 AE2 설정 폴더의 common.json 파일에서 변경할 수 있습니다.

* `baseEnergyPerFuelTick`: 업그레이드가 없을 때의 기본 연료 효율을 설정합니다.
* `minEnergyPerGameTick`: 최소 발전량을 설정합니다. 네트워크가 에너지를 필요로 하지 않아도 연료가 조금씩 소모됩니다.
* `maxEnergyPerGameTick`: 업그레이드가 없을 때의 최대 출력과 발전 속도를 설정합니다.

## 제작법

<RecipeFor id="vibration_chamber" />
