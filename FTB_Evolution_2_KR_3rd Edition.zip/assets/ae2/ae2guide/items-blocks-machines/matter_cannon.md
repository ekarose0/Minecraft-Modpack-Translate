---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Cannon
  icon: matter_cannon
  position: 410
categories:
- tools
item_ids:
- ae2:matter_cannon
---

# Matter Cannon

<ItemImage id="matter_cannon" scale="4" />

Matter Cannon은 <ItemLink id="matter_ball" />이나 금속 조각 같은 작은 아이템을 발사체로 쏘는 휴대용 레일건입니다. 피해량은 탄약 종류에 따라 달라집니다. Matter Ball처럼 가벼운 아이템은 2의 피해를 주고, 금 조각처럼 무거운 아이템은 10의 피해를 줍니다. 발사 한 번당 기본적으로 1,600 AE를 소모합니다.

설정 항목 'matterCannonBlockDamage'가 true라면 탄약의 피해량과 블록 경도에 따라 블록을 파괴할 수도 있습니다.

<ItemLink id="charger" />로 에너지를 다시 충전할 수 있습니다.

Matter Cannon은 [저장 셀](storage_cells.md)처럼 탄약을 저장하며, <ItemLink id="me_chest" />의 저장 셀 슬롯에 넣으면 탄창에 탄약을 쉽게 채울 수 있습니다.

## 업그레이드

Matter Cannon은 [업그레이드](upgrade_cards.md)를 지원하며 <ItemLink id="cell_workbench" />를 통해 장착합니다.

* <ItemLink id="fuzzy_card" />: 아이템의 내구도에 따라 파티션을 지정하거나 아이템 NBT를 무시하도록 할 수 있습니다.
* <ItemLink id="inverter_card" />: 필터를 허용 목록에서 차단 목록으로 전환합니다.
* <ItemLink id="speed_card" />: 발사할 때 소모하는 에너지를 늘려 위력을 높입니다.
* <ItemLink id="void_card" />: 셀이 가득 찼을 때 들어오는 아이템을 삭제합니다. 파티션 설정에 주의하세요.
* <ItemLink id="energy_card" />: 배터리 용량을 늘립니다.

## 제작법

<RecipeFor id="matter_cannon" />
