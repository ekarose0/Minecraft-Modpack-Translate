---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Storage Bus
  icon: storage_bus
  position: 220
categories:
- devices
item_ids:
- ae2:storage_bus
---

# Storage Bus

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/storage_bus.snbt" />
</GameScene>

상자로 가득한 기존 창고를 버리고 싶지 않으신가요? Storage Bus를 사용하면 그대로 활용할 수 있습니다.

Storage Bus는 맞닿은 인벤토리를 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)으로 만듭니다. 네트워크는 이 인벤토리에 무엇이 있는지 확인할 수 있으며, [장치](../ae2-mechanics/devices.md)의 요청에 따라 물품을 넣거나 꺼냅니다.

AE2의 [장치](../ae2-mechanics/devices.md)들은 서로 연동하면서 다양한 기능을 만들어 냅니다. 따라서 Storage Bus를 반드시 물품을 **보관하는 목적**으로만 사용할 필요는 없습니다. [subnetworks](../ae2-mechanics/subnetworks.md)으로 Storage Bus 하나 또는 몇 개만 연결된 네트워크를 만들면 이를 아이템 전송의 출발지나 목적지로 활용할 수 있습니다. 예시는 ["pipe subnet"](../example-setups/pipe-subnet.md)을 참고하세요.

**중요:** 서랍처럼 최적화된 대용량 인벤토리는 괜찮지만, Colossal Chest처럼 슬롯이 매우 많고 최적화되지 않은 인벤토리를 Storage Bus에 연결하면 성능에 심각한 영향을 줄 수 있습니다.

Storage Bus는 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

## 필터

기본적으로 모든 물품을 저장합니다. 필터 슬롯에 아이템을 등록하면 허용 목록으로 작동하여 지정한 아이템만 저장합니다.

실제로 소유하지 않은 아이템도 JEI/REI에서 슬롯으로 끌어와 필터를 지정할 수 있습니다.

양동이나 유체 탱크 같은 용기를 들고 우클릭하면 용기 대신 내부의 유체가 필터로 등록됩니다.

## 우선순위

GUI 오른쪽 위의 렌치 아이콘으로 우선순위를 정할 수 있습니다. 네트워크로 들어온 아이템은 높은 우선순위의 저장 공간부터 사용합니다. 우선순위가 같으면 그 아이템을 이미 보관하는 공간을 선호합니다. 필터가 설정된 저장 공간은 해당 아이템을 이미 보관하는 것으로 간주됩니다. 꺼낼 때는 가장 낮은 우선순위부터 사용하므로 높은 우선순위 공간은 채워지고 낮은 우선순위 공간은 비워집니다.

## 설정

* 인접한 인벤토리에 현재 들어 있는 물품을 기준으로 Bus의 파티션(필터)을 설정할 수 있습니다.
* Bus가 꺼낼 수 없는 아이템도 네트워크에 표시할지 설정할 수 있습니다. 예를 들어 <ItemLink id="inscriber" />의 가운데 입력 슬롯에서 Storage Bus는 아이템을 꺼낼 수 없습니다.
* 물품을 넣을 때와 꺼낼 때 모두 필터를 적용하거나, 넣을 때만 필터를 적용할 수 있습니다.
* 양방향, 넣기 전용, 꺼내기 전용 중에서 선택할 수 있습니다.

## 업그레이드

Storage Bus는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="capacity_card" />: 필터 슬롯 수를 늘립니다.
* <ItemLink id="fuzzy_card" />: 내구도별로 필터링하거나 NBT를 무시할 수 있습니다.
* <ItemLink id="inverter_card" />: 허용 목록을 차단 목록으로 전환합니다.
* <ItemLink id="void_card" />: 연결된 인벤토리가 가득 찬 경우 들어오는 아이템을 삭제합니다. 농장 생산물이 쌓여 막히는 것을 방지하지만 파티션 설정에 주의하세요.

## 제작법

<RecipeFor id="storage_bus" />
