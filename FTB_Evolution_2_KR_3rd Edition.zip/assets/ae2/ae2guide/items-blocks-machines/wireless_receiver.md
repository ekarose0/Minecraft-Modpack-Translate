---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wireless Receiver
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# Wireless Receiver

<ItemImage id="wireless_receiver" scale="4" />

반사 접시 안에 <ItemLink id="fluix_pearl" />을 넣은 부품으로, 근거리 무선 ME 기술에 사용됩니다.

## 제작법

<RecipeFor id="wireless_receiver" />
