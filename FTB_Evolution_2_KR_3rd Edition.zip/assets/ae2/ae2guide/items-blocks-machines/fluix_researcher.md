---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Researcher (Villager)
  icon: minecraft:emerald
  position: 310
categories:
- tools
---

# Fluix Researcher

<Row>
![Fluix Researcher](../assets/diagrams/ae2_villager.png)
<BlockImage id="charger" scale="8" />
</Row>

Fluix Researcher는 주민의 직업 중 하나입니다. 직업 블록은 <ItemLink id="charger" />입니다.

## 거래

거래는 일반 주민과 같은 방식으로 진행되며, 각 직업 단계에서 무작위 거래 두 가지가 열립니다. 해당 단계에 가능한 거래가 하나뿐이면 한 가지만 열립니다.

| 등급      | 요구 아이템                                       | 지급 아이템                                      |
|------------|---------------------------------------------------|-------------------------------------------------|
| 초보     | 3 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="certus_quartz_crystal" />       |
| 초보     | 2 <ItemLink id="minecraft:emerald" />             | 1 <ItemLink id="meteorite_compass" />           |
|            |                                                   |                                                 |
| 견습 | 3 <ItemLink id="charged_certus_quartz_crystal" /> | 1 <ItemLink id="minecraft:emerald" />           |
| 견습 | 5 <ItemLink id="silicon" />                       | 1 <ItemLink id="minecraft:emerald" />           |
| 견습 | 5 <ItemLink id="minecraft:emerald" />             | 8 <ItemLink id="sky_stone_block" />             |
|            |                                                   |                                                 |
| 기능공 | 2 <ItemLink id="quartz_glass" />                  | 1 <ItemLink id="minecraft:emerald" />           |
| 기능공 | 5 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="fluix_crystal" />               |
|            |                                                   |                                                 |
| 전문가     | 5 <ItemLink id="matter_ball" />                   | 1 <ItemLink id="minecraft:emerald" />           |
| 전문가     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="silicon_press" />               |
| 전문가     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="logic_processor_press" />       |
| 전문가     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="calculation_processor_press" /> |
| 전문가     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="engineering_processor_press" /> |
|            |                                                   |                                                 |
| 달인     | 8 <ItemLink id="minecraft:emerald" />             | 5 <ItemLink id="minecraft:slime_ball" />        |
