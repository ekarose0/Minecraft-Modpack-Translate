---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Processors
  icon: logic_processor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:logic_processor
- ae2:calculation_processor
- ae2:engineering_processor
- ae2:printed_silicon
- ae2:printed_logic_processor
- ae2:printed_calculation_processor
- ae2:printed_engineering_processor
- ae2:silicon
---

# Processor

<Row>
  <ItemImage id="logic_processor" scale="4" />

  <ItemImage id="calculation_processor" scale="4" />

  <ItemImage id="engineering_processor" scale="4" />
</Row>

Processor는 AE2의 [장치](../ae2-mechanics/devices.md)와 기계를 만드는 데 필요한 핵심 재료입니다. 자동화 초반에 마주하는 큰 과제 중 하나이기도 합니다. Processor는 금, <ItemLink id="certus_quartz_crystal" />, 다이아몬드를 각각 사용하는 세 종류가 있습니다. [Press](presses.md)를 <ItemLink id="inscriber" />에 장착해 여러 단계에 걸쳐 제작하며, 일반적으로 여러 Inscriber와 필터가 달린 아이템 배관으로 자동화합니다.

## 제작 단계

<Column gap="5">
  1. 필요한 재료를 모으거나 제작합니다: 실리콘, 레드스톤, 금, <ItemLink id="certus_quartz_crystal" />, 다이아몬드.

  <RecipeFor id="silicon" />

  <br />

2. 필요한 인쇄 회로 부품을 압인합니다.

  <Row>
    <RecipeFor id="printed_silicon" />

    <RecipeFor id="printed_logic_processor" />
  </Row>

  <Row>
    <RecipeFor id="printed_calculation_processor" />

    <RecipeFor id="printed_engineering_processor" />
  </Row>

  <br />

3. 마지막으로 조립합니다.

  <Row>
    <RecipeFor id="logic_processor" />

    <RecipeFor id="calculation_processor" />
  </Row>

  <RecipeFor id="engineering_processor" />
</Column>
