---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Growth Accelerator
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# Growth Accelerator

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

Growth Accelerator를 싹트는 블록 옆에 놓으면 Certus Quartz나 자수정의 [성장 과정](../ae2-mechanics/certus-growth.md)을 크게 가속합니다.

흥미롭게도 다양한 식물의 성장도 가속할 수 있습니다.

인접한 블록에 자연적으로 발생하는 무작위 틱 외에 추가 '무작위 틱'을 적용하는 방식입니다. 이론적으로 가속기 하나만으로 성장 속도를 약 90배 높이며, 여러 개를 설치하면 효과가 합산됩니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

위아래 면에 AE2의 [케이블](cables.md)이나 다른 모드의 전력 케이블을 연결해 전원을 공급합니다. AE와 Forge Energy(FE)를 모두 사용할 수 있습니다.

수동으로 전력을 공급하려면 위나 아래에 <ItemLink id="crank" />를 설치하고 우클릭하세요.

위아래 면에는 분홍색 Fluix 장식이 있어 방향을 구분할 수 있습니다.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 제작법

<RecipeFor id="growth_accelerator" />
