---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Chest
  icon: me_chest
  position: 210
categories:
- devices
item_ids:
- ae2:me_chest
---

# ME Chest

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/chest.snbt" />
</GameScene>

ME Chest는 <ItemLink id="terminal" />, <ItemLink id="drive" />, <ItemLink id="energy_acceptor" />가 합쳐진 작은 네트워크처럼 작동합니다. 독립된 소형 저장 네트워크로 사용할 수 있지만 [storage cell](../items-blocks-machines/storage_cells.md)을 한 개만 넣을 수 있어 용량이 제한적입니다.

대신 내부에 장착한 특정 저장 셀을 직접 관리할 때 유용합니다. 내장 Terminal은 장착된 셀의 아이템만 볼 수 있지만, 일반 네트워크의 [장치](../ae2-mechanics/devices.md)은 ME Chest를 포함한 모든 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)의 아이템에 접근할 수 있습니다.

ME Chest에는 두 종류의 화면이 있으며 면에 따라 아이템 입출력 방향이 다릅니다. 위쪽 Terminal을 누르면 내장 Terminal이 열립니다. 이 면으로 셀에 아이템을 넣을 수 있지만 꺼낼 수는 없습니다. 다른 면을 누르면 저장 셀 슬롯과 우선순위 설정 화면이 열립니다. 자동화 장치로 셀을 넣거나 꺼내려면 셀 슬롯이 있는 면을 사용해야 합니다.

<ItemLink id="certus_quartz_wrench" />를 사용해 방향을 회전할 수 있습니다.

ME Chest에는 작은 AE 에너지 버퍼가 있습니다. [Energy Cell](../items-blocks-machines/energy_cells.md)가 있는 네트워크에 연결하지 않은 경우 아이템을 한꺼번에 많이 넣거나 꺼내면 전력 부족으로 일시 정지할 수 있습니다.

Terminal은 <ItemLink id="color_applicator" />로 색을 바꿀 수 있습니다.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/chest_color.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

ME Chest는 <ItemLink id="terminal" /> 또는 <ItemLink id="crafting_terminal" />와 비슷한 설정을 제공하지만 <ItemLink id="view_cell" />은 지원하지 않습니다.

## 셀 상태 표시등

Chest에 장착된 셀의 LED는 다음 상태를 표시합니다.

| 색상 | 상태 |
| :-- | :-- |
| 녹색 | 비어 있음 |
| 파란색 | 일부 내용물이 저장되어 있음 |
| 주황색 | [Types](../ae2-mechanics/bytes-and-types.md)가 가득 차 새로운 종류를 추가할 수 없음 |
| 빨간색 | [Bytes](../ae2-mechanics/bytes-and-types.md)가 가득 차 아이템을 더 넣을 수 없음 |
| 검은색 | 전원이 없거나 Drive에 [채널](../ae2-mechanics/channels.md)이 없음 |

## 우선순위

셀 슬롯 화면의 오른쪽 위 렌치 아이콘으로 우선순위를 정합니다. 네트워크에 들어온 아이템은 가장 우선순위가 높은 저장 공간부터 배치됩니다. 우선순위가 같으면 해당 종류가 이미 들어 있는 공간을 선호합니다. [파티션 설정](cell_workbench.md) 셀은 그 종류를 이미 보관하는 것으로 취급됩니다. 아이템을 꺼낼 때는 우선순위가 가장 낮은 저장 공간부터 사용합니다. 따라서 입출력이 반복되면 높은 우선순위의 저장 공간은 채워지고 낮은 우선순위는 비워집니다.

## 제작법

<RecipeFor id="me_chest" />
