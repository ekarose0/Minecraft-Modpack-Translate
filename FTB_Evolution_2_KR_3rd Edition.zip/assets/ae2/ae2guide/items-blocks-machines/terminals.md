---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Terminals
  icon: crafting_terminal
  position: 210
categories:
- devices
item_ids:
- ae2:terminal
- ae2:crafting_terminal
- ae2:pattern_encoding_terminal
- ae2:pattern_access_terminal
---

# Terminals

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminals.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="pattern_provider" />, <ItemLink id="import_bus" />, <ItemLink id="storage_bus" /> 등이 AE2 네트워크와 외부 세계를 연결하는 주요 수단이라면, Terminals는 AE2 네트워크와 *플레이어*를 연결하는 주요 수단입니다. 기능에 따라 여러 종류가 있습니다.

Terminals는 설치된 [케이블](cables.md)의 색상을 따릅니다.

이 장치는 [케이블 부속 부품](../ae2-mechanics/cable-subparts.md)입니다.

## Terminal 설치 방법

Terminal은 처음 설치하는 [부속 부품](../ae2-mechanics/cable-subparts.md)인 경우가 많아 방향을 거꾸로 설치하기 쉽습니다. 다음은 올바른 설치와 잘못된 설치의 예시입니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminal_placement.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <LineAnnotation color="#ff3333" from="2.5 .5 .5" to="4.5 2.5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="2.5 2.5 .5" to="4.5 .5 .5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="-.5 2.5 .5" to="1 .5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1 .5 .5" to="1.5 1 .5" alwaysOnTop={true} thickness="0.05"/>
</GameScene>

Terminal과 Energy Acceptor는 그대로 사용하지만, 이제 Terminal의 방향이 올바르고 네트워크에도 실제로 연결됩니다. 차지하는 공간도 더 작습니다.

<a name="terminal-ui"></a>

# Terminal 검색

Terminal의 검색창에서는 정규 표현식(*regex*)을 사용할 수 있습니다. 예를 들어 "gtceu:.*ore"를 입력하면 GregTech의 모든 광석을 검색할 수 있습니다. 정규 표현식 문법은 별도로 익혀 두시면 좋습니다.

# Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

기본 Terminal입니다. [네트워크 저장소](../ae2-mechanics/import-export-storage.md)의 내용물을 확인하고 입출고할 수 있으며, [자동 제작](../ae2-mechanics/autocrafting.md) 시스템에 제작을 요청할 수도 있습니다.

## 인터페이스

기본 Terminal의 화면은 여러 영역으로 나뉩니다.

중앙 영역에서는 네트워크 저장소의 아이템을 넣거나 꺼낼 수 있습니다. 다음과 같은 마우스·키보드 단축 조작도 지원합니다.

*   좌클릭하면 한 묶음을, 우클릭하면 반 묶음을 집습니다.
*   아이템이나 유체 등을 [자동 제작](../ae2-mechanics/autocrafting.md)할 수 있다면, '블록 선택'에 지정된 키(일반적으로 마우스 가운데 버튼)를 눌러 제작 수량을 입력할 수 있습니다. `3*64/2` 같은 수식을 입력하거나 `=32`를 입력하여 저장소의 총수량이 32개가 되도록 부족한 만큼만 제작할 수도 있습니다.
*   Shift를 누르고 있으면 표시된 아이템의 위치가 고정되어 수량 변화나 새 아이템 유입으로 정렬 순서가 바뀌지 않습니다.
*   양동이 등의 유체 용기를 들고 우클릭하면 유체를 저장소에 넣습니다.
*   빈손으로 유체를 좌클릭하면 네트워크에 빈 양동이가 있을 때 유체 한 양동이를 꺼냅니다. 유체 용기를 들고 좌클릭하면 해당 용기에 유체를 담습니다.

왼쪽에는 다음 설정 버튼이 있습니다.

*   이름, 모드, 수량 등의 기준으로 정렬
*   저장된 아이템만 표시하거나 제작 가능한 아이템만 표시하거나 둘 다 표시
*   아이템, 유체 또는 둘 다 표시
*   정렬 방향 변경
*   Terminal 세부 설정 창 열기
*   Terminal 화면 높이 변경

오른쪽에는 <ItemLink id="view_cell" />을 장착하는 슬롯이 있습니다.

중앙 영역 오른쪽 위의 망치 버튼을 누르면 [자동 제작](../ae2-mechanics/autocrafting.md) 상태 창이 열립니다. 이곳에서 자동 제작 진행 상황과 각 [Crafting CPU](crafting_cpu_multiblock.md)의 작업을 확인할 수 있습니다.

## 제작법

<RecipeFor id="terminal" />

<a name="crafting-terminal-ui"></a>

# Crafting Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/crafting_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Crafting Terminal은 일반 Terminal과 설정 및 화면 구성이 같지만, [네트워크 저장소](../ae2-mechanics/import-export-storage.md)에서 재료를 자동으로 보충하는 제작 격자가 추가됩니다. 결과물을 Shift+클릭할 때는 주의하세요!

가능하면 Terminal을 Crafting Terminal로 빨리 업그레이드하는 것이 좋습니다.

## 인터페이스

일반 Terminal의 화면 중앙에 제작 격자가 추가된 형태입니다.

제작 격자에 남은 재료를 네트워크 저장소 또는 플레이어 인벤토리로 돌려보내는 버튼 두 개가 더 있습니다.

## 제작법

<RecipeFor id="crafting_terminal" />

<a name="pattern-encoding-terminal-ui"></a>

# Pattern Encoding Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_encoding_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Pattern Encoding Terminal은 일반 Terminal과 같은 설정 및 화면 구성을 갖추면서 [패턴](patterns.md)을 인코딩하는 기능이 추가된 장치입니다. 화면은 Crafting Terminal과 비슷하지만 이 제작 격자에서 실제 제작이 이루어지지는 않습니다.

Crafting Terminal과 별도로 하나 설치하는 것이 좋습니다.

## 인터페이스

일반 Terminal에 [패턴](patterns.md) 인코딩 영역이 추가됩니다. 이 영역은 다음과 같이 구성됩니다.

<ItemLink id="blank_pattern" />을 넣는 슬롯이 있습니다.

패턴을 인코딩하는 큰 화살표 버튼이 있습니다.

인코딩된 패턴을 넣는 슬롯이 있습니다. 기존 패턴을 수정하려면 이 슬롯에 넣고 '인코딩' 화살표를 눌러 새 데이터로 덮어쓰세요.

오른쪽의 탭 4개로 패턴 종류를 선택할 수 있습니다.

*   Crafting
*   Processing
*   Smithing
*   Stonecutting

중앙 화면은 선택한 패턴 종류에 따라 달라집니다.

*   Crafting 모드:
    *   재료를 좌클릭하거나 JEI/REI에서 드래그하여 제작법을 구성합니다. 우클릭하면 재료를 제거합니다.
    *   재료 대체를 활성화하면 나무 판자의 종류와 관계없이 막대기를 제작하는 등의 작업이 가능합니다. 반드시 필요할 때만 사용하세요.
    *   유체 대체를 사용하면 유체가 든 양동이 대신 네트워크에 저장된 유체를 사용할 수 있습니다.
    *   JEI/REI 제작법 화면에서 패턴을 바로 인코딩할 수도 있습니다.

*   Processing 모드:
    *   좌클릭·우클릭하거나 JEI/REI에서 드래그하여 제작법의 입력 재료와 출력 결과물을 지정합니다.
    *   양동이나 유체 탱크 등의 유체 용기를 들고 우클릭하면 용기 자체 대신 그 안의 유체를 재료로 지정합니다.
    *   아이템 묶음을 들고 좌클릭하면 전체 묶음을, 우클릭하면 한 개를 배치합니다. 이미 배치한 재료를 좌클릭하면 묶음 전체가 제거되고, 우클릭하면 수량이 1 감소합니다. '블록 선택'에 지정된 키(일반적으로 마우스 가운데 버튼)로 아이템이나 유체의 정확한 수량을 지정할 수 있습니다.
    *   출력 슬롯에는 주 결과물과 자동 제작 시스템에 알려 줄 추가 부산물을 설정할 공간이 있습니다.
    *   입력·출력 슬롯 모두 스크롤할 수 있어 서로 다른 재료 81종과 추가 결과물 26종까지 설정할 수 있습니다.
    *   JEI/REI 제작법 화면에서 패턴을 바로 인코딩할 수도 있습니다.

*   Smithing과 Stonecutting 모드의 화면은 각각 Smithing Table 및 Stonecutter와 비슷하게 작동합니다.

## 제작법

<RecipeFor id="pattern_encoding_terminal" />

<a name="pattern-access-terminal-ui"></a>

# Pattern Access Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_access_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Pattern Access Terminal을 사용하면 네트워크에 연결된 모든 Pattern Provider에 접근할 수 있습니다. <ItemLink id="pattern_provider" />와 <ItemLink id="molecular_assembler" />를 촘촘히 쌓아 놓으면 내부의 Provider에 직접 접근하여 새 패턴을 넣기 어렵습니다. 기지 반대편까지 걸어가 [패턴](patterns.md)을 넣거나 수정하는 번거로움도 줄일 수 있습니다.

## 인터페이스

이 Terminal은 다른 Terminal과 화면 구성이 다릅니다.

화면 높이와 표시할 Pattern Provider를 설정할 수 있습니다.

각 행은 개별 Pattern Provider 하나를 나타냅니다.

Pattern Provider는 연결된 블록이나 <ItemLink id="name_press" /> 또는 모루로 지정한 이름을 기준으로 정렬·그룹화됩니다.

## 제작법

<RecipeFor id="pattern_access_terminal" />
