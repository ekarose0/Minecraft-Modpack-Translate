---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Pearl
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Fluix Pearl

<ItemImage id="fluix_pearl" scale="4" />

<ItemLink id="fluix_crystal" />로 감싼 엔더 진주입니다. 여러 AE2 부품을 제작하는 데 사용됩니다.

## 제작법

<RecipeFor id="fluix_pearl" />
