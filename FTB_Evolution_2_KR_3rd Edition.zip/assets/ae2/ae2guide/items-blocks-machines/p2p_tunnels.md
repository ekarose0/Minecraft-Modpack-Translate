---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: P2P Tunnel 사용법
  icon: me_p2p_tunnel
  position: 210
categories:
- devices
item_ids:
- ae2:me_p2p_tunnel
- ae2:redstone_p2p_tunnel
- ae2:item_p2p_tunnel
- ae2:fluid_p2p_tunnel
- ae2:fe_p2p_tunnel
- ae2:light_p2p_tunnel
---

# P2P Tunnel

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

P2P Tunnel은 네트워크에 직접 간섭하지 않고 아이템, 유체, 레드스톤 신호, 전력, 빛, [채널](../ae2-mechanics/channels.md) 등을 전송하는 장치입니다. 여러 종류가 있으며 각 종류는 지정된 대상만 전송합니다. 떨어진 두 블록의 면을 직접 연결하는 포털처럼 작동합니다. 양방향이 아니라 입력과 출력이 정해져 있습니다.

![Portal](../assets/assemblies/p2p_portal.png)

예를 들어 Item P2P를 향한 Hopper는 Barrel에 직접 연결된 것처럼 작동하여 아이템을 전달합니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_hopper_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

반면 Barrel 두 개가 서로 인접해 있어도 자동으로 아이템을 주고받지는 않습니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_barrel_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Redstone P2P 같은 다른 종류도 있습니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_redstone.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ME P2P는 채널을 전달합니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## P2P Tunnel의 종류와 조율

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="180" pitch="90" />
</GameScene>

P2P Tunnel에는 여러 종류가 있습니다. 직접 제작할 수 있는 것은 ME P2P Tunnel뿐이며, 나머지는 P2P Tunnel을 특정 아이템으로 우클릭해 변경합니다.
- ME P2P: 아무 [Cable](../items-blocks-machines/cables.md)로 우클릭합니다.
- Redstone P2P: 다양한 레드스톤 부품으로 우클릭합니다.
- Item P2P: Chest 또는 Hopper로 우클릭합니다.
- Fluid P2P: Bucket 또는 Bottle로 우클릭합니다.
- Energy P2P: 에너지를 담을 수 있는 대부분의 아이템으로 우클릭합니다.
- Light P2P: Torch 또는 Glowstone으로 우클릭합니다.

종류별로 주의할 점도 있습니다. ME P2P Tunnel로 전송한 채널을 다른 ME P2P Tunnel에 다시 통과시킬 수 없습니다. Energy P2P Tunnel은 [에너지](../ae2-mechanics/energy.md) 소비량이 늘어나므로 통과하는 FE의 2.5%를 간접적으로 소모합니다.

## 가장 흔한 P2P 활용법

가장 흔한 사용법은 ME P2P Tunnel로 [채널](../ae2-mechanics/channels.md) 전송을 압축하는 것입니다. Dense Cable 여러 가닥 대신 한 가닥으로 많은 채널을 전달할 수 있습니다.

이 예시에서는 ME P2P 입력 8개가 메인 네트워크의 <ItemLink id="controller" />에서 256채널(8×32)을 받아, 출력 8개를 통해 다른 위치로 전달합니다. P2P 입력과 출력은 각각 채널 1개를 사용합니다. 따라서 얇은 Cable로도 많은 채널을 전송할 수 있습니다. P2P Tunnel을 전용 [서브네트워크](../ae2-mechanics/subnetworks.md)에 설치하면 메인 네트워크의 채널을 소비하지도 않습니다. 터널을 Controller에 직접 붙일 수 있지만, 사이에 [Dense Smart Cable](../items-blocks-machines/cables.md#smart-cable)을 두면 채널 상태를 더 쉽게 확인할 수 있습니다.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/p2p_compact_channels.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 1.3 6.3" max="2 2.7 6.7">
        Quartz Fiber는 메인 네트워크와 P2P 서브네트워크 사이에서 에너지를 공유합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.1 0 5.7" max="5 2.3 6.4">
        터널 입력을 Controller에 직접 붙이거나 Cable로 연결할 수 있습니다.
  </BoxAnnotation>

  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

[Quantum Bridge](quantum_bridge.md)와 함께 사용하는 다른 예시는 아래 그림을 참고하세요.

![P2P and quantum bridges](../assets/diagrams/p2p_quantum_network.png)

## 중첩 연결

하지만 이 방식으로 Cable 한 가닥에 무한한 채널을 전달할 수는 없습니다. ME P2P Tunnel의 채널은 다른 ME P2P Tunnel을 통과하지 못하므로 재귀적으로 중첩할 수 없습니다. 빨간 Cable에 연결된 바깥쪽 ME P2P Tunnel이 오프라인인 것을 확인하세요. 이 제한은 ME P2P에만 적용되며, 그림처럼 Redstone P2P 등의 다른 종류는 ME P2P를 통해 정상 작동할 수 있습니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_nesting.snbt" />
  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## 터널 연결

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_linking_frequency.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="memory_card" />를 사용하면 P2P Tunnel의 양쪽 끝을 연결할 수 있습니다. 연결 주파수는 터널 뒷면에 2×2 색상 배열로 표시됩니다.
- Shift+우클릭하면 새로운 P2P 연결 주파수를 생성합니다.
- 우클릭하면 설정, Upgrade Card 또는 연결 주파수를 붙여넣습니다.

Shift+우클릭한 터널은 입력, 일반 우클릭한 터널은 출력이 됩니다. 출력은 여러 개 둘 수 있지만 ME P2P에서는 입력 채널이 출력 사이에 분배되므로 채널을 복제할 수는 없습니다.

## 제작법

<RecipeFor id="me_p2p_tunnel" />