---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Singularities
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# Singularity

<ItemImage id="singularity" scale="4" />

물질을 매우 높은 밀도로 압축한 구체입니다.

<ItemLink id="condenser" />를 특이점 모드로 설정한 뒤 아이템 256,000개 또는 양동이 256,000개 분량을 투입해 만듭니다.

## Quantum Entangled Singularity

<ItemImage id="quantum_entangled_singularity" scale="4" />

두 [Quantum Network Bridges](quantum_bridge.md) 사이를 연결할 때 필요하며, 항상 서로 짝이 맞는 한 쌍으로 생성됩니다. 연결하려면 양쪽 브리지의 <ItemLink id="quantum_link" />에 같은 쌍의 Quantum Entangled Singularity를 하나씩 넣으세요.

<ItemLink id="minecraft:ender_pearl" /> 또는 <ItemLink id="ender_dust" />와 <ItemLink id="singularity" />에 폭발 반응을 일으켜 제작합니다. 거의 모든 종류의 폭발로 반응을 유도할 수 있습니다.

<RecipeFor id="quantum_entangled_singularity" />

***크리퍼의 폭발을 포함해 거의 모든 폭발이 가능합니다.***

항상 두 개가 한 쌍으로 만들어지지만 <ItemLink id="singularity" />는 하나만 있으면 됩니다.

제작한 쌍을 구분하기 쉽도록 모루로 각각 이름을 붙여 두면 편리합니다.
