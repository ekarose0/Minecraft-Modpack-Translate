---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Upgrade Cards 사용법
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
---

# Upgrade Cards

<Row>
  <ItemImage id="redstone_card" scale="2" />

  <ItemImage id="capacity_card" scale="2" />

  <ItemImage id="void_card" scale="2" />

  <ItemImage id="fuzzy_card" scale="2" />

  <ItemImage id="speed_card" scale="2" />

  <ItemImage id="inverter_card" scale="2" />

  <ItemImage id="crafting_card" scale="2" />

  <ItemImage id="equal_distribution_card" scale="2" />

  <ItemImage id="energy_card" scale="2" />
</Row>

Upgrade Card는 AE2 [장치](../ae2-mechanics/devices.md)와 기계의 동작을 변경합니다. 작동 속도를 높이거나, 필터 슬롯을 늘리거나, 레드스톤 제어 기능을 추가하는 등의 효과가 있습니다.

## 카드 재료

<Row>
  <ItemImage id="basic_card" scale="2" />

  <ItemImage id="advanced_card" scale="2" />
</Row>

카드는 Basic Card 또는 Advanced Card를 재료로 제작합니다.

<Row>
  <RecipeFor id="basic_card" />

  <RecipeFor id="advanced_card" />
</Row>

## Redstone Card

<ItemImage id="redstone_card" scale="2" />

Redstone Card는 장치 GUI에 레드스톤 조건을 전환하는 버튼을 추가합니다.

<RecipeFor id="redstone_card" />

## Capacity Card

<ItemImage id="capacity_card" scale="2" />

Capacity Card는 Import Bus, Export Bus, Storage Bus, Formation Plane의 필터 슬롯 수를 늘립니다.

<RecipeFor id="capacity_card" />

## Overflow Destruction Card

<ItemImage id="void_card" scale="2" />

Overflow Destruction Card는 <ItemLink id="cell_workbench" />에서 [Storage Cell](storage_cells.md)에 장착할 수 있습니다. 셀이 가득 찼을 때 들어오는 아이템을 삭제하므로 반드시 셀에 [파티션](cell_workbench.md)을 설정하세요. Equal Distribution Card와 함께 사용하면 다른 아이템의 공간이 남아 있어도 해당 아이템에 배정된 공간이 가득 차면 초과분을 삭제합니다.

<RecipeFor id="void_card" />

## Fuzzy Card

<ItemImage id="fuzzy_card" scale="2" />

Fuzzy Card를 사용하면 필터가 있는 장치와 도구에서 내구도에 따라 구분하거나 아이템 NBT를 무시할 수 있습니다. 예를 들어 내구도나 마법 부여 상태와 관계없이 모든 Iron Axe를 내보내거나, 완전히 수리된 것은 제외하고 손상된 Diamond Sword만 내보낼 수 있습니다.

아래 표는 Fuzzy Damage 비교 모드의 작동 예시입니다. 왼쪽은 Bus의 필터 설정, 위쪽은 비교 대상 아이템입니다.

| 25%                    | 10% 손상된 Pickaxe | 30% 손상된 Pickaxe | 80% 손상된 Pickaxe | 완전히 수리된 Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 거의 부서진 Pickaxe  | ✅                   | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            |
| 완전히 수리된 Pickaxe | \*\*\*\*            | ✅                   | ✅                   | ✅                   |

| 50%                    | 10% 손상된 Pickaxe | 30% 손상된 Pickaxe | 80% 손상된 Pickaxe | 완전히 수리된 Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 거의 부서진 Pickaxe  | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| 완전히 수리된 Pickaxe | \*\*\*\*            | \*\*\*\*            | ✅                   | ✅                   |

| 75%                    | 10% 손상된 Pickaxe | 30% 손상된 Pickaxe | 80% 손상된 Pickaxe | 완전히 수리된 Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 거의 부서진 Pickaxe  | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| 완전히 수리된 Pickaxe | \*\*\*\*            |                     | ✅                   | ✅                   |

| 99%                    | 10% 손상된 Pickaxe | 30% 손상된 Pickaxe | 80% 손상된 Pickaxe | 완전히 수리된 Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 거의 부서진 Pickaxe  | ✅                   | ✅                   | ✅                   | \*\*\*\*            |
| 완전히 수리된 Pickaxe | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            | ✅                   |

| Ignore                 | 10% 손상된 Pickaxe | 30% 손상된 Pickaxe | 80% 손상된 Pickaxe | 완전히 수리된 Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 거의 부서진 Pickaxe  | ✅                   | ✅                   | ✅                   | **✅**               |
| 완전히 수리된 Pickaxe | **✅**               | **✅**               | **✅**               | ✅                   |

<RecipeFor id="fuzzy_card" />

## Acceleration Card

<ItemImage id="speed_card" scale="2" />

Acceleration Card는 작동 속도를 높입니다. Import Bus와 Export Bus는 한 번에 더 많은 아이템을 옮기고, Inscriber와 Molecular Assembler는 작업을 더 빨리 완료합니다.

<RecipeFor id="speed_card" />

## Inverter Card

<ItemImage id="inverter_card" scale="2" />

Inverter Card는 장치와 도구의 필터를 허용 목록에서 차단 목록으로 전환합니다.

<RecipeFor id="inverter_card" />

## Crafting Card

<ItemImage id="crafting_card" scale="2" />

Crafting Card는 장치가 필요한 아이템을 얻도록 [자동 제작](../ae2-mechanics/autocrafting.md) 시스템에 제작을 요청하게 해 줍니다.

<RecipeFor id="crafting_card" />

## Equal Distribution Card

<ItemImage id="equal_distribution_card" scale="2" />

Equal Distribution Card는 <ItemLink id="cell_workbench" />에서 [Storage Cell](storage_cells.md)에 장착할 수 있습니다. [파티션](cell_workbench.md)에 등록된 아이템 종류마다 저장 공간을 동일하게 나누어, 한 종류가 셀 전체를 차지하지 못하게 합니다.

<RecipeFor id="equal_distribution_card" />

## Energy Card

<ItemImage id="energy_card" scale="2" />

Energy Card는 Portable Terminal 같은 일부 도구의 에너지 저장량을 늘리고, <ItemLink id="vibration_chamber" />의 효율을 높입니다.

<RecipeFor id="energy_card" />
