---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial Anchor
  icon: spatial_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:spatial_anchor
---

# Spatial Anchor

<BlockImage id="spatial_anchor" p:powered="true" scale="8"/>

AE2 네트워크의 [장치](../ae2-mechanics/devices.md)들이 정상적으로 작동하려면 관련 청크가 로드되어 있어야 합니다. 네트워크의 일부 청크만 로드되면 오작동할 수 있습니다. Spatial Anchor는 네트워크가 차지하는 청크를 강제로 계속 로드해 이 문제를 해결합니다. 케이블 하나가 청크 경계를 넘어가기만 해도 새 청크가 로드 대상에 포함됩니다.

청크 로딩 효과는 [Quantum Bridge](quantum_bridge.md)를 통해서도 전달되지만 차원을 넘지는 못합니다. 예를 들어 네더로 연결된 브리지가 있다면 기지와 네더의 네트워크에 각각 Spatial Anchor가 있어야 합니다.

기본 설정에서는 로드된 청크에서 무작위 틱도 발생시킵니다. 이 기능은 AE2 설정에서 끌 수 있습니다.

원한다면 <ItemLink id="certus_quartz_wrench" />로 블록 방향도 회전할 수 있습니다.

## 설정

* 에너지 표시 단위를 AE 또는 E/FE로 바꾸는 전체 설정에 접근할 수 있습니다.
* 로드 중인 청크를 보여 주는 홀로그램을 월드에 표시할 수 있습니다.

## 에너지

Spatial Anchor의 [에너지](../ae2-mechanics/energy.md) 사용량은 다음 식에 따릅니다.

e = 80 + (x\*(x+1))/2

여기서 x는 로드 중인 청크의 개수입니다.

## 제작법

<RecipeFor id="spatial_anchor" />
