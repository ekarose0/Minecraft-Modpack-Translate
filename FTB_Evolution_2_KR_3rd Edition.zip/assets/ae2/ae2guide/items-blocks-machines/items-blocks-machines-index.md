---
navigation:
  title: 아이템, 블록, 기계
  position: 50
---

# 아이템, 블록, 기계

다른 페이지에서 참조할 수 있도록 모드의 아이템과 블록, 기계를 모아 놓았으며 각각의 기능을 설명합니다.

## 기타 재료와 블록

<CategoryIndex category="misc ingredients blocks" />

## 네트워크 기반 시설

<CategoryIndex category="network infrastructure" />

## 장치

<CategoryIndex category="devices" />

## 기계

<CategoryIndex category="machines" />

## 도구

<CategoryIndex category="tools" />