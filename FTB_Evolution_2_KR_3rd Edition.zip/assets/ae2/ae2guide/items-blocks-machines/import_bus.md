---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Import Bus
  icon: import_bus
  position: 220
categories:
- devices
item_ids:
- ae2:import_bus
---

# Import Bus

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/import_bus.snbt" />
</GameScene>

Import Bus는 맞닿아 있는 인벤토리에서 아이템과 유체(애드온에 따라 다른 자원도 포함)를 가져와 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에 넣습니다.

서버 지연을 줄이기 위해 한동안 가져올 물품이 없으면 느리게 작동하는 절전 상태로 전환됩니다. 아이템을 가져오는 데 성공하면 다시 가속하여 초당 네 번까지 작업합니다.

Import Bus는 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

## 필터

기본적으로 가져올 수 있는 모든 물품을 가져옵니다. 필터 슬롯에 아이템을 등록하면 허용 목록이 되어 지정한 아이템만 가져옵니다.

실제 아이템을 가지고 있지 않아도 JEI/REI에서 아이템이나 유체를 끌어와 필터 슬롯에 등록할 수 있습니다.

양동이나 탱크 같은 유체 용기를 들고 우클릭하면 용기 대신 안에 든 유체를 필터로 지정합니다.

## 업그레이드

Import Bus는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="capacity_card" />: 필터 슬롯의 수를 늘립니다.
* <ItemLink id="speed_card" />: 한 번에 이동하는 물품의 양을 늘립니다.
* <ItemLink id="fuzzy_card" />: 내구도별로 필터링하거나 NBT를 무시하도록 설정할 수 있습니다.
* <ItemLink id="inverter_card" />: 허용 목록을 차단 목록으로 바꿉니다.
* <ItemLink id="redstone_card" />: 높은 신호, 낮은 신호 또는 펄스마다 한 번 작동하는 레드스톤 제어 기능을 추가합니다.

## 전송 속도

| Acceleration Card 수 | 작업당 아이템 수 |
| :-- | :-- |
| 0 | 1 |
| 1 | 8 |
| 2 | 32 |
| 3 | 64 |
| 4 | 96 |

## 제작법

<RecipeFor id="import_bus" />
