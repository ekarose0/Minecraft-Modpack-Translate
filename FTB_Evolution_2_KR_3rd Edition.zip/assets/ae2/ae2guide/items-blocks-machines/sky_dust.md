---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Sky Stone Dust
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# Sky Stone Dust

<ItemImage id="sky_dust" scale="4" />

<ItemLink id="sky_stone_block" />을 <ItemLink id="inscriber" />로 분쇄해 얻는 재료입니다. <ItemLink id="cell_component_256k" /> 및 <ItemLink id="sky_stone_block" /> 제작에 사용됩니다.

월드의 최대 건축 높이에서 <ItemLink id="annihilation_plane" />이 위를 향하도록 설치해도 얻을 수 있습니다.

## 제작법

<RecipeFor id="sky_dust" />
