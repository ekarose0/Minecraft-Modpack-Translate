---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quartz Fixtures
  icon: quartz_fixture
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_fixture
- ae2:light_detector
---

# Quartz Fixtures

<Row>
<BlockImage id="quartz_fixture" scale="8" />

<BlockImage id="light_detector" scale="8" />
</Row>

충전된 Quartz Fixture는 빛을 내는 작은 장식용 부품입니다.

반면 Light Detecting Fixture는 설치된 위치의 밝기에 따라 레드스톤 신호를 출력합니다.

## 제작법

<RecipeFor id="quartz_fixture" />

<RecipeFor id="light_detector" />
