---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Tools
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# Fluix 도구

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

[Fluix](fluix_crystal.md) 도구는 철 도구와 비슷하지만 내구도가 3배이며 공격력과 채굴 속도도 약간 높습니다.

모든 Fluix 도구에는 최소 행운 I 또는 약탈 I 효과가 기본 적용됩니다. 마법 부여대를 만들기 전 특히 유용합니다.

제작하려면 <ItemLink id="fluix_upgrade_smithing_template" />이 필요합니다.

## 제작법

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
