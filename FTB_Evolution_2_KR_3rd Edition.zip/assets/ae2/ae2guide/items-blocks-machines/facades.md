---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Facades
  icon: facade
  icon_components:
    "ae2:facade_item": "minecraft:stone"
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# Facade

Facade를 사용하면 기지의 케이블을 깔끔하게 감출 수 있습니다. 두 크기의 케이블을 모두 가릴 수 있고 여러 종류의 블록 재질로 만들 수 있습니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Facade로 케이블의 모든 면을 덮어도 [하위 부품](../ae2-mechanics/cable-subparts.md)와 케이블 연결 부분은 바깥쪽으로 돌출될 수 있습니다.

<GameScene zoom="6"  interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

적절히 조합하면 기지 외관을 개선하거나 면마다 다른 질감이 나타나는 블록처럼 꾸밀 수도 있습니다.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Facade 숨기기

어느 손이든 <ItemLink id="network_tool" />를 들고 있으면 Facade가 보이지 않게 됩니다.

Facade를 제거하지 않고도 뒤쪽 블록과 상호작용할 수 있습니다.

## 제작법

원하는 블록의 질감을 가진 Facade를 만들려면 <ItemLink id="cable_anchor" /> 네 개의 가운데에 해당 블록을 놓으세요.

![Facade Recipe](../assets/diagrams/facade_recipe.png)
