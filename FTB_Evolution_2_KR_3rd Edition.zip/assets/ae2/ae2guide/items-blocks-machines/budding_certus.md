---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Budding Certus Quartz
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# Budding Certus Quartz

(자세한 설명: [Certus Growth](../ae2-mechanics/certus-growth.md))

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

자수정처럼 Budding Certus 블록에서 Certus Quartz 싹이 자랍니다. 이 블록은 [meteorites](../ae2-mechanics/meteorites.md)에서 발견됩니다. Budding Certus 블록은 Flawless(완전한), Flawed(결함 있는), Chipped(금이 간), Damaged(손상된)의 네 등급으로 나뉩니다. HWYLA, Jade, The One Probe 같은 정보 표시 모드나 F3 화면으로 쉽게 구분할 수 있습니다.

Flawed, Chipped, Damaged Budding Certus는 싹이 한 단계 자랄 때마다 블록의 등급이 한 단계 낮아질 수 있습니다. 등급이 계속 떨어지면 결국 일반 <ItemLink id="quartz_block" />로 변합니다.

Flawless Budding Certus는 싹이 자라도 등급이 낮아지지 않으므로 무한한 공급원이 됩니다.

일반 곡괭이로 캐면 Budding Certus의 등급이 한 단계 낮아집니다. 섬세한 손길이 붙은 곡괭이를 쓰면 등급이 유지되지만 Flawless에는 적용되지 않습니다. **즉, Flawless Budding Certus는 곡괭이로 캐서 이동할 수 없습니다.** 대신 [Spatial Storage](../ae2-mechanics/spatial-io.md)을 사용해 블록을 잘라서 다른 장소에 붙여 넣을 수 있습니다.

## 제작법

Flawed, Chipped, Damaged Budding Certus는 직전 등급의 Budding 블록(또는 <ItemLink id="quartz_block" />)을 <ItemLink id="charged_certus_quartz_crystal" /> 한 개 이상과 함께 물에 던져 만들 수 있습니다.

Flawless Budding Certus는 제작할 수 없으며 월드에서만 얻을 수 있습니다.

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>
