---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz Crystal
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# Certus Quartz Crystal

<ItemImage id="certus_quartz_crystal" scale="4" />

*"Certus Quartz Crystal은 결정 구조 안에 대량의 에너지를 받아들일 수 있는 독특한 성질을 지니고 있습니다."*

AE2 블록과 [장치](../ae2-mechanics/devices.md), 아이템을 만드는 주요 재료 중 하나입니다. [Budding Certus](../ae2-mechanics/certus-growth.md)에서 성장시켜 얻습니다.

## 다른 제작법

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />
