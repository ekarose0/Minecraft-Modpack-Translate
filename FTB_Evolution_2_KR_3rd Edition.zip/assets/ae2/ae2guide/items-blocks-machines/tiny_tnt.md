---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Tiny TNT
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# Tiny TNT

<BlockImage id="tiny_tnt" scale="8" />

작은 폭발을 일으키는 소형 TNT입니다. <ItemLink id="quantum_entangled_singularity" /> 한 쌍을 만들 때 유용합니다.

서버에서 일반 TNT와 크리퍼의 폭발을 제한하려는 경우, 설정 파일에서 Tiny TNT가 블록을 파괴하지 않도록 지정할 수 있습니다. 이렇게 하면 지형을 훼손할 위험 없이 Singularity를 만들 수 있습니다.

## 제작법

<RecipeFor id="tiny_tnt" />
