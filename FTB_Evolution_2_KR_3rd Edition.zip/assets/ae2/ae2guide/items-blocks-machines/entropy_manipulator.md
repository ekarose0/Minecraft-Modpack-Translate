---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Entropy Manipulator
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# Entropy Manipulator

<ItemImage id="entropy_manipulator" scale="4" />

Entropy Manipulator는 우클릭으로 대상에 열을 가하고, Shift+우클릭으로 냉각합니다. 가능한 작업은 제한적이지만 물을 증발시키거나 얼리고, 용암을 흑요석으로 굳히고, 통나무를 숯으로 굽거나 조약돌을 돌로 바꾸는 등의 작업을 월드에서 직접 수행할 수 있습니다.

대상 블록에 별도의 작용이 정의되어 있지 않다면 부싯돌과 부시처럼 작동합니다.

에너지는 <ItemLink id="charger" />에서 충전할 수 있습니다.

## 제작법

<RecipeFor id="entropy_manipulator" />
