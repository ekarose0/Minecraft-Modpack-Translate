---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Annihilation Plane
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# Annihilation Plane

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

Annihilation Plane은 블록을 파괴하고 아이템을 줍습니다. <ItemLink id="import_bus" />와 비슷하게 작동하며 수거한 아이템은 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에 보냅니다. 아이템이 Plane의 앞면에 닿아야만 주우며 주변 영역 전체를 수거하는 장치는 아닙니다.

Annihilation Plane에는 곡괭이에 붙일 수 있는 모든 마법을 부여할 수 있습니다. 모드팩이 허용한다면 매우 높은 수준의 행운을 부여해 [automate ore processing](../example-setups/ore-fortuner.md)을 수행할 수도 있습니다. 섬세한 손길은 일반적인 방식으로 작동하고, 효율은 블록 파괴의 에너지 소모를 줄이며, 내구성은 에너지를 소모하지 않을 확률을 부여합니다.

Annihilation Plane은 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

**청크 보호 구역에서 가짜 플레이어(Fake Player)를 반드시 허용하세요!**

## 필터

Annihilation Plane은 결과물을 네트워크에 저장할 수 있을 때만 블록을 파괴하거나 아이템을 줍습니다. 따라서 필터링하려면 **네트워크가 저장할 수 있는 아이템을 제한해야 합니다.** 보통 Plane을 [subnetwork](../ae2-mechanics/subnetworks.md)에 연결합니다. <ItemLink id="storage_bus" /> 또는 [cell](../items-blocks-machines/storage_cells.md)를 [파티션 설정](cell_workbench.md)하면 원하는 동작을 만들 수 있습니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        파괴하려는 블록이 떨어뜨리는 아이템만 허용하도록 필터링합니다.
  </DiamondAnnotation>

<DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
        파괴하려는 블록이 떨어뜨리는 아이템만 허용하도록 파티션을 설정합니다.
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

다시 말해 필터는 **블록 자체가 아닌 드롭 아이템**을 기준으로 작동합니다. 예를 들어 <ItemLink id="minecraft:amethyst_cluster" />를 성장 단계별로 구분하여 파괴하려면 섬세한 손길이 부여된 Plane이 필요합니다. 그렇지 않으면 덜 자란 싹은 아무것도 떨어뜨리지 않으며, 네트워크에는 "아무것도 없음"을 언제나 저장할 수 있다고 판단하여 모든 성장 단계가 파괴됩니다.

## 제작법

<RecipeFor id="annihilation_plane" />
