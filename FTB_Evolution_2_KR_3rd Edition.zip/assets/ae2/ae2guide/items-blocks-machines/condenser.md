---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Condenser
  icon: condenser
  position: 310
categories:
- machines
item_ids:
- ae2:condenser
---

# Matter Condenser

<BlockImage id="condenser" scale="8" />

Matter Condenser는 쓰레기통으로 쓰거나 <ItemLink id="matter_ball" />과 [Singularity](singularities.md)를 만드는 데 사용합니다. 저장 셀에 보관할 수 있는 아이템, 유체 등의 물질을 투입할 수 있습니다.

## 설정 및 제작

* **폐기 모드:** 투입된 모든 물질을 삭제합니다.
* **Matter Ball 모드:** 투입한 물질로 <ItemLink id="matter_ball" />을 만듭니다. 이 모드는 장치 위쪽 슬롯에 저장 부품을 넣어야 합니다. Matter Ball 하나당 아이템 또는 양동이 256개 분량이 필요하므로 8,192비트 용량의 <ItemLink id="cell_component_1k" />이면 충분합니다.
* **Singularity 모드:** 투입한 물질로 [Singularity](singularities.md)를 만듭니다. 이때도 위쪽 슬롯에 저장 부품이 필요합니다. Singularity 하나당 아이템 또는 양동이 256,000개 분량이 필요하므로 524,288비트 용량의 <ItemLink id="cell_component_64k" />이면 충분합니다.

뒤의 두 모드에서는 생산되는 물품이 쌓일 수 있습니다. 에너지 버퍼와 출력 아이템 버퍼가 모두 가득 차면 더 이상 물질을 받지 않습니다.

## 제작법

<RecipeFor id="condenser" />
