---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Sky Stone Tank
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# Sky Stone Tank

<BlockImage id="sky_stone_tank" scale="8" />

액체를 양동이 16개 분량까지 저장할 수 있는 탱크입니다. 회수하면 내부 액체가 보존되지 않으므로 주의하세요.

## 제작법

<RecipeFor id="sky_stone_tank" />
