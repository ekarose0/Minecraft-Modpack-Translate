---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charged Certus Quartz Crystal
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# Charged Certus Quartz Crystal

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

<ItemLink id="certus_quartz_crystal" />을 <ItemLink id="charger" />로 충전한 결정입니다. <ItemLink id="fluix_crystal" /> 및 [Budding Certus 블록](../items-blocks-machines/budding_certus.md)을 만드는 데 사용됩니다.

## 제작법

<RecipeFor id="charged_certus_quartz_crystal" />
