---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wireless Access Point
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# Wireless Access Point

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

<ItemLink id="wireless_terminal" />을 통해 네트워크에 무선으로 접속할 수 있게 해 줍니다.
통신 범위와 전력 소모량은 설치된 <ItemLink id="wireless_booster" />의 수에 따라 달라집니다.

하나의 네트워크에 Wireless Access Point를 원하는 만큼 설치할 수 있으며, 각 장치에 넣는 <ItemLink id="wireless_booster" />의 수를 조절해 전력 소모량과 통신 범위를 최적화할 수 있습니다.

[채널](../ae2-mechanics/channels.md)이 필요합니다.

[Wireless Terminal](wireless_terminals.md)을 연결하는 데에도 사용합니다.

# Wireless Booster

<ItemImage id="wireless_booster" scale="2" />

Wireless Access Point의 통신 범위를 늘리는 데 사용합니다.

## 제작법

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />
