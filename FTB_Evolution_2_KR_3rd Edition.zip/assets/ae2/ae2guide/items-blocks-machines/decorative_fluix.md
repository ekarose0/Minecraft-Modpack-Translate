---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Decorative Fluix
  icon: fluix_stairs
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_stairs
- ae2:fluix_wall
- ae2:fluix_slab
---

# Decorative Fluix

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/decorative_fluix.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_block" />을 제작하거나 Stonecutter로 가공하면 여러 장식용 건축 블록을 만들 수 있습니다.

## 제작법

<Row>
  <RecipeFor id="fluix_stairs" />

  <RecipeFor id="fluix_wall" />

  <RecipeFor id="fluix_slab" />
</Row>
