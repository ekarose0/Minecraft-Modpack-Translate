---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Toggle Bus
  icon: toggle_bus
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:toggle_bus
- ae2:inverted_toggle_bus
---

# Toggle Bus

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/toggle_bus.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Toggle Bus는 <ItemLink id="fluix_glass_cable" /> 또는 다른 케이블처럼 작동하지만, 레드스톤 신호로 연결 상태를 전환할 수 있습니다. 이를 이용하면 [ME Network](../ae2-mechanics/me-network-connections.md)의 일부 구역을 분리할 수 있습니다.

레드스톤 신호를 받으면 연결이 활성화됩니다. <ItemLink id="inverted_toggle_bus" />는 반대로 신호를 받으면 연결을 끊습니다.

이 장치를 전환하면 네트워크가 다시 시작되고 연결된 장치 목록을 재계산할 수 있으니 주의하세요.

Toggle Bus는 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

## 제작법

<RecipeFor id="toggle_bus" />

<RecipeFor id="inverted_toggle_bus" />
