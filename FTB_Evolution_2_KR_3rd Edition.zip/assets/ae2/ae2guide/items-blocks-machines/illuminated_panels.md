---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Illuminated Panels
  icon: semi_dark_monitor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:monitor
- ae2:semi_dark_monitor
- ae2:dark_monitor
---

# Illuminated Panels

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/illuminated_panels.snbt" />
  <IsometricCamera yaw="-75" pitch="30" />
</GameScene>

Illuminated Panel은 장식용 광원이며 [Terminal](terminals.md) 제작에도 사용됩니다.

이 부품은 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)으로 설치할 수 있습니다.

## 제작법

<Row>
  <RecipeFor id="monitor" />

  <RecipeFor id="semi_dark_monitor" />

  <RecipeFor id="dark_monitor" />
</Row>
