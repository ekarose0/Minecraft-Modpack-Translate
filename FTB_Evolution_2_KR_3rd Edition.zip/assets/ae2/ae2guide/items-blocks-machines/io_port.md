---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME IO Port
  icon: io_port
  position: 210
categories:
- devices
item_ids:
- ae2:io_port
---

# ME I/O Port

<BlockImage id="io_port" p:powered="true" scale="8" />

ME I/O Port를 사용하면 [저장 셀](../items-blocks-machines/storage_cells.md)에 담긴 내용물을 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)로 빠르게 옮기거나, 반대로 네트워크의 내용물을 셀에 빠르게 채울 수 있습니다.

<ItemLink id="certus_quartz_wrench" />를 사용해 방향을 회전할 수 있습니다.

## 설정

* 셀이 비었을 때, 가득 찼을 때 또는 작업이 끝났을 때 셀을 출력 슬롯으로 이동하도록 설정할 수 있습니다.
* <ItemLink id="redstone_card" />를 장착하면 레드스톤 조건을 설정하는 옵션이 나타납니다.
* 화면 중앙의 화살표로 이동 방향을 정합니다. 셀에서 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)로 보내거나 네트워크 저장 공간에서 셀로 보낼 수 있습니다.

## 업그레이드

ME I/O Port는 다음 [업그레이드](upgrade_cards.md)를 지원합니다.

* <ItemLink id="speed_card" />: 한 번에 옮기는 물품의 양을 늘립니다.
* <ItemLink id="redstone_card" />: 레드스톤 제어 기능을 추가합니다. 높은 신호, 낮은 신호 또는 신호 펄스마다 한 번 작동하도록 설정할 수 있습니다.

## 제작법

<RecipeFor id="io_port" />
