---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cable Anchor
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# Cable Anchor

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

케이블에 설치하는 작은 장식용 고정 부품입니다. 케이블 사이의 연결을 차단하거나, 케이블을 사다리처럼 사용하거나, 주변 벽에 케이블이 연결된 것처럼 보이게 할 수 있습니다. <ItemLink id="facade" /> 제작에도 사용됩니다.

Cable Anchor를 설치한 면에서는 케이블 연결이 형성되지 않습니다.

사다리처럼 타고 올라갈 수도 있습니다.

## 제작법

<RecipeFor id="cable_anchor" />
