---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pattern Provider
  icon: pattern_provider
  position: 210
categories:
- devices
item_ids:
- ae2:pattern_provider
- ae2:cable_pattern_provider
---

# Pattern Provider

<Row gap="20">
<BlockImage id="pattern_provider" scale="8" />
<BlockImage id="pattern_provider" p:push_direction="up" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Pattern Provider는 [자동 제작](../ae2-mechanics/autocrafting.md) 시스템과 외부 세계를 연결하는 주요 장치입니다. 저장된 [패턴](patterns.md)에 따라 인접한 인벤토리로 재료를 밀어 넣으며, Provider에 아이템을 넣어 네트워크에 저장할 수도 있습니다. 기계의 결과물을 <ItemLink id="import_bus" />로 회수하는 대신 가까운 Pattern Provider(대개 재료를 공급한 장치)로 되돌려 보내면 채널 하나를 절약할 수 있습니다.

Pattern Provider는 Crafting CPU의 [Crafting Storage](crafting_cpu_multiblock.md#crafting-storage)에서 재료를 직접 밀어 내기 때문에, 장치 자체의 인벤토리에 재료를 보관하지 않습니다. 따라서 Provider에서 파이프로 재료를 직접 빼낼 수는 없습니다. 먼저 Provider가 Barrel 등의 다른 인벤토리에 재료를 넣도록 한 다음 그곳에서 파이프로 운반해야 합니다.

또한 Provider는 필요한 재료를 **한 번에 전부** 밀어 넣어야 하며, 일부만 나누어 공급할 수 없습니다. 이 특성을 자동화 설계에 활용할 수 있습니다.

Pattern Provider는 [서브넷](../ae2-mechanics/subnetworks.md)의 Interface와 특별하게 상호작용합니다. Interface를 기본 상태로 두고 요청 슬롯에 아무것도 설정하지 않았다면, Provider는 Interface의 인벤토리를 거치지 않고 서브넷의 [저장소](../ae2-mechanics/import-export-storage.md)로 재료를 직접 보냅니다. 따라서 Interface가 제작 재료로 가득 차지 않으며, 기계에 공간이 생길 때까지 다음 재료 묶음을 넣지 않습니다. Blocking Mode도 정상 작동하며, Interface가 아닌 실제 기계의 슬롯에 재료가 있는지를 확인합니다.

예를 들어 다음 구성에서는 제련할 아이템과 연료를 화로의 해당 슬롯에 직접 넣습니다. 같은 방식으로 한 기계의 여러 면이나 여러 기계에 재료를 공급할 수 있습니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Pattern Provider: Certus Quartz Wrench로 방향을 지정한 형태이며, 해당 Processing Pattern이 들어 있습니다.

        ![Iron Pattern](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface: 기본 설정 상태입니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Storage Bus #1: Coal만 허용하도록 필터를 설정합니다.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Storage Bus #2: Inverter Card를 사용하여 Coal을 제외하도록 필터를 설정합니다.
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

여러 기계에 재료를 공급하는 일반적인 구성 예시입니다.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (전체 블록이 아닌 평면형이어야 합니다)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        패턴에 따라 재료를 공급할 대상 위치
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

동일한 패턴을 가진 Pattern Provider를 여러 개 설치하면 병렬로 작동합니다.

Pattern Provider는 재료 묶음을 여러 면에 순차적으로 분배하려고 하므로, 연결된 기계를 병렬로 사용할 수 있습니다.

## 종류

Pattern Provider는 일반형, 방향 지정형, 평면형/[부속 부품](../ae2-mechanics/cable-subparts.md)의 세 종류가 있습니다. 종류에 따라 재료를 내보내는 면, 아이템을 받아들이는 면, 네트워크에 연결되는 면이 달라집니다.

* 일반형 Pattern Provider는 모든 면으로 재료를 공급하고 모든 면에서 아이템을 받습니다. 대부분의 AE2 기계처럼 케이블 역할도 하여 모든 면에 [네트워크 연결](../ae2-mechanics/me-network-connections.md)을 제공합니다.

* 방향 지정형 Pattern Provider는 일반형에 <ItemLink id="certus_quartz_wrench" />를 사용하여 방향을 변경하면 만들 수 있습니다. 선택한 면으로만 재료를 내보내지만 모든 면에서 아이템을 받을 수 있습니다. 선택한 면에는 [네트워크 연결](../ae2-mechanics/me-network-connections.md)을 제공하지 않으므로, 서브넷을 만들 때 네트워크를 서로 연결하지 않고 AE2 기계에 재료를 공급할 수 있습니다.

* 평면형 Pattern Provider는 [케이블 부속 부품](../ae2-mechanics/cable-subparts.md)이므로 케이블 하나에 여러 개를 설치해 공간을 절약할 수 있습니다. 방향 지정형의 선택된 면과 마찬가지로 패턴에 따른 재료 공급과 아이템 수령은 가능하지만, 장치가 향한 면에는 **[네트워크 연결](../ae2-mechanics/me-network-connections.md)을 제공하지 않습니다.**

일반형과 평면형은 제작 격자에서 서로 변환할 수 있습니다.

## 설정

Pattern Provider에는 여러 작동 모드가 있습니다.

*   **Blocking Mode**: 기계 안에 재료가 이미 있다면 다음 재료 묶음을 보내지 않습니다.
*   **Lock Crafting**: 다양한 레드스톤 조건에 따라 Provider를 잠그거나, 이전 제작 결과물이 해당 Pattern Provider로 돌아올 때까지 잠글 수 있습니다.
*   <ItemLink id="pattern_access_terminal" />에서 해당 Provider를 표시하거나 숨길 수 있습니다.

## 우선순위

화면 오른쪽 위의 렌치 버튼으로 우선순위를 설정할 수 있습니다. 동일한 아이템을 제작하는 [패턴](patterns.md)이 여러 개라면 우선순위가 높은 Provider의 패턴을 먼저 사용합니다. 다만 해당 패턴의 재료가 네트워크에 부족하면 우선순위가 낮은 패턴이 선택될 수 있습니다.

## 흔히 하는 오해

다음과 같이 구성하는 경우가 종종 있지만, 원하는 대로 작동하지 않습니다. 아마 <ItemLink id="export_bus" />만 네트워크 밖으로 아이템을 내보낼 수 있다고 생각하고, Pattern Provider도 재료를 내보낸다는 사실을 모르기 때문일 수 있습니다.

[케이블](cables.md) 설명에서 다뤘듯이 AE2 케이블은 아이템 파이프가 아니며 내부 인벤토리도 없습니다. 따라서 Provider는 케이블 안으로 아이템을 밀어 넣지 않습니다.

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_1.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Blast Furnace가 아닙니다
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

Provider가 재료를 보낼 인벤토리가 없으므로 제작 재료를 공급할 수 없습니다. 이 구성에서 Provider는 <ItemLink id="export_bus" />를 네트워크에 연결하는 케이블 역할만 합니다.

또한 Provider가 <ItemLink id="export_bus" />에 무엇을 내보내라고 지시하는 것도 아닙니다. Export Bus는 자체 필터에 설정된 아이템만 내보냅니다.

즉, 실제로는 다음과 같은 구성을 만든 셈입니다.

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_2.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Blast Furnace가 아닙니다
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

원하는 구성은 아마 다음과 같을 것입니다. Pattern Provider가 인접한 기계에 패턴의 재료를 직접 공급하도록 설치해야 합니다.

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_3.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Blast Furnace가 아닙니다
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

## Molecular Assembler와 함께 사용하기

<ItemLink id="molecular_assembler" />도 다른 기계와 마찬가지로 재료를 받을 인벤토리가 있고, 재료를 처리한 뒤 결과물을 인접한 인벤토리로 내보냅니다. 따라서 기본적으로는 다른 기계처럼 Provider와 연결해 사용하면 됩니다. 다만 특별한 기능이 하나 있습니다.

Assembler에 <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" />, <ItemLink id="stonecutting_pattern" />을 직접 넣어 사용할 수 있습니다. 조립 라인에서는 유용하지만, 제작법마다 전용 Assembler를 하나씩 배치하는 것은 번거롭습니다.

이를 해결하기 위해 Pattern Provider는 재료와 함께 패턴 정보도 Assembler에 전달할 수 있습니다. 따라서 Provider 옆에 Assembler를 설치하기만 하면 해당 Provider의 모든 Crafting, Smithing, Stonecutting 패턴에 Assembler 하나를 활용할 수 있습니다.

방법은 간단합니다. Provider에 패턴을 넣으면 됩니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

*이 구성에는 Provider가 정확히 8개 있습니다. Assembler, Provider 또는 Dense Cable이 아닌 일반 케이블 하나를 통해 전달할 수 있는 채널의 최대 개수입니다.*

## 제작법

<RecipeFor id="pattern_provider" />

<RecipeFor id="cable_pattern_provider" />
