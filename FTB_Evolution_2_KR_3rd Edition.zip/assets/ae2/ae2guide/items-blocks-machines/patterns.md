---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Patterns
  icon: crafting_pattern
  position: 410
categories:
- tools
item_ids:
- ae2:blank_pattern
- ae2:crafting_pattern
- ae2:processing_pattern
- ae2:smithing_table_pattern
- ae2:stonecutting_pattern
---

# Pattern

<ItemImage id="crafting_pattern" scale="4" />

Pattern은 <ItemLink id="pattern_encoding_terminal" />에서 빈 패턴에 제작법을 기록해 만들며, <ItemLink id="pattern_provider" /> 또는 <ItemLink id="molecular_assembler" />에 장착합니다.

작업 종류에 따라 여러 가지 Pattern이 있습니다.

* <ItemLink id="crafting_pattern" />: 제작대에서 만드는 레시피를 기록합니다. <ItemLink id="molecular_assembler" />에 직접 넣어 재료가 들어올 때마다 제작할 수도 있지만, 주로 Molecular Assembler 옆에 있는 <ItemLink id="pattern_provider" />에 장착합니다. 이때 Pattern Provider는 재료와 패턴 정보를 인접한 Assembler로 보냅니다. Assembler는 완성품을 인접한 인벤토리로 내보내므로 간단히 제작 패턴을 자동화할 수 있습니다.

***

* <ItemLink id="smithing_table_pattern" />: Crafting Pattern과 비슷하지만 대장장이 작업대의 레시피를 기록합니다. Pattern Provider와 Molecular Assembler로 같은 방식으로 자동화하며, 제작·대장장이·석재 절단 패턴을 동일한 설비에서 함께 사용할 수 있습니다.

***

* <ItemLink id="stonecutting_pattern" />: Stonecutter의 레시피를 기록합니다. Pattern Provider와 Molecular Assembler를 이용해 Crafting Pattern과 같은 방식으로 자동화하며, 제작·대장장이·석재 절단 패턴을 하나의 설비에서 사용할 수 있습니다.

***

* <ItemLink id="processing_pattern" />: 가장 유연하게 사용할 수 있는 일반 처리 패턴입니다. "Pattern Provider가 이 재료를 옆의 인벤토리로 보내면 언젠가 ME 시스템에 지정한 결과물이 들어온다"는 규칙만 정의합니다. 대부분의 모드 기계와 화로를 이 방식으로 자동화합니다. 재료를 복잡한 공장으로 보내 분류·가공하거나 무한 농장에서 추가 재료를 받아 사용하는 등 중간 과정에 제한이 없습니다. ME 시스템은 지정한 결과물만 돌아오면 재료와 결과물이 관련이 있는지도 확인하지 않습니다. 예를 들어 "Cherry Wood Planks 1개 → Nether Star 1개"라는 패턴을 만들고 판자를 받았을 때 Wither 농장이 Wither를 처치하도록 구성해도 작동합니다.

같은 패턴을 기록한 <ItemLink id="pattern_provider" />를 여러 개 사용하면 병렬 작업을 수행할 수 있습니다. 또한 "조약돌 1개 → 돌 1개" 대신 "조약돌 8개 → 돌 8개"로 기록하면 Pattern Provider가 작업마다 조약돌 하나가 아닌 여덟 개를 한 번에 보냅니다.

## 제작법

<RecipeFor id="blank_pattern" />
