---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Formation and Annihilation Cores
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# Formation and Annihilation Cores

<Row>
  <ItemImage id="formation_core" scale="4" />

  <ItemImage id="annihilation_core" scale="4" />
</Row>

AE2의 아이템 입출력 [장치](../ae2-mechanics/devices.md)를 제작할 때 사용하는 핵심 부품입니다. <ItemLink id="fluix_crystal" />의 에너지와 [Logic Processor](processors.md)를 활용해 장치가 아이템, 블록, 유체 등을 입출력하도록 하는 설정상의 부품입니다. Core 자체에는 별도 기능이 없으며 제작 중간 재료로 사용됩니다.

## 제작법

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />
