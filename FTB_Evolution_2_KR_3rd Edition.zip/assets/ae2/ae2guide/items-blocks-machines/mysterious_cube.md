---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Mysterious Cube
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# Mysterious Cube

<BlockImage id="mysterious_cube" scale="8" />

예전에는 모든 Press를 얻으려면 운석을 여러 개 찾아야 했습니다. 이제는 운석마다 Mysterious Cube가 하나씩 들어 있습니다.

Silk Touch 없이 부수면 어떤 일이 일어날까요...?

복제품인 Not So Mysterious Cube를 직접 만들 수도 있습니다.

## 제작법

Mysterious Cube 자체는 제작할 수 없지만, 복제품인 Not So Mysterious Cube는 제작할 수 있습니다.

<RecipeFor id="not_so_mysterious_cube" />
