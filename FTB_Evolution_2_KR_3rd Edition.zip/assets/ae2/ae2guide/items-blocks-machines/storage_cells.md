---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Storage Cells
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# Storage Cells

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />

    <ItemImage id="fluid_storage_cell_4k" scale="4" />

    <ItemImage id="fluid_storage_cell_16k" scale="4" />

    <ItemImage id="fluid_storage_cell_64k" scale="4" />

    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

Storage Cell은 Applied Energistics의 주요 저장 수단 중 하나입니다. <ItemLink id="drive" /> 또는 <ItemLink id="me_chest" />에 장착합니다.

저장 용량과 아이템 종류 제한에 관한 자세한 내용은 [바이트와 종류](../ae2-mechanics/bytes-and-types.md)를 참고하세요.

셀을 분해해 Storage Component와 Housing으로 되돌릴 수 있습니다. 먼저 셀을 비운 뒤, 손에 들고 Shift+우클릭하세요.

<Row>
    <Recipe id="upgrade/item_storage_cell_1k_to_4k" />

    제작대에서 상위 등급 Storage Component와 조합하면 Storage Cell을 업그레이드할 수 있습니다. 저장된 내용은 유지되며 기존 하위 등급 부품은 돌려받습니다.
</Row>

## 저장된 아이템 종류에 따른 용량

[아이템 종류별 기본 용량 소모](../ae2-mechanics/bytes-and-types.md) 때문에 한 종류만 저장하는 셀은 63종을 모두 사용하는 셀보다 약 두 배 많은 아이템을 저장할 수 있습니다.

| Cell                                     | 1종 저장 시 총 용량 | 63종 저장 시 총 용량 |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8,128 |                                       4,160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32,512 |                                      16,640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130,048 |                                      66,560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520,192 |                                     266,240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2,080,768 |                                   1,064,960 |


## 파티션 설정

<ItemLink id="storage_bus" />와 마찬가지로 셀도 특정 아이템만 받도록 필터를 설정할 수 있습니다. <ItemLink id="cell_workbench" />에서 설정하세요.

해당 아이템을 실제로 가지고 있지 않아도 JEI/REI에서 슬롯으로 끌어다 놓아 필터를 설정할 수 있습니다.

## Upgrades

Storage Cell에는 <ItemLink id="cell_workbench" />를 통해 다음 [Upgrade Card](upgrade_cards.md)를 장착할 수 있습니다.

*   <ItemLink id="fuzzy_card" /> (Fluid Cell에는 장착 불가): 내구도 기준으로 파티션을 설정하거나 아이템 NBT를 무시합니다.
*   <ItemLink id="inverter_card" /> 필터를 허용 목록에서 차단 목록으로 전환합니다.
*   <ItemLink id="equal_distribution_card" /> 아이템 종류마다 같은 양의 저장 공간을 배정하여 한 종류가 셀 전체를 채우지 못하게 합니다.
*   <ItemLink id="void_card" /> 셀이 가득 차면 들어오는 아이템을 삭제합니다. Equal Distribution Card가 있다면 해당 아이템에 배정된 공간이 찼을 때 삭제합니다. 농장의 생산물 적체를 막는 데 유용하지만 반드시 파티션을 설정하세요.
*   Portable Cell에는 <ItemLink id="energy_card" />를 장착해 배터리 용량을 늘릴 수 있습니다.

## 색상 변경

Portable Item Cell과 Portable Fluid Cell은 가죽 방어구처럼 염료와 조합해 색상을 변경할 수 있습니다.

# Housing

Storage Component와 Housing을 조합하거나, Storage Component 주위에 Housing 제작 재료를 배치해 셀을 만들 수 있습니다.

<Row>
  <Recipe id="network/cells/item_storage_cell_1k" />

  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

Housing 자체는 다음과 같이 제작합니다.

<Row>
  <RecipeFor id="item_cell_housing" />

  <RecipeFor id="fluid_cell_housing" />
</Row>

# Storage Component

Storage Component는 모든 AE2 셀의 핵심 부품으로, 셀의 저장 용량을 결정합니다. 등급이 한 단계 올라갈 때마다 용량이 4배가 되며 이전 등급 부품 3개가 필요합니다.

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />

    <RecipeFor id="cell_component_4k" />

    <RecipeFor id="cell_component_16k" />
  </Row>

  <Row>
    <RecipeFor id="cell_component_64k" />

    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# Item Storage Cells

Item Storage Cell은 서로 다른 아이템을 최대 63종까지 저장하며, 모든 표준 용량 등급으로 제작할 수 있습니다.

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />

    <Recipe id="network/cells/item_storage_cell_4k_storage" />

    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />

    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## 휴대용 아이템 저장소

주머니 속의 작은 <ItemLink id="me_chest" /> 또는 가방처럼 사용할 수 있습니다. <ItemLink id="charger" />로 충전할 수 있습니다.

일반 Storage Cell과 달리, 휴대용 셀은 바이트 용량이 커질수록 저장 가능한 종류 수가 *줄어듭니다*. 또한 전체 바이트 용량은 일반 셀의 절반입니다.

일반 셀에 장착 가능한 Upgrade Card 외에도 <ItemLink id="energy_card" />를 사용해 내장 배터리를 강화할 수 있습니다.

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />

    <RecipeFor id="portable_item_cell_4k" />

    <RecipeFor id="portable_item_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_item_cell_64k" />

    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# Fluid Storage Cells

Fluid Storage Cell은 서로 다른 유체를 최대 5종까지 저장하며, 모든 표준 용량 등급으로 제작할 수 있습니다.

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## 휴대용 유체 저장소

주머니 속의 작은 <ItemLink id="me_chest" /> 또는 가방처럼 사용할 수 있습니다. <ItemLink id="charger" />로 충전할 수 있습니다.

일반 Storage Cell과 달리, 휴대용 셀은 바이트 용량이 커질수록 저장 가능한 종류 수가 *줄어듭니다*. 또한 전체 바이트 용량은 일반 셀의 절반입니다.

일반 셀에 장착 가능한 Upgrade Card 외에도 <ItemLink id="energy_card" />를 사용해 내장 배터리를 강화할 수 있습니다.

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />

    <RecipeFor id="portable_fluid_cell_4k" />

    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />

    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# Creative Storage Cell

<Row>
  <ItemImage id="creative_storage_cell" scale="2" />
</Row>

Creative Cell은 **무한 저장 공간을 제공하지 않습니다**. 대신 [파티션](cell_workbench.md)에 지정한 아이템이나 유체를 무한히 공급하거나 받아들이는 역할을 합니다.
