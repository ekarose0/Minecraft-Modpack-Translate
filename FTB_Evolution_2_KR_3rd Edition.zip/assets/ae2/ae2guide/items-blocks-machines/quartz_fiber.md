---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quartz Fiber
  icon: quartz_fiber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quartz_fiber
---

# Quartz Fiber

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/quartz_fiber.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Quartz Fiber는 서로 다른 [네트워크](../ae2-mechanics/me-network-connections.md)를 분리된 상태로 유지하면서 전력만 공유하는 데 사용됩니다. 이를 활용하면 곳곳에 Energy Acceptor와 전력 케이블을 설치하지 않고도 [서브네트워크](../ae2-mechanics/subnetworks.md)에 전력을 공급할 수 있습니다.

케이블이 서로 연결되지 않도록 차단하는 용도로도 사용할 수 있지만, 색상이 다른 케이블을 사용하거나 <ItemLink id="cable_anchor" />를 설치하는 편이 더 저렴하고 효율적입니다.

Quartz Fiber는 [케이블 하위 부품](../ae2-mechanics/cable-subparts.md)입니다.

## 제작법

<RecipeFor id="quartz_fiber" />
