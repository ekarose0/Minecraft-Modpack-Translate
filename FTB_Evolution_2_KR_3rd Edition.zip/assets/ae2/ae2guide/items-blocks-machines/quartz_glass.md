---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quartz Glass
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# Quartz Glass

<BlockImage id="quartz_glass" scale="8" />

<ItemLink id="certus_quartz_dust" />로 만드는 거의 투명한 유리입니다. 다양한 AE2 기계와 아이템 제작에 사용됩니다.

빛을 내는 변형 블록인 Vibrant Quartz Glass도 있습니다.

## 제작법

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
