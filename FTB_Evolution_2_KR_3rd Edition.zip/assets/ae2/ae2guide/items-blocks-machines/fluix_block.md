---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Block
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# Fluix Block

<BlockImage id="fluix_block" scale="8" />

<ItemLink id="fluix_crystal" />을 압축해 보관하는 블록입니다. 일부 기계의 제작법에도 사용됩니다.

## 제작법

<RecipeFor id="fluix_block" />
