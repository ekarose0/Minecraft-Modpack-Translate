---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Energy Acceptor
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# Energy Acceptor

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" /> 

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

Energy Acceptor는 다른 기술 모드의 일반적인 에너지를 AE2 내부의 [에너지](../ae2-mechanics/energy.md) 단위인 AE로 변환합니다. <ItemLink id="controller" />도 변환할 수 있지만, Controller의 면은 채널 연결에 중요하므로 Energy Acceptor를 따로 사용하는 편이 좋습니다.

Forge Energy 및 Techreborn Energy의 변환 비율은 다음과 같습니다.

* 2 FE = 1 AE (Forge)
* 1 E = 2 AE (Fabric)

변환 속도는 네트워크에 저장할 수 있는 AE의 양에 따라 달라집니다. 자세한 원리는 [이 페이지](../ae2-mechanics/energy.md)에서 설명합니다.

## 형태

Energy Acceptor에는 일반 블록형과 납작한 [하위 부품](../ae2-mechanics/cable-subparts.md)형의 두 종류가 있어 공간을 더 효율적으로 사용할 수 있습니다.

제작대에서 일반형과 납작한 형태를 서로 바꿀 수 있습니다.

## 제작법

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />
