---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Smithing Template
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Fluix Smithing Template

바닐라 대장장이 형판과 달리 재료를 모아 직접 제작할 수 있습니다.

[Fluix 도구](fluix_tools.md)를 제작할 때 필요합니다.

## 제작법

<RecipeFor id="fluix_upgrade_smithing_template" />