---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ender Dust
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# Ender Dust

<ItemImage id="ender_dust" scale="4" />

<ItemLink id="inscriber" />로 엔더 진주를 분쇄해 얻는 가루입니다. <ItemLink id="wireless_booster" />와 <ItemLink id="quantum_entangled_singularity" /> 쌍을 제작하는 데 사용됩니다.

## 제작법

<RecipeFor id="ender_dust" />
