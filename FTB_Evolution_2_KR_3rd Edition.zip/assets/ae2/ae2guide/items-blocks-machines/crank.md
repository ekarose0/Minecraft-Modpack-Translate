---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Crank
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# Crank

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Crank는 다른 전력 공급 수단이나 <ItemLink id="energy_acceptor" />가 없을 때 기계를 수동으로 작동시키는 데 사용합니다. 게임 초반에 유용합니다.

## 제작법

<RecipeFor id="crank" />
