---
navigation:
  title: "Add-on: AE2 Import Export Card"
  icon: ae2importexportcard:export_card
  position: 150
categories:
  - tools
item_ids:
- ae2importexportcard:export_card
- ae2importexportcard:import_card
- ae2importexportcard:block_picker_card
---

# AE2 Import Export Card

<Row>
  <ItemImage id="ae2importexportcard:export_card" scale="2" />

  <ItemImage id="ae2importexportcard:import_card" scale="2" />

  <ItemImage id="ae2importexportcard:block_picker_card" scale="2" />
</Row>

Import Card, Export Card, Block Picker Card를 사용하면 인벤토리와 ME 시스템 사이에서 아이템을 가져오거나 내보낼 수 있습니다.

## Import Card

<ItemImage id="ae2importexportcard:import_card" scale="2" />

Import Card는 플레이어 인벤토리의 지정된 슬롯에 있는 아이템을 ME 시스템으로 이동시킵니다.

![Import Card](diagrams/import_card.png)

슬롯을 클릭하면 체크 표시가 나타납니다. 체크된 슬롯의 아이템은 ME 시스템으로 들어갑니다. 필터를 변경하려면 인벤토리의 아이템을 위쪽 영역으로 드래그하세요.

### 업그레이드

Import Card에는 다음 [업그레이드](items-blocks-machines/upgrade_cards.md)를 사용할 수 있습니다.

*   <ItemLink id="fuzzy_card" /> 내구도 수준으로 필터링하거나 아이템 NBT를 무시합니다.
*   <ItemLink id="inverter_card" /> 필터를 허용 목록에서 차단 목록으로 전환합니다.

### 제작법

<RecipeFor id="ae2importexportcard:import_card" />

## Export Card

<ItemImage id="ae2importexportcard:export_card" scale="2" />

Export Card는 반대로 ME 시스템에서 아이템을 꺼내 플레이어 인벤토리에 넣습니다.

![Export Card](diagrams/export_card.png)

내보낼 아이템을 지정하려면 인벤토리의 아이템을 위쪽 필터 슬롯으로 드래그하세요. 인벤토리 슬롯을 클릭하면 원하는 수량으로 설정할 수 있으며, 우클릭하면 X 표시로 초기화됩니다.

### 업그레이드

Export Card에는 다음 [업그레이드](items-blocks-machines/upgrade_cards.md)를 사용할 수 있습니다.

*   <ItemLink id="fuzzy_card" /> 내구도 수준으로 필터링하거나 아이템 NBT를 무시합니다.
*   <ItemLink id="speed_card" /> 한 번에 전송하는 양을 아이템 1개에서 최대 한 스택까지 늘립니다.
*   <ItemLink id="crafting_card" /> 현재 없는 아이템의 자동 제작을 요청합니다.

### 제작법

<RecipeFor id="ae2importexportcard:export_card" />

## Block Picker Card

<ItemImage id="ae2importexportcard:block_picker_card" scale="2" />

Block Picker Card를 사용하면 바라보는 블록을 네트워크에서 바로 꺼낼 수 있습니다. 블록을 바라본 상태에서 "Pick Block" 단축키를 누르세요. 네트워크에 해당 블록이 있으면 인벤토리로 가져옵니다.

![Block Picker Card](diagrams/block_picker_card.png)

### 제작법

<RecipeFor id="ae2importexportcard:block_picker_card" />