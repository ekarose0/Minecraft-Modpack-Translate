---
navigation:
  title: Tips and Tricks
  position: 20
---

# 팁과 요령

알아 두면 유용한 작은 팁들을 모았습니다.

* Optifine을 제거하세요.
* 가이드북 장면에 확대·축소 및 주석 표시 버튼이 있다면 장면을 회전하거나 확대할 수 있습니다.
* 네트워크는 나무처럼 가지를 뻗는 구조로 만들고 고리 형태의 순환 연결은 피하세요.
* [장치](ae2-mechanics/devices.md)와 같은 전체 블록 장치는 [채널](ae2-mechanics/channels.md)이 네트워크에서 어떻게 전달되는지 충분히 이해하기 전까지 8개 이하씩 묶어 연결하세요.
* 모든 [Pattern](items-blocks-machines/patterns.md)에 동일한 목재 종류를 사용하세요. 패턴의 재료 대체 기능이 작동할 때도 있지만 목재를 통일하면 관리가 훨씬 편리합니다.
* [Pattern](items-blocks-machines/patterns.md)을 <ItemLink id="pattern_access_terminal" />에서 세로로 정렬하거나 여러 [Pattern Provider](items-blocks-machines/pattern_provider.md)에 분산하여 작업을 병렬로 처리하세요.
* 순간적인 전력 사용량 증가를 감당할 수 있도록 [Energy Cell](items-blocks-machines/energy_cells.md)을 추가하세요.
* <ItemLink id="condenser" />에는 물도 사용할 수 있습니다.
* 검이나 방어구처럼 무작위로 얻는 몬스터 전리품을 네트워크 저장 공간에 쌓지 마세요. 마법 부여와 내구도가 다른 조합마다 별개의 [종류](ae2-mechanics/bytes-and-types.md)로 취급됩니다.
* [Processing Pattern](items-blocks-machines/patterns.md)의 제작 결과를 반환하려면 <ItemLink id="import_bus" />, <ItemLink id="interface" />, <ItemLink id="pattern_provider" />의 반환 슬롯 등을 통해 실제로 "아이템이 시스템에 들어오는" 동작이 발생해야 합니다. <ItemLink id="storage_bus" />를 붙인 상자에 결과물만 넣어 두어서는 안 됩니다.
* 확대·축소 및 주석 표시 버튼이 있는 가이드북 장면은 자유롭게 회전할 수 있습니다.
* <ItemLink id="pattern_provider" />는 완성된 레시피 한 묶음만 한쪽 면으로 밀어 넣습니다. 여러 장소로 재료를 나누고 싶다면 <ItemLink id="interface" />를 [배관형 서브네트워크](example-setups/pipe-subnet.md)으로 사용하거나 여러 종류의 아이템·유체·화학 물질을 동시에 보관하는 중간 상자나 탱크처럼 활용하세요.
* 가이드북 장면의 확대·축소 및 회전 기능을 활용하세요.
