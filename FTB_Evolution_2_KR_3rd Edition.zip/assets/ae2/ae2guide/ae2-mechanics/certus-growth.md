---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Certus Growth
  icon: quartz_cluster
---

# Certus Quartz 성장

## 시작하기 페이지의 설명 요약

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

자수정처럼 [budding certus blocks](../items-blocks-machines/budding_certus.md)에서 Certus Quartz 싹이 자랍니다. 성장하기 전의 싹을 깨면 <ItemLink id="certus_quartz_dust" /> 하나가 나오며 행운 마법의 영향을 받지 않습니다. 완전히 자란 군집을 깨면 <ItemLink id="certus_quartz_crystal" /> 네 개가 나오고 행운 마법에 따라 그 수가 늘어납니다.

Budding Certus 블록은 Flawless(완전한), Flawed(결함 있는), Chipped(금이 간), Damaged(손상된)의 네 등급이며 처음에는 [meteorites](../ae2-mechanics/meteorites.md)에서 발견합니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

싹이 한 단계 성장할 때마다 Budding Certus 블록의 등급이 한 단계 떨어질 확률이 있습니다. 등급이 계속 낮아지면 일반 Certus Quartz 블록으로 바뀝니다. Budding 블록(또는 일반 Certus Quartz 블록)을 <ItemLink id="charged_certus_quartz_crystal" /> 하나 이상과 함께 물에 던지면 등급을 회복하거나 새 Budding 블록을 만들 수 있습니다.

<RecipeFor id="damaged_budding_quartz" />

Flawless Budding Certus는 등급이 떨어지지 않아 Certus Quartz를 무한히 생산합니다. 다만 제작할 수 없고 섬세한 손길이 달린 곡괭이로도 채집하거나 옮길 수 없습니다. 대신 [공간 저장](../ae2-mechanics/spatial-io.md)을 사용하면 이동할 수 있습니다.

Certus Quartz 싹은 그대로 두면 매우 느리게 성장합니다. 다행히 <ItemLink id="growth_accelerator" />를 인접하게 설치하면 성장 속도가 크게 올라갑니다. 초반에는 이 장치를 몇 개 만드는 것을 우선하세요.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

여러 효과가 맞물리기 때문에 Budding 블록의 면을 많이 가릴수록 전체 성장 속도가 낮아지고, 가속기를 더 설치하는 이점을 상쇄할 수 있습니다. 실제 실험에서 확인한 결과는 다음과 같습니다.

![Items/min for ratios](../assets/diagrams/certus_farm_speed_chart_1.png)

![common setups](../assets/diagrams/certus_farm_speed_chart_2.png)

아직 <ItemLink id="energy_acceptor" />나 <ItemLink id="vibration_chamber" />를 만들 Quartz가 충분하지 않다면 <ItemLink id="crank" />를 만들어 가속기 끝에 장착하면 됩니다.

Certus Quartz를 자동으로 수확하는 방법은 [described here](../example-setups/simple-certus-farm.md)에서 설명합니다.
