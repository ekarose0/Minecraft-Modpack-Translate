---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 장치
  icon: interface
---

# 장치

"장치"란 네트워크 자체와 관련된 기능을 수행하는 AE2 네트워크 구성 요소를 뜻합니다. [Level Emitter](../items-blocks-machines/level_emitter.md)와 같은 일부 예외를 제외하면 대부분 채널이 필요합니다.

대표적인 장치는 다음과 같습니다:

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
