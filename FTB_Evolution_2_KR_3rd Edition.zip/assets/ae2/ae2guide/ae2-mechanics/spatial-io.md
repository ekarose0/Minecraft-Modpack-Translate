---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
    title: 공간 입출력(Spatial IO)
  icon: spatial_storage_cell_2
---

# 공간 입출력(Spatial IO)

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/spatial_storage_1x1x1.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="2 2 2">
        이동할 공간의 범위
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />

</GameScene>

Spatial IO는 월드의 일정한 공간을 잘라내어 다른 곳에 붙여 넣는 기능입니다. <ItemLink id="flawless_budding_quartz" />를 이동하거나, 기지의 방 내부를 목적에 따라 교체하거나, End Portal까지 이동할 수 있습니다.

작동 원리는 지정한 공간을 Spatial Storage 차원의 같은 크기 공간과 *맞바꾸는 것*입니다. Pylon 배열 안의 내용물은 Spatial Storage 차원으로 이동하고, 그 차원에 있던 내용물은 Pylon 배열로 이동합니다.

따라서 차원 사이를 이동할 방법이 있다면 원하는 크기의 Compact Machine이나 개인 차원처럼 활용할 수 있습니다. Spatial IO 자체로 순간이동 장치를 만드는 것도 *가능*하지만 매우 복잡하고 불안정하여 이 설명서에서는 다루지 않습니다.

# 멀티블록 구성

Spatial IO가 작동하려면 부품을 정해진 방식으로 배치해 이동할 공간을 정의해야 합니다.

모든 부품은 같은 [네트워크](me-network-connections.md)에 연결되어야 하며, 네트워크 하나당 Spatial IO 설비는 하나만 설치할 수 있습니다. 따라서 [서브네트워크](subnetworks.md)를 사용하는 것이 좋습니다.

## Spatial IO Port

<BlockImage id="spatial_io_port" p:powered="true" scale="4" />

<ItemLink id="spatial_io_port" />는 Spatial IO 작업을 제어하고 멀티블록 상태를 표시하며 [Spatial Cell](../items-blocks-machines/spatial_cells.md)을 보관합니다.

다음 정보를 표시합니다.
- 네트워크의 현재 및 최대 [에너지](energy.md)
- 작업에 필요한 에너지. 순간적으로 막대한 에너지가 소모될 수 있으므로 충분한 [Energy Cell](../items-blocks-machines/energy_cells.md)을 설치해야 합니다.
- Pylon 배열의 효율
- 지정한 공간의 크기

Spatial IO 작업을 실행하려면 입력 슬롯에 Spatial Storage Cell을 넣고 Spatial IO Port에 레드스톤 펄스를 보내세요. 그러면 Pylon 안의 공간과 Spatial Storage 차원의 공간이 *교환*됩니다. 첫 번째 블록 구성을 차원으로 보낸 뒤 Pylon 안에 다른 블록 구성을 설치하고 같은 셀로 다시 작동시키면, 두 번째 블록 구성은 사라지고 첫 번째 블록 구성이 돌아옵니다.

**주의: 지정한 공간 안에 있는 모든 엔티티는 플레이어를 포함해 함께 이동합니다. 탈출 수단이 없으면 Spatial Storage 차원의 어둡고 아무것도 없는 공간에 갇힐 수 있습니다.** 친구에게 장난을 칠 때도 주의하세요!

## Pylon

<BlockImage id="spatial_pylon" p:powered_on="true" scale="4" />

<ItemLink id="spatial_pylon" />는 Spatial IO의 핵심 부품이며 이동할 공간의 범위를 정의합니다.

이동 범위는 Pylon 바깥쪽을 둘러싼 직육면체에서 모든 방향으로 1블록씩 안쪽으로 줄인 공간입니다.

배치 규칙은 다음과 같습니다.
- 최소 크기는 3×3×3이며 내부 공간은 1×1×1입니다.
- 모든 Spatial Pylon은 바깥 경계 상자 안에 있어야 합니다.
- 모든 Spatial Pylon은 같은 네트워크에 연결되어야 합니다.
- 각 Pylon은 최소 2블록 길이여야 합니다.

예를 들어 3×3×3 공간을 지정하려면 규칙 2에 따라 Pylon을 해당 공간을 둘러싼 5×5×5 껍질 안에 배치해야 합니다. 두께가 1블록인 이 경계 안에 있기만 하면 배치 형태는 거의 자유롭습니다.

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/spatial_storage_3x3x3_pylon_demonstration.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        이동할 공간의 범위
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

실용적인 배치 예시는 다음과 같습니다.

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/better_spatial_storage_3x3x3.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        이동할 공간의 범위
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 효율

Pylon 배열의 효율은 경계 영역을 얼마나 채웠는지에 따라 달라집니다. 큰 공간에 Pylon을 최소한으로 배치하면 효율이 매우 낮아져 *수십억 AE*가 필요할 수도 있습니다.

## 셀 크기

[Spatial Cell](../items-blocks-machines/spatial_cells.md)을 한 번 사용하면 XYZ 크기(예: 3×4×2)가 영구적으로 고정되고 Spatial Storage 차원의 특정 공간과 연결됩니다. **한 번 사용한 Spatial Cell은 초기화하거나 재포맷하거나 크기를 변경할 수 없습니다.** 다른 크기가 필요하면 새 셀을 제작해야 합니다. 

이는 셀 이름에 표시된 크기와 다릅니다. 16^3 Cell은 각 축이 최대 16블록인 범위에서 다양한 크기를 사용할 수 있습니다.

공간에는 방향이 있으며 회전할 수 없습니다. 2×2×3과 3×2×2는 전체 부피가 같더라도 서로 다른 크기로 취급됩니다.

셀의 XYZ 크기가 IO Port에 표시된 공간 크기와 일치하지 않으면 IO Port가 작동하지 않습니다.