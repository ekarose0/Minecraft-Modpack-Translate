---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Meteorites
  icon: sky_stone_block
---

# Meteorites

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

운석은 AE2를 시작하는 데 중요한 장소입니다. 여러 종류의 [Budding Certus 블록](../items-blocks-machines/budding_certus.md)과 중앙에 있는 <ItemLink id="mysterious_cube" /> 등 핵심 재료를 얻을 수 있습니다.

운석을 발견한 뒤 무엇을 해야 할지는 [시작하기](../getting-started.md) 문서를 참고하세요.

## 운석 찾기

운석은 비교적 흔하며 지면에 커다란 구덩이를 남기므로 이미 몇 개를 발견했을 수도 있습니다. 아직 찾지 못했다면 <ItemLink id="meteorite_compass" />를 사용하세요. 가장 가까운 Mysterious Cube가 있는 방향을 가리킵니다.

![운석 충돌구](../assets/assemblies/meteorite-crater.png)
