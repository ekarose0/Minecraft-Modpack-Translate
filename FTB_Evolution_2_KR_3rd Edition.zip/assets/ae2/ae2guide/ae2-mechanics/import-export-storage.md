---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
    title: 아이템 가져오기·내보내기·저장
---

# 아이템 가져오기·내보내기·저장

**ME 시스템과 외부 세계의 연결**

AE2의 핵심 개념 중 하나는 네트워크 저장 공간입니다. 네트워크의 아이템을 보관하는 곳으로, 일반적으로 [Storage Cell](../items-blocks-machines/storage_cells.md)이나 <ItemLink id="storage_bus" />가 연결된 인벤토리가 해당합니다. 대부분의 AE2 [장치](../ae2-mechanics/devices.md)는 어떤 방식으로든 이 저장 공간과 상호작용합니다.

예를 들면 다음과 같습니다.

*   <ItemLink id="import_bus" />는 아이템을 네트워크 저장소에 넣습니다.
*   <ItemLink id="export_bus" />는 네트워크 저장소에서 아이템을 꺼냅니다.
*   <ItemLink id="interface" />는 네트워크 저장소에서 아이템을 꺼내거나 넣을 수 있습니다.
*   [Terminal](../items-blocks-machines/terminals.md)은 아이템을 넣거나 꺼내거나 제작 슬롯을 보충할 때 네트워크 저장소와 양방향으로 아이템을 이동시킵니다.
*   <ItemLink id="storage_bus" />는 네트워크 저장소에서 직접 입출력하는 것이 아니라 연결된 인벤토리를 네트워크 저장소로 사용하게 합니다. 즉 다른 장치들이 *Storage Bus*를 통해 아이템을 입출력합니다.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_export_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="8 1 1" max="9 1.3 2">
        Import Bus는 향하고 있는 인벤토리에서 아이템을 가져와 네트워크 저장소에 넣습니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="8 2 1" max="9 3 1.3">
        플레이어 인벤토리에서 Terminal에 아이템을 넣는 것도 네트워크의 가져오기 동작입니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="7 0 1" max="8 1 2">
        Interface의 슬롯에 비축할 아이템이 지정되지 않았거나 지정된 수량보다 많은 아이템이 들어 있으면, Interface는 그 아이템을 네트워크로 가져옵니다. 따라서 Interface에 아이템을 밀어 넣어 네트워크에 저장할 수 있습니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="6 0 1" max="7 1 2">
        Pattern Provider는 내부 반환 슬롯의 아이템을 네트워크로 가져옵니다. 따라서 이곳으로 아이템을 밀어 넣어 네트워크에 저장할 수 있습니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 2 2">
        Drive는 장착된 Storage Cell을 네트워크 저장 공간으로 제공합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        Storage Bus는 향하고 있는 인벤토리를 네트워크 저장 공간으로 사용합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 1" max="2 1.3 2">
        Export Bus는 네트워크 저장소의 아이템을 향하고 있는 인벤토리로 내보냅니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="2 3 1.3">
        Terminal에서 아이템을 꺼내는 것도 네트워크의 내보내기 동작입니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 2 2">
        Interface의 슬롯에 비축할 아이템이 지정되어 있으면 해당 아이템을 내부 인벤토리에 채웁니다. 따라서 Interface에서 아이템을 꺼내 네트워크의 저장물을 추출할 수 있습니다.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

자동화와 물류 시스템을 설계할 때는 네트워크 저장 공간으로 아이템이 들어오고 나가는 방식을 이해하는 것이 중요합니다.

## 저장 우선순위

일부 GUI의 오른쪽 위 렌치 버튼으로 저장 우선순위를 설정할 수 있습니다. 네트워크에 들어오는 아이템은 우선순위가 가장 높은 저장소부터 채워집니다. 우선순위가 같은 저장소가 여러 개라면 해당 아이템을 이미 보관하고 있는 저장소가 우선됩니다. 허용 목록이 설정된 셀은 같은 우선순위 그룹에서 해당 아이템을 이미 보관하는 것으로 간주됩니다. 반대로 아이템을 꺼낼 때는 우선순위가 가장 낮은 저장소부터 사용합니다. 따라서 높은 우선순위의 저장소는 먼저 채워지고, 낮은 우선순위의 저장소는 먼저 비워집니다.
