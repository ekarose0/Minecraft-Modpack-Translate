---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 네트워크 연결
  icon: fluix_glass_cable
---

# 네트워크 연결

## 네트워크란 무엇인가요?

"네트워크"는 [채널](../ae2-mechanics/channels.md)을 전달할 수 있는 블록으로 서로 연결된 [장치](../ae2-mechanics/devices.md)의 집합입니다. [Cable](../items-blocks-machines/cables.md)뿐 아니라 한 블록을 차지하는 기계와 [장치](../ae2-mechanics/devices.md)(<ItemLink id="charger" />, <ItemLink id="interface" />, <ItemLink id="drive" /> 등)도 연결에 사용됩니다. 엄밀히 말하면 Cable 하나만 있어도 네트워크입니다.

## 장치의 설치 위치에 관하여

[네트워크 저장소](../ae2-mechanics/import-export-storage.md)에 아이템을 넣고 꺼내는 <ItemLink id="interface" />, 저장량을 확인하는 <ItemLink id="level_emitter" />, 저장 공간을 제공하는 <ItemLink id="drive" />처럼 네트워크 기능을 수행하는 [장치](../ae2-mechanics/devices.md)는 물리적인 설치 위치가 중요하지 않습니다.

다시 말해 **장치의 물리적인 위치는 중요하지 않습니다**. 중요한 것은 네트워크에 연결되어 있는지, 그리고 *어느 네트워크*에 연결되어 있는지입니다.

## 네트워크 연결

어떤 장치가 네트워크에 연결되었는지 확인하려면 <ItemLink id="network_tool" />를 사용하세요. 네트워크의 모든 구성 요소가 표시됩니다. 연결되면 안 되는 것이 보이거나 있어야 할 것이 없다면 연결에 문제가 있는 것입니다.

예를 들어 아래 구조는 서로 분리된 두 네트워크입니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        네트워크 1
  </BoxAnnotation>

<BoxAnnotation color="#5CA7CD" min="2 0 0" max="3 2 2">
        네트워크 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

이 구조도 두 네트워크입니다. <ItemLink id="quartz_fiber" />는 [에너지](../ae2-mechanics/energy.md)만 공유하고 네트워크 연결은 전달하지 않기 때문입니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        네트워크 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="1.3 0 0" max="3 2 2">
        네트워크 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

반면 이 구조는 하나의 네트워크입니다. [Quantum Bridge](../items-blocks-machines/quantum_bridge.md)는 무선 [Dense Cable](../items-blocks-machines/cables.md#dense-cable)처럼 작동하므로 양쪽 끝이 같은 네트워크에 속합니다.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
        모두 하나의 네트워크
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

이 구조도 하나의 네트워크입니다. [Cable](../items-blocks-machines/cables.md)의 색상은 서로 다른 색상의 Cable끼리 연결되지 않게 하는 기능만 있습니다. 모든 색상은 Fluix(무색) Cable에 연결됩니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        모두 하나의 네트워크
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 서브네트워크에서의 연결

[서브네트워크](../ae2-mechanics/subnetworks.md)는 네트워크를 연결하거나 의도적으로 **연결하지 않는** 방식으로 [장치](../ae2-mechanics/devices.md)가 접근할 수 있는 다른 장치를 제한합니다.

결국 서브네트워크란 별도로 분리된 네트워크입니다.

[Automatic Ore Fortuner](../example-setups/ore-fortuner.md)를 예로 들면, 서로 다른 목적을 수행하는 네트워크 3개가 있습니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 2" max="3 1 3">
        네트워크 1: 파이프형 서브네트워크입니다. Import Bus의 접근 범위를 제한하여 Formation Plane을 통해 광석 블록을 "저장"하도록 합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="0 0 0" max="3 1 1">
        네트워크 2: 또 다른 파이프형 서브네트워크입니다. Annihilation Plane의 접근 범위를 제한하여 채굴한 광석을 메인 네트워크가 아닌 Barrel에 저장합니다. 따라서 메인 네트워크의 채널도 사용하지 않습니다.
  </BoxAnnotation>

  <BoxAnnotation color="#82CD5C" min="2 0 1" max="4 1 2">
        네트워크 3: 저장과 제작을 담당하는 메인 네트워크입니다. 여기서는 사실상 전력만 공급하며, 다른 두 서브네트워크와는 *연결되지 않습니다*.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## P2P에서의 연결

[P2P Tunnel](../items-blocks-machines/p2p_tunnels.md) 중에는 아이템·유체·레드스톤 신호 대신 [채널](channels.md)을 전송하는 종류가 있습니다. P2P Tunnel이 설치된 네트워크와 그 터널을 통해 전달되는 네트워크는 서로 별개입니다. 두 네트워크가 같을 수도 있지만 그럴 필요는 없으며, 보통은 서로 다릅니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels_network_connection.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 1">
        네트워크 1: 전송되는 네트워크(보통 메인 네트워크)
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="3.98 1 1">
        네트워크 2: ME P2P Tunnel을 구동하는 네트워크(보통 메인 네트워크가 *아님*)
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="4.02 0 0" max="6 1 1">
        네트워크 1: 전송되는 네트워크(보통 메인 네트워크)
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 직관적이지 않은 연결

이 구조는 하나의 네트워크입니다. 한 블록을 차지하는 <ItemLink id="pattern_provider" />가 Cable처럼 작동하고, <ItemLink id="inscriber" />도 비슷하기 때문입니다. 따라서 네트워크 연결이 두 장치를 통과합니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        모두 하나의 네트워크
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

이 연결을 막으려면 <ItemLink id="certus_quartz_wrench" />로 Pattern Provider를 우클릭하여 방향을 지정하세요. 그러면 한쪽 면으로 채널이 전달되지 않습니다. [서브네트워크](../ae2-mechanics/subnetworks.md)를 활용하는 자동 제작 구성에 유용합니다.

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 2">
        네트워크 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="4 2 2">
        네트워크 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
        Cable이 연결되지 않는 것을 확인하세요
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

<ItemLink id="import_bus" />, <ItemLink id="storage_bus" />, <ItemLink id="cable_interface" /> 등 대부분의 [케이블 부착형](../ae2-mechanics/cable-subparts.md) [장치](../ae2-mechanics/devices.md)도 방향별 네트워크 연결을 전달하지 않습니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>