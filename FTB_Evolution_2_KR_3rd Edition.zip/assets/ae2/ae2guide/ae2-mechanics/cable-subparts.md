---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Cable Subparts
icon: fluix_glass_cable
---

# Cable Subparts

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

AE2에서는 일부 [장치](devices.md)와 부품을 같은 블록 공간에 있는 케이블 위에 함께 설치할 수 있습니다. 공간을 절약해 장치를 구성할 때 유용합니다.

<ItemLink id="certus_quartz_wrench" /> 또는 <ItemLink id="network_tool" />을 들고 Shift+우클릭하면 해당 블록의 다른 부품은 그대로 두고 특정 부품이나 케이블만 분리할 수 있습니다.
