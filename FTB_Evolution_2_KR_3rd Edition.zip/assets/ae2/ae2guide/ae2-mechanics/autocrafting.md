---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Autocrafting
  icon: pattern_provider
---

# Autocrafting

### 자동 제작의 핵심

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Autocrafting은 AE2의 핵심 기능 중 하나입니다. 필요한 하위 재료를 일일이 계산하고 직접 제작하는 대신 ME 시스템에 작업을 맡길 수 있습니다. 아이템을 자동으로 제작하여 다른 곳으로 내보내거나, 특정 아이템을 일정 수량 이상 유지하도록 구성할 수도 있습니다. 유체에도 적용되며, Mekanism의 가스처럼 다른 모드의 재료 유형을 지원하는 애드온이 있다면 그런 재료도 자동화할 수 있습니다.

다소 복잡한 주제이므로 차근차근 살펴보겠습니다.

자동 제작 시스템은 다음 세 가지로 구성됩니다.
- 제작 요청을 보내는 장치 또는 플레이어
- Crafting CPU
- <ItemLink id="pattern_provider" />

작동 과정은 다음과 같습니다.

1.  제작 요청이 발생합니다. 플레이어가 Terminal에서 자동 제작 가능한 아이템을 선택하거나, Crafting Card를 장착한 Export Bus 또는 Interface가 지정된 아이템의 제작을 요청할 수 있습니다.

*   (**중요:** 이미 보유한 아이템의 제작을 요청할 때는 '블록 선택'에 지정된 키(일반적으로 마우스 가운데 버튼)를 사용합니다. 인벤토리 정렬 모드와 단축키가 충돌할 수 있습니다.)

2.  ME 시스템이 요청을 처리하는 데 필요한 재료와 선행 제작 단계를 계산하고, 선택한 Crafting CPU에 작업 정보를 저장합니다.

3.  해당 [패턴](../items-blocks-machines/patterns.md)이 들어 있는 <ItemLink id="pattern_provider" />가 패턴에 지정된 재료를 인접한 인벤토리로 밀어 넣습니다. 제작대 제작법(Crafting Pattern)이라면 <ItemLink id="molecular_assembler" />가 대상이고, 가공 제작법(Processing Pattern)이라면 다른 기계나 레드스톤으로 제어하는 설비 등이 대상입니다.

4.  완성된 결과물을 Import Bus, Interface 또는 Pattern Provider를 통해 ME 시스템으로 돌려보냅니다. **반드시 '아이템이 시스템에 들어오는' 이벤트가 발생해야 합니다. <ItemLink id="storage_bus" />가 연결된 상자에 결과물을 넣는 것만으로는 충분하지 않습니다.**

5.  해당 결과물이 다음 제작 단계의 선행 재료라면 Crafting CPU에 보관되었다가 후속 제작에 사용됩니다.

## 재귀 제작법

<ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="4" />

자동 제작 알고리즘이 *직접 처리할 수 없는* 것 중 하나가 재귀 제작법입니다. 예를 들어 Botania Mana Pool에 Redstone Dust를 넣어 "Redstone Dust 1개 → 2개"로 복제하는 제작법이나, 기본 Minecraft의 Smithing Template 복제 제작법이 여기에 해당합니다. 하지만 [이러한 제작법을 처리하는 방법](../example-setups/recursive-crafting-setup.md)이 있습니다.

# Patterns

<ItemImage id="crafting_pattern" scale="4" />

패턴은 <ItemLink id="pattern_encoding_terminal" />에서 Blank Pattern을 인코딩하여 만듭니다.

용도에 따라 여러 종류의 패턴이 있습니다.

*   <ItemLink id="crafting_pattern" />은 제작대 제작법을 저장합니다. <ItemLink id="molecular_assembler" />에 직접 넣으면 재료가 공급될 때 제작할 수 있지만, 주로 Molecular Assembler 옆에 설치한 <ItemLink id="pattern_provider" />에 넣어 사용합니다. 이때 Pattern Provider는 인접한 Assembler에 재료와 함께 패턴 정보도 보냅니다. Assembler는 제작 결과물을 인접한 인벤토리로 자동 배출하므로, Provider 옆에 Assembler를 놓는 것만으로 Crafting Pattern을 자동화할 수 있습니다.

***

*   <ItemLink id="smithing_table_pattern" />은 Crafting Pattern과 비슷하지만 Smithing Table 제작법을 저장합니다. Pattern Provider와 Molecular Assembler로 같은 방식으로 자동화할 수 있습니다. Crafting, Smithing, Stonecutting 패턴은 하나의 설비에서 함께 사용할 수 있습니다.

***

*   <ItemLink id="stonecutting_pattern" />은 Crafting Pattern과 비슷하지만 Stonecutter 제작법을 저장합니다. Pattern Provider와 Molecular Assembler로 같은 방식으로 자동화할 수 있습니다. Crafting, Smithing, Stonecutting 패턴은 하나의 설비에서 함께 사용할 수 있습니다.

***

*   <ItemLink id="processing_pattern" />은 자동 제작의 활용 범위를 크게 넓혀 주는 가장 범용적인 패턴입니다. 기본적으로 "Pattern Provider가 이 재료를 인접한 인벤토리에 보내면, 언젠가 ME 시스템에 이 결과물이 들어온다"는 관계만 정의합니다. 거의 모든 모드 기계나 Furnace 등을 자동화할 때 사용합니다. 재료를 보낸 뒤 결과물을 받기까지 어떤 과정이 일어나는지는 신경 쓰지 않으므로, 복잡한 공장 생산 라인을 거치거나 무한 생산 농장에서 추가 재료를 공급받는 등 다양한 자동화가 가능합니다. ME 시스템은 패턴에 지정된 결과물만 받으면 되며, 재료와 결과물의 직접적인 연관성조차 요구하지 않습니다. 예를 들어 "Cherry Wood Planks 1개 ⇒ Nether Star 1개"라는 패턴을 만들어 나무 판자를 받으면 Wither 농장이 Wither를 처치하도록 구성해도 자동 제작이 작동합니다.

동일한 패턴을 넣은 <ItemLink id="pattern_provider" />를 여러 개 설치하면 병렬로 작동합니다. 또한 패턴을 "Cobblestone 1개 → Stone 1개"가 아니라 "Cobblestone 8개 → Stone 8개"로 설정하면, Provider가 제련 설비에 재료를 한 개씩이 아닌 8개씩 공급합니다.

## 더욱 범용적인 '패턴'

Processing Pattern보다 더 범용적인 방식도 있습니다. Crafting Card를 장착한 <ItemLink id="level_emitter" />가 레드스톤 신호를 출력하여 제작 설비를 작동시키도록 설정하는 것입니다. 이 방식은 재료를 정의하거나 확인하지 않습니다. 단지 "이 Level Emitter가 레드스톤 신호를 출력하면, 언젠가 ME 시스템에 지정된 아이템이 들어온다"고 가정합니다. 주로 입력 재료가 필요 없는 무한 생산 농장을 켜고 끄거나, 일반 자동 제작으로 처리할 수 없는 재귀 제작법을 다루는 설비를 작동시킬 때 사용합니다. 예를 들어 Cobblestone을 복제하는 기계가 있다면 "Cobblestone 1개 → 2개" 같은 작업도 처리할 수 있습니다.

# The Crafting CPU

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Crafting CPU는 제작 요청과 작업을 관리합니다. 여러 단계의 제작 과정에서 중간 재료를 보관하며, 처리 가능한 작업의 규모와 일부 처리 속도에 영향을 줍니다. 멀티블록 구조로 만들어야 하며, Crafting Storage를 하나 이상 포함하는 직육면체여야 합니다.

Crafting CPU는 다음 블록으로 구성됩니다.

*   (필수) [Crafting Storage](../items-blocks-machines/crafting_cpu_multiblock.md): 1k, 4k, 16k, 64k, 256k 크기가 있습니다. 제작에 필요한 재료와 중간 재료를 보관하므로, 재료가 많이 필요한 작업에는 더 크거나 더 많은 Storage가 필요합니다.
*   (선택) <ItemLink id="crafting_accelerator" />: Pattern Provider가 재료 묶음을 더 자주 보내도록 하여 제작 속도를 높입니다. 예를 들어 Molecular Assembler 6개로 둘러싸인 Provider가 한 번에 하나가 아닌 6개 모두에 재료를 공급할 수 있습니다.
*   (선택) <ItemLink id="crafting_monitor" />: CPU가 현재 처리 중인 작업을 표시합니다. <ItemLink id="color_applicator" />로 색상을 바꿀 수 있습니다.
*   (선택) <ItemLink id="crafting_unit" />: Crafting CPU를 직육면체로 만들기 위해 빈 공간을 채우는 블록입니다.

Crafting CPU 하나는 요청이나 작업 하나만 처리합니다. Calculation Processor와 Smooth Stone 256개를 동시에 제작하려면 CPU 멀티블록이 2개 필요합니다.

CPU는 플레이어 요청, 자동화 장치(Export Bus 및 Interface)의 요청 또는 둘 다 처리하도록 설정할 수 있습니다.

# Pattern Providers

<Row>
<BlockImage id="pattern_provider" scale="4" />

<BlockImage id="pattern_provider" p:push_direction="up" scale="4" />

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

<ItemLink id="pattern_provider" />는 자동 제작 시스템과 외부 세계를 연결하는 주요 장치입니다. [패턴](../items-blocks-machines/patterns.md)에 지정된 재료를 인접한 인벤토리로 보내며, Provider에 아이템을 넣어 네트워크에 저장할 수도 있습니다. 기계의 결과물을 <ItemLink id="import_bus" />로 회수하는 대신 가까운 Pattern Provider(대개 재료를 보낸 장치)로 되돌리면 채널 하나를 절약할 수 있습니다.

Pattern Provider는 Crafting CPU의 [Crafting Storage](../items-blocks-machines/crafting_cpu_multiblock.md#crafting-storage)에서 재료를 직접 밀어 내므로 자체 인벤토리에 재료를 보관하지 않습니다. 따라서 Provider에서 파이프로 재료를 직접 꺼낼 수 없습니다. 먼저 Barrel 같은 다른 인벤토리에 공급한 뒤 그곳에서 파이프로 운반해야 합니다.

또한 Provider는 필요한 재료를 **한 번에 전부** 보내야 하며, 일부만 나누어 공급할 수 없습니다. 이 특성을 자동화에 활용할 수 있습니다.

Pattern Provider는 [서브넷](../ae2-mechanics/subnetworks.md)의 Interface와 특별하게 상호작용합니다. Interface를 기본 상태로 두고 요청 슬롯을 비워 놓으면 Provider는 Interface를 건너뛰고 서브넷의 [저장소](../ae2-mechanics/import-export-storage.md)로 재료를 직접 보냅니다. Interface가 제작 재료로 가득 차지 않으며, 저장 공간이 생길 때까지 다음 재료 묶음을 보내지 않습니다.

동일한 패턴을 넣은 Pattern Provider 여러 개가 병렬로 작동할 수 있습니다.

Provider는 재료 묶음을 각 면에 순서대로 분배하려고 하므로, 연결된 기계들을 병렬로 사용할 수 있습니다.

## 종류

Pattern Provider는 일반형, 방향 지정형, 평면형의 세 종류가 있습니다. 종류에 따라 재료를 공급하는 면, 아이템을 받는 면, 네트워크 연결을 제공하는 면이 달라집니다.

*   일반형 Pattern Provider는 모든 면으로 재료를 공급하고 모든 면에서 아이템을 받습니다. 다른 AE2 기계처럼 케이블 역할도 하여 모든 면에 네트워크 연결을 제공합니다.

*   방향 지정형 Pattern Provider는 일반형에 <ItemLink id="certus_quartz_wrench" />를 사용하여 방향을 바꾸면 만들 수 있습니다. 선택한 면으로만 재료를 내보내고 모든 면에서 아이템을 받지만, 선택한 면에는 네트워크 연결을 제공하지 않습니다. 따라서 서브넷을 구성할 때 네트워크를 서로 연결하지 않고 AE2 기계에 재료를 공급할 수 있습니다.

*   평면형 Pattern Provider는 [케이블 부속 부품](../ae2-mechanics/cable-subparts.md)으로, 케이블 하나에 여러 개를 설치해 공간을 절약할 수 있습니다. 방향 지정형의 선택된 면처럼 패턴에 따라 재료를 공급하고 아이템을 받지만, 장치가 향한 면에는 네트워크 연결을 제공하지 않습니다.

일반형과 평면형은 제작 격자에서 서로 변환할 수 있습니다.

## 설정

Pattern Provider에는 여러 작동 모드가 있습니다.

*   **Blocking Mode**: 기계 안에 재료가 남아 있으면 다음 재료 묶음을 보내지 않습니다.
*   **Lock Crafting**: 레드스톤 조건에 따라 잠그거나, 이전 제작 결과물이 해당 Provider로 돌아올 때까지 잠글 수 있습니다.
*   <ItemLink id="pattern_access_terminal" />에서 Provider를 표시하거나 숨길 수 있습니다.

## 우선순위

화면 오른쪽 위의 렌치 버튼으로 우선순위를 설정할 수 있습니다. 같은 아이템을 제작하는 [패턴](../items-blocks-machines/patterns.md)이 여러 개라면 우선순위가 높은 Provider의 패턴이 먼저 선택됩니다. 다만 그 패턴의 재료가 네트워크에 부족하면 우선순위가 낮은 패턴을 사용할 수 있습니다.

# Molecular Assemblers

<BlockImage id="molecular_assembler" scale="4" />

<ItemLink id="molecular_assembler" />는 입력된 아이템을 인접한 <ItemLink id="pattern_provider" />가 지정한 작업이나 내부에 넣은 <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" />, <ItemLink id="stonecutting_pattern" />에 따라 처리하고, 결과물을 인접한 인벤토리로 내보냅니다.

주로 <ItemLink id="pattern_provider" /> 옆에 설치하여 사용합니다. 이때 Provider는 재료와 함께 해당 패턴 정보도 Assembler에 전달합니다. Assembler가 결과물을 인접한 인벤토리(Provider의 반환 슬롯 포함)로 자동 배출하므로, Provider 옆에 Assembler를 설치하는 것만으로 Crafting Pattern을 자동화할 수 있습니다.

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>
