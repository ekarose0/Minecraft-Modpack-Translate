---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
    title: 에너지
  icon: energy_cell
---

# 에너지

네트워크를 작동하려면 에너지가 필요합니다. 네트워크에는 [장치](../ae2-mechanics/devices.md)가 직접 사용하는 공용 에너지 저장 공간이 있으며, <ItemLink id="vibration_chamber" />, <ItemLink id="energy_acceptor" />, <ItemLink id="controller" />가 여기에 에너지를 공급합니다. <ItemLink id="network_tool" />을 들고 네트워크를 우클릭하거나 Controller를 우클릭하면 에너지 통계를 볼 수 있습니다. 에너지가 네트워크 전체에서 공유되므로 별도의 전송 속도 제한은 없으며, 실제 한계는 저장 용량에 의해 결정됩니다.

## 에너지 입력

<Row>
  <BlockImage id="energy_acceptor" scale="4" />

  <GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
  </GameScene>

  <BlockImage id="controller" p:state="online" scale="4" />

  <BlockImage id="vibration_chamber" p:active="true" scale="4" />
  
  <BlockImage id="crystal_resonance_generator" scale="4" />
</Row>

AE2는 Forge Energy(Forge)나 TechReborn Energy(Fabric)를 내부적으로 직접 사용하지 않고, 자체 단위인 AE로 변환합니다. 이 변환은 단방향입니다. <ItemLink id="energy_acceptor" />나 <ItemLink id="controller" />로 변환할 수 있지만, Controller의 면은 [채널](../ae2-mechanics/channels.md) 연결에 활용하는 편이 좋습니다. <ItemLink id="vibration_chamber" />나 <ItemLink id="crystal_resonance_generator" />로도 AE를 생산할 수 있으나, AE2는 다른 기술 모드의 발전 설비와 함께 사용하는 것을 염두에 두고 설계되었습니다.

따라서 기지의 전력 공급 구조를 설계할 때는 AE2 네트워크 전체를 하나의 거대한 멀티블록 기계로 생각하는 편이 좋습니다.

Forge Energy와 TechReborn Energy의 변환 비율은 다음과 같습니다.

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

## 에너지 저장

<Row>
  <BlockImage id="energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="4" />
</Row>

네트워크는 한 게임 틱에 저장 용량보다 많은 에너지를 받거나 사용할 수 없습니다. 예를 들어 저장 용량이 800 AE라면, 저장소가 가득 찼을 때 [장치](../ae2-mechanics/devices.md)가 한 틱에 사용할 수 있는 양도 최대 800 AE입니다. 저장소가 비어 있을 때 Energy Acceptor가 한 틱에 공급할 수 있는 양 역시 최대 800 AE입니다.

이 때문에 이상한 동작이 발생할 수 있습니다. Energy Acceptor, Drive, Terminal과 몇 가지 장치만 있는 소형 네트워크에 많은 아이템을 한 번에 넣으면, 그 틱에 필요한 에너지가 저장량을 초과할 수 있습니다. 그러면 일부 아이템이 들어가지 않고 에너지가 고갈되어 네트워크가 재시작됩니다.

**Energy Cell을 추가하면 이 문제를 해결할 수 있습니다.**

네트워크에는 케이블·기계·부품마다 기본적으로 25 AE의 에너지 버퍼가 있습니다.

<ItemLink id="controller" />는 블록당 8k AE의 내부 저장 공간이 있습니다.

<ItemLink id="energy_cell" />은 200k AE(Controller 25개 분량)를 저장할 수 있습니다. 일반적인 네트워크에서 순간적인 에너지 수요를 감당하는 데는 대개 하나면 충분합니다.

<ItemLink id="dense_energy_cell" />은 1.6M AE(Energy Cell 8개 분량)를 저장합니다. 저장한 에너지로 네트워크를 운용하거나 대규모 [Spatial Storage](spatial-io.md)의 막대한 순간 전력 소모를 감당할 때 적합합니다.

<ItemLink id="creative_energy_cell" />은 테스트용 크리에이티브 아이템으로, 무제한 에너지를 제공합니다.
