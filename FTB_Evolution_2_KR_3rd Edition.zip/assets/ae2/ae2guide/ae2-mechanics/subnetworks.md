---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
    title: 서브네트워크
---

# 서브네트워크

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/subnet_demonstration.snbt" />

<DiamondAnnotation pos="6.5 2.5 0.5" color="#00ff00">
        아이템 파이프 서브네트워크
    </DiamondAnnotation>

<DiamondAnnotation pos="5.5 2.5 0.5" color="#00ff00">
        유체 파이프 서브네트워크
    </DiamondAnnotation>

<DiamondAnnotation pos="4.5 2.5 0.5" color="#00ff00">
        필터가 적용된 Annihilation Plane
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 2.5 0.5" color="#00ff00">
        Formation Plane 서브네트워크
    </DiamondAnnotation>

<DiamondAnnotation pos="2.5 2.5 0.5" color="#00ff00">
        Interface와 Storage Bus의 상호작용으로 메인 네트워크가 접근할 수 있는 로컬 저장소를 구성한 서브네트워크
    </DiamondAnnotation>

<DiamondAnnotation pos="1.5 1.5 0.5" color="#00ff00">
        충전된 아이템을 Pattern Provider로 돌려보내는 또 다른 아이템 파이프 서브네트워크
    </DiamondAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

"서브네트워크"는 엄밀하게 정의된 용어는 아니지만, 메인 네트워크를 지원하거나 작은 작업을 수행하는 별도의 [네트워크](../ae2-mechanics/me-network-connections.md)를 뜻합니다. 일반적으로 Controller가 필요 없을 만큼 작습니다. 주된 용도는 다음 두 가지입니다.

* [장치](../ae2-mechanics/devices.md)가 접근할 수 있는 저장소를 제한합니다. 예를 들어 파이프 서브네트워크의 Import Bus가 메인 저장소에 접근할 수 있다면 아이템을 목적지 인벤토리가 아닌 Storage Cell에 넣을 수 있습니다.
* 메인 네트워크의 채널을 절약합니다. 기계마다 Pattern Provider를 설치해 여러 채널을 사용하는 대신, 하나의 Pattern Provider가 여러 기계의 Storage Bus와 연결된 Interface로 출력하도록 구성하면 채널 하나만 사용할 수 있습니다.

서브네트워크를 만들 때 가장 중요한 것은 [네트워크 연결](../ae2-mechanics/me-network-connections.md)을 확인하는 것입니다. Interface와 Bus를 복잡하게 배치해 서브네트워크라고 생각하더라도, 여러 완전한 블록형 장치를 통해 메인 네트워크에 그대로 연결되어 있을 수 있습니다.

서로 다른 색의 케이블은 직접 연결되지 않는다는 점을 제외하면 서브네트워크 생성과 특별한 관계가 없습니다.

서브네트워크 활용 사례는 다음과 같습니다.

* Trash Can이나 Void Upgrade 대신 별도의 AE2 네트워크를 만들어 남는 아이템을 상황에 따라 Composter나 재활용 기계로 분배합니다.
* 복잡한 제작 공정의 세부 과정을 서브네트워크에서 관리해 메인 네트워크에는 공장 전체가 하나의 기계처럼 보이도록 구성합니다.
* 병렬 처리: 느린 기계 하나를 동일한 기계 10개로 대체해도 메인 네트워크에서는 구조가 달라지지 않고 추가 채널도 사용하지 않습니다.
* Import Bus와 Storage Bus를 사용해 아이템·유체 파이프처럼 두 용기 사이에서 내용물을 전송합니다.
* Annihilation Plane와 Storage Bus를 연결해 채굴한 아이템이 Storage Bus로만 들어가도록 제한하면 Plane에 필터를 적용한 효과를 얻을 수 있습니다.
* Interface와 Formation Plane를 연결해 Interface에 넣은 아이템을 월드에 설치하거나 떨어뜨립니다.
* 메인 네트워크의 <ItemLink id="level_emitter" />로 수량을 제어하는 Certus Quartz 자동 생산 설비를 만듭니다.
* Storage Bus와 Interface의 특수 상호작용을 활용해 농장 생산물이 메인 저장소로 넘치지 않도록 하면서 메인 네트워크에서 접근 가능한 전용 저장소를 만듭니다.
* 그 밖에도 다양한 용도로 활용할 수 있습니다.

서브네트워크를 만들 때 <ItemLink id="quartz_fiber" />가 특히 유용합니다. 네트워크끼리 직접 연결하지 않고 에너지만 전달하므로, 곳곳에 Energy Acceptor와 전력 케이블을 설치하지 않아도 서브네트워크에 전력을 공급할 수 있습니다.
