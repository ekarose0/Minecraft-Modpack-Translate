---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Channels
  icon: controller
---

# Channels

Applied Energistics 2의 [ME Network](me-network-connections.md)는 네트워크 저장소나 다른 네트워크 기능을 사용하는 [장치](../ae2-mechanics/devices.md)를 연결하기 위해 채널(Channel)이 필요합니다. 채널은 컴퓨터의 USB 포트와 비슷합니다. USB 포트 수가 한정되어 있듯이 네트워크에서 연결할 수 있는 장치 수도 제한됩니다. 대부분의 기계, 전체 블록형 장치, 일반 케이블은 최대 8채널을 전달합니다. 이를 8가닥의 '채널 전선' 묶음으로 생각할 수 있습니다. 반면 [Dense Cable](../items-blocks-machines/cables.md#dense-cable)은 최대 32채널을 전달합니다. 그 밖에 32채널을 전달할 수 있는 장치는 <ItemLink id="me_p2p_tunnel" />과 [Quantum Network Bridge](../items-blocks-machines/quantum_bridge.md)입니다. 장치 하나가 채널을 사용하면 묶음에서 전선 한 가닥을 떼어 낸 것과 같으므로, 그 채널은 뒤쪽 장치에서 사용할 수 없습니다.

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
  케이블의 8채널이 모두 사용 중이므로 Drive에는 채널이 할당되지 않습니다.  
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
        케이블의 8채널이 모두 사용 중이므로 Drive에는 채널이 할당되지 않습니다.
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

네트워크에서 채널이 어떻게 사용되고 전달되는지 쉽게 확인하려면 [Smart Cable](../items-blocks-machines/cables.md)을 사용하세요. 케이블 표면에 채널의 경로와 사용량이 표시됩니다.

채널은 통과하는 노드 하나당 1⁄128 AE/t의 전력을 소모합니다. 따라서 장치 8개와 노드 96개 이상으로 구성된 네트워크에서는 <ItemLink id="controller" />를 추가하여 채널 할당 방식을 바꾸면 오히려 전력 소모가 줄어들 수도 있습니다.

중요한 점은 **채널 수와 케이블 색상은 관계가 없다는 것**입니다. 케이블 색상은 케이블끼리 연결되는 것을 제한하는 역할만 합니다.

## 채널 경로 지정

<ItemLink id="controller" />를 사용하는 경우 채널은 세 단계를 거쳐 경로를 찾습니다. 먼저 인접한 기계를 지나 가장 가까운 [일반 케이블](../items-blocks-machines/cables.md)(Glass, Covered, Smart)까지 최단 경로를 선택합니다. 그다음 일반 케이블을 통해 가장 가까운 [Dense Cable](../items-blocks-machines/cables.md)(Dense 또는 Dense Smart)까지 최단 경로를 찾습니다. 마지막으로 Dense Cable을 통해 <ItemLink id="controller" />까지 최단 경로를 선택합니다. 최단 경로의 채널이 이미 가득 찼다면 일부 [장치](devices.md)에 필요한 채널이 공급되지 않을 수 있습니다. 케이블 색상, Cable Anchor, Tunnel을 활용하여 원하는 경로로 채널이 흐르도록 구성하세요.

다음 예시에서는 케이블 전체의 채널 용량은 충분하지만, 채널이 최단 경로로 몰려 일부 케이블은 과부하되고 다른 케이블은 비어 있어 Drive 일부가 채널을 받지 못합니다.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
        이 구간으로 8개가 넘는 채널이 지나가려고 하므로 일부가 차단됩니다.
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

채널이 지나갈 수 있는 경로를 더 명확하게 제한하면 해결할 수 있습니다. 네트워크는 나무처럼 가지가 뻗는 구조로 설계하고, 고리 형태의 경로나 모호한 채널 경로는 최소화하는 것이 좋습니다.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## Ad-Hoc 네트워크

<ItemLink id="controller" />가 없는 네트워크를 Ad-Hoc 네트워크라고 하며, 채널을 사용하는 장치를 최대 8개까지 지원합니다. 장치가 8개를 초과하면 채널을 사용하는 장치들이 작동을 멈춥니다. 이때는 장치를 제거하거나 <ItemLink id="controller" />를 추가해야 합니다.

Controller가 있는 네트워크와 달리, Ad-Hoc 네트워크의 [Smart Cable](../items-blocks-machines/cables.md)은 해당 케이블을 지나는 채널 수가 아니라 네트워크 전체에서 사용 중인 채널 수를 표시합니다.

Ad-Hoc 네트워크에서는 장치 하나가 네트워크 전체의 채널 하나를 사용합니다. 이는 <ItemLink id="controller" />가 최단 경로를 기준으로 채널을 할당하는 방식과 크게 다릅니다.

## 네트워크 설계

앞서 [채널 경로 지정](channels.md#channel-routing)에서 설명했듯이 네트워크는 나무처럼 가지를 뻗는 구조가 좋습니다. Controller에서 Dense Cable을 뻗고, Dense Cable에서 일반 케이블을 분기한 다음, 일반 케이블마다 [장치](../ae2-mechanics/devices.md)를 8개 이하로 묶어 연결하세요.

다음은 잘못된 구성의 예시입니다.

채널 경로를 따라가 보겠습니다.

1. Controller에서 오른쪽으로 나오자마자 Drive가 일반 케이블처럼 작동하여 채널 용량이 8개로 제한됩니다. Smart Cable이 아니므로 사용 중인 채널 수도 확인하기 어렵습니다. 남은 채널: 8개.
2. Drive가 채널 하나를 사용합니다. 남은 채널: 7개.
3. 위쪽 Terminal에 채널 2개가 공급됩니다. 남은 채널: 5개.
4. 오른쪽 Interface가 채널 하나를 사용합니다. 남은 채널: 4개.
5. 위쪽 Pattern Provider에 채널 하나가 공급됩니다. 남은 채널: 3개.
6. 오른쪽 Import Bus에 채널 하나가 공급됩니다. 남은 채널: 2개.
7. Assembler에 재료를 공급하는 Pattern Provider 묶음에는 채널 2개만 도달하므로 Provider 2개가 채널을 받지 못합니다.

문제의 원인은 채널을 좁은 구간에 집중시키고 채널 분배 경로를 고려하지 않은 것입니다.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1채널
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  채널 없음
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  채널 없음
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

다음은 올바르게 설계한 구조의 예시입니다.

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
        Pattern Provider가 8개씩 별도의 그룹으로 나뉘어 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
        채널이 가득 찬 일반 케이블 두 개가 합쳐지는 곳에는 Dense Cable이 필요합니다.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
        서로 다른 케이블 색상을 사용하여 인접한 케이블끼리 연결되지 않도록 합니다.
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## 채널 모드

Minecraft 1.18용 AE2 10.0.0부터 세계에서 채널이 작동하는 방식을 변경할 수 있습니다. 일반 설정의 `channels` 항목으로 조절하거나, 관리자 권한으로 게임 내 명령어를 사용할 수 있습니다. `/ae2 channelmode <mode>`로 모드를 변경하고 `/ae2 channelmode`로 현재 모드를 확인합니다. 게임에서 모드를 변경하면 기존 ME 네트워크가 모두 재시작되어 새 모드가 즉시 적용됩니다.

이는 Minecraft 1.12에 있던 기능을 개선하여 다시 도입한 것으로, 채널 시스템을 완전히 없애지는 않으면서 좀 더 편하게 플레이하려는 사용자를 위한 선택지를 제공합니다.

다음 표는 설정 파일과 명령어에서 사용할 수 있는 모드를 보여 줍니다.

| 설정       | 설명                                                                                                                                                                                                                               |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `default`  | 일반 케이블과 Ad-Hoc 네트워크의 채널 용량에 앞서 설명한 기본 제한을 적용합니다                                                                                                                           |
| `x2`       | 모든 채널 용량이 2배가 됩니다(일반 케이블 16개, Dense Cable 64개, Ad-Hoc 네트워크 16개)                                                                                                                           |
| `x3`       | 모든 채널 용량이 3배가 됩니다(일반 케이블 24개, Dense Cable 92개, Ad-Hoc 네트워크 24개)                                                                                                                           |
| `x4`       | 모든 채널 용량이 4배가 됩니다(일반 케이블 32개, Dense Cable 128개, Ad-Hoc 네트워크 32개)                                                                                                                       |
| `infinite` | 모든 채널 제한을 해제합니다. Controller는 여전히 네트워크의 전력 소모를 *크게* 줄여 줍니다. Smart Cable은 채널이 없는 상태(꺼짐)와 채널이 하나 이상 있는 상태(켜짐)만 표시합니다. |