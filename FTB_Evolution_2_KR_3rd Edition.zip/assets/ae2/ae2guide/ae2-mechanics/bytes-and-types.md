---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
    title: 바이트와 종류
  icon: creative_storage_cell
---

# 바이트와 종류

<Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

[Storage Cell](../items-blocks-machines/storage_cells.md)의 용량은 *바이트(Bytes)*와 *종류(Types)*로 결정됩니다. 바이트는 컴퓨터의 저장 용량처럼 셀에 들어 있는 아이템의 총량을 나타내고, 종류는 서로 다른 아이템이 몇 종류 저장되어 있는지를 나타냅니다. 같은 Cobblestone 4,096개는 1종류이지만 인챈트가 서로 다른 검 16개는 16종류로 계산됩니다.

각 Storage Cell에는 정해진 데이터 용량이 있습니다. 새로운 종류를 저장할 때는 셀 크기에 따라 일정량의 바이트를 먼저 사용하며, 아이템 하나는 1비트를 사용합니다. 따라서 아이템 8개는 1바이트, 64개는 8바이트를 차지합니다. ME 네트워크 밖에서 중첩 가능한지와는 무관하므로 같은 종류의 Saddle 64개와 Stone 64개는 동일한 공간을 차지합니다.

다시 말해 아이템 하나는 1비트이므로 8개가 1바이트입니다. 유체 셀은 양동이 8개 분량이 1바이트에 해당합니다.

셀에 저장할 수 있는 종류 수가 적다고 느낄 수 있지만 이는 ***필요한 제한***입니다. 셀은 아이템 자체의 NBT 태그에 데이터를 저장하므로 안정적이지만, 지나치게 많은 데이터를 넣으면 플레이어에게 전송되는 데이터가 과도해져 기본 Minecraft의 "Book Banning"과 비슷한 문제가 발생할 수 있습니다. 종류가 많을수록 정렬과 아이템 처리 부담도 커집니다. 하지만 고유한 비중첩 아이템을 대량으로 보관하지 않는다면 큰 제약은 아닙니다. <ItemLink id="drive" /> 하나를 셀로 가득 채우면 630종류를 저장할 수 있습니다.

종류 제한은 몹 농장에서 나오는 내구도와 인챈트가 제각각인 방어구·도구 수백 개를 ME 시스템에 무작정 넣지 않도록 하는 장치이기도 합니다. 각각 별도의 종류로 저장되어 용량을 낭비하므로 네트워크에 들어오기 전에 필터로 걸러내는 것이 좋습니다.

최상위 Storage Cell부터 제작하는 것이 항상 좋은 선택은 아닙니다. 재료는 더 많이 사용하지만 저장 가능한 종류 수가 늘지는 않기 때문입니다. 각 크기에는 장단점이 있으므로 게임 후반에도 모든 크기의 셀이 유용합니다.

아래 표는 Storage Cell 등급별 용량과 대략적인 제작 비용을 비교한 것입니다.

## Storage Cell 용량과 제작 비용

| Cell                                     |   바이트 | 종류 | 종류당 바이트 | Certus | Redstone | Gold | Glowstone |
| ---------------------------------------- | ------: | ----: | -------------: | -----: | -------: | ---: | --------: |
| <ItemLink id="item_storage_cell_1k" />   |   1,024 |    63 |              8 |      4 |        5 |    1 |         0 |
| <ItemLink id="item_storage_cell_4k" />   |   4,096 |    63 |             32 |  14.25 |       20 |    3 |         0 |
| <ItemLink id="item_storage_cell_16k" />  |  16,384 |    63 |            128 |     45 |       61 |    9 |         4 |
| <ItemLink id="item_storage_cell_64k" />  |  65,536 |    63 |            512 | 137.25 |      184 |   27 |        16 |
| <ItemLink id="item_storage_cell_256k" /> | 262,144 |    63 |           2048 |    414 |      553 |   81 |        48 |

## 저장 종류 수에 따른 실제 용량

새로운 종류를 저장할 때 발생하는 기본 용량 소모 때문에, 한 종류만 저장한 셀은 63종류를 모두 저장한 셀보다 약 두 배 많은 아이템을 담을 수 있습니다.

| Cell                                     | 1종류 저장 시 총용량 | 63종류 저장 시 총용량 |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8,128 |                                       4,160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32,512 |                                      16,640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130,048 |                                      66,560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520,192 |                                     266,240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2,080,768 |                                   1,064,960 |

![1종류를 저장한 셀](../assets/diagrams/1_type_cell.png)

![63종류를 저장한 셀](../assets/diagrams/63_type_cell.png)
