---
navigation:
  parent: example-setups/example-setups-index.md
    title: 양동이 채우기 자동화
  icon: minecraft:water_bucket
---

# 양동이 채우기 자동화

[양동이 비우기](bucket-emptier.md)도 참고하세요.

<ItemLink id="pattern_provider" />를 사용하므로 [자동 제작](../ae2-mechanics/autocrafting.md) 시스템에 연결하는 것을 전제로 합니다.

유체 자체가 아닌 유체가 담긴 양동이가 필요한 경우가 있습니다. Thermal Expansion의 Fluid Transposer 같은 기계가 있다면 해결할 수 있지만, 해당 모드가 없을 수도 있습니다. 기본 Minecraft의 <ItemLink id="minecraft:dispenser" />를 이용해 자동화할 수 있습니다.

**[Pattern Encoding Terminal](../items-blocks-machines/terminals.md#pattern-encoding-terminal)의 Fluid Substitutions 기능을 사용하면 제작법에서 양동이 대신 유체 자체를 사용할 수 있으므로, 이 장치가 필요하지 않은 경우도 많습니다.**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_filler.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) Pattern Provider: 해당 Processing Pattern을 넣고 제작 잠금을 "With redstone signal"로 설정합니다.

        <Row>
        ![Fill Pattern](../assets/diagrams/water_fill_pattern_small.png)
        ![Fill Pattern](../assets/diagrams/lava_fill_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (2) Interface: 기본 설정을 사용합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 1.1 0.8" max="3.9 1.9 1">
        (3) Storage Bus #1: 기본 설정을 사용합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) Formation Plane: Inverter Card를 장착해 양동이를 차단 목록에 등록합니다.
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 2 1.2" max="3.8 2.2 1.8">
        (5) Import Bus: Inverter Card를 장착해 양동이를 차단 목록에 등록합니다.
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        (6) Storage Bus #2: 기본 설정을 사용합니다.
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## 설정

* <ItemLink id="pattern_provider" /> (1)에 해당 <ItemLink id="processing_pattern" />을 넣고 제작 잠금을 "With redstone signal"로 설정합니다.
  
    ![Charger Pattern](../assets/diagrams/water_fill_pattern.png)
    ![Charger Pattern](../assets/diagrams/lava_fill_pattern.png)

* <ItemLink id="interface" /> (2)는 기본 설정을 사용합니다.
* 첫 번째 <ItemLink id="storage_bus" /> (3)는 기본 설정을 사용합니다.
* <ItemLink id="formation_plane" /> (4)에 Inverter Card를 장착해 양동이를 차단 목록에 등록합니다.
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* <ItemLink id="import_bus" /> (5)에 Inverter Card를 장착해 양동이를 차단 목록에 등록합니다.
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* 두 번째 <ItemLink id="storage_bus" /> (6)는 기본 설정을 사용합니다.

## 작동 원리

1. <ItemLink id="pattern_provider" />가 재료를 <ItemLink id="interface" /> 쪽으로 보냅니다. 실제로는 최적화 과정에서 Storage Bus와 Formation Plane를 Provider의 면처럼 사용하므로 아이템이 Interface 내부에 들어가지는 않습니다.
2. [파이프 서브네트워크](pipe-subnet.md#providing-to-multiple-places)와 <ItemLink id="formation_plane" />의 작동 원리에 따라 양동이가 <ItemLink id="minecraft:dispenser" />로 이동하고 유체는 Formation Plane에 의해 설치됩니다.
3. <ItemLink id="minecraft:comparator" />가 Dispenser의 양동이를 감지하면 Dispenser에 전력을 공급하는 동시에 <ItemLink id="pattern_provider" />를 잠급니다.
4. Dispenser가 양동이로 유체를 퍼 담으면 내부에 유체가 든 양동이가 남습니다.
5. <ItemLink id="import_bus" />가 유체가 든 양동이를 꺼내 <ItemLink id="storage_bus" />를 통해 Pattern Provider에 넣고 메인 네트워크로 반환합니다.
6. Comparator가 Dispenser가 비었다는 것을 감지하면 Provider의 잠금이 해제됩니다.
