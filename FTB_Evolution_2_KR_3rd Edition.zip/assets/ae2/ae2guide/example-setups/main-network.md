---
navigation:
  parent: example-setups/example-setups-index.md
    title: 메인 네트워크 구성 예시
  icon: controller
---

# 메인 네트워크 구성 예시

다른 자동화 예시에서는 자주 "메인 네트워크"를 언급합니다. 여러 [장치](../ae2-mechanics/devices.md)를 어떻게 연결해 하나의 시스템으로 구성하는지 궁금할 수 있습니다. 다음은 그 예시입니다.

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/small_base_network.snbt" />

    <BoxAnnotation color="#33dd33" min="5 1 10" max="9 7 14" thickness="0.05">
        Pattern Provider와 Molecular Assembler를 대규모로 배치하면 제작·Stonecutting·Smithing 패턴을 많이 처리할 수 있습니다. 바둑판식 배열은 공간을 절약하면서 여러 Assembler를 병렬로 사용하게 합니다. 8개 단위로 묶으면 채널이 잘못 연결되는 것을 방지할 수 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 10 12" max="14 11 14" thickness="0.05">
        Controller를 반드시 크게 만들 필요는 없습니다. 다른 기지에서 보이는 거대한 고리나 큐브 구조는 대부분 외관을 꾸미기 위한 것입니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 12 13" max="14 13 14" thickness="0.05">
        안정적인 네트워크에는 Energy Cell이 필요합니다. 게임 틱당 에너지 입력 한도를 높이고 전력 변동을 완화합니다.
    </BoxAnnotation>
    
    <BoxAnnotation color="#33dd33" min="2 1 10" max="4 4 13" thickness="0.05">
        다른 모드의 Reactor, Solar Panel, Generator 같은 전력원을 사용하는 편이 좋습니다. Vibration Chamber도 사용할 수 있지만 AE2는 모드팩의 주 발전 설비에서 전력을 공급받도록 설계되었습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="15 1 9" max="16 3 14" thickness="0.05">
        Facade를 사용해 벽 뒤의 장치를 가릴 수 있습니다.
    </BoxAnnotation>
    <BoxAnnotation color="#33dd33" min="15 3 12" max="16 10 14" thickness="0.05">
        Facade를 사용해 벽 뒤의 장치를 가릴 수 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 7" max="14 10 9" thickness="0.05">
        일반 저장소에는 Drive와 셀을 지나치게 많이 설치할 필요가 없습니다. 보통 Drive 2~4개에 4k 또는 16k Cell을 넣으면 충분합니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 10" max="14 11 11" thickness="0.05">
        대량 저장할 아이템은 별도의 Drive에 대용량 Cell을 넣고 해당 아이템만 받도록 필터를 설정한 뒤 우선순위를 높이는 편이 좋습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10 9 13" max="11.7 13 14" thickness="0.05">
        Interface를 이용한 자동 재고 보충 장치입니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="6 10 12" max="9 12 15" thickness="0.05">
        Charger 자동화 구조를 여러 Charger로 확장한 형태입니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="2 10 12" max="5 11 15" thickness="0.05">
        1.20부터 Inscriber가 결과물을 자동 배출할 수 있어 Processor를 자동화하는 다른 방법도 사용할 수 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="3 10 10" max="4 12 11" thickness="0.05">
        1.20부터 Inscriber가 결과물을 자동 배출할 수 있어 Processor를 자동화하는 다른 방법도 사용할 수 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.2 9.2 8.2" max="7.8 10 8.8" thickness="0.05">
        Wireless Access Point의 범위는 구형이므로 중앙에 설치합니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="14 1 2" max="16 5 7" thickness="0.05">
        일반적으로 대규모 작업용 Crafting CPU 1~2개와, 큰 CPU가 바쁠 때 보조 작업을 처리할 소형 CPU 몇 개를 함께 사용합니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="5 3 6" max="6 4 7" thickness="0.05">
        서브네트워크의 장치가 8개를 넘는 경우(예: 8곳 이상으로 분배할 때) 별도의 Controller가 필요할 수 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.3 1 3.3" max="9.7 4 6" thickness="0.05">
        Certus 농장입니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10.3 1 2.3" max="12.7 3.7 5" thickness="0.05">
        물에 던지는 제작법 자동화 설비입니다.
    </BoxAnnotation>

  <IsometricCamera yaw="135" pitch="15" />
</GameScene>
