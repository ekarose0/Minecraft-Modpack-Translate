---
navigation:
  parent: example-setups/example-setups-index.md
    title: Amethyst 농장
  icon: minecraft:amethyst_shard
---

# Amethyst 자동 농장

<ItemLink id="growth_accelerator" />는 Amethyst에도 효과가 있지만, [Certus Bud](../items-blocks-machines/budding_certus.md)에 사용하는 <ItemLink id="annihilation_plane" /> 필터 방식은 Amethyst Bud에 그대로 적용할 수 없습니다. 덜 자란 Certus Bud는 <ItemLink id="certus_quartz_dust" />를 떨어뜨리지만, 덜 자란 Amethyst Bud는 아무것도 떨어뜨리지 않습니다. 네트워크는 "아무것도 없는" 결과를 항상 수용할 수 있으므로 Annihilation Plane가 이를 무조건 파괴하게 됩니다.

해결 방법은 Annihilation Plane에 Silk Touch를 부여하는 것입니다. 그러면 덜 자란 Amethyst Bud도 성장 단계에 해당하는 블록을 떨어뜨리므로 필터로 구분할 수 있습니다.

수확한 <ItemLink id="minecraft:amethyst_cluster" />를 <ItemLink id="formation_plane" />로 다시 설치한 다음, Silk Touch가 없는 <ItemLink id="annihilation_plane" />로 파괴해야 <ItemLink id="minecraft:amethyst_shard" />를 얻을 수 있습니다.

Cluster에는 설치 방향이 있으므로 Formation Plane의 정면에 단단한 블록 면이 있어야 합니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
        (1) Annihilation Plane #1: 설정 GUI는 없으며 Silk Touch를 부여해야 합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
        (2) Formation Plane: Amethyst Cluster만 설치하도록 필터를 설정합니다.
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
        (3) Annihilation Plane #2: 설정 GUI는 없으며 Fortune을 부여할 수 있습니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
        (4) Storage Bus #1: Amethyst Shard만 받도록 필터를 설정합니다.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
        (5) Storage Bus #2: Amethyst Shard만 받도록 필터를 설정하고 메인 저장소보다 우선순위를 높입니다.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* 첫 번째 <ItemLink id="annihilation_plane" /> (1)는 설정 GUI가 없으며 반드시 Silk Touch를 부여해야 합니다.
* <ItemLink id="formation_plane" /> (2)는 <ItemLink id="minecraft:amethyst_cluster" />만 설치하도록 필터를 설정합니다.
* 두 번째 <ItemLink id="annihilation_plane" /> (3)는 설정 GUI가 없으며 Fortune을 부여할 수 있습니다.
* 첫 번째 <ItemLink id="storage_bus" /> (4)는 <ItemLink id="minecraft:amethyst_shard" />만 받도록 필터를 설정합니다.
* 두 번째 <ItemLink id="storage_bus" /> (5)는 <ItemLink id="minecraft:amethyst_shard" />만 받도록 필터를 설정하고 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 메인 저장소보다 높입니다.

## 작동 원리

1. 첫 번째 <ItemLink id="annihilation_plane" />는 정면의 블록을 파괴하려 하지만, 서브네트워크의 유일한 저장 대상인 <ItemLink id="formation_plane" />가 <ItemLink id="minecraft:amethyst_cluster" />만 받도록 설정되어 있어 완전히 자란 Cluster만 파괴할 수 있습니다. Silk Touch가 없으면 덜 자란 Bud가 아무것도 떨어뜨리지 않아 함께 파괴되므로 반드시 필요합니다.
2. <ItemLink id="formation_plane" />가 정면의 블록에 Cluster를 설치합니다.
3. 두 번째 <ItemLink id="annihilation_plane" />가 Cluster를 파괴해 <ItemLink id="minecraft:amethyst_shard" />를 생산합니다.
4. 첫 번째 <ItemLink id="storage_bus" />가 Shard를 Barrel에 저장합니다. 두 번째 Annihilation Plane가 완전히 자란 Cluster만 파괴하므로 엄밀히는 이 필터가 없어도 됩니다.
5. 두 번째 <ItemLink id="storage_bus" />를 통해 메인 네트워크가 Barrel에 보관된 모든 Amethyst Shard에 접근할 수 있습니다. [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 높게 설정했으므로 Shard는 메인 저장소보다 Barrel에 먼저 보관됩니다.
