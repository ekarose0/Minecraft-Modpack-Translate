---
navigation:
  parent: example-setups/example-setups-index.md
    title: 저장소 종류와 네트워크 정리
  icon: drive
---

# 저장소 유형과 네트워크 정리 방법

필터, [파티션](../items-blocks-machines/cell_workbench.md), [저장 우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 활용하면 아이템 종류에 따라 여러 단계의 저장소를 구성할 수 있습니다.

일반적인 저장소 유형은 다음과 같습니다.
* 일반 저장소: 수 개에서 수천 개 정도 보유한 다양한 아이템을 저장합니다. 4k 또는 16k 같은 소형 [Storage Cell](../items-blocks-machines/storage_cells.md)을 사용합니다.
* 대량 저장소: Cobblestone이나 Iron처럼 수천 개 이상 쌓이는 아이템을 저장합니다. 256k 같은 대용량 Cell이나 MEGA 애드온의 셀을 사용합니다.
* 농장 로컬 저장소: [특수 목적의 로컬 저장소](specialized-local-storage.md)와 여러 [Certus](simple-certus-farm.md) [농장](semiauto-certus-farm.md) [예시](advanced-certus-farm.md)에서 설명한 방식입니다.

아이템이 메인 네트워크에 들어오면 우선 전용 대량 저장소나 로컬 저장소에 보관하도록 우선순위를 설정합니다. 필터나 파티션 때문에 저장할 수 없는 아이템만 일반 저장소로 보냅니다. 다만 저장 우선순위는 기존 아이템을 저장소 사이에서 *능동적으로 이동시키지 않습니다*. 아이템이 네트워크에 들어오고 나갈 때 자연스럽게 저장 위치가 바뀝니다. 기존 아이템을 직접 옮기려면 <ItemLink id="io_port" />를 사용하세요.

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/network_storage_types.snbt" />

    <BoxAnnotation color="#33dd33" min="11 0 1" max="12 1.3 2" thickness="0.05">
        대량 저장소: Drawer 같은 대용량 저장 장치에 필터가 설정된 Storage Bus를 연결한 예시입니다. Coal만 받도록 설정하고 우선순위를 높이면 네트워크에 들어오는 Coal은 이곳에 먼저 저장되고, 꺼낼 때는 *이곳을 제외한 다른 저장소*에서 먼저 가져오므로 Coal이 자연스럽게 Drawer로 모입니다.

        중요: Drawer처럼 최적화된 대용량 인벤토리는 적합하지만, Colossal Chest처럼 슬롯이 많고 최적화되지 않은 인벤토리를 Storage Bus와 연결하면 성능이 크게 떨어질 수 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="11 0 3" max="12 1 4" thickness="0.05">
        대량 저장소: 우선순위가 높은 Drive에 Cobblestone과 Iron만 받도록 파티션을 설정한 256k Cell을 넣은 예시입니다. Equal Distribution Card가 있어 Cobblestone만으로 용량이 가득 차 Iron을 저장하지 못하는 문제를 막습니다. 우선순위가 높으므로 두 아이템이 들어올 때 이 셀에 먼저 저장되고, 꺼낼 때는 *이곳을 제외한 다른 저장소*에서 먼저 가져와 자연스럽게 이 셀로 모입니다.
    </BoxAnnotation>

    <BoxAnnotation color="#33dddd" min="11 0 5" max="12 1 6" thickness="0.05">
        일반 저장소: 파티션이 없는 16k Cell로 채운 Drive입니다. 우선순위는 기본값인 0이므로 아이템이 들어올 때는 전용 대량 저장소나 로컬 저장소에 먼저 저장되고, 꺼낼 때는 이곳에서 먼저 가져옵니다. 따라서 전용 저장소가 있는 아이템은 일반 저장소에서 자연스럽게 빠져나갑니다.
    </BoxAnnotation>

    <BoxAnnotation color="#88ff88" min="11 0 8" max="12 1 9" thickness="0.05">
        이 IO Port는 네트워크 저장소를 정리하는 데 중요합니다. 저장 우선순위만으로는 아이템이 *능동적으로* 이동하지 않으므로, 일반 저장소의 Cell을 주기적으로 IO Port에 넣어 아이템을 다시 분배해야 합니다. 이렇게 하면 전용 저장소가 있는 아이템이 해당 위치로 이동해 여러 곳에 흩어져 저장되는 현상을 줄일 수 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 11" max="15 1 12" thickness="0.05">
        몹 농장의 로컬 저장소: Bone과 Arrow처럼 보관할 전리품만 받도록 파티션을 설정한 Cell이 들어 있는 Drive입니다. 우선순위는 Drive 자체가 아니라 메인 네트워크에서 서브네트워크에 접근하는 Storage Bus가 결정합니다. Cell에는 Equal Distribution Card와 Void Card가 장착되어 있습니다.
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 1 10" max="15 2.3 11" thickness="0.05">
        몹 농장의 로컬 저장소: Storage Bus와 Interface를 연결해 메인 네트워크가 서브네트워크의 저장소에 접근하도록 합니다. Storage Bus의 우선순위를 높이고 서브네트워크 Cell에 보관하는 아이템만 받도록 필터를 설정합니다.

        중요: 서브네트워크에 폐기 장치가 있으므로 Storage Bus의 필터를 반드시 설정하세요. 그렇지 않으면 네트워크에 들어오는 *모든 아이템과 유체 등이 폐기될 수 있습니다*!
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 9" max="15 1.3 10" thickness="0.05">
        몹 농장의 로컬 저장소: Matter Condenser에 연결된 Storage Bus의 우선순위를 Drive보다 낮게 설정합니다. 그러면 Drive의 Cell에 들어갈 수 없는 전리품이 이곳으로 넘쳐 폐기됩니다. 내구도가 거의 소진된 Bow 같은 잡동사니로 서브네트워크가 막히는 것을 방지합니다.
    </BoxAnnotation>

    <BoxAnnotation color="#dd33dd" min="8 1 11.7" max="9 2.3 13" thickness="0.05">
        Melon 농장의 로컬 저장소: 여러 Certus 농장 예시와 비슷한 방식을 사용합니다. 서브네트워크의 Storage Bus가 수확물을 Barrel에 넣고, 메인 네트워크의 다른 Storage Bus가 Melon Slice만 받도록 필터와 높은 우선순위를 설정해 해당 수확물에 접근할 수 있도록 합니다.
    </BoxAnnotation>

  <IsometricCamera yaw="270" pitch="30" />
</GameScene>
