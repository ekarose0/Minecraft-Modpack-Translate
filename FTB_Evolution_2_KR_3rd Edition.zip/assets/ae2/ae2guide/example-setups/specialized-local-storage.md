---
navigation:
  parent: example-setups/example-setups-index.md
    title: 특수 목적의 로컬 저장소
  icon: drive
---

# 특수 목적의 로컬 저장소

[Interface의 특수 동작](../items-blocks-machines/interface.md#special-interactions)을 이용하면 [서브네트워크](../ae2-mechanics/subnetworks.md)의 저장 내용을 메인 네트워크에 제공할 수 있습니다. 이때 서브네트워크는 메인 네트워크의 저장소를 볼 수 없으며, 메인 네트워크의 [채널](../ae2-mechanics/channels.md)은 1개만 사용합니다.

농장에서 생산한 아이템이 메인 저장소로 넘쳐 들어가지 않도록 별도의 로컬 저장소를 만들 때 유용합니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

<BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
        (1) 아이템을 들여오는 장치입니다. 여기서는 Interface를 사용합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
        (2) Drive: Storage Cell을 장착합니다. 셀은 농장 생산물만 받도록 필터를 설정해야 합니다. Equal Distribution Card와 Void Card를 사용할 수 있습니다.
        <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
        (3) Crafting Terminal: 서브네트워크의 Drive 내용은 볼 수 있지만 메인 네트워크의 저장소는 볼 수 없습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (4) Interface #2: 기본 설정을 사용합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
        (5) Storage Bus: 메인 저장소보다 우선순위를 높게 설정하고 농장 생산물만 받도록 필터를 지정할 수 있습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 0.3">
        Crafting Terminal: 메인 네트워크와 서브네트워크의 저장 내용을 *모두* 볼 수 있습니다.
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* 첫 번째 <ItemLink id="interface" /> (1)는 농장 생산물을 받아 서브네트워크로 보냅니다.
* <ItemLink id="drive" /> (2)에는 [Storage Cell](../items-blocks-machines/storage_cells.md)을 넣습니다. 셀은 농장 생산물에 맞게 [파티션](../items-blocks-machines/cell_workbench.md)을 설정하세요. <ItemLink id="equal_distribution_card" />와 <ItemLink id="void_card" />도 사용할 수 있습니다.
* 두 번째 <ItemLink id="interface" /> (4)는 기본 설정을 사용합니다.
* <ItemLink id="storage_bus" />의 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 메인 저장소보다 높게 설정합니다. 농장 생산물만 받도록 필터를 설정할 수도 있습니다.

## 작동 원리

* 서브네트워크의 <ItemLink id="interface" />가 <ItemLink id="drive" />의 저장 내용을 메인 네트워크의 <ItemLink id="storage_bus" />에 제공합니다. 따라서 Storage Bus는 Drive의 셀에 아이템을 직접 넣거나 꺼낼 수 있습니다.
* Storage Bus의 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 높여 아이템이 메인 저장소보다 서브네트워크에 먼저 보관되도록 합니다.
* 중요한 점은 서브네트워크의 셀이 가득 차더라도 아이템이 메인 네트워크로 넘쳐 들어가지 않는다는 것입니다. 생산물이 쌓이면 농장이 고장 나는 구조라면 <ItemLink id="void_card" />로 초과 아이템을 제거할 수 있습니다. 
* 농장이 여러 종류의 아이템을 생산한다면 <ItemLink id="equal_distribution_card" />를 사용해 한 종류가 셀 용량을 독점하는 것을 막을 수 있습니다.