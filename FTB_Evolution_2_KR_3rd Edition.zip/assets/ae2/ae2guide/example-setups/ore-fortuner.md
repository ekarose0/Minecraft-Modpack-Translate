---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatic Ore Fortuner
  icon: minecraft:raw_iron
---

# 광석 행운 자동화

<ItemLink id="annihilation_plane" />에는 행운을 포함한 모든 곡괭이 마법을 부여할 수 있습니다. 따라서 일부 Plane에 행운을 부여하고 <ItemLink id="formation_plane" />와 <ItemLink id="annihilation_plane" />를 활용해 광석을 빠르게 설치하고 파괴하는 자동화를 만들 수 있습니다.

<ItemLink id="import_bus" />는 작동 속도가 서서히 올라가므로 처음에는 느리지만 몇 초가 지나면 최대 속도에 도달합니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
        (1) Import Bus: Acceleration Card를 몇 개 장착합니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
        (2) Formation Plane: 기본 설정입니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
        (3) Annihilation Plane: 별도 설정 화면은 없으며 행운 마법을 부여합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
        (4) Storage Bus: 기본 설정입니다.
  </BoxAnnotation>

<DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
        입력
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
        출력
    </DiamondAnnotation>

<DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* (1) <ItemLink id="import_bus" />에 <ItemLink id="speed_card" />를 몇 개 넣습니다. Formation Plane의 수가 많을수록 한 번에 가져올 아이템이 늘어야 하므로 카드가 더 필요합니다.
* (2) <ItemLink id="formation_plane" />는 기본 설정입니다.
* (3) <ItemLink id="annihilation_plane" />에는 GUI가 없지만 행운 마법을 부여할 수 있습니다.
* (4) <ItemLink id="storage_bus" />는 기본 설정입니다.

## 작동 원리

1. 녹색 서브네트워크의 <ItemLink id="import_bus" />가 첫 번째 통에서 블록을 꺼내 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)로 보냅니다.
2. 녹색 서브네트워크에는 <ItemLink id="formation_plane" />만 저장 공간으로 연결되어 있어 블록을 배치합니다.
3. 주황색 서브네트워크의 <ItemLink id="annihilation_plane" />가 블록을 파괴하면서 행운 효과를 적용합니다.
4. 주황색 서브네트워크의 <ItemLink id="storage_bus" />가 파괴 결과물을 두 번째 통에 저장합니다.
