---
navigation:
  parent: example-setups/example-setups-index.md
    title: 자동 수량 조절 Cobblestone 생성기
  icon: minecraft:cobblestone
---

# 자동 수량 조절 Cobblestone 생성기

Cobblestone 생성기의 자동화는 간단합니다. 기본 Minecraft의 조약돌 생성기에 <ItemLink id="annihilation_plane" />를 향하게 설치하면 됩니다. 다만 계속 가동하면 네트워크가 Cobblestone으로 가득 차므로 생산량을 조절해야 합니다.

Annihilation Plane는 <ItemLink id="import_bus" />처럼 작동하므로, <ItemLink id="redstone_card" />가 장착된 <ItemLink id="export_bus" />를 <ItemLink id="level_emitter" />로 제어하는 방식만으로는 해결되지 않습니다. 중간 저장소 없이 Import에서 Export로 직접 전송할 수 없기 때문에 다른 방법이 필요합니다.

<ItemLink id="toggle_bus" />는 레드스톤 신호로 네트워크 연결을 켜고 끌 수 있지만, 전환할 때마다 네트워크가 재시작됩니다. [서브네트워크](../ae2-mechanics/subnetworks.md)에 Toggle Bus를 설치하면 서브네트워크만 재시작되므로 이 문제를 피할 수 있습니다.

<ItemLink id="annihilation_plane" />와 <ItemLink id="storage_bus" />로 독립적인 [서브네트워크](../ae2-mechanics/subnetworks.md)를 만들고 메인 네트워크의 <ItemLink id="interface" />로 아이템을 보내게 합니다. Toggle Bus는 <ItemLink id="quartz_fiber" />와 서브네트워크의 연결을 전환하여 Plane에 공급되는 에너지를 차단합니다.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

<BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
        (1) Annihilation Plane: 설정 GUI는 없지만 Efficiency와 Unbreaking을 부여해 에너지 소모를 줄일 수 있습니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
        (2) Storage Bus: 기본 설정을 사용합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
        (3) Toggle Bus: 반드시 메인 네트워크가 아닌 서브네트워크 쪽에 설치해야 합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
        (4) Level Emitter: Cobblestone과 목표 수량을 지정하고 "Emit when levels are below limit"로 설정합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
        (5) Interface: 기본 설정을 사용합니다.
  </BoxAnnotation>

<DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

<DiamondAnnotation pos="5 1.5 3.5" color="#00ff00">
        물에 잠긴 계단은 물이 흘러 용암을 Obsidian으로 바꾸는 것을 방지합니다.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* <ItemLink id="annihilation_plane" /> (1)는 설정 GUI가 없지만 Efficiency와 Unbreaking을 부여해 에너지 소모를 줄일 수 있습니다.
* <ItemLink id="storage_bus" /> (2)는 기본 설정을 사용합니다.
* <ItemLink id="toggle_bus" /> (3)는 Quartz Fiber의 메인 네트워크 쪽이 아니라 서브네트워크 쪽에 설치해야 합니다. 그렇지 않으면 전환할 때마다 메인 네트워크가 재시작됩니다.
* <ItemLink id="level_emitter" /> (4)에 대상 아이템과 목표 수량을 설정하고 "Emit when levels are below limit"를 선택합니다.
* <ItemLink id="interface" /> (5)는 기본 설정을 사용합니다.

## 작동 원리

1. 생성기가 Cobblestone을 생산합니다.
2. <ItemLink id="annihilation_plane" />가 Cobblestone을 채굴합니다. 
3. <ItemLink id="storage_bus" />가 Cobblestone을 <ItemLink id="interface" />에 넣어 메인 네트워크로 보냅니다.
4. 메인 네트워크의 Cobblestone 수량이 설정값을 초과하면 <ItemLink id="level_emitter" />가 신호를 중단하고 <ItemLink id="toggle_bus" />가 꺼집니다.
5. 서브네트워크의 전력 공급이 끊기면서 Annihilation Plane의 작동이 중지됩니다.
