---
navigation:
  parent: example-setups/example-setups-index.md
  title: Interface Autostocking
  icon: interface
---

# Interface를 이용한 자동 비축

"여러 종류의 아이템을 일정 수량씩 유지하고, 부족할 때마다 자동으로 제작하려면 어떻게 할까요?"

<ItemLink id="interface" />와 <ItemLink id="crafting_card" />를 이용하면 네트워크의 [자동 제작](../ae2-mechanics/autocrafting.md)에 필요한 아이템 제작을 자동으로 요청할 수 있습니다. 이 구성은 다양한 종류의 아이템을 소량씩 비축할 때 적합합니다.

예시를 지나치게 길게 만들지 않도록 일부를 생략했습니다. 실제로는 <ItemLink id="interface" /> 네 개와 <ItemLink id="storage_bus" /> 네 개를 사용해 [채널](../ae2-mechanics/channels.md) 여덟 개를 일반 [케이블](../items-blocks-machines/cables.md)에서 모두 활용하는 편이 효율적입니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
        (1) Interface: 원하는 아이템을 지정한 수량만큼 자체적으로 유지합니다. Crafting Card를 장착합니다.
        <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
        (2) Storage Bus: "입출력 모드"를 "꺼내기 전용"으로 설정합니다.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* (1) <ItemLink id="interface" />의 위쪽 슬롯에 보관할 아이템을 넣거나 JEI에서 끌어와 지정하고, 슬롯 위의 렌치 아이콘으로 유지할 수량을 정합니다. <ItemLink id="crafting_card" />를 장착합니다.
* (2) <ItemLink id="storage_bus" />의 "입출력 모드"를 "꺼내기 전용"으로 설정합니다.

## 작동 원리

1. <ItemLink id="interface" />가 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에서 설정된 수량을 가져오지 못하면 장착된 <ItemLink id="crafting_card" />가 네트워크의 [자동 제작](../ae2-mechanics/autocrafting.md)에 부족한 아이템 제작을 요청합니다.
2. <ItemLink id="storage_bus" />가 Interface의 내용물을 네트워크에서 접근할 수 있도록 합니다.
