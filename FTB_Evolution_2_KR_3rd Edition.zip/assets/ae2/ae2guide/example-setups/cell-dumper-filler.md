---
navigation:
  parent: example-setups/example-setups-index.md
  title: Cell Dumper or Filler
  icon: io_port
---

# Storage Cell 빠르게 비우기 또는 채우기

"Storage Cell의 내용물을 상자, 서랍, 배낭으로 빠르게 옮기거나 반대로 그 안의 물품으로 셀을 채우려면 어떻게 할까요?"

<ItemLink id="io_port" />와 서브네트워크를 사용해 아이템을 넣거나 꺼낼 대상 저장 공간을 제한하면 됩니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
        (1) I/O Port: 화면 중앙의 화살표로 "네트워크로 전송" 또는 "Storage Cell로 전송"을 선택합니다. Acceleration Card 세 장을 장착합니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
        (2) Storage Bus: 기본 설정 상태입니다.
  </BoxAnnotation>

<BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
        비우거나 채울 대상 저장 장치를 이곳에 놓습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0.35 0.35" max="2.3 0.65 0.65">
        Quartz Fiber: 다른 네트워크에서 전력을 공급받을 때만 필요합니다.
  </BoxAnnotation>

<DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
        다른 네트워크나 Energy Acceptor 등의 전원에 연결합니다.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* (1) <ItemLink id="io_port" />의 화면 중앙 화살표에서 "네트워크로 전송" 또는 "Storage Cell로 전송"을 선택합니다. 최대 속도를 위해 Acceleration Card 세 장을 넣습니다.
* (2) <ItemLink id="storage_bus" />는 기본 설정 상태입니다.

## 작동 원리

### "네트워크로 전송" 모드

1. <ItemLink id="io_port" />가 삽입된 [storage cell](../items-blocks-machines/storage_cells.md)의 내용물을 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에 옮기려고 합니다.
2. 서브네트워크의 유일한 저장 공간은 <ItemLink id="storage_bus" />이므로 앞에 놓인 상자나 서랍 등에 아이템과 유체를 넣습니다.
* <ItemLink id="energy_cell" />은 순간 전력 소비가 커도 네트워크가 꺼지지 않도록 충분한 [에너지](../ae2-mechanics/energy.md)를 저장합니다.

### "Storage Cell로 전송" 모드

1. <ItemLink id="io_port" />가 [network's storage](../ae2-mechanics/import-export-storage.md)의 내용물을 삽입된 [storage cell](../items-blocks-machines/storage_cells.md)에 옮기려고 합니다.
2. 서브네트워크의 유일한 저장 공간은 <ItemLink id="storage_bus" />이므로 앞에 놓인 상자나 서랍에서 아이템과 유체를 꺼냅니다.
* <ItemLink id="energy_cell" />은 순간 전력 소비가 커도 네트워크가 꺼지지 않도록 충분한 [에너지](../ae2-mechanics/energy.md)를 저장합니다.
