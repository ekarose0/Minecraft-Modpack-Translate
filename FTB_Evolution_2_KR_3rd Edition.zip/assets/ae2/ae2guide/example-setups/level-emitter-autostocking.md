---
navigation:
  parent: example-setups/example-setups-index.md
  title: Level Emitter Autostocking
  icon: level_emitter
---

# Level Emitter를 이용한 자동 비축

"특정 아이템을 일정 수량 이상 유지하고 부족하면 자동 제작하려면 어떻게 할까요?"

<ItemLink id="export_bus" />, <ItemLink id="level_emitter" />, <ItemLink id="crafting_card" />를 사용해 네트워크의 [자동 제작](../ae2-mechanics/autocrafting.md)에 제작을 자동 요청할 수 있습니다. 이 구성은 한 종류의 아이템을 대량으로 비축할 때 적합합니다.

Level Emitter와 Redstone Card를 제거하면 계속해서 제작하도록 만들 수도 있습니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (1) Export Bus: 원하는 아이템만 내보내도록 필터를 설정합니다. Redstone Card와 Crafting Card를 장착합니다. 레드스톤 모드는 "신호가 있을 때 활성화", 제작 방식은 "비축된 아이템 사용 안 함"으로 설정합니다.
        <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
        (2) Level Emitter: 원하는 아이템과 수량을 지정하고 "수량이 한도 미만일 때 신호 출력"으로 설정합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (3) Interface: 기본 설정 상태입니다.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* (1) <ItemLink id="export_bus" />의 필터에 원하는 아이템을 등록하고 <ItemLink id="redstone_card" /> 및 <ItemLink id="crafting_card" />를 장착합니다. 레드스톤 모드는 "신호가 있을 때 활성화", 제작 방식은 "비축된 아이템 사용 안 함"으로 설정합니다.
* (2) <ItemLink id="level_emitter" />에 원하는 아이템과 수량을 지정하고 "수량이 한도 미만일 때 신호 출력"으로 설정합니다.
* (3) <ItemLink id="interface" />는 기본 설정입니다.

## 작동 원리

1. [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)의 지정 아이템 수량이 <ItemLink id="level_emitter" />에 설정된 값보다 적으면 레드스톤 신호를 출력합니다.
2. 장착된 <ItemLink id="crafting_card" />와 비축 아이템을 사용하지 않는 설정에 따라, 신호를 받은 <ItemLink id="export_bus" />가 네트워크의 [자동 제작](../ae2-mechanics/autocrafting.md)에 새 제작을 요청한 뒤 결과물을 내보냅니다.
3. <ItemLink id="interface" />는 내부에 보관할 아이템이 설정되어 있지 않으므로 입력받은 아이템을 네트워크 저장 공간으로 보냅니다.
