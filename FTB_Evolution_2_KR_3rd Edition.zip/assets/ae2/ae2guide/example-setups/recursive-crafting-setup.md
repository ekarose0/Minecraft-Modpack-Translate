---
navigation:
  parent: example-setups/example-setups-index.md
    title: 재귀 제작 자동화
  icon: minecraft:netherite_upgrade_smithing_template
---

# 재귀 제작 자동화 구성

[자동 제작](../ae2-mechanics/autocrafting.md)에서 설명했듯이 자동 제작 계획 알고리즘은 주요 결과물이 제작 재료로 다시 들어가는 제작법을 처리하지 못합니다. 예를 들어 <ItemLink id="minecraft:netherite_upgrade_smithing_template" /> 복제 제작법은 직접 자동화할 수 없습니다.

이를 해결하는 방법 중 하나는 <ItemLink id="level_emitter" />가 [패턴](../items-blocks-machines/patterns.md)처럼 작동하는 기능을 이용하는 것입니다.

이 기능으로 제작 장치를 켜서 해당 제작법을 반복 실행하게 할 수 있습니다. 여기서는 <ItemLink id="minecraft:netherite_upgrade_smithing_template" /> 복제 설비를 살펴보겠습니다.

<RecipeFor id="minecraft:netherite_upgrade_smithing_template" />

***

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/recursive_recipe_setup.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Interface: 추가 재료인 Diamond와 Netherrack을 비축하도록 설정합니다.
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="minecraft:netherrack" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 1 0.3" max="2.7 1.3 0.7">
        (2) Level Emitter: Netherite Smithing Template을 지정하고 "Emit Redstone to craft item"으로 설정합니다.
        <Row><ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (3) Import Bus #1: Interface에 비축한 아이템만 받도록 필터를 설정합니다. Redstone Card를 장착하고 "Active with signal"로 설정합니다.
        <Row>
        <ItemImage id="minecraft:diamond" scale="2" />
        <ItemImage id="minecraft:netherrack" scale="2" />
        <ItemImage id="redstone_card" scale="2" />
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        (4) Storage Bus #1: 다른 Storage Bus보다 우선순위를 높게 설정합니다. 매우 중요합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 0 1" max="4 1 2">
        (5) Molecular Assembler: Smithing Template 복제 패턴을 넣습니다.

        ![Pattern](../assets/diagrams/smithing_template_pattern_small.png)

        최초 설치 시 Smithing Template 하나를 직접 넣어 두어야 합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        (6) Import Bus #2: 기본 설정을 사용합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="2 1 1.3">
        (7) Storage Bus #2: Netherite Smithing Template만 받도록 필터를 설정하고 다른 Storage Bus보다 우선순위를 낮춥니다.
        <ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

## 설정

* <ItemLink id="interface" /> (1)는 추가 재료인 Diamond와 Netherrack을 비축하도록 설정합니다.
* <ItemLink id="level_emitter" /> (2)는 Netherite Smithing Template을 지정하고 "Emit Redstone to craft item"으로 설정합니다.
* 첫 번째 <ItemLink id="import_bus" /> (3)는 Interface에 비축된 재료만 받도록 필터를 설정하고 Redstone Card를 장착해 "Active with signal"로 설정합니다.
* 첫 번째 <ItemLink id="storage_bus" /> (4)는 두 번째 Storage Bus보다 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 *높게* 설정합니다.
* <ItemLink id="molecular_assembler" /> (5)에 Smithing Template 복제 패턴과 초기 재료인 Smithing Template 하나를 직접 넣습니다.

  ![Pattern](../assets/diagrams/smithing_template_pattern.png)

* 두 번째 <ItemLink id="import_bus" /> (6)는 기본 설정을 사용합니다.
* 두 번째 <ItemLink id="storage_bus" /> (7)는 Netherite Smithing Template만 받도록 필터를 설정하고 첫 번째 Storage Bus보다 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 *낮게* 설정합니다.

## 작동 원리

1. <ItemLink id="crafting_card" />를 장착하고 "Emit Redstone to craft item"으로 설정한 <ItemLink id="level_emitter" />가 [패턴](../items-blocks-machines/patterns.md)처럼 작동합니다. 따라서 [Terminal](../items-blocks-machines/terminals.md)에서 Netherite Smithing Template을 [자동 제작](../ae2-mechanics/autocrafting.md)할 수 있는 항목으로 표시합니다.
2. 플레이어나 시스템이 해당 아이템 제작을 요청하면 Level Emitter가 켜집니다.
3. 첫 번째 <ItemLink id="import_bus" />가 Level Emitter의 신호로 활성화되어 <ItemLink id="interface" />에 비축된 재료를 꺼냅니다.
4. 네트워크에서 이 재료를 저장할 수 있는 유일한 <ItemLink id="storage_bus" />는 Assembler에 연결된 것입니다.
5. <ItemLink id="molecular_assembler" />가 재료를 받아 기존에 들어 있던 Smithing Template 하나와 함께 제작해 Template 두 개를 만듭니다.
6. 두 번째 <ItemLink id="import_bus" />가 Smithing Template 하나를 꺼냅니다.
7. 첫 번째 Storage Bus의 우선순위가 더 높으므로 Template이 Assembler로 돌아갑니다.
8. 두 번째 <ItemLink id="import_bus" />가 남은 Template 하나를 꺼냅니다.
9. Assembler에는 더 이상 Template을 넣을 수 없으므로 두 번째 Template은 우선순위가 낮은 Storage Bus를 거쳐 Interface에 들어갑니다.
10. <ItemLink id="interface" />는 Smithing Template을 비축하도록 설정되지 않았으므로 이를 네트워크 저장소로 보냅니다.