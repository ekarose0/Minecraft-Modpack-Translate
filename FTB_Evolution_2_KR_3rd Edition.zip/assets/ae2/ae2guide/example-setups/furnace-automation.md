---
navigation:
  parent: example-setups/example-setups-index.md
  title: Furnace Automation
  icon: minecraft:furnace
---

# 화로 자동화

이 구성은 <ItemLink id="pattern_provider" />를 사용하므로 [자동 제작](../ae2-mechanics/autocrafting.md)에 연결하는 방식입니다. 화로 한 대만 독립적으로 자동화하려면 호퍼와 상자를 사용하세요.

<ItemLink id="minecraft:furnace" />의 자동화는 [charger](../example-setups/charger-automation.md)처럼 간단한 기계보다 조금 더 복잡합니다. 화로는 두 면에서 아이템을 받아야 하고 세 번째 면으로 결과물을 내보내야 합니다. 제련할 아이템은 윗면으로, 연료는 옆면으로 넣고 결과물은 아래쪽에서 꺼내야 합니다.

윗면에 <ItemLink id="pattern_provider" />, 옆면에 연료를 계속 공급하는 <ItemLink id="export_bus" />, 아랫면에 결과물을 가져오는 <ItemLink id="import_bus" />를 배치하는 방법도 있습니다. 하지만 이 방법에는 [채널](../ae2-mechanics/channels.md) 세 개가 필요합니다.

다음은 채널 하나만 사용하는 구성입니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Pattern Provider: Certus Quartz Wrench로 방향을 지정하고 관련 처리 패턴을 장착합니다.

        ![Iron Pattern](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface: 기본 설정입니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Storage Bus #1: 석탄만 허용합니다.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Storage Bus #2: Inverter Card로 석탄을 차단 목록에 등록합니다.
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* (1) <ItemLink id="pattern_provider" />에는 관련 <ItemLink id="processing_pattern" />을 장착하고 기본 설정을 사용합니다. <ItemLink id="certus_quartz_wrench" />로 방향을 지정합니다.

  ![Iron Pattern](../assets/diagrams/furnace_pattern.png)

* (2) <ItemLink id="interface" />는 기본 설정입니다.
* (3) 첫 번째 <ItemLink id="storage_bus" />는 석탄 등 사용할 연료만 허용하도록 필터를 설정합니다.
* (4) 두 번째 <ItemLink id="storage_bus" />에는 <ItemLink id="inverter_card" />를 사용하여 연료를 차단 목록으로 지정합니다.

## 작동 원리

1. <ItemLink id="pattern_provider" />가 재료를 <ItemLink id="interface" />에 넣습니다. 실제로는 최적화 때문에 Storage Bus를 Provider 면의 확장처럼 이용하여 재료를 직접 전송하므로 Interface 내부를 거치지 않습니다.
2. Interface는 저장할 물품이 없도록 설정되어 있어 재료를 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)로 보내려고 합니다.
3. 녹색 서브네트워크에는 <ItemLink id="storage_bus" />만 저장 공간으로 연결되어 있습니다. 석탄을 허용하는 Bus는 연료를 화로 옆면으로 보내고, 석탄을 차단한 Bus는 제련할 재료를 윗면으로 보냅니다.
4. 화로가 제련을 수행합니다.
5. 호퍼가 화로 아래에서 결과물을 꺼내 Pattern Provider의 반환 슬롯에 넣어 메인 네트워크로 돌려보냅니다.
