---
navigation:
  parent: example-setups/example-setups-index.md
  title: 고급 Certus 농장
  icon: certus_quartz_crystal
  position: 120
---

# 고급 Certus 농장

이 구성은 [반자동 Certus 농장](semiauto-certus-farm.md)을 ME 시스템에 완전히 통합한 형태입니다.

Budding 블록을 대량으로 비축해 두었다가 직접 재생하는 대신, [Charger 자동화](charger-automation.md)와 [물에 던지는 제작법 자동화](throw-in-water-automation.md)를 활용하여 블록을 자동으로 재생합니다.

예상 성장 속도는 [Certus 성장](../ae2-mechanics/certus-growth.md)을 참고하세요.

**복잡한 구조이며 다른 블록 뒤에 가려진 장치가 있습니다. 화면을 회전하여 모든 방향에서 확인하세요.**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Annihilation Plane #1: 설정 GUI는 없지만 Fortune 마법 부여가 가능합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
        (2) Storage Bus #1: Certus Quartz Crystal만 허용하도록 필터를 설정합니다.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    수정 군집 파괴 서브네트워크
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Annihilation Plane #2: 설정 GUI는 없으며 Silk Touch 마법을 부여해야 합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
        (4) Storage Bus #2: Certus Quartz Block만 허용하도록 필터를 설정합니다.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Certus 블록 파괴 서브네트워크
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Formation Plane: 기본 설정을 사용합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
        (6) Import Bus: Flawed Budding Certus Quartz로 필터를 설정합니다.
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Budding 블록 배치 서브네트워크
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
        (7) Storage Bus #3: Certus Quartz Crystal로 필터를 설정하고 메인 저장소보다 높은 우선순위를 지정합니다.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
        (8) Interface: Flawed Budding Certus Quartz 1개를 유지하도록 설정하고 Crafting Card를 장착합니다.
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
        메인 네트워크, Charger 자동화, 물에 던지는 제작법 자동화로 연결
        <Row>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        </Row>
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## 장치 설정

### 수정 군집 파괴 장치

* 첫 번째 <ItemLink id="annihilation_plane" /> (1)은 설정 GUI가 없지만 Fortune 마법 부여가 가능합니다.
* 첫 번째 <ItemLink id="storage_bus" /> (2)의 필터에는 <ItemLink id="certus_quartz_crystal" />을 지정합니다.

### Certus 블록 파괴 장치

* 두 번째 <ItemLink id="annihilation_plane" /> (3)은 설정 GUI가 없으며 Silk Touch 마법을 반드시 부여해야 합니다.
* 두 번째 <ItemLink id="storage_bus" /> (4)의 필터에는 <ItemLink id="quartz_block" />을 지정합니다.

### Budding 블록 배치 장치

* <ItemLink id="formation_plane" /> (5)은 기본 설정을 사용합니다.
* <ItemLink id="import_bus" /> (6)의 필터에는 <ItemLink id="flawed_budding_quartz" />을 지정합니다.

### 메인 네트워크

* 세 번째 <ItemLink id="storage_bus" /> (7)의 필터에는 <ItemLink id="certus_quartz_crystal" />을 지정하고 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 메인 저장소보다 높게 설정합니다.
* <ItemLink id="interface" /> (8)은 Flawed Budding Certus Quartz 1개를 유지하도록 설정하고 <ItemLink id="crafting_card" />를 장착합니다.

## 작동 원리

### 수정 군집 파괴 장치

수정 군집 파괴 서브네트워크는 [간단한 Certus 농장](simple-certus-farm.md)의 서브네트워크와 거의 동일하게 작동합니다.

1. <ItemLink id="annihilation_plane" />은 앞의 블록을 부수려고 하지만, 서브네트워크에 있는 유일한 저장 공간이 <ItemLink id="certus_quartz_crystal" />로 필터링된 <ItemLink id="storage_bus" />이므로 <ItemLink id="quartz_cluster" />만 부술 수 있습니다.
2. <ItemLink id="storage_bus" />는 수확한 Certus Quartz Crystal을 Barrel에 저장합니다.

### Certus 블록 파괴 장치

Certus 블록 파괴 서브네트워크는 성장 능력을 잃은 Budding 블록이 일반 <ItemLink id="quartz_block" />으로 변하면 이를 파괴합니다. 수정 군집 파괴 장치와 비슷하게 작동합니다.

1. <ItemLink id="annihilation_plane" />은 앞의 <ItemLink id="quartz_block" />을 파괴하려 하지만, 서브네트워크의 유일한 저장 공간이 <ItemLink id="quartz_block" />으로 필터링된 <ItemLink id="storage_bus" />이므로 해당 블록만 파괴합니다. Silk Touch를 부여해야 Budding 블록을 파괴할 때 성장 단계가 손실되지 않아 조기에 파괴하는 일을 막을 수 있습니다.
2. <ItemLink id="storage_bus" />는 Certus Quartz Block을 <ItemLink id="interface" />에 보관합니다. [물에 던지는 제작법 자동화](throw-in-water-automation.md)가 이를 사용해 새로운 <ItemLink id="flawed_budding_quartz" />을 제작합니다.

### Budding 블록 배치 장치

Budding 블록 배치 서브네트워크는 파괴 서브네트워크가 소모된 블록을 제거하면 새로운 <ItemLink id="flawed_budding_quartz" />을 설치합니다.

1. <ItemLink id="import_bus" />가 <ItemLink id="interface" />에서 Budding 블록을 가져와 [네트워크 저장소](../ae2-mechanics/import-export-storage.md)로 옮깁니다.
2. 서브네트워크의 유일한 저장 공간인 <ItemLink id="formation_plane" />이 Budding 블록을 배치합니다.

### 메인 네트워크

* <ItemLink id="storage_bus" />를 통해 메인 네트워크와 [Charger 자동화](charger-automation.md)가 Barrel의 모든 Certus Quartz Crystal에 접근할 수 있습니다. [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 높게 설정하면 수정이 메인 저장소보다 Barrel에 먼저 보관됩니다.
* <ItemLink id="interface" />는 Budding 블록 배치 서브네트워크에 <ItemLink id="flawed_budding_quartz" />을 공급하고, Certus 블록 파괴 서브네트워크가 소모된 블록을 메인 네트워크로 돌려보낼 통로를 제공합니다. <ItemLink id="crafting_card" />를 장착하면 Interface가 메인 네트워크의 [자동 제작](../ae2-mechanics/autocrafting.md)에 새로운 Budding 블록 제작을 요청할 수 있습니다.