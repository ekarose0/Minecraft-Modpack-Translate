---
navigation:
  parent: example-setups/example-setups-index.md
    title: 물에 던지는 제작법 자동화
  icon: fluix_crystal
---

# 물에 아이템을 던지는 제작법 자동화

<ItemLink id="pattern_provider" />를 사용하므로 [자동 제작](../ae2-mechanics/autocrafting.md) 시스템과 연동하는 것을 전제로 합니다.

일부 제작법은 아이템을 물에 던져야 합니다. 같은 방식으로 다른 장소에 아이템을 던지는 작업도 자동화할 수 있습니다. <ItemLink id="formation_plane" />와 <ItemLink id="annihilation_plane" /> 및 보조 장치로 자동화할 수 있으며, 기본적으로 두 개의 변형된 [파이프 서브네트워크](pipe-subnet.md)를 사용합니다.

이 구조는 <ItemLink id="charged_certus_quartz_crystal" />을 공급하는 [Charger 자동화](charger-automation.md) 설비와 함께 사용하도록 설계되었습니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (1) Pattern Provider: 해당 Processing Pattern을 넣고 기본 설정을 사용합니다.

        ![Fluix Pattern](../assets/diagrams/fluix_pattern_small.png) ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
        (2) Interface: 기본 설정을 사용합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
        (3) Formation Plane: 입력 아이템을 월드에 떨어뜨리도록 설정합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
        (4) Annihilation Plane: 별도의 설정 GUI가 없습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (5) Storage Bus: 패턴의 결과물만 받도록 필터를 설정합니다.
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="3.9 0.5 1.5" color="#00ff00">
        메인 네트워크 및 Charger 자동화 설비로 연결
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
    </DiamondAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## 설정 및 패턴

* <ItemLink id="pattern_provider" /> (1)에 해당 <ItemLink id="processing_pattern" />을 넣고 기본 설정을 사용합니다.
  * <ItemLink id="fluix_crystal" />은 JEI/REI에 표시되는 기본 제작법을 그대로 사용해도 됩니다.

    ![Fluix Pattern](../assets/diagrams/fluix_pattern.png)

  * <ItemLink id="flawed_budding_quartz" />는 <ItemLink id="quartz_block" />에서 직접 제작하도록 패턴을 만드는 편이 좋습니다. 한 제작법의 결과물이 다른 제작법의 재료와 겹쳐 Storage Bus가 필터를 제대로 적용하지 못하는 문제를 피할 수 있습니다.

    ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern.png)

* <ItemLink id="interface" /> (2)는 기본 설정을 사용합니다.
* <ItemLink id="formation_plane" /> (3)는 입력 아이템을 월드에 떨어뜨리도록 설정합니다.
* <ItemLink id="annihilation_plane" /> (4)는 설정 GUI가 없어 별도로 설정할 수 없습니다.
* <ItemLink id="storage_bus" /> (5)는 패턴의 결과물만 받도록 필터를 설정합니다.

## 작동 원리

1.  <ItemLink id="pattern_provider" />가 재료를 옆면에 연결된 초록색 서브네트워크의 <ItemLink id="interface" />로 보냅니다.
2.  Interface는 기본적으로 아이템을 보관하지 않으므로 내용물을 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)으로 보내려고 합니다.
3.  초록색 서브네트워크의 유일한 저장 대상인 <ItemLink id="formation_plane" />가 받은 아이템을 물에 떨어뜨립니다.
4.  주황색 서브네트워크의 <ItemLink id="annihilation_plane" />가 떨어진 아이템을 회수하려 하지만, 이 서브네트워크의 유일한 저장 공간인 Pattern Provider 위의 <ItemLink id="storage_bus" />가 제작 결과물만 받도록 설정되어 있어 아직 회수할 수 없습니다.
5.  아이템이 월드에서 변환됩니다.
6.  변환된 결과물은 Storage Bus의 필터를 통과하므로 Annihilation Plane가 회수할 수 있습니다.
7.  Storage Bus가 결과물을 Pattern Provider에 넣어 네트워크로 반환합니다.
