---
navigation:
  parent: example-setups/example-setups-index.md
  title: Processor 자동화
  icon: logic_processor
---

# Processor 생산 자동화

[Processor](../items-blocks-machines/processors.md)를 자동으로 생산하는 방법은 다양하며, 아래는 그중 한 가지입니다.

이 기본 배치는 필터를 설정할 수만 있다면 다른 모드의 물류 Pipe, Conduit, Duct 등으로도 구현할 수 있습니다.

![Processor 공정 흐름도](../assets/diagrams/processor_flow_diagram.png)

여기서는 [파이프 역할을 하는 Subnet](pipe-subnet.md)을 이용해 AE2만으로 구현하는 방법을 자세히 설명합니다.

이 구성에는 <ItemLink id="pattern_provider" />가 있으므로 [자동 제작](../ae2-mechanics/autocrafting.md) 시스템에 연결하는 것을 전제로 합니다. Processor만 독립적으로 자동 생산하려면 Pattern Provider를 Barrel로 바꾸고 위쪽 Barrel에 재료를 직접 넣으세요.

이 방식은 이전 AE2 버전과도 호환됩니다. <ItemLink id="inscriber" />의 면별 입출력 제한이 있더라도 파이프 Subnet이 올바른 면으로 재료를 넣고 결과물을 꺼내기 때문입니다.

## Pattern 인코딩 시 주의사항

인코딩해야 하는 [Pattern](../items-blocks-machines/patterns.md)은 **JEI에 표시된 제작법이나 + 버튼으로 생성한 Pattern과 다를 수 있습니다.**
JEI는 Printed 부품 제작과 최종 조립을 각각 별도 Pattern으로 만들고, Printed 부품의 Pattern에는 [Press](../items-blocks-machines/presses.md)도 포함합니다. 하지만 이 설비는 원재료를 받아 완성된 Processor를 내보내도록 구성되어 있습니다. Press는 이미 Inscriber 안에 있으므로, 원재료 → 완성 Processor의 Pattern 하나만 만들고 Press는 재료에서 제외하세요.

---

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
        (1) Pattern Provider: 해당 Processing Pattern을 넣고 기본 설정을 사용합니다.

        <Row>
            ![Logic Pattern](../assets/diagrams/logic_pattern_small.png)
            ![Calculation Pattern](../assets/diagrams/calculation_pattern_small.png)
            ![Engineering Pattern](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.7 2 0" max="5 3 1" thickness=".05">
        (2) Storage Bus #1: 기본 설정을 사용합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="4.3 2 1" thickness=".05">
        (3) Export Bus #1: Silicon으로 필터를 설정하고 Acceleration Card 2개를 넣습니다.
        <Row><ItemImage id="silicon" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="4.3 3 1" thickness=".05">
        (4) Export Bus #2: Gold Ingot으로 필터를 설정하고 Acceleration Card 2개를 넣습니다.
        <Row><ItemImage id="minecraft:gold_ingot" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="4.3 4 1" thickness=".05">
        (5) Export Bus #3: Certus Quartz Crystal로 필터를 설정하고 Acceleration Card 2개를 넣습니다.
        <Row><ItemImage id="certus_quartz_crystal" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 6 0" max="4.3 5 1" thickness=".05">
        (6) Export Bus #4: Diamond로 필터를 설정하고 Acceleration Card 2개를 넣습니다.
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 0" max="2 2 1" thickness=".05">
        (7) Export Bus #5: Redstone Dust로 필터를 설정하고 Acceleration Card 2개를 넣습니다.
        <Row><ItemImage id="minecraft:redstone" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="3 2 1" thickness=".05">
        (8) Inscriber #1: 기본 설정. Silicon Press와 Acceleration Card 4개를 넣습니다.
        <Row><ItemImage id="silicon_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 3 0" max="3 4 1" thickness=".05">
        (9) Inscriber #2: 기본 설정. Logic Press와 Acceleration Card 4개를 넣습니다.
        <Row><ItemImage id="logic_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="3 5 1" thickness=".05">
        (10) Inscriber #3: 기본 설정. Calculation Press와 Acceleration Card 4개를 넣습니다.
        <Row><ItemImage id="calculation_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="3 6 1" thickness=".05">
        (11) Inscriber #4: 기본 설정. Engineering Press와 Acceleration Card 4개를 넣습니다.
        <Row><ItemImage id="engineering_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 0" max="1 3 1" thickness=".05">
        (12) Inscriber #5: 기본 설정. Acceleration Card 4개를 넣습니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 2 0" max="3 1 1" thickness=".05">
        (13) Import Bus #1: 기본 설정. Acceleration Card 2개를 넣습니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 4 0" max="3 3 1" thickness=".05">
        (14) Import Bus #2: 기본 설정. Acceleration Card 2개를 넣습니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 5 0" max="3 4 1" thickness=".05">
        (15) Import Bus #3: 기본 설정. Acceleration Card 2개를 넣습니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 6 0" max="3 5 1" thickness=".05">
        (16) Import Bus #4: 기본 설정. Acceleration Card 2개를 넣습니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 3 0" max="1 3.3 1" thickness=".05">
        (17) Storage Bus #2: 기본 설정을 사용합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1.7 0" max="1 2 1" thickness=".05">
        (18) Storage Bus #3: 기본 설정을 사용합니다.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 0" max="0.7 3 1" thickness=".05">
        (19) Import Bus #5: 기본 설정. Acceleration Card 2개를 넣습니다.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="5 0.7 0" max="6 1 1" thickness=".05">
        (20) Storage Bus #4: 기본 설정을 사용합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.3 2.7 0.3" max="3.7 3 0.7" thickness=".05">
        Inscriber는 Cable처럼 전력을 전달하므로 Quartz Fiber 하나로 Inscriber 3개에 전력을 공급할 수 있습니다.
  </BoxAnnotation>

<DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## 장치 설정

* <ItemLink id="pattern_provider" /> (1)은 기본 설정으로 두고 해당 <ItemLink id="processing_pattern" />을 넣습니다.
  Pattern은 원재료에서 완성 Processor로 바로 이어져야 하며 [Press](../items-blocks-machines/presses.md)를 **포함하면 안 됩니다.**

  ![Logic Pattern](../assets/diagrams/logic_pattern.png)
  ![Calculation Pattern](../assets/diagrams/calculation_pattern.png)
  ![Engineering Pattern](../assets/diagrams/engineering_pattern.png)

* <ItemLink id="storage_bus" /> (2, 17, 18, 20)는 기본 설정을 사용합니다.
* <ItemLink id="export_bus" /> (3~7)는 해당 재료만 통과하도록 필터를 설정하고 <ItemLink id="speed_card" /> 2개를 넣습니다.
    <Row>
      <ItemImage id="silicon" scale="2" />
      <ItemImage id="minecraft:gold_ingot" scale="2" />
      <ItemImage id="certus_quartz_crystal" scale="2" />
      <ItemImage id="minecraft:diamond" scale="2" />
      <ItemImage id="minecraft:redstone" scale="2" />
    </Row>
* <ItemLink id="import_bus" /> (13~16, 19)는 기본 설정을 사용하고 <ItemLink id="speed_card" /> 2개를 넣습니다.
* <ItemLink id="inscriber" />는 기본 설정을 사용하고, 알맞은 [Press](../items-blocks-machines/presses.md)와 <ItemLink id="speed_card" /> 4개를 넣습니다.
   <Row>
     <ItemImage id="silicon_press" scale="2" />
     <ItemImage id="logic_processor_press" scale="2" />
     <ItemImage id="calculation_processor_press" scale="2" />
     <ItemImage id="engineering_processor_press" scale="2" />
   </Row>

## 작동 원리

1. <ItemLink id="pattern_provider" />가 재료를 Barrel로 밀어 넣습니다.
2. 첫 번째 [Pipe Subnet](pipe-subnet.md)(주황색)이 Barrel에서 Silicon, Redstone Dust, 그리고 해당 Processor의 재료(Gold Ingot, Certus Quartz Crystal 또는 Diamond)를 꺼내 알맞은 <ItemLink id="inscriber" />에 넣습니다.
3. 앞쪽의 <ItemLink id="inscriber" /> 4개가 <ItemLink id="printed_silicon" />과 <ItemLink id="printed_logic_processor" />, <ItemLink id="printed_calculation_processor" /> 또는 <ItemLink id="printed_engineering_processor" />를 만듭니다.
4. 두 번째와 세 번째 [Pipe Subnet](pipe-subnet.md)(초록색)이 앞쪽 <ItemLink id="inscriber" /> 4개에서 Printed 부품을 꺼내 최종 조립용 다섯 번째 <ItemLink id="inscriber" />에 넣습니다.
5. 다섯 번째 <ItemLink id="inscriber" />가 [Processor](../items-blocks-machines/processors.md)를 조립합니다.
6. 네 번째 [Pipe Subnet](pipe-subnet.md)(보라색)이 완성된 Processor를 Pattern Provider에 넣어 메인 네트워크로 돌려보냅니다.