---
navigation:
  parent: example-setups/example-setups-index.md
  title: Simple Certus Farm
  icon: certus_quartz_crystal
  position: 110
---

# 간단한 Certus Quartz 농장

[Certus Growth](../ae2-mechanics/certus-growth.md)에서 설명한 것처럼 <ItemLink id="certus_quartz_crystal" />의 자동 수확에는 <ItemLink id="annihilation_plane" />와 <ItemLink id="storage_bus" />가 사용됩니다. <ItemLink id="growth_accelerator" />로 싹의 성장을 크게 가속한 다음, 완전히 자란 <ItemLink id="quartz_cluster" />만 Plane으로 파괴합니다. 덜 자란 싹은 블록 대신 <ItemLink id="certus_quartz_dust" />를 떨어뜨리는 특성을 활용해 필터링합니다.

<ItemLink id="flawless_budding_quartz" />를 사용하면 농장이 완전히 자동으로 작동합니다. Flawed, Chipped, Damaged Budding Certus Quartz는 블록을 수동으로 교체해야 하지만 [Semi-Auto Certus Farm](semiauto-certus-farm.md)와 [Advanced Certus Farm](advanced-certus-farm.md)에서 설명하는 방법으로 교체 과정까지 자동화할 수 있습니다.

예상 생산 속도는 [Certus Growth](../ae2-mechanics/certus-growth.md)을 참고하세요.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
        (1) Annihilation Plane: 설정 화면은 없지만 행운 마법을 부여할 수 있습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
        (2) Storage Bus #1: Certus Quartz Crystal만 허용합니다.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
        (3) Storage Bus #2: Certus Quartz Crystal만 허용하고 메인 저장소보다 우선순위를 높입니다.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* (1) <ItemLink id="annihilation_plane" />에는 GUI가 없지만 행운 마법을 부여할 수 있습니다.
* (2) 첫 번째 <ItemLink id="storage_bus" />는 <ItemLink id="certus_quartz_crystal" />만 허용하도록 필터를 설정합니다.
* (3) 두 번째 <ItemLink id="storage_bus" /> 역시 <ItemLink id="certus_quartz_crystal" />만 허용하고 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 메인 저장소보다 높게 설정합니다.

## 작동 원리

1. <ItemLink id="annihilation_plane" />는 <ItemLink id="quartz_cluster" />만 파괴할 수 있습니다. 서브네트워크의 유일한 저장 공간이 <ItemLink id="storage_bus" />이고 <ItemLink id="certus_quartz_crystal" />만 허용하기 때문입니다.
2. 첫 번째 <ItemLink id="storage_bus" />가 Certus Quartz Crystal을 통에 저장합니다.
3. 두 번째 <ItemLink id="storage_bus" />가 통 안의 Certus Quartz Crystal을 메인 네트워크에서 이용할 수 있게 합니다. 높은 [우선순위](../ae2-mechanics/import-export-storage.md#storage-priority)를 설정했으므로 메인 저장 공간보다 통에 우선적으로 보관합니다.
