---
navigation:
  parent: example-setups/example-setups-index.md
  title: 아이템/유체 파이프 Subnet
  icon: storage_bus
---

# 아이템/유체 파이프 Subnet

AE2 [장치](../ae2-mechanics/devices.md)를 이용해 아이템 또는 유체 Pipe의 기능을 구현하는 간단한 방법입니다. 일반 Pipe가 필요한 대부분의 상황에서 사용할 수 있으며, 제작 결과물을 <ItemLink id="pattern_provider" />에 돌려보내는 데에도 활용할 수 있습니다.

주로 다음 두 가지 방법을 사용합니다.

## Import Bus → Storage Bus

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Import Bus: 필터를 설정할 수 있습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Storage Bus: 필터를 설정할 수 있습니다. 목적지로 사용할 다른 Storage Bus를 포함하여
        네트워크의 유일한 저장소여야 합니다.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        출발지
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        목적지
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

출발지 인벤토리에 설치한 <ItemLink id="import_bus" /> (1)이 아이템이나 유체를 가져와 [네트워크 저장소](../ae2-mechanics/import-export-storage.md)에 저장하려고 합니다.
이 네트워크의 유일한 저장소가 <ItemLink id="storage_bus" /> (2)이므로 아이템이나 유체가 목적지 인벤토리로 이동합니다. 메인 네트워크가 아니라 별도의 Subnet을 사용하는 이유가 바로 이것입니다. 전력은 <ItemLink id="quartz_fiber" />를 통해 공급합니다.
Import Bus와 Storage Bus 모두 필터를 설정할 수 있습니다. 필터가 없으면 접근 가능한 모든 아이템과 유체를 옮깁니다. Import Bus와 Storage Bus를 여러 개 연결해도 작동합니다.

## Storage Bus → Export Bus

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Storage Bus: 필터를 설정할 수 있습니다. 출발지로 사용할 다른 Storage Bus를 포함하여
        네트워크의 유일한 저장소여야 합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Export Bus: 필터 설정이 필수입니다.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        출발지
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        목적지
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

목적지 인벤토리에 설치한 <ItemLink id="export_bus" />가 필터에 지정된 아이템을 [네트워크 저장소](../ae2-mechanics/import-export-storage.md)에서 가져오려고 합니다.
네트워크의 유일한 저장소가 <ItemLink id="storage_bus" />이므로 출발지 인벤토리에서 아이템이나 유체를 꺼내 목적지로 이동시킵니다. 따라서 메인 네트워크가 아닌 별도의 Subnet으로 구성해야 합니다. 전력은 <ItemLink id="quartz_fiber" />를 통해 공급합니다.
Export Bus는 필터가 있어야 작동하므로 반드시 필터를 설정하세요. Storage Bus와 Export Bus를 여러 개 사용해도 됩니다.

## 작동하지 않는 구성 (Import Bus → Export Bus)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

<BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
        Import Bus: 네트워크에 저장소가 없어 가져온 아이템을 넣을 곳이 없습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
        (2) Export Bus: 네트워크에 저장소가 없어 내보낼 아이템이 없습니다.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#ff0000">
        출발지
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#ff0000">
        목적지
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Import Bus와 Export Bus만 연결한 구성은 작동하지 않습니다. Import Bus는 출발지에서 가져온 아이템이나 유체를 네트워크 저장소에 넣으려 하고, Export Bus는 네트워크 저장소에서 꺼내 목적지로 보내려 합니다. 하지만 이 네트워크에는 **저장소가 전혀 없으므로** Import Bus도 Export Bus도 작업할 수 없습니다.

## 한 면으로 입출력하기

한 면에서 재료를 넣고 결과물을 꺼낼 수 있는 기계가 있다고 가정하겠습니다. (예: <ItemLink id="charger" />)
앞서 설명한 두 Pipe Subnet 방식을 결합하면 같은 면으로 재료를 넣고 결과물을 회수할 수 있습니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
        (1) Import Bus: 필터를 설정할 수 있습니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (2) Storage Bus: 필터를 설정할 수 있습니다. 아이템을 주고받을 다른 Storage Bus를 포함하여
        네트워크의 유일한 저장소여야 합니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (3) 재료를 넣고 결과물을 꺼낼 기계: 이 예시에서는 Charger입니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
        (4) Export Bus: 필터 설정이 필수입니다.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 1.5" color="#00ff00">
        출발지
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 1.5" color="#00ff00">
        목적지
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Interface 활용

Import Bus와 Export Bus 외에도 [네트워크 저장소](../ae2-mechanics/import-export-storage.md)에 아이템을 넣거나 꺼내는 [장치](../ae2-mechanics/devices.md)가 있습니다.
그중 <ItemLink id="interface" />가 유용합니다. Interface에 재고 유지 대상으로 지정하지 않은 아이템을 넣으면 네트워크 저장소로 보내므로 Import Bus → Storage Bus 방식처럼 활용할 수 있습니다. 반대로 Interface에 특정 아이템의 재고 유지를 설정하면 네트워크 저장소에서 해당 아이템을 가져오므로 Storage Bus → Export Bus 방식처럼 사용할 수 있습니다.
Interface에 아이템별 재고 유지 여부를 설정하면 Storage Bus를 이용한 원격 입출력도 구현할 수 있습니다.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        Interface
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.7 0 2" max="4 1 3">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 2" max="1 1.3 3">
        Interface
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 일대다, 다대일 및 다대다 연결

물론 <ItemLink id="import_bus" />, <ItemLink id="export_bus" />, <ItemLink id="storage_bus" />를 각각 하나씩만 사용할 필요는 없습니다.

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## 여러 위치에 재료 공급하기

이 원리를 이용하면 <ItemLink id="pattern_provider" />의 한 면에서 나온 재료를 여러 기계 또는 한 기계의 여러 면으로 분배할 수 있습니다.

<ItemLink id="pattern_provider" />는 재료를 내부에 보관하지 않으므로 Import → Storage 또는 Storage → Export Pipe를 그대로 사용할 수는 없습니다. 대신 Provider는 인접한 인벤토리로 재료를 *밀어 넣기* 때문에, 아이템을 받아 네트워크로 가져올 수 있는 인접 인벤토리가 필요합니다.

바로 <ItemLink id="interface" />가 적합합니다!
Provider를 방향 지정 모드나 평면 Subpart 모드로 설정하거나, Interface를 평면 Subpart 모드로 설정해 두 장치가 서로 직접 네트워크 연결을 형성하지 않도록 주의하세요.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (전체 블록이 아닌 평면형이어야 합니다)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Pattern Provider의 재료를 공급할 위치 (여러 기계 또는 한 기계의 여러 면)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>