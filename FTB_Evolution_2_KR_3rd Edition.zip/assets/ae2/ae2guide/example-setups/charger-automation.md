---
navigation:
  parent: example-setups/example-setups-index.md
  title: Charger Automation
  icon: charger
---

# Charger 자동화

이 구성은 <ItemLink id="pattern_provider" />를 사용하므로 [자동 제작](../ae2-mechanics/autocrafting.md) 설비에 연결하는 방식입니다. <ItemLink id="charger" />만 독립적으로 자동화하고 싶다면 호퍼와 상자 등을 사용하세요.

<ItemLink id="charger" />의 자동화는 비교적 간단합니다. <ItemLink id="pattern_provider" />가 재료를 Charger에 넣고, [pipe subnet](pipe-subnet.md) 또는 다른 아이템 운송 장치가 결과물을 다시 Provider에 보냅니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Pattern Provider: 관련 처리 패턴을 넣은 기본 설정 상태입니다. Charger에 전원도 공급합니다.

        ![Charger Pattern](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
        (2) Import Bus: 기본 설정 상태입니다.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (3) Storage Bus: 기본 설정 상태입니다.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        메인 네트워크로 연결
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 설정

* (1) <ItemLink id="pattern_provider" />는 관련 <ItemLink id="processing_pattern" />을 넣은 기본 설정 상태입니다. <ItemLink id="charger" />에 [에너지](../ae2-mechanics/energy.md)를 공급하는 [케이블](../items-blocks-machines/cables.md)의 역할도 합니다.

    ![Charger Pattern](../assets/diagrams/charger_pattern.png)

* (2) <ItemLink id="import_bus" />는 기본 설정입니다.
* (3) <ItemLink id="storage_bus" />도 기본 설정입니다.

## 작동 원리

1. <ItemLink id="pattern_provider" />가 재료를 <ItemLink id="charger" />에 넣습니다.
2. Charger가 재료를 충전합니다.
3. 녹색 서브네트워크의 <ItemLink id="import_bus" />가 Charger에서 결과물을 꺼내 [네트워크 저장 공간](../ae2-mechanics/import-export-storage.md)에 저장하려고 합니다.
4. 녹색 서브네트워크의 유일한 저장 공간은 <ItemLink id="storage_bus" />이므로 결과물이 Pattern Provider로 돌아가고, 다시 메인 네트워크로 반환됩니다.
