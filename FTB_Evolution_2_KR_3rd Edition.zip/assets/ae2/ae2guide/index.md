---
navigation:
  title: 목차
  position: 0
---

![Logo](assets/logo.png)

# Applied Energistics 2 소개

# 이 가이드 사용법

* 왼쪽 사이드바에서 목차를 열어 원하는 설명을 찾아보세요.
* 일부 페이지에는 직접 조작할 수 있는 3차원 장면이 있습니다. 장면 옆에 ![Plus](assets/diagrams/plus.png)
와 ![Minus](assets/diagrams/minus.png) 확대·축소 버튼이 표시된다면 카메라를 회전하거나 이동할 수 있습니다.
마우스 왼쪽 버튼으로 드래그하면 회전하고, 오른쪽 버튼으로 드래그하면 시점이 이동합니다.

# Applied Energistics 2란?

Applied Energistics 2(AE2)는 아이템 운송과 저장을 위한 장치 및 시스템을 추가하는 모드입니다.
상자로 가득한 창고를 작은 ME Network로 대체할 수 있으며, 이는 활용법의 시작에 불과합니다.

AE2는 모드팩의 다른 모드와 연동해 작업을 자동화하도록 설계되었습니다.
복잡한 조합 과정을 클릭 한 번으로 처리하거나, 특정 아이템을 정해진 수량만큼 항상 비축하도록
자동 제작할 수도 있습니다. 기지 곳곳의 아이템을 자동으로 옮기는 데도 사용할 수 있습니다.

* [시작하기](getting-started.md)
* [유용한 팁](tips-and-tricks.md)
* [AE2 작동 원리](ae2-mechanics/ae2-mechanics-index.md)
* [구성 예시](example-setups/example-setups-index.md)
* [아이템, 블록 및 기계](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
