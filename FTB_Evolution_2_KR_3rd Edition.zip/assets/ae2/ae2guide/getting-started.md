---
navigation:
  title: 시작하기 (1.20+)
  position: 10
---

<div class="notification is-info">
  다음 내용은 Minecraft 1.20 이상 버전의 Applied Energistics 2에만 적용됩니다.
</div>

# 시작하기

## 첫 재료 확보하기

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assets/assemblies/meteor_interior.snbt" />
</GameScene>

Applied Energistics 2를 시작하려면 먼저 [운석](ae2-mechanics/meteorites.md)을 찾아야 합니다. 운석은 비교적 흔하며 지형에 커다란 구덩이를 남기므로 탐험 중에 이미 발견하셨을 수도 있습니다.
아직 찾지 못했다면 <ItemLink id="meteorite_compass" />를 제작하세요. 가장 가까운 <ItemLink id="mysterious_cube" />의 방향을 가리킵니다.

운석을 찾았다면 중심부까지 채굴하세요. 내부에서 Certus Quartz Cluster, Certus Quartz Bud, 여러 종류의 [Budding Certus 블록](items-blocks-machines/budding_certus.md), 그리고 중앙의 Mysterious Cube를 발견할 수 있습니다.

Certus Quartz Cluster와 발견한 Certus Quartz 블록을 채굴하세요. Budding Certus 블록도 회수할 수 있지만, Silk Touch가 없다면 품질이 한 단계 떨어집니다.

Flawless Budding Certus는 부수지 마세요. Silk Touch를 사용해도 Flawed Budding Certus로 변하며, 다시 Flawless 상태로 복구할 수 없습니다.

운석 중앙의 Mysterious Cube도 채굴하면 Inscriber Press 네 종류를 모두 얻을 수 있습니다.

## Certus Quartz 재배

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Certus Quartz Bud는 자수정처럼 [Budding Certus 블록](items-blocks-machines/budding_certus.md)에서 자랍니다. 완전히 자라기 전에 Bud를 부수면 Fortune 효과와 관계없이 <ItemLink id="certus_quartz_dust" /> 1개가 나옵니다. 완전히 성장한 Cluster를 부수면 <ItemLink id="certus_quartz_crystal" /> 4개가 나오며, Fortune으로 수량을 늘릴 수 있습니다.

Budding Certus 블록은 Flawless, Flawed, Chipped, Damaged의 네 단계로 구분됩니다.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_blocks.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Bud가 한 단계 자랄 때마다 해당 블록은 일정 확률로 품질이 한 단계 떨어지며, 결국 일반 Certus Quartz 블록이 됩니다. Budding 블록 또는 Certus Quartz 블록을 하나 이상의 <ItemLink id="charged_certus_quartz_crystal" />과 함께 물에 던지면 복구하거나 새로운 Budding 블록을 만들 수 있습니다.

<RecipeFor id="damaged_budding_quartz" />

Flawless Budding Certus는 품질이 떨어지지 않으므로 Certus를 무한히 생산합니다. 하지만 제작할 수 없으며, Silk Touch 곡괭이로도 옮길 수 없습니다. 단, [Spatial Storage](ae2-mechanics/spatial-io.md)를 이용하면 이동시킬 수 있습니다.

Certus Quartz Bud는 자연 상태에서 매우 느리게 자랍니다. 다행히 <ItemLink id="growth_accelerator" />를 Budding 블록 옆에 설치하면 성장 속도가 크게 빨라집니다. 처음에는 이 장치를 몇 개 만드는 것을 우선하세요.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_2.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="energy_acceptor" />나 <ItemLink id="vibration_chamber" />를 만들 Quartz가 부족하다면 <ItemLink id="crank" />를 제작하여 가속기 끝에 부착할 수 있습니다.

Certus를 자동으로 수확하는 방법은 [여기](example-setups/simple-certus-farm.md)에 설명되어 있습니다.

## Fluix에 관한 짧은 설명

또 다른 필수 재료는 Growth Accelerator 제작 과정에서 이미 사용한 Fluix입니다. Charged Certus, Redstone, Nether Quartz를 물에 던져 만들 수 있습니다. 이를 자동화하는 방법은 직접 연구해 보세요.

아직 만들지 않았다면 <ItemLink id="charged_certus_quartz_crystal" />를 생산하는 데 필요한 <ItemLink id="charger" />를 제작하세요.

## Processor 제작하기

운석의 Mysterious Cube를 부수면 Press 네 종류를 얻습니다. 이들은 <ItemLink id="inscriber" />에서 세 종류의 Processor를 만드는 데 사용됩니다.

<ItemGrid>
  <ItemIcon id="silicon_press" />

  <ItemIcon id="logic_processor_press" />

  <ItemIcon id="calculation_processor_press" />

  <ItemIcon id="engineering_processor_press" />
</ItemGrid>

Inscriber는 일반 Furnace처럼 투입 방향에 따라 슬롯이 구분됩니다. 위쪽이나 아래쪽에서 넣으면 위·아래 슬롯에, 옆이나 뒤에서 넣으면 가운데 슬롯에 들어갑니다. 결과물은 옆이나 뒤에서 꺼낼 수 있습니다.

Hopper를 이용한 자동화를 쉽게 하고 복잡한 파이프 배치를 줄이려면 <ItemLink id="certus_quartz_wrench" />로 Inscriber의 방향을 회전할 수 있습니다.

다음 단계인 기초 ME 시스템을 준비하기 위해 Processor를 종류별로 몇 개씩 만드세요. Processor 자동 생산 방법은 [여기](example-setups/processor-automation.md)에서 확인할 수 있습니다.

## Matter Energy 기술: ME 네트워크와 저장소

### ME 저장소란?

ME는 '엠이'라고 읽으며 Matter Energy의 약자입니다.

Matter Energy는 Applied Energistics 2의 핵심 기술입니다. 여러 블록으로 이루어진 상자를 발전시킨 듯한 시스템으로, 아이템 보관 방식을 완전히 바꿔 줍니다. ME는 Minecraft의 다른 저장 시스템과 크게 달라 처음에는 익숙해지는 데 시간이 걸릴 수 있습니다. 하지만 작은 공간에 방대한 물품을 저장하고 여러 Terminal에서 접근하는 것은 시작에 불과합니다.

### 시작하려면 무엇을 알아야 하나요?

ME는 아이템을 [Storage Cell](items-blocks-machines/storage_cells.md)이라는 다른 아이템 안에 저장합니다. 저장 용량이 증가하는 다섯 단계의 Cell이 있습니다.
Storage Cell을 사용하려면 <ItemLink id="me_chest" /> 또는 <ItemLink id="drive" />에 넣어야 합니다.

<ItemLink id="me_chest" />에 Cell을 넣으면 내용물이 바로 표시되며, 일반 <ItemLink id="minecraft:chest" />처럼 아이템을 넣거나 꺼낼 수 있습니다. 다만 아이템은 <ItemLink id="me_chest" /> 자체가 아닌 Storage Cell에 보관됩니다.

<ItemLink id="me_chest" />는 활용 범위가 제한적입니다. AE2를 제대로 활용하려면 [ME Network](ae2-mechanics/me-network-connections.md)를 구축해야 합니다.

## 첫 번째 ME 시스템

Applied Energistics 2의 기본 재료와 기계를 준비했다면 첫 ME(Matter Energy) 시스템을 만들 수 있습니다. 자동 제작이나 물류 기능 없이 검색 가능한 저장소만 갖춘 간단한 구성입니다.

<GameScene zoom="6" interactive={true}>
<ImportStructure src="assets/assemblies/tiny_me_system.snbt" />

</GameScene>

*   필요한 재료:
    * 1x <ItemLink id="drive" />
    * 1x <ItemLink id="terminal" /> 또는 <ItemLink id="crafting_terminal" />
    * 1x <ItemLink id="energy_acceptor" />
    * [Cable](items-blocks-machines/cables.md) 몇 개. Glass, Covered, Smart 중에서 선택하되 Dense는 제외합니다.
    * [Storage Cell](items-blocks-machines/storage_cells.md) 몇 개. 용량과 종류 제한의 균형을 고려하면 4k를 추천합니다. (4k와 1k를 섞어 [파티션 설정](items-blocks-machines/cell_workbench.md)을 하는 편이 효율적이지만, 여기서는 다루지 않겠습니다.)
---
1.  Drive를 설치합니다.
2.  Energy Acceptor를 비롯한 여러 AE2 [장치](ae2-mechanics/devices.md)는 큐브형과 평면형 두 가지 형태가 있으며 제작대에서 전환할 수 있습니다. 큐브형이면 Drive 옆에 놓고, 평면형이면 Drive에 Cable을 연결한 뒤 그 위에 부착합니다.
3.  원하는 발전 모드의 Cable, Pipe 또는 Conduit를 이용해 Energy Acceptor에 전력을 공급합니다.
4.  Drive 위쪽이나 눈높이에 Cable을 설치하고 Terminal 또는 Crafting Terminal을 부착합니다.
5.  Drive에 Storage Cell을 넣습니다.
6.  이제 저장소를 사용할 수 있습니다.
7.  Terminal 설정을 살펴보세요.
8.  완성된 시스템의 편리함을 누려 보세요.
9.  다만 전체 ME 시스템의 가능성과 비교하면 아직 아주 작은 규모라는 점도 기억하세요.

### 네트워크 확장하기

기본 저장소를 만들고 접근할 수 있게 되었다면, 다음으로 가공 과정의 자동화를 시도해 볼 수 있습니다.

예를 들어 Furnace 위에 <ItemLink id="export_bus" />를 설치해 Ore를 넣고, 아래에 <ItemLink id="import_bus" />를 설치해 제련된 결과물을 회수할 수 있습니다.

<ItemLink id="export_bus" />는 네트워크의 아이템을 연결된 인벤토리로 내보내고, <ItemLink id="import_bus" />는 연결된 인벤토리의 아이템을 네트워크로 가져옵니다.

### 제한 극복하기

이쯤이면 [장치](ae2-mechanics/devices.md)가 8개 정도 되었을 것입니다. 9개째부터는 [Channel](ae2-mechanics/channels.md)을 관리해야 합니다. 많은 장치가 작동에 Channel을 요구하지만 모든 장치가 그런 것은 아닙니다.

기본 네트워크는 8개의 Channel을 지원합니다. 이 한계를 넘으려면 네트워크에 <ItemLink id="controller" />를 추가해야 하며, 이를 통해 네트워크를 크게 확장할 수 있습니다.
[Smart Cable](items-blocks-machines/cables.md)을 사용하면 네트워크에서 Channel이 어떻게 전달되는지 확인할 수 있습니다. 처음 배우는 동안이나 Redstone과 Glowstone이 충분할 때 적극 활용해 보세요.
