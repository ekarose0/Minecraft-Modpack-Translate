---
navigation:
  parent: example-setups/index.md
  icon: milky_soul_ball
  title: Milky Soul Ball Farm
categories:
  - example
---

# Milky Soul Ball Farm

<GameScene zoom="4" interactive={true} paddingLeft="30" paddingRight="30">
  <ImportStructure src="../assets/assemblies/milky_soul_farm.snbt" />
  <Entity id="minecraft:cow" x="2.5" z="1.5" rotationY="170"/>
  <IsometricCamera yaw="200" pitch="20" />
  <BlockAnnotation x="5" y="1" z="1">
    <ItemGrid>
        <ItemIcon id="minecraft:bucket" />
        <ItemIcon id="minecraft:soul_sand" />
    </ItemGrid>
  </BlockAnnotation>
  <BlockAnnotation x="3" y="1" z="1">
    User가 빈 양동이로 소에게서 우유를 얻습니다.

    ![빈 양동이가 필터로 설정된 User GUI](../assets/images/user_empty_bucket.png)
  </BlockAnnotation>
  <BlockAnnotation x="3" y="4" z="1">
    User가 우유 양동이를 Soul Sand에 사용하고, 생성된 Milky Soul Ball과 빈 양동이를 네트워크 저장소로 돌려보냅니다.

    ![우유 양동이가 필터로 설정된 User GUI](../assets/images/user_milk_bucket.png)
  </BlockAnnotation>
  <BlockAnnotation x="1" y="4" z="1">
    Placer가 User 앞에 Soul Sand를 설치합니다.

    ![Soul Sand가 필터로 설정된 Placer GUI](../assets/images/placer_soul_sand.png)
  </BlockAnnotation>
</GameScene>

이 농장에서는 <ItemLink id="user" />가 빈 양동이로 소의 우유를 얻어 [네트워크 저장소](../nodeworks-mechanics/network-storage.md)에 넣습니다. 다른 User는 <ItemLink id="placer" />가 설치한 <ItemLink id="minecraft:soul_sand" />에 <ItemLink id="minecraft:milk_bucket" />을 사용합니다.

> **참고:** Placer와 User의 레드스톤 모드는 모두 **Low**로 설정하여 계속 작동하도록 합니다.
