---
navigation:
  parent: example-setups/index.md
  icon: celestine_shard
  title: Celestine Farm
categories:
  - example
---

# Celestine Farm

<ItemLink id="budding_celestine" />은 <ItemLink id="breaker" />로 쉽게 자동 수확할 수 있으며, 필요하면 <ItemLink id="terminal" />을 함께 사용할 수 있습니다.

Breaker의 파괴 대상 필터를 `#c:clusters`로 설정하세요.

![파괴 대상 필터가 클러스터로 설정된 Breaker GUI](../assets/images/breaker_clusters.png)

<GameScene zoom="4" interactive={true} paddingLeft="30" paddingRight="30">
  <ImportStructure src="../assets/assemblies/celestine_farm.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
</GameScene>

원한다면 Focus Node를 사용해 모든 장치를 연결할 수도 있습니다.

<GameScene zoom="4" interactive={true} paddingLeft="30" paddingRight="30">
  <ImportStructure src="../assets/assemblies/celestine_farm_focus_node.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
</GameScene>

각 Breaker의 GUI에서 레드스톤 모드를 **Low**로 설정하면 신호가 없어도 작동합니다.
각 Breaker의 파괴 대상을 <ItemLink id="celestine_cluster" />로 지정하세요.

완전히 성장한 Celestine Cluster를 파괴하고, 획득한 아이템을 [네트워크 저장소](../nodeworks-mechanics/network-storage.md)에 넣습니다.