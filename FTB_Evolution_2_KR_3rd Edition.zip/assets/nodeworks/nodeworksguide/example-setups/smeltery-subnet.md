---
navigation:
  parent: example-setups/index.md
  icon: minecraft:furnace
  title: Smeltery Subnet
categories:
  - example
---

# Smeltery Subnet

전용 서브넷을 사용하면 네트워크의 작업을 분담하고 제작법을 재사용하기 좋습니다.

<GameScene zoom="3" interactive={true} paddingLeft="30" paddingRight="30" paddingTop="20">
  <ImportStructure src="../assets/assemblies/roundrobin_smeltery_subnet.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <BoxAnnotation min="0 0.75 0" max="3 1 1" color="#B02E26">
    <ItemImage id="storage_card"/> 화로에서 완성된 아이템을 가져오는 빨간색 Storage Card
  </BoxAnnotation>
  <BoxAnnotation min="1 3 1" max="2 3.25 2" color="#3C44AA">
    <ItemImage id="storage_card"/> 모든 Processing Handler 입력 아이템을 받는 파란색 Storage Card
  </BoxAnnotation>
  <BoxAnnotation min="0 2 0" max="3 2.25 1" color="#80C71F">
    <ItemImage id="storage_card"/> Import Chest가 아이템을 순차 분배하는 연두색 Storage Card
  </BoxAnnotation>
  <BlockAnnotation x="1" y="2" z="1">
    RoundRobin 활성화

    채널: <Color id="green">Lime</Color>
  </BlockAnnotation>
</GameScene>

위 그림은 <ItemLink id="processing_storage" />를 <ItemLink id="broadcast_antenna" />로 송신하는 **제련용** 서브넷 예시입니다. 다른 네트워크에서는 <ItemLink id="link_crystal" />로 연결해 이 서브넷의 제작법을 사용할 수 있습니다.

여기에는 네트워크의 Processing Set 세 개에 연결된 <ItemLink id="processing_handler" /> 장치가 세 개 있습니다. 각 장치는 입력 아이템을 <ItemLink id="import_chest" />에 넣습니다.
Import Chest는 아이템을 별도 채널로 순차 분배하도록 설정되어 있으며, 그 채널에는 화로 위쪽을 향하는 Storage Card가 연결되어 있습니다.
화로 아래쪽에는 완성된 아이템을 가져오는 빨간색 Storage Card가 있습니다.

자세한 내용은 [자동 제작](../nodeworks-mechanics/autocrafting.md) 페이지를 참고하세요.
