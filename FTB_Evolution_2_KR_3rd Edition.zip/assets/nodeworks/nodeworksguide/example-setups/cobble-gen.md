---
navigation:
  parent: example-setups/index.md
  icon: minecraft:cobblestone
  title: Cobblestone Generator
categories:
  - example
---

# Cobblestone Generator

Cobblestone 생성기는 <ItemLink id="breaker" />를 사용하는 가장 간단한 예시입니다.
아래와 같이 생성기 앞에 Breaker를 설치하세요.

<GameScene zoom="5" interactive={true} paddingLeft="60" paddingRight="30">
  <ImportStructure src="../assets/assemblies/cobble_gen.snbt" />
  <IsometricCamera yaw="200" pitch="30" />
  <RemoveBlocks id="minecraft:sandstone" />
  <RemoveBlocks id="minecraft:sandstone" />
  <RemoveBlocks id="minecraft:stone" />
</GameScene>

Breaker가 `minecraft:cobblestone`을 파괴하도록 설정하고, 레드스톤 모드를 **Low**로 바꾸면 항상 작동합니다.

![파괴 대상이 Cobblestone으로 설정된 Breaker GUI](../assets/images/breaker_cobblestone.png)

네트워크에 <ItemLink id="terminal" />이 있다면 다음 스크립트로 여러 Breaker를 같은 방식으로 작동시킬 수 있습니다.

<LuaCode>
```lua
local breaker_1 = network:get("breaker_1")
scheduler:second(function()
    breaker_1:mine() -- 항상 채굴
end)
```
</LuaCode>