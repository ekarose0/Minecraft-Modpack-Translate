---
navigation:
  title: 네트워크 구성 예시
  position: 50
---

# 예시

<CategoryIndexDescriptions category="example" />