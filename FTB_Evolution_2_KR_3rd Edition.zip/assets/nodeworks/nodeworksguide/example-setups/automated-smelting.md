---
navigation:
  parent: example-setups/index.md
  icon: minecraft:furnace
  title: Automated Smelting Subnet
categories:
  - example
---

# Automated Smelting Subnet

<ItemLink id="export_chest" />와 <ItemLink id="import_chest" />를 사용하면 두 네트워크를 연결할 수 있습니다. 이 예시에서는 한 네트워크가 `#c:raw_material` 아이템을 화로 여러 대가 설치된 작은 네트워크로 보내고, 작은 네트워크는 제련 결과물을 다시 원래 네트워크로 돌려보냅니다.

<GameScene zoom="4" interactive={true} paddingLeft="30" paddingRight="30">
  <ImportStructure src="../assets/assemblies/automated_smelting.snbt" />
  <IsometricCamera yaw="190" pitch="10" />
  <BlockAnnotation x="7" y="4">
  ![](../assets/images/automated_smelting_export_raw.png)
  </BlockAnnotation>
  <BlockAnnotation x="7" y="3">
  ![](../assets/images/automated_smelting_import_raw.png)
  </BlockAnnotation>
  <BlockAnnotation x="5" y="3">
  ![](../assets/images/automated_smelting_export_cooked.png)
  </BlockAnnotation>
  <BlockAnnotation x="5" y="4">
  ![](../assets/images/automated_smelting_import_cooked.png)
  </BlockAnnotation>
  <DiamondAnnotation pos="7.5 4 0.5" color="#ff0000">
    저장소 네트워크의 Export Chest는 GUI에서 아이템을 아래쪽(Down)으로 보내도록 설정되어 있습니다.

    **이 두 상자는 서로 연결되지 않으며, 각각 별도의 네트워크에 속합니다.**
  </DiamondAnnotation>
  <DiamondAnnotation pos="5.5 4 0.5" color="#ff0000">
    화로 네트워크의 Export Chest는 GUI에서 아이템을 위쪽(Up)으로 보내도록 설정되어 있습니다.

    **이 두 상자는 서로 연결되지 않으며, 각각 별도의 네트워크에 속합니다.**
  </DiamondAnnotation>
  <BoxAnnotation min="5 0.75 0" max="8 1 1" color="#B02E26">
    <ItemImage id="storage_card" /> Red Channel로 설정된 Storage Card의 아이템을 Export Chest가 `*` 필터로 모두 가져옵니다.
  </BoxAnnotation>
  <BoxAnnotation min="5 2 0" max="8 2.25 1" color="#3C44AA">
    <ItemImage id="storage_card" /> Import Chest는 라운드 로빈 방식으로 Blue Channel에 설정된 Storage Card에 아이템을 보냅니다.
  </BoxAnnotation>
</GameScene>

<ItemLink id="terminal" />을 사용하면 같은 작업을 더욱 유연하게 구성할 수도 있습니다.

<GameScene zoom="4" interactive={true} paddingLeft="30" paddingRight="30">
  <ImportStructure src="../assets/assemblies/automated_smelting_scripting.snbt" />
  <IsometricCamera yaw="190" pitch="10" />
  <BoxAnnotation min="5 1 0" max="8 1.25 1" color="#22C55E">
    <ItemImage id="io_card" /> IO Cards
  </BoxAnnotation>
</GameScene>

다음 스크립트를 사용합니다:

<LuaCode>
```lua
local furnaces = network:cards("furnace_*")
-- 원재료와 광석을 화로에 넣습니다
importer
    :from(network)
    :to(furnaces:face("top"))
    :filter("#c:raw_materials")
    :filter("#c:ores")
    :roundrobin()
    :start()
-- 제련이 끝난 주괴를 화로에서 꺼냅니다
importer
    :from(furnaces:face("bottom"))
    :to(network)
    :start()
```
</LuaCode>
