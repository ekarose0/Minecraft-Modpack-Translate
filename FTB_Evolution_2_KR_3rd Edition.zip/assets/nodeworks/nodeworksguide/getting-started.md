---
navigation:
  title: 시작하기
  position: 10
---

# 시작하기

## 필요한 재료

Nodeworks 네트워크는 <ItemLink id="celestine_shard" />의 반사 특성을 이용해 작동합니다.

## Celestine 성장시키기

Celestine은 <ItemLink id="minecraft:amethyst_cluster" />와 마찬가지로
<ItemLink id="budding_celestine" />에서 자랍니다.

## 첫 Nodeworks 네트워크

스크립트 없이 구성하는 간단한 네트워크입니다. Inventory Terminal을 사용하면
연결된 여러 상자에 보관된 아이템을 한곳에서 확인할 수 있습니다.

<GameScene interactive={true} zoom="5">
  <IsometricCamera yaw="200" pitch="10" />
  <ImportStructure src="assets/assemblies/first_network.snbt" />
  <BoxAnnotation min="2.25 0.1 0.1" max="2 0.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" /> Storage Card
  </BoxAnnotation>
</GameScene>

- 이 네트워크는 다음과 같이 구성됩니다.
  - 1x <ItemLink id="inventory_terminal" />
  - 모든 장치를 연결하는 <ItemLink id="pipe" /> 여러 개
  - 상자 등 외부 블록을 네트워크에 연결하는 <ItemLink id="node" /> 여러 개
  - 상자를 향한 Node 면에 장착하는 <ItemLink id="storage_card" /> 1개

### Nodeworks 네트워크 확장하기

- [아이템 이동](./nodeworks-mechanics/moving-items.md)
- [자동 제작](./nodeworks-mechanics/autocrafting.md)
- [구성 예시](./example-setups/index.md)
