---
navigation:
  parent: lua-api/index.md
  title: PlacerHandle
  icon: placer
categories:
  - api_types
description: 정면에 블록을 설치하는 장치
---

# PlacerHandle

`PlacerHandle`은 [`network:get(name)`](network.md#get)으로 얻는 네트워크의 <ItemLink id="placer" /> 참조입니다. [Network Storage](../nodeworks-mechanics/network-storage.md)에서 지정한 아이템 하나를 꺼내 Placer가 바라보는 위치에 블록으로 설치합니다.

<BlockImage scale="6" id="placer" />

`:place(...)`는 동기식 메서드로, 호출한 틱에 바로 `true` 또는 `false`를 반환합니다. 여러 틱에 걸친 진행 과정이나 Builder, 콜백은 없습니다. 설치 가능한 블록 형태를 가진 `BlockItem`만 성공하며, 도구나 음식처럼 설치할 수 없는 아이템은 즉시 실패합니다.

## 속성

- **`.name`**
  - Placer의 별칭(Terminal 사이드바에 표시되는 이름과 동일)

## place

Network Storage에서 지정한 아이템 하나를 꺼내 Placer의 정면에 설치합니다. 성공하면 `true`를 반환합니다.

인수로 아이템 ID 문자열 또는 [ItemsHandle](./items-handle.md)을 전달할 수 있습니다. Handle을 전달하면 `.id`를 읽어 문자열을 직접 지정했을 때와 마찬가지로 네트워크 저장소에서 해당 아이템 하나를 꺼냅니다. Handle 자체의 원본 저장소가 아니라 네트워크의 Storage Card에서 아이템을 가져옵니다.

<LuaCode>
```lua
local placer = network:get("placer_1")
placer:place("minecraft:cobblestone")
```
</LuaCode>

다음 경우에는 블록을 설치하지 않고 `false`를 반환합니다:
- 네트워크에 해당 아이템이 없을 때
- 설치 대상 위치가 공기가 아닐 때
- 아이템이 설치 가능한 블록이 아닐 때(예: `minecraft:diamond`, `minecraft:stick`)

<LuaCode>
```lua
local placer = network:get("bridge_builder")
local ok = placer:place("minecraft:oak_planks")
if not ok then
  print("nothing placed, no planks in storage or target blocked")
end
```
</LuaCode>

## block

Placer가 바라보는 위치의 블록 ID를 반환합니다. 반환 형태는 [`ObserverCard:block`](./card-handle.md#observer-card)과 같습니다. `:place` 호출 전에 위치가 비어 있는지 또는 예상한 블록이 있는지 확인할 때 유용합니다.

<LuaCode>
```lua
local placer = network:get("placer_1")
if placer:block() == "minecraft:air" then
  placer:place("minecraft:torch")
end
```
</LuaCode>

## isBlocked

대상 위치를 다른 블록으로 교체할 수 없으면 `true`, 설치할 수 있는 위치라면 `false`를 반환합니다. 공기가 아닌 블록이라도 Grass나 Snow처럼 교체 가능한 블록은 막힌 것으로 취급하지 않습니다. 설치 가능 여부만 알고 싶다면 `:place`를 호출하고 결과를 확인하는 것보다 효율적입니다.

<LuaCode>
```lua
local placer = network:get("placer_1")
if not placer:isBlocked() then
  placer:place("minecraft:cobblestone")
end
```
</LuaCode>
