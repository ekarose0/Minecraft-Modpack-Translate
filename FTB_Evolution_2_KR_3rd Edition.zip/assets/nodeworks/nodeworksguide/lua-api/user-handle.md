---
navigation:
  parent: lua-api/index.md
  title: UserHandle
  icon: user
categories:
  - api_types
description: 앞쪽 블록에 아이템을 사용하여 우클릭하는 장치
---

# UserHandle

`UserHandle`은 [`network:get(name)`](network.md#get)으로 얻는 네트워크의 <ItemLink id="user" /> 참조입니다. [Network Storage](../nodeworks-mechanics/network-storage.md)에서 아이템 하나를 꺼내 User 앞의 대상에 우클릭으로 사용합니다.

<BlockImage scale="6" id="user" />

User에는 두 가지 모드가 있습니다. **Instant**는 `:use()`를 호출할 때마다 한 번 우클릭합니다. **Hold**는 `:stop()`을 호출하거나 아이템의 사용이 끝나거나 30초 제한 시간이 지나기 전까지 여러 틱에 걸쳐 우클릭을 유지합니다. 필터는 <ItemLink id="storage_card" />와 같은 문법을 사용합니다.

## 속성

- **`.name`**
  - User의 별칭(Terminal 사이드바에 표시되는 이름과 동일)
- **`.kind`**
  - 항상 `"user"`

## use

User를 작동시킵니다. **Instant** 모드에서는 한 번 우클릭하고 실제 동작 성공 여부를 반환합니다. **Hold** 모드에서는 누르고 있는 동작을 시작하고 Hold 상태에 진입했는지를 반환합니다.

User가 이미 사용 중이거나, 쿨다운 중이거나, 필터 조건을 만족하지 못하거나, 저장소에 해당 아이템이 없거나, 네트워크에 Controller가 없으면 작동하지 않고 `false`를 반환합니다.

<LuaCode>
```lua
local farmer = network:get("crop_farmer")
farmer:use()
```
</LuaCode>

Hold를 다시 시작하려면 먼저 `:stop()`을 호출하세요.

## stop

대기 중인 Instant 동작을 취소하거나 진행 중인 Hold를 해제합니다. 아무 동작도 하지 않는 상태에서 호출해도 오류 없이 `false`를 반환합니다. 예약한 아이템을 Network Storage로 돌려보내는 복귀 애니메이션은 취소할 수 없습니다.

<LuaCode>
```lua
local user = network:get("user_1")
local watcher = network:get("observ_1")
user:setMode("hold")
user:use() -- 수상한 블록에 Brush 사용 시작
-- 블록이 일반 Sand 또는 Gravel로 바뀌면 User를 중지합니다
watcher:onChange(function(block: BlockId, state: any)
    if block == "minecraft:gravel" or block == "minecraft:sand" then
        user:stop()
    end
end)
```
</LuaCode>

## isUsing

Hold가 진행 중이면 `true`, 그렇지 않으면 `false`를 반환합니다.

<LuaCode>
```lua
local user = network:get("user_1")
if not user:isUsing() then
  user:use()
end
```
</LuaCode>

## mode

현재 모드를 `"instant"` 또는 `"hold"` 문자열로 반환합니다.

<LuaCode>
```lua
local user = network:get("user_1")
print(user:mode()) -- "instant"
```
</LuaCode>

## setMode

User의 모드를 지정합니다. `"instant"` 또는 `"hold"`를 입력할 수 있으며 대소문자를 구분하지 않습니다.

<LuaCode>
```lua
local user = network:get("crop_farmer")
user:setMode("hold")
```
</LuaCode>

## filter

현재 필터 규칙을 문자열로 반환합니다. 설정된 필터가 없으면 빈 문자열을 반환합니다.

<LuaCode>
```lua
local user = network:get("user_1")
print(user:filter()) -- "minecraft:bone_meal"
```
</LuaCode>

## setFilter

User의 필터 규칙을 지정합니다. <ItemLink id="storage_card" />와 같은 문법을 사용하므로 아이템 ID, `#namespace:tag`, `minecraft:*`, `/regex/` 및 `$item:` / `$fluid:` 접두사를 사용할 수 있습니다.

<LuaCode>
```lua
local user = network:get("crop_farmer")
user:setFilter("minecraft:bone_meal")
```
</LuaCode>

## facing

User가 바라보는 방향을 소문자 문자열(`"north"`, `"south"`, `"east"`, `"west"`, `"up"`, `"down"`)로 반환합니다.

<LuaCode>
```lua
local user = network:get("user_1")
print(user:facing()) -- "north"
```
</LuaCode>
