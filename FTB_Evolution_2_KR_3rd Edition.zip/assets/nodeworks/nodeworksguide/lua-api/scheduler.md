---
navigation:
  parent: lua-api/index.md
  title: Scheduler
  icon: minecraft:repeater
categories:
  - api_builtin
description: tick/second/delay 콜백을 등록하는 모듈
---

# Scheduler

`scheduler` 모듈은 서버 틱(20 TPS)에 맞춰 주기적으로 또는 일정 시간 후 실행할 콜백을 등록합니다. 등록할 때마다 작업 ID가 반환되며, 이 ID를 `:cancel`에 전달하면 실행을 중지할 수 있습니다.

> **팁:** [`scheduler:tick`](scheduler.md#tick) 또는 [`scheduler:second`](scheduler.md#second)를 항상 실행하려면 <ItemLink id="terminal" />의 ["Autorun"](../items-blocks/scripting_terminal.md#autorun)을 켜는 것이 좋습니다.

![](../assets/images/autorun.png)

## tick

매 서버 틱마다 지정한 콜백을 실행합니다.

<LuaCode>
```lua
scheduler:tick(function()
  -- 초당 20회 실행
end)
```
</LuaCode>

## second

매초(20틱마다) 지정한 콜백을 실행합니다.

<LuaCode>
```lua
scheduler:second(function()
  -- 초당 1회 실행
end)
```
</LuaCode>

## delay

지정한 틱 수가 지난 뒤 콜백을 실행합니다.

<LuaCode>
```lua
scheduler:delay(20, function()
  -- 1초 후 실행
end)
```
</LuaCode>

## cancel

지정한 작업 ID의 실행을 중지합니다. 이미 취소되었거나 종료된 작업의 ID를 전달해도 안전합니다.

<LuaCode>
```lua
local task = scheduler:tick(function()
  print("hello")
end)
-- 1초 후 scheduler:tick 작업 취소
scheduler:delay(20, function()
  scheduler:cancel(task)
end)
-- "hello" (x20)
```
</LuaCode>
