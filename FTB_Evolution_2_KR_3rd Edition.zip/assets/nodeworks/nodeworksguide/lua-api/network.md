---
navigation:
  parent: lua-api/index.md
  title: Network
  icon: node
categories:
  - api_builtin
description: 저장소 조회, 아이템 전송, 제작 작업 시작, Handler 등록
---

# Network

`network` 모듈은 <ItemLink id="terminal" />이 연결된 Nodeworks 네트워크에 접근하는 진입점입니다. 저장소를 조회하고, Handle 사이에 아이템을 전송하며, 콜백을 등록합니다.

## get

이름으로 네트워크의 <ItemLink id="storage_card" />, <ItemLink id="io_card" />, <ItemLink id="redstone_card" />, <ItemLink id="observer_card" />, <ItemLink id="variable" /> 등을 찾아 참조를 반환합니다. 보통 스크립트 시작 부분에서 사용합니다. Card와 Variable의 이름이 같으면 Card가 우선합니다.

Scripting Terminal 사이드바에서 항목을 클릭하면 참조 코드를 자동으로 추가할 수도 있습니다.

![아이템을 클릭하기 전](../assets/images/click-to-add-card-01.png) ![아이템을 클릭한 후](../assets/images/click-to-add-card-02.png)

<GameScene zoom="5" interactive={true} paddingLeft="50" paddingRight="60">
  <ImportStructure src="../assets/assemblies/chest_furnace_terminal.snbt" />
  <BoxAnnotation min="1 1.1 0.1" max="1.25 1.9 0.9" color="#AA83E0">
    이름을 **"chest"**로 변경<ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BoxAnnotation min="1 0.1 0.1" max="1.25 0.9 0.9" color="#83E086">
    이름을 **"furnace"**로 변경<ItemImage id="nodeworks:io_card" />
  </BoxAnnotation>
</GameScene>

<LuaCode>
```lua
local chest = network:get("chest")        -- Storage Card를 가져옵니다
local furnace = network:get("furnace")    -- IO Card를 가져옵니다
local count = network:get("count")        -- "count"라는 Variable을 가져옵니다
```
</LuaCode>

---

## getAll

지정한 유형에 일치하는 모든 Card 또는 Variable의 [HandleList](handle-list.md)를 반환합니다. HandleList는 `:set`, `:onChange` 등의 쓰기 메서드를 모든 구성원에게 전달하므로 여러 Piston을 동시에 켜거나 여러 Observer에 Handler를 등록할 수 있습니다. 구성원을 하나씩 처리하려면 `:list()`를 호출하세요.

<GameScene zoom="5" interactive={true} paddingLeft="50" paddingRight="60">
  <ImportStructure src="../assets/assemblies/chest_connected_storage_card.snbt" />
  <BoxAnnotation min="2.25 1.1 0.1" max="2 1.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BoxAnnotation min="2.25 0.1 0.1" max="2 0.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
</GameScene>

<LuaCode>
```lua
-- 모든 Redstone Card를 한꺼번에 켭니다
network:getAll("redstone"):set(true)
-- 읽기 메서드의 결과가 필요하면 각 구성원을 순회합니다
local storages = network:getAll("storage")
for _, storage in storages:list() do
    print(storage.name)
end
-- "storage_0"
-- "storage_1"
```
</LuaCode>

---

## cards

이름 패턴과 일치하는 Card들의 [HandleList](handle-list.md)를 반환합니다. 같은 명명 규칙을 사용하는 여러 Card를 한꺼번에 조작할 때 유용합니다.

<LuaCode>
```lua
local allPistonCards = network:cards("piston_*")
allPistonCards:set(true) -- 모든 Piston을 켭니다
```
</LuaCode>

---

## channel

조회 범위를 하나의 염료 색상 채널로 제한합니다. [`Channel`](./channel.md) Handle을 반환하며, 해당 Handle의 `:get`, `:getAll`, `:getFirst`는 지정한 색상에 속하는 Card·Variable·장치만 찾습니다. 알 수 없는 색상 이름을 지정하면 오류가 발생합니다.

<LuaCode>
```lua
local red = network:channel("red")
red:getAll("redstone"):set(true) -- Red 채널의 Piston만 제어합니다
local count = red:get("counter") -- Red 채널의 Variable
```
</LuaCode>

---

## channels

네트워크에서 사용 중인 모든 염료 색상 채널 목록을 반환합니다. Card, Variable, Breaker, Placer 중 하나라도 할당된 색상이 포함됩니다. `DyeColor` ID 오름차순으로 정렬되어 반복 순서가 일정합니다. 채널 목록을 코드에 고정하지 않고 실행 중에 확인할 때 유용합니다.

> **참고:** `white`는 새 구성원의 기본 채널이므로 비어 있지 않은 네트워크에서는 거의 항상 나타납니다.

<LuaCode>
```lua
for _, color in network:channels() do
  print(color, "is in use")
end
-- "white" is in use
-- "red" is in use
-- "blue" is in use
```
</LuaCode>

일반적인 활용 예시: 플레이어가 선택한 색상과 관계없이 모든 활성 채널에 같은 Handler를 적용합니다.

<LuaCode>
```lua
for _, color in network:channels() do
  network:channel(color):getAll("redstone"):set(false)
end
```
</LuaCode>

---

## find

[Network Storage](../nodeworks-mechanics/network-storage.md) 전체에서 필터에 일치하는 아이템·유체를 검색합니다. 저장소의 수량을 합산한 Handle을 반환하며, 일치하는 항목이 없으면 `nil`을 반환합니다.

<LuaCode>
```lua
local all = network:find("*") -- 아이템과 유체를 모두 검색합니다
local allItems = network:find("$item:*") -- 아이템만 검색
local allFluids = network:find("$fluid:*") -- 유체만 검색
local allCoal = network:find("minecraft:coal") -- 아이템 ID
local allLogs = network:find("#minecraft:logs") -- 태그
local allRaw = network:find("/^Raw.*/") -- 정규식
```
</LuaCode>

`:find` 결과를 사용하기 전에는 항목이 실제로 존재하는지 확인해야 합니다.

<LuaCode>
```lua
local allCoal = network:find("minecraft:coal")
if allCoal then
  print("we have coal")
end
```
</LuaCode>

---

## findEach

[find](./network.md#find)와 같이 [Network Storage](../nodeworks-mechanics/network-storage.md) 전체를 검색하지만, 하나의 합산 Handle 대신 [ItemsHandle](./items-handle.md) 목록을 반환합니다. 아이템 ID와 NBT 데이터가 다른 항목은 별도로 취급합니다.

<LuaCode>
```lua
for _, items in network:findEach("$item:*") do
  print(items.id, items.count, items.kind)
end
```
</LuaCode>

네트워크에 마법이 부여된 Diamond Sword와 일반 Diamond Sword가 함께 있다면 서로 다른 항목으로 나뉩니다.

<LuaCode>
```lua
for _, items in network:findEach("minecraft:diamond_sword") do
  print(items.id, items.hasData)
end
-- "minecraft:diamond_sword" true
-- "minecraft:diamond_sword" false
```
</LuaCode>

---

## count

[Network Storage](../nodeworks-mechanics/network-storage.md)에서 필터에 일치하는 리소스의 총수량을 반환합니다. 유체는 mB 단위입니다.

필터 문법은 [find](network.md#find)와 완전히 동일합니다.

<LuaCode>
```lua
print("swords:", network:count("minecraft:diamond_sword"))
print("cobblestone:", network:count("minecraft:cobblestone"))
print("all:", network:count("*"))
-- "swords:" 3
-- "cobblestone:" 256
-- "all:" 259
```
</LuaCode>

---

## insert

기본 <ItemLink id="storage_card" /> 우선순위 규칙에 따라 [ItemsHandle](items-handle.md)을 [Network Storage](../nodeworks-mechanics/network-storage.md)에 넣습니다. 요청한 모든 아이템을 넣을 공간이 없으면 하나도 이동하지 않고 `false`를 반환합니다. 가능한 만큼만 이동하려면 [tryInsert](./network.md#tryinsert)를 사용하세요.

<LuaCode>
```lua
local ok = network:insert(items)
if ok then
  print("all items were moved")
else
  print("no items were moved, not enough space")
end
```
</LuaCode>

---

## tryInsert

[`insert`](network.md#insert)와 달리 가능한 만큼만 이동합니다. 실제로 들어간 수량(0부터 요청 수량까지)을 반환하며, 들어가지 못한 아이템은 출처에 남습니다. 일부 이동을 허용할 때 사용하세요.

<LuaCode>
```lua
local moved = network:tryInsert(items)
print(moved .. " items were moved") -- 0부터 items.count까지의 값
```
</LuaCode>

---

## craft

([Auto-Crafting](../nodeworks-mechanics/autocrafting.md)도 참고하세요.)

지정한 아이템의 제작을 대기열에 등록하고 [CraftBuilder](./craft-builder.md)를 반환합니다. 기본적으로 제작이 끝나면 결과물이 [Network Storage](../nodeworks-mechanics/network-storage.md)에 자동 저장되므로 별도 메서드를 연결할 필요가 없습니다.

<LuaCode>
```lua
-- 완료를 기다리지 않고 Bread 제작을 요청하며, 결과물은 저장소로 이동합니다
network:craft("minecraft:bread", 4)
```
</LuaCode>

결과물을 직접 처리하려면 `:connect(fn)`을 연결하세요. 콜백에는 [ItemsHandle?](items-handle.md)가 전달되며, 성공 시 Handle, 실패 시(계획 실패, 비동기 시간 초과, CPU 없음) `nil`입니다. `:connect`를 호출하면 기본 자동 저장은 비활성화됩니다.

<LuaCode>
```lua
local furnace = network:get("furnace")
network:craft("minecraft:charcoal"):connect(function(item: ItemsHandle?)
  if item then
    furnace:insert(item)
  end
end)
```
</LuaCode>

---

## shapeless

[Network Storage](../nodeworks-mechanics/network-storage.md)의 재료로 형태가 없는 제작법을 즉시 제작합니다. 제작법이 유효하지 않거나 재료가 부족하면 제작하지 않고 `nil`을 반환합니다.

<LuaCode>
```lua
-- Flint and Steel을 제작하고 결과물을 Network Storage에 자동 저장합니다.
network:shapeless("minecraft:flint", 1, "minecraft:iron_ingot", 1)
```
</LuaCode>

---

## handle

([Auto-Crafting](../nodeworks-mechanics/autocrafting.md)도 참고하세요.)

네트워크의 <ItemLink id="processing_set" />에 대한 처리 Handler를 등록합니다. Handler는 입력 재료를 전달받으며, 결과물을 가져오도록 전달된 [Job](job.md)의 `pull`을 호출해야 합니다. [InputItems](input-items.md)에 포함된 아이템은 **반드시 모두** Handler에서 가져가야 합니다.

<GameScene zoom="5" interactive={true} paddingTop="40" paddingLeft="60" paddingRight="30">
  <ImportStructure src="../assets/assemblies/processing_storage_single_entry.snbt" />
  <BoxAnnotation min="1.9 0.1 0.75" max="1.1 0.9 1" color="#83E086">
    이름을 **"furnace"**로 변경<ItemImage id="nodeworks:io_card" />
  </BoxAnnotation>
  <BlockAnnotation x="0" y="0" z="0">
    <Row>
      <ItemImage id="minecraft:raw_iron" />
      **➜**
      <ItemImage id="minecraft:iron_ingot" />
    </Row>
  </BlockAnnotation>
</GameScene>

<LuaCode>
```lua
local furnace = network:get("furnace")
-- Raw Iron을 Iron Ingot으로 처리하는 Handler
network:handle("…", function(job: Job, items: InputItems)
  furnace:face("top"):insert(items.rawIron)
  job:pull(furnace:face("bottom"))
end)
```
</LuaCode>

---

## recipes

하나의 함수로 여러 Processing Set을 처리합니다. Set의 입력 조건을 지정하면 모든 입력이 일치하는 Set이 같은 Handler를 사용합니다. 나중에 네트워크에 추가된 Set도 자동으로 인식하므로 스크립트를 다시 시작할 필요가 없습니다.

<LuaCode>
```lua
local furnaces = network:get("furnaces")

local function smelt(job: Job, items: InputItems)
  for _, input in items:all() do
    furnaces:face("top"):insert(input)
  end
  job:pull(furnaces:face("bottom"))
end

network
  :recipes("#c:ores", "#c:raw_materials")
  :except("mod:uranium", "mod:other_ore")
  :handle(smelt)
```
</LuaCode>

### 일치하는 Set 판정

- **`network:recipes(...)`**: Set의 모든 입력이 지정한 규칙 중 하나에 일치해야 합니다. 예를 들어 Ingot 규칙에 Coal까지 필요한 합금 제작법이 섞이지 않도록 합니다. 규칙이 없으면 모든 Set이 일치합니다.
- **`:except(...)`**: 입력 중 하나라도 지정한 규칙에 일치하는 Set을 제외합니다.
- **`:outputs(...)`**: 선택 사항입니다. Set에서 확정적으로 생성하는 모든 출력도 지정한 규칙에 일치해야 합니다. 같은 Raw Iron을 Furnace에 넣어 Ingot을 만들거나 Crusher에 넣어 Dust를 만드는 경우처럼 기계를 구분할 때 유용합니다. 확률적 결과물은 검사하지 않습니다.

<LuaCode>
```lua
-- Raw Material 중 Ingot을 만드는 Set만 선택합니다.
network:recipes("#c:raw_materials"):outputs("#c:ingots"):handle(smelt)
```
</LuaCode>

규칙 문법은 [Storage Card 필터](../items-blocks/storage_card.md#filters)와 같으므로 아이템 ID, `#tags`, `*` 와일드카드를 사용할 수 있습니다.

### 우선순위

- 특정 Set에 등록한 [`network:handle`](./network.md#handle)이 `recipes` Handler보다 항상 우선합니다.
- <ItemLink id="processing_handler" /> 또는 <ItemLink id="multi_processing_handler" />에 연결된 Set은 해당 블록에서 처리됩니다. 넓은 범위의 규칙이라도 블록에 지정한 Set을 가져가지 않습니다.
- 두 `recipes` Handler가 같은 Set에 일치하면 먼저 등록한 Handler가 우선합니다.

### 한 번에 하나씩 제작

`recipes` Handler는 보통 여러 제작법이 같은 기계를 공유하므로 한 번에 하나의 제작만 처리합니다. 다른 작업은 Furnace를 놓고 충돌하지 않도록 차례를 기다립니다. 반대로 Furnace마다 다른 재료를 처리하는 설비처럼 기계를 공유하지 않는다면 `:parallel()`을 호출해 여러 작업을 동시에 실행할 수 있습니다.

<LuaCode>
```lua
network:recipes("#c:raw_materials"):parallel():handle(smelt)
```
</LuaCode>

### 중지 및 상태 확인

`:handle`은 중지하거나 현재 담당하는 Set을 조회할 수 있는 Handler를 반환합니다.

<LuaCode>
```lua
local ores = network:recipes("#c:ores"):handle(smelt)
for _, line in ipairs(ores:sets()) do
  print(line) -- minecraft:raw_iron -> minecraft:iron_ingot
end
ores:stop()
```
</LuaCode>

각 제작의 상세 정보는 [`job`](job.md#recipe)에서, 입력 재료는 [`items:all()`](input-items.md#all)에서 확인하세요.

---

## route

이름 패턴과 일치하는 모든 <ItemLink id="storage_card" />의 [필터 설정](../items-blocks/storage_card.md#filters)을 일괄 수정합니다. 여러 Card의 규칙을 하나의 메서드 체인으로 작성할 수 있는 Builder를 반환합니다. 각 메서드는 Card를 우클릭해 GUI에서 수정하는 것처럼 설정을 즉시 변경합니다.

이름 패턴에서 `*`는 와일드카드입니다. `cobblestone_*`는 `cobblestone_0`, `cobblestone_1` 등에 일치하며, `*`만 지정하면 네트워크의 모든 Storage Card에 일치합니다.

<LuaCode>
```lua
network:route("cobblestone_*")
  :reset()
  :rule("#c:cobblestones")
  :noNbt()
  :allow()
```
</LuaCode>

### Builder 메서드

| 메서드                                                 | 효과                                              |
| ------------------------------------------------------ | ------------------------------------------------- |
| `:rule(filter)`                                        | 규칙 추가(GUI 규칙 목록과 같은 문법)               |
| `:clearRules()`                                        | 모드는 유지하고 모든 규칙 삭제                     |
| `:allow()` / `:deny()`                                 | 규칙 목록 모드 설정                                |
| `:stackable()` / `:nonStackable()` / `:anyStackable()` | Stackability 필터 설정                             |
| `:hasNbt()` / `:noNbt()` / `:anyNbt()`                 | NBT 필터 설정                                      |
| `:reset()`                                             | 규칙 삭제, Allow + Any + Any로 초기화              |

메서드들은 동일한 Builder를 반환하므로 연속 호출할 수 있습니다. 변경 사항은 즉시 적용되며 저장 및 불러오기 후에도 유지됩니다.

---

## debug

네트워크 연결 구조의 요약 정보를 출력합니다.

<LuaCode>
```lua
network:debug()
-- === Network Debug ===
-- Controller: BlockPos{x=-25, y=70, z=10}
-- Nodes: 1
--   Node BlockPos{x=-25, y=70, z=9}: 1 cards
--     NORTH: cobblestone_storage (storage)
-- Terminals: 1
--   BlockPos{x=-26, y=70, z=9}
-- CPUs: 0
-- Crafters (Instruction Sets): 0
-- Processing APIs: 0
-- Variables: 0
```
</LuaCode>