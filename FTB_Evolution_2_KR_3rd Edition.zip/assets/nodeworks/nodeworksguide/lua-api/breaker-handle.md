---
navigation:
  parent: lua-api/index.md
  title: Breaker Handle
  icon: breaker
categories:
  - api_types
description: 전방의 블록을 파괴하는 장치
---

# BreakerHandle

`BreakerHandle`은 네트워크에 연결된 <ItemLink id="breaker" />를 참조하는 객체이며, [`network:get(name)`](network.md#get)으로 가져옵니다. Breaker 전방의 블록을 여러 틱에 걸쳐 파괴하고, 드롭 아이템을 네트워크 또는 사용자 지정 Handler로 보냅니다.

<BlockImage scale="6" id="breaker" />

Breaker의 채굴 등급은 Diamond Pickaxe와 같지만, 파괴 시간은 Wooden Pickaxe의 계산식을 사용합니다. 따라서 단단한 블록일수록 파괴하는 데 더 오래 걸립니다. Breaker 하나당 한 번에 한 블록만 파괴할 수 있으며, 작업 중 다시 `:mine()`을 호출해도 아무 일도 일어나지 않습니다.

## 속성

- **`.name`**
  - Breaker의 별칭(터미널 사이드바에 표시되는 이름과 동일)

## mine

Breaker가 바라보는 블록을 여러 틱에 걸쳐 파괴하기 시작합니다. [BreakBuilder](./breaker-handle.md#breakbuilder)를 반환하므로 `:connect(fn)`을 이어 호출해 드롭 아이템의 목적지를 바꿀 수 있습니다. 별도로 지정하지 않으면 [Storage Card](../items-blocks/storage_card.md)의 우선순위 규칙에 따라 [Network Storage](../nodeworks-mechanics/network-storage.md)로 들어갑니다.

<LuaCode>
```lua
local breaker = network:get("quarry_1")
breaker:mine() -- 드롭 아이템을 네트워크 저장소로 보냅니다
```
</LuaCode>

대상이 공기이거나 파괴할 수 없거나 Breaker의 채굴 등급보다 높다면 `:mine()`은 아무 작업도 하지 않는 Builder를 반환합니다. 따라서 이어서 메서드를 호출해도 오류가 발생하지 않습니다.

## cancel

진행 중인 블록 파괴를 중단합니다. 대기 중에 호출해도 안전합니다. 블록은 파괴되지 않으며 드롭 아이템도 생성되지 않습니다.

<LuaCode>
```lua
local breaker = network:get("breaker_1")
breaker:mine()
if dangerous() then
  breaker:cancel() -- 완료 전에 중단합니다
end
```
</LuaCode>

## block

Breaker가 바라보는 위치의 블록 ID를 반환합니다. 반환 형식은 [`ObserverCard:block`](./card-handle.md#observer-card)과 같습니다. 블록 종류에 따라 파괴 여부를 결정할 때 유용합니다.

<LuaCode>
```lua
local breaker = network:get("breaker_1")
if breaker:block() == "minecraft:stone" then
  breaker:mine()
end
```
</LuaCode>

## state

Breaker가 바라보는 블록의 속성을 테이블로 반환합니다. [`ObserverCard:state`](./card-handle.md#observer-card)와 같은 형식이며, 성장 단계 `age`, 방향 `facing`, 점등 상태 `lit`, 침수 상태 `waterlogged` 등 모든 `BlockState` 속성이 필드로 제공됩니다.

<LuaCode>
```lua
local breaker = network:get("crop_breaker")
local state = breaker:state()
if state.age == 7 then
  breaker:mine() -- 완전히 성장한 작물만 수확합니다
end
```
</LuaCode>

## isMining

블록을 파괴하는 동안에는 `true`, 대기 중에는 `false`를 반환합니다. 작업 중 `:mine()`을 다시 호출하지 않도록 확인할 수 있습니다. 재호출 자체는 무시되지만, `:isMining()`으로 조건을 명확하게 나눌 수 있습니다.

<LuaCode>
```lua
local breaker = network:get("breaker_1")
if not breaker:isMining() then
  breaker:mine()
end
```
</LuaCode>

## progress

현재 파괴 작업의 진행 정도를 `0`부터 `1` 사이의 값으로 반환합니다. 대기 중에는 `0`입니다. 진행률 표시나 후속 작업의 타이밍을 조절할 때 사용할 수 있습니다.

<LuaCode>
```lua
local breaker = network:get("breaker_1")
print(string.format("%.0f%%", breaker:progress() * 100))
```
</LuaCode>

---

## BreakBuilder

[`Breaker:mine()`](./breaker-handle.md#mine)이 반환하는 객체입니다. 블록 파괴가 끝난 후 드롭 아이템의 이동 경로를 설정합니다. 별도 지정이 없으면 네트워크 저장소로 자동 이동하며, `:connect(fn)`을 이어 호출하면 스크립트 Handler로 보낼 수 있습니다.

### connect

이 파괴 작업의 드롭 아이템을 콜백으로 전달합니다. Handler는 드롭된 아이템 스택마다 [ItemsHandle](./items-handle.md) 형식의 값을 하나씩 받습니다. 따라서 Fortune 효과가 적용된 광석처럼 여러 스택이 나오는 블록은 Handler가 여러 번 호출될 수 있습니다.

Handler는 드롭 아이템의 `.id`, `.name`, `.count`, `.kind`를 읽어 처리 방법을 결정할 수 있습니다. Handler가 가져가지 않은 아이템은 기본 경로에 따라 네트워크 저장소로 이동합니다.

<LuaCode>
```lua
local breaker = network:get("breaker_1")
local chest = network:get("ore_chest")
breaker:mine():connect(function(item: ItemsHandle)
  if item.id == "minecraft:diamond" then
    chest:insert(item) -- Diamond를 전용 상자에 넣습니다
  end
  -- 나머지 아이템은 네트워크 저장소로 이동합니다
end)
```
</LuaCode>

> **참고:** Breaker의 `:connect` Handler는 매 틱이 아니라 블록 파괴가 완료될 때 실행됩니다. Handler 내부 오류는 무시되므로 잘못된 콜백 때문에 Breaker가 멈추지 않습니다.
