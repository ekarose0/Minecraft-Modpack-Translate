---
navigation:
  parent: lua-api/index.md
  title: Channel
  icon: io_card
categories:
  - api_types
description: 염료 색상으로 범위를 구분한 네트워크 보기
---

# Channel

`Channel`은 염료 색상별로 네트워크를 구분해 접근하는 기능입니다. [`network:channel(color)`](network.md#channel)로 얻을 수 있습니다. Channel을 통해 조회하면 해당 색상으로 설정된 Card, Variable, Device만 보입니다. 각 Card나 Device의 GUI에서 채널을 선택할 수 있으므로, 여러 하위 시스템이 같은 네트워크를 사용해도 이름이 충돌하지 않습니다.

<LuaCode>
```lua
local red = network:channel("red")
local blue = network:channel("blue")
red:getAll("redstone"):set(true)   -- 빨간색 채널의 피스톤만 작동합니다
blue:getAll("redstone"):set(true)  -- 파란색 채널의 피스톤만 작동합니다
```
</LuaCode>

색상 이름은 바닐라 염료 16종(`white`, `red`, `blue`, `light_blue`, `light_gray` 등) 중 하나여야 합니다. 알 수 없는 색상을 입력하면 오류가 발생합니다.

## 채널 선택

모든 [Card](../nodeworks-mechanics/cards.md)와 [Device](../nodeworks-mechanics/devices.md)에서 채널을 지정할 수 있습니다. 기본 채널은 모두 `white`입니다. 색상 선택 영역을 클릭하면 목록이 펼쳐지며 다른 색상을 고를 수 있습니다.

![](../assets/images/choose_channel.png)

## get

이 채널에 속한 별칭을 조회합니다. [`network:get`](network.md#get)과 같은 이름 범위에서 [CardHandle](card-handle.md), [VariableHandle](variable-handle.md), Breaker 또는 Placer를 반환합니다. 채널에서 해당 별칭을 찾지 못하면 오류가 발생합니다.

<LuaCode>
```lua
local red = network:channel("red")
local counter = red:get("counter")  -- 빨간색 채널의 "counter" 변수
local door = red:get("door")     -- 빨간색 채널의 "door" Card
```
</LuaCode>

## getAll

이 채널에서 지정한 종류에 해당하는 모든 구성원을 [HandleList](handle-list.md)로 반환합니다. 종류 문자열은 [`network:getAll`](network.md#getAll)과 동일하며 `"io"`, `"storage"`, `"redstone"`, `"observer"`, `"variable"`, `"breaker"`, `"placer"`입니다. 인수를 생략하면 종류와 관계없이 채널의 모든 구성원을 반환합니다.

<LuaCode>
```lua
local red = network:channel("red")
red:getAll("observer"):onChange(function(block, state)
  print("red-channel observer fired:", block)
end)
```
</LuaCode>

## getFirst

이 채널에서 지정한 종류에 해당하는 첫 번째 구성원을 반환합니다. 일치하는 항목이 없으면 `nil`을 반환합니다. 채널마다 해당 종류가 하나뿐이라면 HandleList에서 인덱스로 찾을 필요가 없어 편리합니다.

<LuaCode>
```lua
local sensor = network:channel("blue"):getFirst("observer")
if sensor then
  print(sensor.name, "is the blue-channel observer")
end
```
</LuaCode>
