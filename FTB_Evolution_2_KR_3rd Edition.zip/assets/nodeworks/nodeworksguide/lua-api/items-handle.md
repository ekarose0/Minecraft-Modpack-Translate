---
navigation:
  parent: lua-api/index.md
  title: ItemsHandle
  icon: minecraft:bundle
categories:
  - api_types
description: 수량, 출처, 이동 작업 정보를 가진 특정 아이템 또는 유체 리소스
---

# ItemsHandle

`ItemsHandle`은 **수량이 연결된 하나의 리소스 유형**입니다. 네트워크나 Card에서 "저장소에 무엇이 있나요?"라고 조회할 때 반환되는 값이며, "이 아이템을 다른 곳으로 옮겨 주세요"라고 요청할 때도 사용합니다.

> **참고:** Handle은 호출 시점에 생성된 **스냅샷**입니다. 이후 저장소에 아이템이 들어오거나 나가더라도 `.count`는 자동으로 바뀌지 않습니다. 최신 수량이 필요하면 `:find`를 다시 호출하세요.

---

## Handle이 나타내는 것과 나타내지 않는 것

Handle은 개별 인벤토리 슬롯이 아니라 **조회 위치에서 조건에 일치하는 모든 리소스를 합산한 값**입니다. 따라서 다음 두 가지를 알아 두어야 합니다.

**하나의 Handle로 아이템과 유체를 모두 다룰 수 있습니다.** `.kind` 필드로 종류를 구분합니다. 아이템 수량은 개수, 유체 수량은 밀리버킷(mB) 단위입니다. 자세한 내용은 [count](./items-handle.md#count) 및 [kind](./items-handle.md#kind)를 참고하세요.

**수량이 `maxStackSize`를 초과할 수 있습니다.** `network:find("minecraft:coal")`은 슬롯당 최대 64개만 들어가더라도 `count = 192`인 Handle을 반환할 수 있습니다. 이 값은 여러 슬롯, Storage Card, 탱크에 흩어진 리소스를 합산한 것입니다. [card:find](card-handle.md#find)도 해당 Card의 슬롯과 탱크를 합산합니다.

마법이 부여된 Sword와 일반 Sword처럼 같은 ID를 가진 서로 다른 스택을 구분하려면 [`findEach`](network.md#findEach)를 사용하세요. ID와 **NBT 데이터**를 기준으로 나누어 각각의 조합을 별도 Handle로 반환합니다.

<LuaCode>
```lua
local allCoal = network:find("minecraft:coal")
print(allCoal.count) -- 192, 네트워크 전체 합계

for _, h in network:findEach("minecraft:diamond_sword") do
  print(h.name, h.hasData) -- 마법이 부여된 Sword와 일반 Sword를 별도 항목으로 표시
end
```
</LuaCode>

---

## 속성

### id

Handle이 가리키는 리소스 ID입니다. 아이템은 `"minecraft:diamond"`, 유체는 `"minecraft:water"`처럼 동일한 형식을 사용합니다.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
print(coal.id) -- "minecraft:coal"
```
</LuaCode>

### name

플레이어의 툴팁에 표시되는 이름입니다. 언어 번역과 서식이 적용되며, 모루로 변경한 사용자 지정 이름도 반영됩니다.

<LuaCode>
```lua
local sword = network:find("minecraft:diamond_sword")
print(sword.name) -- "Diamond Sword" (이름을 바꿨다면 "Excalibur")
```
</LuaCode>

### count

Handle이 나타내는 리소스 수량입니다. **아이템은 실제 개수**(64개 스택의 수가 아님), **유체는 mB**(밀리버킷, 1000mB = 1버킷) 단위입니다.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
print(coal.count) -- 192 (Coal 192개)
-- 유체인 경우
local water = network:find("minecraft:water")
print(water.count) -- 4000 (4버킷, mB 단위)
```
</LuaCode>

### kind

`"item"` 또는 `"fluid"`입니다. 스크립트에서 두 종류를 함께 처리할 때 이 값을 기준으로 분기하세요.

<LuaCode>
```lua
for _, h in network:findEach("*") do
  if h.kind == "fluid" then
    print(h.count, "mB of", h.name)
  else
    print(h.count, "x", h.name)
  end
end
```
</LuaCode>

### stackable

최대 중첩 수량이 1보다 큰 아이템(Cobblestone, Ingot, Plank 등)은 `true`, 도구·방어구·특수 아이템(사용자 지정 NBT가 있는 Potion, 작성된 Book 등)은 `false`입니다. 유체는 스택이 아니라 부피로 관리하므로 항상 `false`입니다.

<LuaCode>
```lua
for _, item in inputChest:findEach("*") do
  if not item.stackable then
    nonStackables:insert(item)
  else
    network:insert(item)
  end
end
```
</LuaCode>

네트워크 밖의 다른 상자로 중첩할 수 없는 아이템을 이동하는 예시입니다.

### maxStackSize

인벤토리 슬롯 하나에 들어갈 수 있는 최대 수량입니다. 대부분의 아이템은 `64`, Snowball과 Ender Pearl은 `16`, 도구와 방어구는 `1`입니다. 유체도 `1`을 반환하지만 의미 있는 값은 아닙니다.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
print(coal.maxStackSize) -- 64
```
</LuaCode>

### hasData

기본값과 다른 NBT, 마법 부여, 사용자 지정 이름, 작성된 책의 내용, 염색된 방어구, Suspicious Stew 효과 등이 있으면 `true`입니다. 일반 대량 자원과 특별한 아이템을 구분할 때 유용합니다.

<LuaCode>
```lua
for _, item in inputChest:findEach("*") do
  if item.hasData then
    enchantedItems:insert(item)
  else
    network:insert(item)
  end
end
```
</LuaCode>

---

## 메서드

### hasTag

리소스가 지정한 태그에 속하면 `true`를 반환합니다. 태그 ID 앞의 `#`은 생략할 수 있으므로 `"minecraft:logs"`와 `"#minecraft:logs"` 모두 사용할 수 있습니다.

<LuaCode>
```lua
for _, h in network:findEach("*") do
  if h:hasTag("minecraft:logs") then
    print(h.name, "is a log type")
  end
end
```
</LuaCode>

태그 소속 여부는 Minecraft 제작법과 바이옴 판정에 사용되는 태그를 기준으로 합니다. 바닐라의 "아무 Log나 사용"하는 제작법에 해당하는 아이템이라면 여기서도 일치합니다.

### matches

리소스가 지정한 필터에 일치하면 `true`를 반환합니다. 필터 문법은 [`network:find`](network.md#find)와 동일합니다. `:find`로 전체 검색을 반복하지 않고도 아이템별 전송 조건이나 분기를 처리할 수 있습니다.

<LuaCode>
```lua
function smelt(item: ItemsHandle)
  if item:matches("/_ore$/") then
    machine:insert(item)
    return
  end
  furnace:insert(item)
end
```
</LuaCode>

---

## 이동 메서드에 Handle 전달하기

Handle은 단순한 읽기 전용 값이 아니라 **아이템 이동의 출처**이기도 합니다. 대부분의 이동 메서드는 Handle을 인자로 받아 원래 위치에서 새 목적지로 아이템을 옮깁니다.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
if coal then
  -- 모든 아이템을 Chest로 옮깁니다
  chest:insert(coal)
end
```
</LuaCode>

이런 방식으로 Handle을 사용하는 메서드는 다음과 같습니다.

- [`card:insert`](card-handle.md#insert) / [`card:tryInsert`](card-handle.md#tryinsert): Card에 인접한 인벤토리로 이동
- [`network:insert`](network.md#insert) / [`network:tryInsert`](network.md#tryinsert): 전송 규칙에 따라 Network Storage로 이동
- [`placer:place`](placer-handle.md#place): Handle의 `.id`를 이용해 설치할 블록 선택

이 메서드가 이동할 수 있는 최대 수량은 Handle의 `.count`입니다. 두 번째 인자를 선택적으로 전달하면 이동 수량을 제한할 수 있어, 화로 연료 슬롯처럼 작은 목적지에 유용합니다.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
furnace:insert(coal, 8) -- 연료 슬롯에 Coal 8개를 보충합니다
```
</LuaCode>

> **참고:** `:insert`는 요청 수량을 모두 이동하거나 전혀 이동하지 않습니다. 목적지 공간이 부족하면 아무것도 옮기지 않고 `false`를 반환합니다. 일부만 옮겨도 된다면 `:tryInsert`를 사용하거나, 두 번째 인자로 수량을 제한하세요.

---

## 일치하는 항목이 없을 때 nil

필터와 일치하는 항목이 없으면 `:find`와 `findEach`의 결과는 `nil`입니다. `count = 0`인 Handle은 존재하지 않으므로 메서드를 연속 호출하기 전에 결과를 확인하세요.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
if coal then
  print(coal.count, "coal available")
else
  print("no coal in storage")
end
```
</LuaCode>

편집기의 타입 시스템도 이를 추적합니다. `coal` 위에 마우스를 올리면 `ItemsHandle?`가 표시되며, `?`는 "또는 nil"을 뜻합니다. 확인을 빠뜨리면 편집기에서 알려 줍니다.
