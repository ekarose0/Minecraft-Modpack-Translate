---
navigation:
  parent: lua-api/index.md
  title: InputItems
  icon: minecraft:cobblestone
categories:
  - api_types
description: network:handle 콜백의 두 번째 인수로 전달되는 레시피 입력 아이템 목록
---

# InputItems

`InputItems`는 [`network:handle`](network.md#handle) 함수가 받는 두 번째 인수입니다. 네트워크가 레시피 재료를 이미 저장소에서 꺼내 입력 슬롯별 필드에 담아 둔 상태입니다. 스크립트는 이 아이템을 실제 기계로 옮기면 됩니다.

각 필드는 완전한 [ItemsHandle](items-handle.md)이므로 다른 Handle과 마찬가지로 `:insert`, `:tryInsert`, `:count` 등을 사용할 수 있습니다.

## 필드 이름

필드 이름은 **입력 아이템 ID를 camelCase로 변환한 형태**입니다. 예를 들어 `minecraft:raw_iron`은 `items.rawIron`, `minecraft:copper_ingot`은 `items.copperIngot`이 됩니다. 스크립트 편집기가 해당 레시피에 맞는 이름을 자동 완성하므로 외울 필요는 없습니다.

<LuaCode>
```lua
local furnace = network:get("furnace")
network:handle("...", function(job: Job, items: InputItems)
  furnace:face("top"):insert(items.rawIron) -- minecraft:raw_iron
  job:pull(furnace:face("bottom"))
end)
```
</LuaCode>

### 중복 재료

같은 재료가 여러 슬롯에 들어가는 레시피라면 두 번째 항목에 `2`, 세 번째에 `3` 등의 접미사가 붙습니다. 예를 들어 Copper Ingot 2개와 Gold Ingot 1개가 필요한 레시피는 `items.copperIngot`, `items.goldIngot`, `items.copperIngot2`로 제공됩니다.

<LuaCode>
```lua
local press = network:get("press")
network:handle("...", function(job: Job, items: InputItems)
  press:face("top"):insert(items.copperIngot)
  press:face("top"):insert(items.copperIngot2)
  press:face("north"):insert(items.goldIngot)
  job:pull(press:face("bottom"))
end)
```
</LuaCode>

## all

레시피에 정의된 순서대로 모든 입력을 목록으로 반환합니다. [`network:recipes`](network.md#recipes)처럼 하나의 핸들러가 여러 레시피를 처리하고 레시피마다 필드 이름이 달라질 때 유용합니다.

<LuaCode>
```lua
local furnace = network:get("furnace")
network:handle("...", function(job: Job, items: InputItems)
  for _, input in ipairs(items:all()) do
    furnace:face("top"):insert(input)
  end
  job:pull(furnace:face("bottom"))
end)
```
</LuaCode>

목록의 Handle은 이름으로 접근하는 필드와 동일한 객체입니다. 따라서 `items.rawIron`을 옮기면 목록에 있는 해당 항목도 비워집니다.

## 모든 입력을 사용해야 합니다

핸들러는 입력으로 받은 모든 아이템을 기계로 옮겨야 합니다. 핸들러가 종료될 때 `items.<slot>`에 아이템이 남아 있으면 네트워크는 제작이 완료되지 않았다고 판단하고 나중에 레시피를 다시 시도합니다. 입력을 건너뛰는 모드는 없습니다. 레시피가 Copper Ingot N개를 요구한다면 N개 모두 어딘가로 이동해야 합니다.

> **참고:** 여기서 사용한다는 것은 접근 가능한 곳에 넣는다는 뜻입니다. `network:insert`로 Network Storage에 다시 넣어도 사용한 것으로 간주됩니다. 검사는 스크립트가 받은 아이템을 모두 처리했는지만 확인하며, 올바른 기계에 들어갔는지는 검사하지 않습니다.