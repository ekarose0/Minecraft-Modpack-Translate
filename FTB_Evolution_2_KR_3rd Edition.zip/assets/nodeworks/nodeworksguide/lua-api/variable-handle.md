---
navigation:
  parent: lua-api/index.md
  title: VariableHandle
  icon: variable
categories:
  - api_types
description: 네트워크의 <ItemLink id="variable" />를 참조합니다
---

# VariableHandle

`VariableHandle`은 네트워크에 있는 <ItemLink id="variable" />를 참조하는 객체이며, Card와 마찬가지로 [`network:get(name)`](network.md#get)으로 가져옵니다. 선언된 변수 유형을 추적하며, 각 유형은 아래 공통 API 외에도 고유한 보조 메서드를 제공합니다.

<BlockImage scale="6" id="variable" />

> **참고:** 모든 값 변경은 원자적으로 처리됩니다. 다른 스크립트가 같은 변수에 `:set` 또는 `:cas`를 호출하더라도 작업 중간에 끼어들 수 없습니다.

## 속성

- **`.name`**
  - 변수의 별칭(터미널 사이드바에 표시되는 이름과 동일)

## 공통 메서드

### get / set

변수의 현재 값을 읽거나 설정합니다.

<LuaCode>
```lua
local myNumericVar = network:get("myNumericVar")
print(myNumericVar:get())
myNumericVar:set(1)
print(myNumericVar:get())
-- "0"
-- "1"
```
</LuaCode>

### cas

비교 후 교체(Compare-and-swap) 기능입니다. 현재 값이 `expected`와 같을 때만 `new`로 변경하며, 다르면 그대로 둡니다. 변경에 성공하면 `true`, 다른 작업이 먼저 값을 바꿨다면 `false`를 반환합니다.

새 값이 **현재 값에 따라 달라지고**, 여러 스크립트가 같은 변수에 접근할 수 있다면 이 기능을 사용하세요. `:set`은 기존 값을 무조건 덮어쓰므로 두 스크립트가 동시에 작업하면 서로의 변경 내용을 잃을 수 있습니다. `:cas`는 예상한 값이 그대로 있을 때만 변경합니다.

<LuaCode>
```lua
-- 작업 슬롯 확보: 빈 문자열을 먼저 확인한 스크립트만 성공합니다
if slot:cas("", "worker_A") then
  print("i got the job")
else
  print("someone else already claimed it")
end
```
</LuaCode>

작업 도중 값이 바뀔 수 있을 때 사용하는 일반적인 읽기-수정-쓰기 반복문입니다.

<LuaCode>
```lua
-- 값이 0보다 클 때만 감소시키며, 충돌 시 다시 시도합니다
while true do
  local current = counter:get()
  if current <= 0 then
    break -- 더 이상 가져올 값이 없습니다
  end
  if counter:cas(current, current - 1) then
    break -- 변경에 성공했습니다
  end
  -- :get과 :cas 사이에 다른 스크립트가 값을 바꿨으므로 재시도합니다
end
```
</LuaCode>

> **참고:** 단순한 덧셈과 뺄셈에는 원자적으로 작동하는 [`increment / decrement`](variable-handle.md#increment--decrement)가 더 간단합니다. 값의 변경 조건이 단순한 증감이 아닐 때 `:cas`를 사용하세요.

### type

이 `VariableHandle`의 유형을 나타내는 문자열을 반환합니다.

- **`NumberVariableHandle`**
  - `"number"`
- **`BoolVariableHandle`**
  - `"bool"`
- **`StringVariableHandle`**
  - `"string"`

<LuaCode>
```lua
local numberVar = network:get("numberVar")
local boolVar = network:get("boolVar")
local stringVar = network:get("stringVar")
print(numberVar:type())
print(boolVar:type())
print(stringVar:type())
-- "number"
-- "bool"
-- "string"
```
</LuaCode>

## BoolVariableHandle

`bool` 유형으로 선언된 <ItemLink id="variable" />를 가리키는 [`VariableHandle`](./variable-handle.md)입니다. bool 변수에서만 사용할 수 있는 메서드가 추가됩니다.

### toggle

현재 값을 반전합니다(`true`는 `false`로, `false`는 `true`로 변경). 변경된 값을 반환합니다.

<LuaCode>
```lua
local lights = network:get("lights")
print(lights:get())
lights:toggle()
print(lights:get())
-- "false"
-- "true"
```
</LuaCode>

> **참고:** [`RedstoneCard:onChange`](./card-handle.md#onchange)로 Redstone 버튼에 연결하면 버튼을 누를 때마다 상태를 전환하는 기능을 만들 수 있습니다.

### tryLock / unlock

bool 변수는 상호 배제 잠금으로도 사용할 수 있습니다. `:tryLock()`은 값을 원자적으로 `false`에서 `true`로 바꾸고 성공하면 `true`를 반환합니다. 이미 `true`라면(다른 스크립트가 잠금을 보유한 상태) **기다리지 않고** `false`를 반환합니다. `:unlock()`은 다시 `false`로 되돌립니다.

<LuaCode>
```lua
local mutex = network:get("job_mutex") -- bool 변수
if mutex:tryLock() then
  -- 작업 수행
  mutex:unlock()
end
```
</LuaCode>

> **중요:** `:tryLock`은 다른 스크립트가 잠금을 보유하고 있어도 기다리지 않고 즉시 `false`를 반환합니다. 잠금을 얻지 못하면 나중에 다시 시도([`scheduler:delay`](scheduler.md#delay))하거나 작업을 건너뛰도록 설계하세요.
>
> `:tryLock`에 성공했다면 반드시 `:unlock`을 호출해야 합니다. 코드 오류로 잠금이 해제되지 않는 상황을 방지하려면 중요한 작업 구간을 `pcall`로 보호하세요.

## NumberVariableHandle

`number` 유형으로 선언된 <ItemLink id="variable" />를 가리키는 [`VariableHandle`](./variable-handle.md)입니다. 숫자 변수에서만 사용할 수 있는 메서드가 추가됩니다.

### increment / decrement

변수의 현재 값에 지정한 수량을 더하거나 뺍니다. 두 메서드 모두 변경된 값을 반환합니다.

<LuaCode>
```lua
local counter = network:get("counter")
counter:set(0)
counter:increment(1) -- +1 -> 1
counter:increment(5) -- +5 -> 6
counter:decrement(2) -- -2 -> 4
```
</LuaCode>

### min / max

- `:min(n)`: 현재 값과 `n` 중 더 작은 값으로 설정합니다.
- `:max(n)`: 현재 값과 `n` 중 더 큰 값으로 설정합니다.

두 메서드 모두 새 값을 반환합니다.

<LuaCode>
```lua
local best = network:get("best_score")
best:set(42)
best:max(50) -- 42 vs 50 -> 50 (new high)
best:max(35) -- 50 vs 35 -> 50 (unchanged)
best:min(10) -- 50 vs 10 -> 10 (capped)
```
</LuaCode>

## StringVariableHandle

`string` 유형으로 선언된 <ItemLink id="variable" />를 가리키는 [`VariableHandle`](./variable-handle.md)입니다. 문자열 변수에서만 사용할 수 있는 메서드가 추가됩니다.

### append / length / clear

- `:append(str)`: 현재 문자열 끝에 `str`을 추가하고 변경된 문자열을 반환합니다.
- `:length()`: 현재 문자열의 문자 수를 반환합니다.
- `:clear()`: 변수를 빈 문자열(`""`)로 초기화합니다.

<LuaCode>
```lua
local log = network:get("log")
log:clear()
log:append("start ")
log:append("middle ")
log:append("end")
print(log:get())
print(log:length())
-- "start middle end"
-- 16
```
</LuaCode>