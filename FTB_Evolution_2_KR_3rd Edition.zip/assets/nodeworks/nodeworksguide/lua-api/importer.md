---
navigation:
  parent: lua-api/index.md
  title: Importer
  icon: minecraft:hopper
categories:
  - api_types
  - api_preset
description: 분배 전략을 지정해 아이템과 유체를 A에서 B로 이동합니다
---

# Importer

전역 객체 `importer`는 하나 이상의 출발지에서 아이템과 유체를 가져와 하나 이상의 목적지로 보내는 작업을 만듭니다. 각 Importer는 내부적으로 예약 작업으로 실행되며, 스크립트가 종료되거나 Handle에서 `:stop()`을 호출할 때까지 설정한 간격으로 계속 작동합니다.

## from

<LuaCode>
```lua
Importer:from(...sources: string | CardHandle | network): ImporterBuilder
```
</LuaCode>

Importer 메서드 체인을 시작합니다. 출발지에는 Card 별칭, CardHandle 객체, 전체 Network Storage를 의미하는 전역 `network`를 자유롭게 조합할 수 있습니다. 출발지는 최소 하나 필요합니다.

<LuaCode>
```lua
importer:from("farmChest")                        -- 이름이 지정된 출발지 하나
importer:from(network)                            -- 네트워크 저장소를 출발지로 지정
importer:from("chestA", network, network:get("chestB"))  -- 여러 형식 혼합
```
</LuaCode>

## to

<LuaCode>
```lua
ImporterBuilder:to(...targets: string | CardHandle | network): ImporterBuilder
```
</LuaCode>

목적지를 설정합니다. `:from`과 마찬가지로 Card 별칭, CardHandle 객체, 저장소를 뜻하는 `network`를 사용할 수 있습니다. 목적지는 최소 하나 필요합니다.

목적지로 지정한 Storage Card의 규칙은 그대로 적용됩니다. `network:insert`와 마찬가지로 규칙 목록, 중첩 가능 여부, 데이터 필터를 모두 통과한 아이템만 들어갑니다. 따라서 Importer의 `:filter` 설정과 관계없이 방어구 전용 Card는 방어구만 받습니다.

<LuaCode>
```lua
importer:from("farm"):to("storage1", "storage2"):start()
importer:from("mobFarm"):to(network):start()  -- 네트워크 저장소에 넣습니다
```
</LuaCode>

## filter

이동할 아이템을 지정합니다. 규칙 중 하나에 일치하는 아이템을 이동하며, 필터를 생략하면 모든 아이템을 이동합니다. 필터 구문은 [Network:find](network.md#find)와 같습니다.

`:filter()`를 여러 번 호출해 필터를 추가하거나 인자 없이 호출해 필터를 초기화할 수 있습니다.

<LuaCode>
```lua
importer
  :from(network)
  :filter("$item:minecraft:cobblestone")
  :filter("$item:minecraft:stone")
  :to("io_*")
  :start()

local puller = importer
  :from("quarry")
  :filter("#c:ores")
  :to(network)

puller:filter() -- 필터를 초기화합니다
puller:start() -- Importer를 시작합니다
```
</LuaCode>

## except

이동 대상에서 **제외할** 아이템을 지정합니다.

<LuaCode>
```lua
-- 화로에서 제련할 수 없는 광석을 제외하고 모두 이동합니다
importer
  :from(network)
  :to("furnace_*")
  :filter("#c:ores")
  :except("mod:uranium")
  :roundrobin()
  :start()

-- 기계 내부를 비우되 Slag는 남겨 둡니다
importer:from("crusher"):to(network):except("mod:slag"):start()
```
</LuaCode>

## Fluids

Importer는 유체도 이동할 수 있습니다. 규칙에서 유체를 지정할 수 있으며, 아이템과 유체의 이름이 같다면 `$fluid:`로 유체를 선택합니다. 수량 단위는 mB(밀리버킷)이며, 양동이 한 개는 `1000`mB입니다. 유체 탱크가 없는 목적지는 건너뜁니다.

<LuaCode>
```lua
importer
  :from(network)
  :to("boiler")
  :filter("$fluid:minecraft:water")
  :start()
```
</LuaCode>

## 분배 방식

Importer는 목적지에 아이템을 분배하는 두 가지 방식을 지원합니다. 기본값은 순차 채우기(Fill)이며, Round Robin은 직접 지정해야 합니다.

### Fill (기본값)

첫 번째 목적지를 먼저 채우고, 가득 차면 남은 아이템을 다음 목적지로 보냅니다. 우선순위가 있고 특정 상자를 먼저 채운 뒤 남은 아이템을 다른 곳에 저장하고 싶을 때 유용합니다.

<LuaCode>
```lua
importer
  :from("furnaceOutput")
  :filter("$item:iron_ingot")
  :to("mainChest", "overflow")
  :start()
```
</LuaCode>

### roundrobin

모든 목적지에 아이템을 고르게 분배합니다. 인자를 지정하면 한 번에 각 목적지로 보낼 수량을 설정하며 기본값은 1입니다. 아이템은 개수, 유체는 mB 단위를 사용하므로 유체를 양동이 한 개씩 분배하려면 `1000`을 지정하세요.

<LuaCode>
```lua
importer
  :from("bufferChest")
  :to("furnace1", "furnace2", "furnace3")
  :roundrobin()
  :start()

importer
  :from(network)
  :to("boiler_*")
  :filter("$fluid:minecraft:water")
  :roundrobin(1000)
  :start()
```
</LuaCode>

Round Robin의 분배 위치는 매 틱 한 칸씩 이동하므로, 출발지의 아이템이 부족해 일부 목적지만 받을 수 있는 상황에서도 장기적으로 균등하게 분배됩니다.

## Card 별칭의 와일드카드

`:from`과 `:to`에서는 Card 이름에 `*` 와일드카드를 사용할 수 있습니다. `"io_*"`를 지정하면 해당 패턴과 일치하는 모든 Card를 선택합니다. 네트워크 연결 구조가 바뀔 때마다 일치하는 Card 목록도 다시 계산됩니다.

<LuaCode>
```lua
-- 한 상자의 아이템을 io_... 이름을 가진 모든 Card에 분배합니다
importer:from("input"):to("io_*"):roundrobin():start()

-- 여러 출발지 상자에서 하나의 목적지로 아이템을 가져옵니다
importer:from("farm_*"):to("storage"):start()
```
</LuaCode>

## 예시: 두 단계 제련 설비

광석과 원재료를 Round Robin 방식으로 각 화로에 분배하고, 완성된 주괴는 네트워크로 다시 회수합니다.

<LuaCode>
```lua
local furnaces = network:cards("furnace_*")

-- 화로에 재료를 균등하게 공급합니다
importer:from(network)
  :to(furnaces:face("top"))
  :filter("#c:ores", "#c:raw_materials")
  :except("mod:uranium")
  :roundrobin()
  :every(10)
  :start()

-- 출력되는 결과물을 모두 수집합니다
importer:from(furnaces:face("bottom"))
  :to(network)
  :start()
```
</LuaCode>

## 관련 문서

* [Preset 공통 메서드](presets.md#shared-methods) (`:every`, `:start`, `:stop`, `:isRunning`)
* 일정 재고를 유지하는 기능은 [Stocker](stocker.md)를 참고하세요.
* 필터 구문은 [Network:find](network.md#find)를 참고하세요.
