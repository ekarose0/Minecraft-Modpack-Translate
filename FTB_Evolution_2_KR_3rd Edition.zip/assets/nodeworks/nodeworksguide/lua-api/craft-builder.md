---
navigation:
  parent: lua-api/index.md
  title: CraftBuilder
  icon: minecraft:crafting_table
categories:
  - api_types
description: [`network:craft`](network.md#craft)가 반환하며 제작 완료 후 결과물 전달 방식을 설정합니다
---

# CraftBuilder

`CraftBuilder`는 [`network:craft`](network.md#craft)가 반환하는 객체로, 네트워크에서 계획했지만 아직 결과물을 전달하지 않은 제작 작업을 나타냅니다. 기본적으로 제작이 완료되면 결과물이 [Network Storage](../nodeworks-mechanics/network-storage.md)에 저장됩니다. 콜백으로 전달하려면 `:connect(fn)`을 이어 호출하세요.

제작은 같은 틱에 끝날 수도 있고(저장소의 재료로 완성되는 바닐라 제작법), 여러 틱이 걸릴 수도 있습니다([`network:handle`](network.md#handle) 처리 Handler를 거치거나 여러 단계로 이루어진 제작). 어느 경우든 Builder API는 동일합니다.

> **참고:** 제작법이 없거나 재료가 부족하거나 Crafting CPU가 없어 제작을 계획할 수 없더라도 `network:craft`는 항상 Builder를 반환합니다. 실패 여부는 `:connect` 콜백에 `nil`이 전달되는 것으로 확인할 수 있습니다.

## 기본 동작: 결과물 저장

메서드를 추가로 연결하지 않으면 완성된 아이템이 [Storage Card](../items-blocks/storage_card.md) 우선순위와 [`network:route`](network.md#route) 규칙에 따라 Network Storage로 자동 이동합니다. 이후 다른 저장 아이템처럼 `network:find`로 검색할 수 있습니다.

<LuaCode>
```lua
-- 결과를 기다리지 않고 Torch 16개를 제작해 저장소에 넣습니다
network:craft("minecraft:torch", 16)
```
</LuaCode>

## connect

완성된 아이템을 자동 저장하는 **대신** 콜백에 전달합니다. `:connect`를 호출하면 기본 자동 저장이 비활성화되고, 콜백에서 결과물을 직접 처리해야 합니다.

콜백 인자는 `ItemsHandle?`이며, 성공 시 [ItemsHandle](items-handle.md), 실패 시 `nil`이 전달됩니다. 사용하기 전에 반드시 확인하세요.

<LuaCode>
```lua
local oven = network:get("oven")
network:craft("minecraft:bread", 4):connect(function(items: ItemsHandle?)
  if not items then
    print("bread craft failed")
    return
  end
  oven:insert(items) -- 완성된 Bread를 Oven으로 바로 보냅니다
end)
```
</LuaCode>

제작 작업이 끝나면 콜백이 한 번 실행됩니다. 다음과 같은 실패는 `nil`로 전달됩니다.

- 계획 실패: 제작법이 없거나 재료가 부족하거나 네트워크에 Crafting CPU가 없습니다.
- 비동기 시간 초과: 처리 Handler가 결과물을 전달하지 않았습니다.
- CPU 연결 끊김: 제작 중 Crafting CPU가 파괴되거나 제거되었습니다.

어떤 이유로 실패하더라도 CPU 버퍼에 남아 있는 아이템은 Network Storage로 되돌려 보내므로 재료가 버퍼에 고립되지 않습니다.

### 결과물 이동은 직접 처리해야 합니다

콜백에 전달되는 Handle은 **Crafting CPU 버퍼에 아직 남아 있는 아이템을 직접 참조**합니다. `card:insert(items)` 또는 `network:insert(items)`를 호출하면 해당 아이템이 버퍼에서 목적지로 이동합니다.

콜백이 종료될 때 버퍼에 남아 있는 아이템은 **CPU 위치에 드롭**되고 터미널에 오류가 기록됩니다. Handle을 받았다면 아이템 이동까지 직접 책임져야 하며, 옮기지 못한 경우에도 조용히 넘어가지 않습니다.

<LuaCode>
```lua
local chest = network:get("ore_chest")
network:craft("minecraft:iron_ingot", 8):connect(function(items: ItemsHandle?)
  if not items then return end
  if not chest:insert(items) then
    -- 상자가 가득 찼으면 드롭하지 않고 네트워크 저장소로 보냅니다
    network:insert(items)
  end
end)
```
</LuaCode>

이 동작은 Storage Card를 통해 자동으로 전송하고 모든 Card가 거부할 때만 월드에 드롭하는 자동 저장 방식과 다릅니다. `:connect`를 사용하면 콜백이 목적지를 결정하며, 실제로 아이템을 이동시키는 것도 스크립트의 책임입니다.

> **참고:** 콜백 내부에서 발생한 오류는 터미널에 기록되지만, 스크립트의 나머지 부분은 중단되지 않습니다.

## connect가 동기적으로 실행되는 경우

재료가 이미 저장소에 있는 바닐라 제작법은 같은 틱에 완료될 수 있습니다. 이 경우에도 `:connect`가 등록될 시간을 확보하도록 `:craft` 호출보다 한 틱 뒤에 동일한 경로로 콜백이 실행됩니다. 동기 제작과 비동기 제작을 별도로 처리할 필요는 없습니다.

<LuaCode>
```lua
-- 즉시 제작되거나 제련에 30초가 걸려도 동일하게 동작합니다
network:craft("minecraft:iron_ingot", 8):connect(function(items: ItemsHandle?)
  if items then chest:insert(items) end
end)
```
</LuaCode>
