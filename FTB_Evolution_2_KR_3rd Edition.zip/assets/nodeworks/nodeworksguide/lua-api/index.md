---
navigation:
  title: Nodeworks 스크립트 API
  position: 40
---

# Nodeworks 스크립트 API

<BlockImage scale="6" id="terminal" float="left" />

Nodeworks는 스크립트 언어로 [Lua](https://www.lua.org/docs.html)를 사용합니다.
편집기는 스크립트를 실행하기 전에 다음과 같은 편의 기능을 처리합니다.

- **자료형 주석:** ( `local x: CardHandle`, `function(xs: { CardHandle }): ItemsHandle` 등 )
  - 변수, 매개변수, 반환값의 자료형을 편집기에 알려줍니다. 이를 통해 정확한 마우스 오버 도움말, 향상된 자동 완성, for 반복문 내부 요소의 자료형 추론을 사용할 수 있습니다.

## 내장 함수

<CategoryIndexDescriptions category="api_builtin" />

- [clock()](): 스크립트 실행 시작 후 경과한 시간(초, 소수 포함)
- [print(...)](): 터미널 출력에 기록
- [require(name)](): 같은 터미널의 다른 스크립트 탭을 이름으로 불러오기

## 프리셋

자주 사용하는 스케줄러 반복 작업을 한 줄의 메서드 체인으로 구성하는 선언형 빌더입니다.
공통 사용법은 [프리셋](presets.md)을 참고하세요.

<CategoryIndexDescriptions category="api_preset" />

## 자료형

<CategoryIndexDescriptions category="api_types" />
