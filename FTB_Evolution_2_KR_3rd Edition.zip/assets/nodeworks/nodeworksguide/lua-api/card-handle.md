---
navigation:
  parent: lua-api/index.md
  title: CardHandle
  icon: blank_card
categories:
  - api_types
description: 네트워크에 연결된 Card 하나를 참조하는 Handle
---

# CardHandle

네트워크에 있는 Card 하나를 참조합니다. [`network:get(alias)`](network.md#get) 또는 [`network:getAll(type)`](network.md#getAll)이 반환하는 [HandleList](handle-list.md)에서 얻을 수 있습니다.

<ItemImage scale="6" id="blank_card" />

---

## 속성

- **`.name`**
  - Card의 별칭(터미널 사이드바에 표시되는 이름과 동일)

---

## Inventory Cards <ItemImage scale="0.5" id="nodeworks:storage_card" /> <ItemImage scale="0.5" id="nodeworks:io_card" />

*IO Card와 Storage Card에 적용됩니다.* 두 Card는 동일한 Lua API를 제공하지만, 연결된 블록을 네트워크가 취급하는 방식은 다릅니다. 실제 월드에서의 동작은 <ItemLink id="storage_card" /> 및 <ItemLink id="io_card" />를 참고하세요.

### face

인접한 블록의 특정 면을 선택합니다. 화로의 입력면과 출력면처럼 면마다 다른 인벤토리를 가진 블록에서 유용합니다.

기본적으로 Card가 바라보는 면을 사용합니다.

<GameScene zoom="5" interactive={true} paddingLeft="50" paddingRight="60">
  <ImportStructure src="../assets/assemblies/furnace_and_terminal.snbt" />
  <BoxAnnotation min="0 0.9 0" max="1 1.1 1" color="#00ff00">
    `card:face("top")`
  </BoxAnnotation>
  <BoxAnnotation min="1.1 0 0" max="0.9 1 1" color="#00ff00">
    `card`
  </BoxAnnotation>
</GameScene>

<LuaCode>
```lua
local card = network:get("io_1")
card:insert(coal)
card:face("top"):insert(inputItem)
```
</LuaCode>

### slots

인덱스로 Card 인벤토리의 특정 슬롯만 선택합니다. 슬롯 번호는 1부터 시작합니다.

<ItemGrid>
  <ItemIcon id="minecraft:cobblestone" />
  <ItemIcon id="minecraft:stone" components="minecraft:enchantment_glint_override=true,custom_name=Selected" />
  <ItemIcon id="minecraft:oak_planks" />
  <ItemIcon id="minecraft:diorite" components="minecraft:enchantment_glint_override=true,custom_name=Selected" />
  <ItemIcon id="minecraft:deepslate" />
  <ItemIcon id="minecraft:stick" />
</ItemGrid>

<LuaCode>
```lua
local card = network:get("io_1")
card:slots(2, 4):find("*") -- Stone과 Diorite 슬롯만 선택합니다
```
</LuaCode>

### find

Card 인벤토리에서 필터와 일치하는 아이템이나 유체를 검색합니다. 필터 문법은 [`network:find`](network.md#find)와 동일하지만, 네트워크 전체의 Storage Card가 아니라 해당 Card의 슬롯과 탱크만 검색합니다.

<LuaCode>
```lua
local coalInCard = card:find("minecraft:coal")
if coalInCard then
  print(coalInCard.count, "coal in this card")
end
```
</LuaCode>

### findEach

[find](./card-handle.md#find)와 비슷하지만 [ItemsHandle](./items-handle.md) 목록을 반환합니다. 아이템 ID와 NBT 데이터의 조합이 다른 항목은 별도로 취급합니다.

예를 들어 네트워크에 마법이 부여된 Diamond Sword와 일반 Diamond Sword가 함께 있다면 서로 다른 항목으로 나뉩니다.

<ItemGrid>
  <ItemIcon id="minecraft:cobblestone" />
  <ItemIcon id="minecraft:cobblestone" />
  <ItemIcon id="minecraft:oak_planks" />
  <ItemIcon id="minecraft:cobblestone" />
  <ItemIcon id="minecraft:oak_planks" />
  <ItemIcon id="minecraft:stick" />
</ItemGrid>

<LuaCode>
```lua
local allItems = card:findEach("*")
for _, val in allItems do
  print(val.name)
end
-- Cobblestone
-- Oak Planks
-- Stick
```
</LuaCode>

### insert

아이템이나 유체를 이 Card의 인벤토리로 *넣습니다.* 요청한 수량을 모두 넣을 수 있을 때만 이동하며, 일부만 옮기지는 않습니다. 모두 이동하면 `true`, 공간이 부족하면 `false`를 반환합니다. [`network:insert`](network.md#insert)와 같지만 대상이 이 Card로 제한됩니다.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
if coal and card:insert(coal, 32) then
  print("stored 32 coal in this card")
end
```
</LuaCode>

### tryInsert

[`insert`](card-handle.md#insert)와 달리 가능한 만큼만 이동합니다. 실제 이동한 수량(0부터 요청 수량까지)을 반환하며, 들어가지 못한 나머지는 원래 위치에 남습니다. 일부 이동을 허용할 때 사용하세요.

<LuaCode>
```lua
local coal = network:find("minecraft:coal")
if coal then
  local moved = card:tryInsert(coal)
  print("moved", moved, "of", coal.count, "coal")
end
```
</LuaCode>

### count

이 Card 인벤토리에서 필터와 일치하는 총수량을 반환합니다. 유체는 mB 단위로 계산합니다.

필터 문법은 [find](network.md#find)와 완전히 동일합니다.

<LuaCode>
```lua
print(card:count("#minecraft:coals"))
```
</LuaCode>

---

## Redstone Card <ItemImage scale="0.5" id="nodeworks:redstone_card" />

*<ItemLink id="redstone_card" />에만 적용됩니다.* 위의 인벤토리 메서드는 사용할 수 없으며, Redstone Card에서 `card:find()`는 `nil`을 반환합니다.

### powered

입력 Redstone 신호가 0보다 크면 `true`를 반환합니다.

<GameScene zoom="5" interactive={true} paddingTop="10" paddingLeft="60" paddingRight="30">
  <ImportStructure src="../assets/assemblies/redstone_read_lever.snbt" />
  <BoxAnnotation min="1.2 0.2 1.2" max="1 0.8 1.8" color="#F53B68">
    <ItemImage id="nodeworks:redstone_card" />
  </BoxAnnotation>
</GameScene>

<LuaCode>
```lua
local card = network:get("redstone_1")
print(card:powered())
-- true
```
</LuaCode>

### strength

입력 Redstone 신호 강도를 0~15 범위의 숫자로 반환합니다.

<GameScene zoom="5" interactive={true} paddingTop="10" paddingBottom="40" paddingLeft="60" paddingRight="30">
  <ImportStructure src="../assets/assemblies/redstone_read_strength.snbt" />
  <BoxAnnotation min="3.2 1.2 0.2" max="3 1.8 0.8" color="#F53B68">
    <ItemImage id="nodeworks:redstone_card" />
  </BoxAnnotation>
</GameScene>

<LuaCode>
```lua
local card = network:get("redstone_1")
print(card:strength())
-- "14"
```
</LuaCode>

### set

Redstone 신호를 출력합니다. <ItemLink id="minecraft:lever" />와 마찬가지로 Boolean 값은 15 또는 0으로 변환하며, 숫자는 0~15 범위로 제한합니다.

<GameScene zoom="5" interactive={true} paddingTop="10" paddingLeft="60" paddingRight="30">
  <ImportStructure src="../assets/assemblies/redstone_set_true.snbt" />
  <BoxAnnotation min="3 1 0.2" max="4 1.1 0.8">
    신호 강도 15
  </BoxAnnotation>
  <BoxAnnotation min="4.2 1.2 0.2" max="4 1.8 0.8" color="#F53B68">
    <ItemImage id="nodeworks:redstone_card" />
  </BoxAnnotation>
  <RemoveBlocks id="minecraft:stone" />
</GameScene>

<LuaCode>
```lua
local card = network:get("redstone_1")
card:set(true) -- Lever처럼 신호 강도 15를 출력합니다
card:set(false) -- 출력 신호를 0으로 설정합니다
```
</LuaCode>

출력할 신호 강도를 숫자로 직접 지정할 수도 있습니다.

<GameScene zoom="5" interactive={true} paddingTop="10" paddingLeft="60" paddingRight="30">
  <ImportStructure src="../assets/assemblies/redstone_set_low.snbt" />
  <BoxAnnotation min="3 1 0.2" max="4 1.1 0.8">
    신호 강도 3
  </BoxAnnotation>
  <BoxAnnotation min="4.2 1.2 0.2" max="4 1.8 0.8" color="#F53B68">
    <ItemImage id="nodeworks:redstone_card" />
  </BoxAnnotation>
  <RemoveBlocks id="minecraft:stone" />
</GameScene>

<LuaCode>
```lua
local card = network:get("redstone_1")
card:set(3)
```
</LuaCode>

### onChange

입력 Redstone 신호 강도가 바뀔 때마다 실행되는 콜백을 등록합니다.

<GameScene zoom="5" interactive={true} paddingTop="10" paddingLeft="60" paddingRight="30">
  <ImportStructure src="../assets/assemblies/redstone_onchange.snbt" />
  <BoxAnnotation min="3.2 1.2 0.2" max="3 1.8 0.8" color="#F53B68">
    <ItemImage id="nodeworks:redstone_card" />
  </BoxAnnotation>
  <BoxAnnotation min="0 1 0" max="3 2 2">
    Redstone 시계/펄스 발생기
  </BoxAnnotation>
</GameScene>

<LuaCode>
```lua
local card = network:get("redstone_1")
-- Redstone Torch가 켜지거나 꺼질 때 "state changed"를 출력합니다
local lastPowered = card:powered()
card:onChange(function(strength: number)
    local powered = strength > 0
    if lastPowered == powered then
        return
    end
    lastPowered = powered
    print("state changed")
end)
```
</LuaCode>

> **팁:** `:onChange`를 사용할 때는 <ItemLink id="terminal" />의 ["Autorun"](../items-blocks/scripting_terminal.md#autorun)도 켜 두는 것이 좋습니다.

![](../assets/images/autorun.png)

## Observer Card <ItemImage scale="0.5" id="nodeworks:observer_card" />

*<ItemLink id="observer_card" />에만 적용됩니다.* 위의 인벤토리 메서드는 사용할 수 없으며, Observer Card의 `card:find()`는 `nil`입니다. 이 Card는 설치된 면 앞의 블록을 감시하고 블록 ID, 속성 및 변경 이벤트를 제공합니다.

### block

감시 중인 위치의 블록 ID를 `"namespace:path"` 문자열로 반환합니다.

<LuaCode>
```lua
local watcher = network:get("watcher_1")
print(watcher:block())
-- "nodeworks:celestine_cluster"
```
</LuaCode>

감시 중인 청크가 로드되지 않았더라도 캐시된 블록을 반환합니다(읽을 때 Minecraft가 청크를 로드합니다). 많은 블록을 감시하는 스크립트에서는 매 틱 `:block()`을 호출하기보다 `:onChange`를 사용하는 편이 좋습니다.

### state

감시 중인 블록의 속성 테이블을 반환합니다. 키는 `age`, `facing`, `waterlogged`, `lit`, `axis` 등의 속성 이름이며, 값은 속성 유형에 따라 숫자·Boolean·소문자 문자열입니다. 공기처럼 속성이 없는 블록은 빈 테이블을 반환합니다.

<LuaCode>
```lua
local s = network:get("watcher_1"):state()
if s.age == 3 then
    print("fully grown")
end
```
</LuaCode>

블록마다 제공하는 속성이 다르므로 `state()`의 결과도 감시 중인 블록에 따라 달라집니다. 블록 종류에 따라 분기해야 한다면 먼저 `:block()`을 확인하세요.

### data

감시 중인 블록 엔티티의 저장 데이터를 중첩 테이블로 반환하며, 블록 엔티티가 없다면 `nil`을 반환합니다. 화로의 연료 및 조리 진행도, 상자의 아이템, 기계의 에너지와 제작법 상태 등 블록이 디스크에 저장하는 데이터가 대상입니다. 키 이름은 모드마다 다르므로 실제 반환값을 확인하세요.

<LuaCode>
```lua
local dat = network:get("reactorWatcher"):data()
if dat and dat.heat > 75 then
    network:get("reactorRedstoneCard"):set(false)
end
```
</LuaCode>

숫자와 문자열은 원래 형태로 전달됩니다. NBT에는 Boolean이 없으므로 플래그는 `0` 또는 `1`로 표시됩니다. 목록은 1부터 시작하는 테이블입니다. 저장된 값이 8192개를 넘으면 데이터가 잘리고 `truncated = true`가 설정됩니다.

데이터는 블록당 최대 1초에 한 번 읽기 때문에 매 틱 확인해도 부담이 적지만, 표시되는 값은 최대 1초 전 정보일 수 있습니다. 블록이 교체되면 즉시 다시 읽습니다. 메모리에만 존재하고 저장되지 않는 데이터는 포함되지 않습니다.

### energy

에너지 저장 기능이 있는 블록에서는 `EnergyInfo`를, 그렇지 않으면 `nil`을 반환합니다. `stored`와 `capacity` 두 필드를 가지며 단위는 FE입니다. 값을 읽기 전에 `nil`인지 확인하세요. `:data()`와 달리 항상 최신 값입니다.

<LuaCode>
```lua
local e = network:get("battery_watch"):energy()
if e and e.stored < e.capacity * 0.1 then
    network:get("generator_switch"):set(true) -- Variable을 설정합니다
end
```
</LuaCode>

### onChange

감시 중인 블록 ID나 상태 속성이 바뀔 때 실행되는 콜백을 등록합니다. 같은 Card에 등록된 이전 Handler는 교체됩니다. 새 블록 ID와 속성 테이블을 인자로 받습니다.

<LuaCode>
```lua
local watcher = network:get("watcher_1")
local breaker = network:get("breaker_1")

watcher:onChange(function(block: string, state: { [string]: any })
    if block == "nodeworks:celestine_cluster" then
        breaker:set(true)
        scheduler:delay(2, function() breaker:set(false) end)
    end
end)
```
</LuaCode>

등록 직후 첫 번째 확인에서는 마지막 상태만 조용히 저장합니다. 따라서 스크립트를 다시 시작해도 이미 현재 상태였던 블록에 대해 가짜 변경 이벤트가 발생하지 않습니다.

> **팁:** Redstone `:onChange`와 마찬가지로 자동 실행을 권장합니다. <ItemLink id="terminal" />의 ["Autorun"](../items-blocks/scripting_terminal.md#autorun)을 켜 두면 재접속 후에도 Handler가 계속 실행됩니다.
