---
navigation:
  parent: lua-api/index.md
  title: Stocker
  icon: minecraft:observer
categories:
  - api_types
  - api_preset
description: 저장소에서 가져오거나 제작하여 목적지의 재고를 유지합니다
---

# Stocker

전역 객체 `stocker`는 지정한 수량의 재고를 유지하는 작업을 만듭니다. 목적지 컨테이너, 목표 수량 `:keep(n)`, 공급 방식(저장소에서 가져오기, 제작, 둘 다)을 지정하면 재고가 목표보다 적어질 때 자동으로 보충합니다. 목표에 도달한 뒤에는 아이템을 꺼내지 않으며, 플레이어가 추가로 넣은 아이템도 그대로 둡니다.

## 세 가지 공급 방식

아이템을 어디서 가져올지에 따라 다음 세 가지 메서드 중 하나로 Stocker 체인을 시작합니다.

### from

<LuaCode>
```lua
Stocker:from(...sources: string | CardHandle | network): StockerBuilder
```
</LuaCode>

특정 Card나 네트워크 저장소에서 아이템을 가져옵니다. 부족하더라도 제작하지 않습니다. 특정 버퍼 상자에서만 가져오거나 저장소가 비어 있으면 기다리는 경우에 적합합니다. [`:filter`](./stocker.md#filter)를 사용하면 특정 아이템만 대상으로 지정할 수 있으며, 필터가 없으면 아이템 종류와 관계없이 총수량을 `:keep(n)`까지 채웁니다.

<LuaCode>
```lua
-- 지정한 두 상자에서 Arrow를 가져옵니다
stocker:from("chest1", "chest2"):filter("$item:arrow"):to("dispenser"):keep(64):start()

-- 네트워크 저장소에서 가져오며, 재고가 없으면 기다립니다
stocker:from(network):filter("$item:arrow"):to("dispenser"):keep(64):start()
```
</LuaCode>

### ensure

<LuaCode>
```lua
Stocker:ensure(itemId: string): StockerBuilder
```
</LuaCode>

네트워크 저장소에서 먼저 가져오고 부족한 수량은 제작합니다. 특정 아이템을 항상 N개 유지할 때 가장 흔히 사용하는 방식입니다. 제작 계획에는 정확한 결과물이 필요하므로 아이템 ID를 명시해야 합니다.

<LuaCode>
```lua
stocker:ensure("minecraft:arrow"):to("dispenser"):keep(64):start()
stocker:ensure("minecraft:iron_ingot"):to(network):keep(256):start()
```
</LuaCode>

### craft

<LuaCode>
```lua
Stocker:craft(itemId: string): StockerBuilder
```
</LuaCode>

기존 저장소의 아이템을 사용하지 않고 항상 제작하여 재고를 유지합니다. 새 결과물을 확보해야 하거나 공유 상자에서 가져오는 대신 제작으로 보충하고 싶을 때 유용합니다.

<LuaCode>
```lua
stocker:craft("minecraft:bread"):to("foodChest"):keep(16):start()
```
</LuaCode>

## 필수 메서드

### to

<LuaCode>
```lua
StockerBuilder:to(target: string | CardHandle | network): StockerBuilder
```
</LuaCode>

목적지를 지정합니다. Card 별칭, CardHandle 객체 또는 네트워크 저장소 자체의 수량을 유지하는 `network`를 사용할 수 있습니다. Stocker는 목적지의 일치하는 아이템 수량을 계산하며, `network`를 지정하면 모든 Storage Card의 수량을 합산합니다. Storage Card의 자체 규칙도 적용되므로 허용된 아이템만 들어갑니다.

### keep

<LuaCode>
```lua
StockerBuilder:keep(amount: number): StockerBuilder
```
</LuaCode>

목표 재고 수량입니다. Stocker는 이 수량까지 채우고 멈춥니다. 플레이어나 다른 스크립트가 아이템을 추가해 목표 수량을 초과해도 아무 작업을 하지 않습니다. Stocker는 보충만 하며 아이템을 빼내지 않습니다.

## 선택 메서드

### filter

`:keep(n)` 수량에 포함할 아이템과 `:from`으로 가져올 아이템을 지정합니다. 생략하면 모든 아이템을 계산합니다. 여러 규칙을 전달하거나 여러 번 호출하거나 테이블로 지정할 수 있습니다. 인자 없이 호출하면 초기화됩니다. **`:ensure`와 `:craft`는 필터를 자동으로 설정**하므로 `:from`을 사용할 때만 직접 지정하면 됩니다.

<LuaCode>
```lua
stocker
  :from("buffer")
  :filter("$item:arrow")
  :to("dispenser")
  :keep(64)
  :start()
```
</LuaCode>

### except

`:filter`에 일치하더라도 수량 계산과 가져오기 대상에서 제외할 아이템을 지정합니다.

<LuaCode>
```lua
-- Arrow 한 스택을 유지하되 Tipped Arrow는 제외합니다
stocker:from("buffer")
  :filter("#minecraft:arrows")
  :except("minecraft:tipped_arrow")
  :to("dispenser")
  :keep(64)
  :start()
```
</LuaCode>

### batch

<LuaCode>
```lua
StockerBuilder:batch(size: number): StockerBuilder
```
</LuaCode>

제작 요청을 지정한 묶음 크기로 합칩니다. 기본값 `0`은 부족한 수량만 정확히 제작한다는 뜻입니다(3개 부족하면 3개 제작). `:batch(64)`로 설정하면 한 번에 64개씩 제작합니다. 여러 재료나 단계를 거치는 제작법처럼 준비 비용이 큰 작업에서 작은 제작 요청이 반복되어 CPU에 부담을 주는 상황을 줄일 수 있습니다.

<LuaCode>
```lua
stocker:craft("minecraft:iron_ingot"):to("chest"):keep(64):batch(32):start()
-- 10개가 부족해도 32개를 제작하므로 완료 직후 재고가 일시적으로 74개가 될 수 있습니다.
```
</LuaCode>

묶음 제작으로 인해 목적지의 수량이 일시적으로 `:keep(n)`을 초과할 수 있습니다. 이후 재고가 다시 목표 아래로 내려갈 때까지 추가 작업을 하지 않습니다.

## 예시: 부족하면 제작하는 Arrow Dispenser

<LuaCode>
```lua
stocker:ensure("minecraft:arrow")
  :to("trapDispenser")
  :keep(64)
  :batch(16)
  :every(20)
  :start()
```
</LuaCode>

매초 Dispenser의 Arrow가 64개 미만이면 네트워크 저장소에서 먼저 가져옵니다. 그래도 부족하면 16개를 추가 제작합니다. Dispenser가 채워질 때까지 반복합니다.

## 관련 문서

* [Preset 공통 메서드](presets.md#shared-methods) (`:every`, `:start`, `:stop`, `:isRunning`)
* 목표 수량 없이 A에서 B로 계속 이동하는 기능은 [Importer](importer.md)를 참고하세요.
* 기본 제작 기능은 [Network:craft](network.md#craft)를 참고하세요.
