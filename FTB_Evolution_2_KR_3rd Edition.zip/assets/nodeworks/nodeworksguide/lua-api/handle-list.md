---
navigation:
  parent: lua-api/index.md
  title: HandleList
  icon: minecraft:red_bundle
categories:
  - api_types
description: getAll로 얻는 Card 또는 Variable의 일괄 처리 목록
---

# HandleList

`HandleList<T>`는 **모든 구성원에 쓰기 메서드를 한 번에 적용하는** Card 또는 Variable 목록입니다. [`network:getAll(type)`](network.md#getAll)이나 [`Channel:getAll(type)`](network.md#channel-getall)로 얻습니다.

목록에 쓰기 메서드를 호출하면 동일한 인수로 각 구성원에 순서대로 실행됩니다. 읽기 메서드는 목록에서 사용할 수 없습니다. 읽기 메서드의 반환값을 여러 구성원에 대해 조용히 버리는 오류를 방지하기 위해서입니다. 개별 값을 읽으려면 `:list()`로 목록을 가져와 순회하세요.

<LuaCode>
```lua
-- 빨간색 채널의 모든 피스톤을 한 번에 켭니다.
network:channel("red"):getAll("redstone"):set(true)
-- 모든 Observer에 동일한 onChange 핸들러를 등록합니다.
network:getAll("observer"):onChange(function(block, state)
    if block == "nodeworks:celestine_cluster" then
        -- ...
    end
end)
```
</LuaCode>

## 일괄 실행되는 메서드

반환값에 의존하지 않는 **쓰기 메서드**만 목록 전체에 적용됩니다. `:powered()`, `:count()`, `:get()`, `:block()`과 같은 읽기 메서드는 제공되지 않습니다. 구성원별로 값을 읽으려면 `:list()`를 호출한 다음 각 항목을 확인하세요.

어떤 메서드가 읽기 또는 쓰기 작업인지에 대한 정확한 정보는 [RedstoneCard](card-handle.md#redstone-card), [VariableHandle](variable-handle.md) 등 각 종류의 문서를 참고하세요.

## list

내부 배열을 반환합니다. 구성원별로 순회하거나 값을 읽고, 일괄 호출로 표현하기 어려운 개별 작업을 수행할 때 사용합니다.

<LuaCode>
```lua
local pistons = network:channel("red"):getAll("redstone")
for _, p in pistons:list() do
    if p:powered() then
        print(p.name, "is currently powered")
    end
end
```
</LuaCode>

## count

목록에 포함된 구성원의 수를 반환합니다. 배열을 만들지 않으므로 `#list:list()`보다 효율적입니다.

<LuaCode>
```lua
local watchers = network:getAll("observer")
print(watchers:count(), "observer cards on the network")
```
</LuaCode>

## face

Card 구성원의 접근 면을 `name`으로 바꾼 새 HandleList를 반환합니다. 원래 목록은 변경되지 않고 반환된 복사본에만 적용됩니다. [CardHandle](card-handle.md)이 아닌 Variable, Breaker, Placer는 그대로 전달되며, 해당 Handle은 면 설정을 무시합니다.

이 설정은 목록을 [Importer](importer.md) 또는 [Stocker](stocker.md) Preset에 전달할 때도 유지됩니다. 따라서 와일드카드로 여러 Card를 선택한 뒤 한 번의 표현식으로 기본값이 아닌 면에서 읽거나 쓸 수 있습니다.

<LuaCode>
```lua
-- 모든 io_* Card의 화로 아래쪽 면에서 결과물을 꺼내 출력 상자로 보냅니다
importer:from(network:cards("io_*"):face("bottom")):to("output"):start()
```
</LuaCode>

[`CardHandle:face`](card-handle.md#face)와 같은 기능을 목록 전체에 한 번에 적용합니다.