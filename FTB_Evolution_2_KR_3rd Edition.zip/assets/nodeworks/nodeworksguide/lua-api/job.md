---
navigation:
  parent: lua-api/index.md
  title: Job
  icon: minecraft:paper
categories:
  - api_types
description: [network:handle 콜백](network.md#handle)의 첫 번째 인자로, Handler가 결과물을 생성해야 하는 처리 작업을 나타냅니다
---

# Job

`Job`은 [`network:handle`](network.md#handle) 함수가 받는 첫 번째 인자입니다. 네트워크가 Processing Set의 제작법을 실행할 때마다 새로운 `Job`과 저장소에서 가져온 [아이템](input-items.md)을 Handler에 전달합니다. Handler는 재료를 기계에 넣은 다음 `job:pull(card)`를 호출해 완성된 아이템을 어디서 가져올지 네트워크에 알려줍니다.

## pull

완성된 아이템이 나올 위치를 네트워크에 지정합니다. 하나 이상의 [CardHandle](card-handle.md)을 전달하면 네트워크가 지정한 위치를 감시하여 결과물을 필요한 수량만큼 수집합니다.

결과물이 이미 Card 중 하나에 들어 있다면(즉시 제작법, 형태가 없는 조합법 등) 같은 틱에 제작이 끝납니다. 그렇지 않으면 네트워크가 매 틱 확인하여 생성된 결과물을 차례대로 가져옵니다. 따라서 화로에서 주괴가 한 개씩 나와도 정상적으로 작동합니다.

<LuaCode>
```lua
local furnace = network:get("furnace")
network:handle("...", function(job: Job, items: InputItems)
  furnace:face("top"):insert(items.rawIron)
  -- 제련이 완료되면 아래쪽 면에서 결과물을 가져옵니다
  job:pull(furnace:face("bottom"))
end)
```
</LuaCode>

### 여러 출력 Card

완성된 아이템이 여러 위치 중 어디로든 나올 수 있다면 Card를 여러 개 전달하세요. 네트워크가 각 Card를 순서대로 확인하여 아이템이 있는 곳에서 가져옵니다. 파이프나 Hopper가 아이템 종류에 따라 서로 다른 상자로 결과물을 보내는 경우에 유용합니다.

<LuaCode>
```lua
local furnace = network:get("furnace")
local outboxA = network:get("outbox_a")
local outboxB = network:get("outbox_b")
network:handle("...", function(job: Job, items: InputItems)
  furnace:face("top"):insert(items.rawIron)
  -- 완성된 주괴가 두 상자 중 하나로 분류되므로 양쪽 모두 확인합니다
  job:pull(outboxA, outboxB)
end)
```
</LuaCode>

### 먼저 재료를 넣으세요

`:pull`은 출력 측만 처리합니다. [InputItems](input-items.md)는 직접 기계에 넣어야 합니다. Handler가 종료될 때 `items.<slot>`에 재료가 남아 있으면 제작이 완료되지 않은 것으로 간주되어 네트워크가 제작법을 다시 시도합니다.

### 시간 초과

결과물이 끝내 나타나지 않으면 작업 시간이 초과되고 재료가 저장소로 반환됩니다. Processing Set마다 GUI에서 틱 단위로 시간 제한을 설정할 수 있으며, 기본값은 15초입니다. 대량 제련이나 여러 초가 걸리는 모드 제작법처럼 느린 기계에는 제한 시간을 늘리세요.

> **참고:** Handler 내부 오류는 *해당 제작 작업만* 중단하며 스크립트의 나머지 부분에는 영향을 주지 않습니다. 제작이 예상치 못하게 멈춘다면 터미널 로그에서 오류를 확인하세요.

## recipe

`Job`에는 실행 중인 Processing Set 정보도 들어 있습니다. 따라서 [`network:recipes`](network.md#recipes) Handler처럼 여러 제작법을 처리하는 하나의 Handler에서도 제작법에 따라 다른 동작을 수행할 수 있습니다.

- `job.name`: Processing Set 이름이며 `network:handle`에 전달하는 이름과 같습니다.
- `job.inputs`: 슬롯 순서대로 정리된 입력 재료 목록입니다. 각 항목에는 `id`, `count`가 있으며, 태그의 아무 아이템이나 허용하는 경우 `tag`도 포함됩니다.
- `job.outputs`: 결과물 목록입니다. 각 항목에는 `id`, `count`, `optional`이 있으며, 확률적 결과물일 경우 `optional`이 `true`입니다.

<LuaCode>
```lua
local furnace = network:get("furnace")
local blast = network:get("blast_furnace")
network:recipes("#c:raw_materials"):handle(function(job: Job, items: InputItems)
  -- Iron은 Blast Furnace로, 나머지는 일반 Furnace로 보냅니다.
  local machine = furnace
  if job.outputs[1].id == "minecraft:iron_ingot" then machine = blast end
  for _, input in ipairs(items:all()) do
    machine:face("top"):insert(input)
  end
  job:pull(machine:face("bottom"))
end)
```
</LuaCode>
