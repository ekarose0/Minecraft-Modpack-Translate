---
navigation:
  parent: lua-api/index.md
  title: Presets
  icon: terminal
categories:
  - api_builtin
description: 일반적인 아이템 이동 및 재고 유지에 사용하는 선언형 Builder(importer, stocker)
---

# Presets

Preset은 자주 사용하는 두 가지 스크립트 동작인 **A에서 B로 아이템 이동**과 **일정 재고량 유지**를 간단하게 작성하는 선언형 Builder입니다. 각 Preset은 왼쪽부터 순서대로 읽을 수 있는 메서드 체인으로 구성되며, 마지막에 `:start()`를 호출해 시작합니다.

Preset은 기존 스크립트 API를 기반으로 합니다. 여전히 Lua를 사용하며 Card와 필터도 같은 방식으로 처리하고, 스크립트가 종료되면 함께 중단됩니다. 차이점은 상태를 직접 관리하는 Scheduler 반복문 약 15줄을 Preset 한 줄로 대체할 수 있다는 것입니다.

<LuaCode>
```lua
-- 매초 농장 상자에서 Cobblestone을 Network Storage로 옮깁니다.
importer:from("mobFarm"):filter("$item:cobblestone"):to(network):start()
-- Dispenser에 Arrow 64개를 유지하며, 부족하면 추가 제작합니다.
stocker:ensure("minecraft:arrow"):to("dispenser"):keep(64):start()
```
</LuaCode>

## 사용 가능한 Preset

* [Importer](importer.md): 하나 이상의 출발지에서 하나 이상의 목적지로 아이템을 이동합니다. 기본적으로 목적지를 차례대로 채우며, `:roundrobin()`을 호출하면 목적지를 순환하며 분배합니다.
* [Stocker](stocker.md): 저장소에서 가져오거나 제작하거나 두 방식을 함께 사용해 목적지의 재고를 `:keep(n)` 수량으로 유지합니다. 목표 수량에 도달한 뒤에는 아이템을 꺼내지 않습니다.

## 출발지 및 목적지 참조

Preset에서 출발지나 목적지를 지정할 때는 다음 세 가지 형식을 사용할 수 있습니다.

1. Card의 별칭을 나타내는 **문자열**: `"bufferChest"`
2. `network:get(...)`으로 가져온 **CardHandle**
3. 전체 Network Storage를 의미하는 전역 객체 **`network`**

<LuaCode>
```lua
-- 세 형식은 모두 유효하며 함께 사용할 수 있습니다.
importer:from("farm", network:get("secondary"), network)
  :to("output")
  :start()
```
</LuaCode>

네트워크 연결 구조가 바뀔 때마다 Card를 이름으로 다시 찾습니다. 따라서 Card가 파괴되었다가 같은 이름으로 다시 설치되어도 Preset을 재시작하지 않고 계속 작동합니다. 없는 Card는 다시 나타날 때까지 조용히 건너뜁니다.

## 공통 메서드

`ImporterBuilder`와 `StockerBuilder`는 동일한 실행 상태 및 제어 메서드를 지원합니다.

### every

<LuaCode>
```lua
ImporterBuilder:every(ticks: number): ImporterBuilder
StockerBuilder:every(ticks: number): StockerBuilder
```
</LuaCode>

Preset이 상태를 다시 확인하는 간격을 설정합니다. 기본값은 20틱(1초)입니다. 실행 중 간격을 바꾸면 기존 Scheduler 작업을 취소하고 새 간격으로 다시 등록하므로 `imp:every(5)`가 즉시 적용됩니다.

### start / stop / isRunning

<LuaCode>
```lua
ImporterBuilder:start()
ImporterBuilder:stop()
ImporterBuilder:isRunning(): boolean
```
</LuaCode>

`:start()`는 메서드 체인을 검사하고 실행을 시작합니다. 이미 실행 중이면 아무 작업도 하지 않으므로 반복 호출해도 안전합니다. `:stop()`은 실행만 중단하고 설정은 유지하므로, 나중에 `:start()`를 호출하면 Round Robin의 현재 위치를 포함해 같은 설정으로 다시 시작합니다.

<LuaCode>
```lua
local imp = importer:from("src"):to("dst")
scheduler:second(function()
  if someCondition() and not imp:isRunning() then
    imp:start()
  elseif imp:isRunning() and not someCondition() then
    imp:stop()
  end
end)
```
</LuaCode>

## 스크립트 종료 시 정리

Scripting Terminal이 수동으로 중지되거나 네트워크 연결이 끊기면, 해당 스크립트에서 등록한 모든 Preset이 자동으로 중단됩니다. 생성했지만 `:start()`를 호출하지 않은 Builder도 정리됩니다. 스크립트를 다시 시작하면 모든 Preset이 처음부터 재생성되므로 이전 작업이 남아 있을 걱정 없이 코드를 수정할 수 있습니다.
