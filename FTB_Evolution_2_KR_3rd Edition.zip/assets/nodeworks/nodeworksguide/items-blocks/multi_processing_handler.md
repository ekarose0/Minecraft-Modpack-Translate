---
navigation:
  parent: items-blocks/index.md
  icon: multi_processing_handler
  title: Multi-Processing Handler
categories:
  - autocrafting
  - requires_controller
description: 하나의 Handler로 여러 Processing Set 제작법을 처리합니다
item_ids:
- nodeworks:multi_processing_handler
---

# Multi-Processing Handler

여러 [Processing Set](./recipe_sets.md#processing-set) 제작법을 한 번에 처리하는 <ItemLink id="processing_handler" />입니다. 화로 여러 대 앞에 Handler 하나를 두고 여러 광석 제작법을 연결하면, Lua 스크립트나 제작법별 별도 Handler 없이 [Crafting CPU](./crafting_cpu.md)가 각 제작 작업을 처리합니다.

> 사용하려면 <ItemLink id="network_controller" />가 필요합니다.

<GameScene zoom="3" interactive={true} paddingLeft="50" paddingRight="50" paddingTop="30">
  <IsometricCamera yaw="160" roll="0" pitch="10" />
  <ImportStructure src="../assets/assemblies/multi_processor_handler.snbt" />
  <BoxAnnotation min="0 2 0" max="1 2.25 1" color="#3C44AA">
    <ItemImage id="storage_card" /> 파란색 채널의 Storage Card
  </BoxAnnotation>
  <BoxAnnotation min="0 0.75 0" max="1 1 1" color="#B02E26">
    <ItemImage id="storage_card" /> 빨간색 채널의 Storage Card
  </BoxAnnotation>
  <BlockAnnotation x="2" y="1">
    여러 제련 제작법을 처리하도록 설정한 모습입니다.
  </BlockAnnotation>
</GameScene>

## 두 방향의 연결

Processing Handler와 같은 구조입니다. **뒷면**은 상위 네트워크에 연결하고, **앞면**에는 기계 주변의 파이프, Node, Storage Card로 구성된 마이크로 네트워크를 연결합니다. 구성 방법은 [두 방향의 연결](./processing_handler.md#two-sides)을 참고하세요.

## 제작법 선택하기

Handler를 우클릭하면 상위 네트워크에 있는 모든 Processing Set이 체크박스와 함께 표시됩니다. 이 Handler가 처리할 제작법에 체크하세요. 선택한 제작법은 목록 위쪽에 정렬되며, 검색창에서 제작법이나 아이템 이름으로 필터링할 수 있습니다.

화면 구석의 숫자는 허용 한도 중 몇 개의 제작법을 선택했는지 보여줍니다. 스크립트나 다른 Handler가 이미 맡은 제작법은 회색으로 표시되며, 한도에 도달하면 나머지 제작법도 선택할 수 없습니다.

선택했던 제작법을 Processing Storage에서 제거하면 목록에 누락된 제작법으로 표시되므로 체크를 해제할 수 있습니다. 해당 Set을 다시 넣으면 제작법이 다시 활성화됩니다.

## 채널

모든 제작법이 **입력 채널 하나와 출력 채널 하나**를 공유합니다. 선택된 제작법의 재료는 입력 채널 색상과 일치하는 마이크로 네트워크의 <ItemLink id="storage_card" />로 보내지고, 완성품은 출력 채널 색상의 카드에서 회수됩니다. 화로 여러 대를 사용한다면 각 화로 위에 파란색 카드, 아래에 빨간색 카드를 하나씩 설치하는 식입니다.

모든 재료가 같은 채널로 들어오므로 실제 분류는 카드에서 처리합니다. Storage Card마다 [필터](./storage_card.md#filters)를 설정하면 조건에 맞는 아이템만 해당 블록에 들어갑니다. 예를 들어 각 화로 옆의 카드에서는 `#c:coal`을 허용해 연료를 받고, 위쪽 카드에서는 이를 거부해 광석만 받게 할 수 있습니다. 두 카드 모두 파란색 채널을 사용합니다.

![](../assets/images/in_out_channels.png)

## 병렬 모드

기본적으로 Handler는 한 번에 제작 작업 하나만 실행합니다. 따라서 같은 제작 계통에 있는 두 제작법이 화로를 동시에 사용하려 하지 않고 순서대로 대기하며, 기다리는 Co-Processor는 다른 작업을 수행할 수 있습니다. 여러 작업을 동시에 실행하려면 **Parallel** 스위치를 켜세요.

![](../assets/images/parallel_toggle.png)

## Processing Handler와 비교

하나의 제작법에 전용 기계가 필요하거나 재료마다 별도 채널이 필요하다면 <ItemLink id="processing_handler" />를 사용하세요. 여러 제작법이 동일한 기계 묶음을 공유하고 같은 경로로 처리된다면 Multi-Processing Handler가 적합합니다.

## 제작법

<RecipeFor id="multi_processing_handler" />
