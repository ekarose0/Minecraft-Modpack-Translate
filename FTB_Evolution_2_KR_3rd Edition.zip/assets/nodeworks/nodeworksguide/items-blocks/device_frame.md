---
navigation:
  parent: items-blocks/index.md
  icon: device_frame
  title: Device Frame
categories:
  - device
description: 장치 제작에 사용하는 주요 재료
item_ids:
- nodeworks:device_frame
---

# Device Frame

모든 [Device](../nodeworks-mechanics/devices.md)를 제작하는 데 사용하는 재료입니다.

<BlockImage scale="6" id="device_frame" />

## 제작법

<RecipeFor id="device_frame" />