---
navigation:
  parent: items-blocks/index.md
  icon: placer
  title: Placer
categories:
  - device
description: 네트워크의 아이템을 사용해 블록을 설치하는 장치
item_ids:
- nodeworks:placer
---

# Placer Block

Placer는 자신의 앞쪽에 블록 형태의 아이템을 설치합니다. 스크립트에서 아이템 ID를 지정하거나 [ItemsHandle](../lua-api/items-handle.md)을 전달하면, [네트워크 저장소](../nodeworks-mechanics/network-storage.md)에서 일치하는 아이템을 가져와 설치합니다. 동기 방식으로 작동하므로 요청한 틱에 `true` 또는 `false` 결과를 반환합니다.

<BlockImage scale="6" id="placer" />

## 블록 설치

Placer의 앞면은 설치할 때 바라보던 방향을 향합니다(피스톤이나 발사기와 유사). 설치한 블록은 그 면 바로 앞에 놓입니다. 블록 형태의 아이템만 사용할 수 있으며 도구, 음식 등은 설치에 실패합니다.

## 블록 필터

Placer의 GUI에는 설치할 블록을 지정하는 슬롯이 있습니다. Placer가 작동할 때마다 [네트워크 저장소](../nodeworks-mechanics/network-storage.md)에서 일치하는 아이템을 가져옵니다. 슬롯을 비워 두면 스크립트가 특정 블록을 요청할 때까지 대기합니다.

## 레드스톤

GUI에서 Placer의 작동 조건을 설정합니다.

- **High**: 레드스톤 신호가 있을 때 작동합니다.
- **Low**: 레드스톤 신호가 없을 때 작동합니다.
- **Ignored**: 레드스톤 신호를 무시하며 스크립트에서 호출할 때만 작동합니다.

## 채널

Placer의 GUI에서 이름과 채널을 지정할 수 있습니다. 어떤 스크립트가 장치를 제어할 수 있는지는 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 스크립트

스크립트 API는 [PlacerHandle](../lua-api/placer-handle.md) 페이지를 참고하세요.

## 제작법

<RecipeFor id="placer" />
