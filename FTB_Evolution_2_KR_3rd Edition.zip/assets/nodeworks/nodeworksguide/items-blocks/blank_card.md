---
navigation:
  parent: items-blocks/index.md
  icon: blank_card
  title: Blank Card
categories:
  - card
description: 모든 [Card](../nodeworks-mechanics/cards.md)의 기본 재료
item_ids:
- nodeworks:blank_card
---

# Blank Card

다른 모든 [Card](../nodeworks-mechanics/cards.md)를 제작하는 데 사용하는 기본 아이템입니다.

<ItemImage scale="6" id="blank_card" />

## 제작법

<RecipeFor id="blank_card" />