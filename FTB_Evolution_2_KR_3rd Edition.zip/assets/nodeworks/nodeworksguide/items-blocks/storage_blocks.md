---
navigation:
  parent: items-blocks/index.md
  icon: instruction_storage
  title: Recipe Storage Blocks
categories:
  - autocrafting
  - requires_controller
description: Crafting CPU가 사용할 Recipe Set을 보관하는 블록
item_ids:
- nodeworks:instruction_storage
- nodeworks:processing_storage
---

# Recipe Storage Blocks

Storage Block은 작성한 [Recipe Set](./recipe_sets.md)을 <ItemLink id="crafting_core" />가 사용할 수 있도록 보관하는 장치입니다. 우클릭으로 열고 슬롯에 Recipe Set을 넣으면 됩니다.

Recipe Set 종류마다 전용 Storage Block이 있습니다.

- **Instruction Storage:** Instruction Set 보관
- **Processing Storage:** Processing Set 보관

## 작동 원리

Storage Block을 Node에 연결하면 안에 있는 모든 Recipe Set이 CPU에 표시됩니다.

<GameScene zoom="3.5" interactive={true} paddingTop="20" paddingLeft="50" paddingRight="60">
  <ImportStructure src="../assets/assemblies/processing_storage_cluster.snbt" />
  <BoxAnnotation min="0 0 0" max="3 1 1">
    서로 **맞닿아 연결된** Processing Storage는 한 묶음으로 내보내집니다.
  </BoxAnnotation>
</GameScene>

Storage Block을 서로 붙여 설치하면 하나의 클러스터를 이룹니다. 클러스터에서는 **한 블록만** 네트워크에 연결하면 나머지도 맞닿은 면을 통해 연결됩니다. 두 부분을 이어 주던 블록을 파괴하면 클러스터가 다시 나뉘고, 각 부분은 네트워크 연결 여부를 독립적으로 확인합니다. 블록의 발광 색상은 소속된 네트워크 색상을 따르므로 어느 네트워크에 속하는지 쉽게 알아볼 수 있습니다.

## Recipe Storage Block 묶기

Recipe Storage Block 하나가 네트워크에 연결되어 있으면, 인접한 다른 Recipe Storage Block도 클러스터에 합쳐져 같은 네트워크에 연결됩니다.

## 제작법

<Row>
    <RecipeFor id="instruction_storage" />
    <RecipeFor id="processing_storage" />
</Row>
