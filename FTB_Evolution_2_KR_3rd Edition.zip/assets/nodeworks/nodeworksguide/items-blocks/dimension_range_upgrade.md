---
navigation:
  parent: items-blocks/index.md
  icon: dimension_range_upgrade
  title: Dimension Range Upgrade
categories:
  - infrastructure
description: <ItemLink id="broadcast_antenna" />의 범위를 확장하는 업그레이드
item_ids:
- nodeworks:dimension_range_upgrade
---

# Dimension Range Upgrade

<ItemLink id="broadcast_antenna" />의 범위를 확장하여
안테나가 설치된 차원 전체에서 접근할 수 있도록 합니다.

<ItemImage scale="6" id="dimension_range_upgrade" />

## 제작법

<RecipeFor id="dimension_range_upgrade" />