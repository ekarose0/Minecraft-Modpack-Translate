---
navigation:
  parent: items-blocks/index.md
  icon: node
  title: Node
categories:
  - infrastructure
description: Pipe 네트워크에서 Card를 장착하는 블록
item_ids:
- nodeworks:node
- nodeworks:focus_node
---

# Node

Node는 [Card](../nodeworks-mechanics/cards.md)를 장착하는 블록입니다. 네트워크의 연결은 [Pipe](pipe.md)를 통해 이루어지며, Node는 인접 블록과 Card로 상호작용해야 하는 위치에 Pipe 사이에 설치합니다.

<BlockImage scale="6" id="node" />

## 면의 역할

각 면은 인접 블록에 따라 역할이 바뀝니다. 다른 네트워크 블록과 맞닿은 면은 Pipe 연결에 사용되어 Card 슬롯이 비활성화됩니다. 일반 블록과 맞닿은 면에는 해당 블록을 대상으로 하는 Card를 장착할 수 있습니다.

## GUI 열기

Pipe가 연결되지 않은 면을 우클릭하면 Card 슬롯이 열립니다. Shift + 우클릭하면 *반대쪽 면*이 열리므로 접근하기 어려운 면을 설정할 때 유용합니다. Pipe 면은 열 수 없으며 측면 선택 목록에서 흐리게 표시됩니다.

![](../assets/images/node_gui.png)

## Card

Device 면의 9개 슬롯에 Card를 넣으면 해당 면에 기능이 추가됩니다:

- <ItemImage scale="0.5" id="io_card" /> <ItemLink id="io_card" />: 인접 블록에 아이템을 넣거나 꺼냅니다.
- <ItemImage scale="0.5" id="storage_card" /> <ItemLink id="storage_card" />: 인접 블록의 인벤토리를 Network Storage로 지정합니다.
- <ItemImage scale="0.5" id="redstone_card" /> <ItemLink id="redstone_card" />: 해당 면에서 레드스톤 신호를 읽거나 출력합니다.
- <ItemImage scale="0.5" id="observer_card" /> <ItemLink id="observer_card" />: 바라보는 블록의 상태를 읽습니다.

하나의 면에 여러 Card를 장착할 수 있습니다. IO Card와 Redstone Card를 함께 장착하면 같은 면에서 아이템을 이동하면서 레드스톤 신호도 출력할 수 있습니다.

## Focus Node

<GameScene interactive={true} zoom="5">
  <IsometricCamera yaw="200" pitch="10" />
  <ImportStructure src="../assets/assemblies/focus_node.snbt" />
</GameScene>

<ItemLink id="focus_node" />는 장거리 연결에 사용하는 Node의 변형입니다. <ItemLink id="network_wrench" />로 두 Focus Node를 연결하면 그 사이에 연속된 Pipe가 없어도 같은 네트워크로 인식됩니다. 떨어진 기계 구역이나 틈을 연결할 때 전체 구간에 Pipe를 설치할 필요가 없습니다.

Focus Node의 여섯 면은 일반 Node와 동일하게 작동합니다. Pipe / Device / Free 역할과 Card 슬롯, 인접 Pipe 자동 연결 기능을 그대로 가지며, 렌치로 연결한 링크가 여기에 추가됩니다.

## 제작법

<RecipeFor id="node" />

<RecipeFor id="focus_node" />
