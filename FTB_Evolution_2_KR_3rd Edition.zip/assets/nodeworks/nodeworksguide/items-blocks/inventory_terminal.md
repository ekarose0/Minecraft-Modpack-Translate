---
navigation:
  parent: items-blocks/index.md
  icon: inventory_terminal
  title: Inventory Terminal
categories:
  - terminal
description: [네트워크 저장소](../nodeworks-mechanics/network-storage.md)의 내용을 조회하는 터미널
item_ids:
- nodeworks:inventory_terminal
---

# Inventory Terminal

Inventory Terminal은 [네트워크 저장소](../nodeworks-mechanics/network-storage.md)의 내용을 한곳에서 확인하는 장치입니다.

<BlockImage scale="6" id="inventory_terminal" />

## 목록 탐색

![](../assets/images/inventory_terminal_gui_expanded.png)

- 좌클릭: 아이템 한 묶음 가져오기
- 우클릭: 묶음의 절반 가져오기
- 더블클릭: 커서에 있는 아이템과 같은 종류를 모두 모으기
- 아이템 묶음을 목록에 내려놓기: [네트워크 저장소](../nodeworks-mechanics/network-storage.md)에 넣기
- 아이템을 든 상태에서 목록 우클릭: 한 개 넣기
- `Alt`를 누른 상태: 네트워크에서 자동 제작할 수 있는 아이템 표시

왼쪽 버튼에서는 다음을 설정할 수 있습니다.

- 화면 배치 변경
- 목록 정렬
- 표시 대상 필터(저장된 아이템, 제작법 또는 둘 다)
- 표시 종류(아이템, 유체 또는 둘 다)
- 검색창 자동 포커스
- JEI 검색어와 터미널 검색어 동기화
- 채널별 보기

가운데에는 접을 수 있는 제작 격자가 있으며 다음 버튼을 사용할 수 있습니다.

- 네트워크에서 재료 자동 가져오기
- 제작 격자에 재료를 균등하게 배치하기
- 제작 격자의 재료를 네트워크 저장소에 넣기

제작 결과를 Shift+클릭하면 인벤토리로 한 묶음을 제작합니다. `Ctrl` + Shift+클릭하면 인벤토리에 들어가는 만큼 최대한 제작합니다.

## 제작법

<RecipeFor id="inventory_terminal" />
