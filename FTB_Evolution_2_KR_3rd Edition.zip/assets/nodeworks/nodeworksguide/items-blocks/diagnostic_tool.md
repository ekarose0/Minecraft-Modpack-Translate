---
navigation:
  parent: items-blocks/index.md
  icon: diagnostic_tool
  title: Diagnostic Tool
categories:
  - tool
description: 네트워크 구성, CPU, 스크립트 및 최근 오류를 검사합니다
item_ids:
- nodeworks:diagnostic_tool
---

# Diagnostic Tool

Nodeworks 네트워크를 살펴보는 휴대용 진단 도구입니다. 네트워크에 속한 블록을 우클릭하면 구성 요소와 현재 동작을 요약한 패널이 열립니다.

<ItemImage scale="6" id="diagnostic_tool" />

## 사용 방법

검사할 네트워크의 블록을 우클릭하세요. <ItemLink id="node" />, <ItemLink id="terminal" />, <ItemLink id="network_controller" />, 안테나 또는 저장소 블록 모두 사용할 수 있습니다. [Crafting CPU](crafting_cpu.md) 멀티블록의 어느 부분(Core, Buffer, Coolant, Substrate, Co-Processor)을 클릭해도 도구가 연결된 Core를 찾아줍니다.

클릭한 블록이 네트워크에 속하지 않으면 화면에 안내 메시지만 표시되며 패널은 열리지 않습니다.

## 표시 정보

진단 패널에는 네트워크에서 확인할 수 있는 정보가 모여 있습니다:

- **네트워크 구성:** 모든 블록의 위치·종류·세부 정보를 표시합니다. <ItemLink id="node" />의 각 면에 장착된 Card와 해당 면이 향하는 인접 블록도 확인할 수 있습니다.
- **네트워크 식별 정보:** Controller의 이름과 색상, 레드스톤 모드, 핸들러 재시도 횟수 제한, 청크 로딩 설정을 표시합니다.
- **CPU:** 각 <ItemLink id="crafting_core" />의 진행 중인 제작 작업, 버퍼 사용량, 효율, 멀티블록 구성 상태를 표시합니다.
- **Terminal:** 모든 <ItemLink id="terminal" />의 스크립트 목록, 자동 실행 여부, 실행 상태 및 실행 중인 스크립트가 등록한 [Processing Set](recipe_sets.md#processing-set) 핸들러를 표시합니다.
- **제작 가능 아이템:** <ItemLink id="instruction_storage" />와 <ItemLink id="processing_storage" />를 바탕으로 네트워크가 자동 제작할 수 있는 아이템 전체를 표시합니다.
- **최근 오류:** Terminal에서 발생한 최근 스크립트 오류 10개와 각 오류가 발생한 지 몇 틱이 지났는지 표시합니다.

이 패널은 읽기 전용입니다. 클릭해도 네트워크 설정이 변경되지 않으며, 구성과 오류 원인을 파악하는 용도로만 사용합니다.

## 사용하면 좋은 상황

- 제작에 실패했지만 <ItemLink id="crafting_core" />까지 가지 않고 오류를 확인하고 싶을 때
- 네트워크가 복잡해 전체 구성을 파악해야 할 때
- 자동 제작이 안 되는 이유를 확인할 때: 제작 가능 아이템 목록에서 네트워크가 실제로 인식하는 레시피를 확인할 수 있습니다.
- 스크립트가 멈춘 것처럼 보일 때: 모든 Terminal을 직접 열지 않고 실행 상태와 등록된 핸들러를 확인할 수 있습니다.

## 제작법

<RecipeFor id="diagnostic_tool" />
