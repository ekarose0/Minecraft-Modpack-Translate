---
navigation:
  parent: items-blocks/index.md
  icon: receiver_antenna
  title: Receiver Antenna
categories:
  - infrastructure
description: 다른 네트워크의 Processing Storage 및 Export Chest에 연결
item_ids:
- nodeworks:receiver_antenna
---

# Receiver Antenna

하나의 네트워크를 다른 [서브넷](../nodeworks-mechanics/subnets.md)에 연결할 때 사용합니다.
여러 네트워크에 [Processing Set](./recipe_sets.md#processing-set) 제작법을 분산하여 [자동 제작](../nodeworks-mechanics/autocrafting.md)에 활용할 때 유용합니다.

<GameScene zoom="4" paddingTop="30" paddingLeft="60" paddingRight="60">
  <IsometricCamera yaw="180" roll="0" pitch="0" />
  <ImportStructure src="../assets/assemblies/receiving_antenna_uses.snbt" />
  <BoxAnnotation min="2 0 0" max="3 1 1">
    다른 네트워크에서 Processing Set 제작법 수신
  </BoxAnnotation>
  <BoxAnnotation min="0 0 0" max="1 2 1">
    송신 중인 Export Chest에서 아이템 수신
  </BoxAnnotation>
</GameScene>

## 무선 아이템 수신

<ItemLink id="import_chest" /> 위에 Receiver Antenna를 설치하고, 다른 네트워크의 <ItemLink id="export_chest" /> 위에 설치된 <ItemLink id="broadcast_antenna" />와 연결하세요. 송신 측 Export Chest에 들어간 아이템이 수신 측 Import Chest로 전달되어, 두 네트워크 사이에서 무선으로 아이템을 운반할 수 있습니다.

## 제작법

<RecipeFor id="receiver_antenna" />
