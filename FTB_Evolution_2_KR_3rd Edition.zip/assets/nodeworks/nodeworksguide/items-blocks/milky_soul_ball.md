---
navigation:
  parent: items-blocks/index.md
  icon: milky_soul_ball
  title: Milky Soul Ball
categories:
  - ingredient
description: 제작에 사용할 특별한 영혼이 담긴 아이템
item_ids:
- nodeworks:milky_soul_ball
---

# Milky Soul Ball

제작에 사용할 수 있는 독특한 우윳빛 영혼입니다.
적에게 던지면 시듦(Withering) 효과를 부여할 수도 있습니다. :3

<ItemImage scale="6" id="milky_soul_ball" />

## 제작 방법

<ItemLink id="minecraft:milk_bucket" />을 손에 들고 <ItemLink id="minecraft:soul_sand" /> 블록을 우클릭하세요.

## 제작법

<RecipeFor id="milky_soul_ball" />