---
navigation:
  parent: items-blocks/index.md
  icon: link_crystal
  title: Link Crystal
categories:
  - infrastructure
description: Broadcast Antenna와 연결하는 데 사용
item_ids:
- nodeworks:link_crystal
---

# Link Crystal

<ItemLink id="broadcast_antenna" />와 페어링할 때 사용합니다.

<ItemImage scale="6" id="link_crystal" />

## 사용법

페어링 절차는 [Broadcast Antenna](./broadcast_antenna.md#pairing) 페이지를 참고하세요.

## 제작법

<RecipeFor id="link_crystal" />