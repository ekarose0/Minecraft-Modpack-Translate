---
navigation:
  parent: items-blocks/index.md
  icon: storage_card
  title: Storage Card
categories:
  - card
description: 인접한 블록을 네트워크 저장소에 포함시킵니다
item_ids:
- nodeworks:storage_card
---

# Storage Card

Storage Card는 인접한 블록을 [Network Storage](../nodeworks-mechanics/network-storage.md)의 일부로 지정합니다. 이 블록의 아이템은 네트워크에서 검색하거나 전송할 수 있으며, Inventory Terminal에도 표시됩니다.

<ItemImage scale="6" id="storage_card" />

## 설정

**Storage Card**를 들고 우클릭하면 우선순위, 채널, 필터를 설정할 수 있습니다.

![](../assets/images/storage-card-gui.png)

> **팁:** <ItemLink id="card_programmer" />를 사용하면 Card 설정을 복사할 수 있습니다. 이름과 채널도 선택적으로 함께 복사할 수 있어, 템플릿으로 여러 Card를 일괄 설정하기 좋습니다.
>
> [`network:route()`](../lua-api/network.md#route)를 이용하면 Card를 직접 조작하지 않고도 설정을 일괄 변경할 수 있습니다.

## 대상 면

Card가 인접 블록의 어느 면과 상호작용할지 선택할 수 있습니다. 기본값은 Node가 바라보는 면이며, 대부분 그대로 사용하면 됩니다. 화로처럼 면마다 기능이 다른 블록은 직접 지정하세요. 화로는 위쪽으로 재료를 받고, 옆면으로 연료를 받으며, 아래쪽으로 결과물을 내보냅니다.

## 채널

Storage Card GUI에서도 채널을 선택할 수 있습니다. 채널에 따라 이 Card를 인식하는 스크립트, 전송 규칙, Preset의 범위가 달라집니다. 자세한 내용은 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 필터

각 Storage Card가 특정 아이템만 받도록 설정하면, 여러 Card가 있는 네트워크에서 아이템을 알맞은 저장소로 분배할 수 있습니다. 새 Card에는 필터가 없으므로 모든 아이템을 받습니다.

### 모드

Storage Card GUI의 **Mode** 버튼은 규칙 목록의 동작을 다음과 같이 전환합니다.

- **Allow**: 하나 이상의 규칙에 일치하는 아이템만 허용합니다.
- **Deny**: 하나 이상의 규칙에 일치하는 아이템을 거부하고 나머지는 허용합니다.

규칙 목록이 비어 있으면 Mode 설정은 영향을 주지 않지만, 아래의 **Stackability** 및 **NBT** 필터는 계속 적용됩니다. 모든 아이템을 받으려면 세 필터를 모두 기본값(규칙 없음, Any Stackability, Any NBT)으로 두어야 합니다.

### 규칙

각 규칙은 한 줄의 필터 구문으로 작성하며, Card에 들어오려는 아이템에 적용됩니다.

| 구문                    | 일치 대상                                      |
| ----------------------- | ---------------------------------------------- |
| `minecraft:cobblestone` | 정확한 아이템 ID                              |
| `#minecraft:logs`       | 해당 태그에 속한 모든 아이템                  |
| `minecraft:*`           | 해당 모드 또는 네임스페이스의 모든 아이템      |
| `/^.*_ore$/`            | 이 정규식과 ID가 일치하는 아이템              |
| `*`                     | 모든 아이템 및 유체                           |

규칙은 다음 세 가지 방법으로 추가할 수 있습니다.

1. 목록 아래의 **[+ Add Rule]**을 눌러 새 줄에 입력합니다. 입력하는 동안 자동 완성이 아이템 ID와 태그를 추천합니다.
2. JEI에서 아이템을 규칙 목록으로 끌어다 놓습니다. 해당 아이템 ID가 새 규칙으로 추가됩니다.
3. Scripting Terminal에서 [`network:route()`](../lua-api/network.md#route)를 사용해 여러 Card의 규칙을 한 번에 설정합니다.

### 중첩 가능 여부와 NBT

규칙 목록 외에도 두 가지 설정으로 허용할 아이템을 더 좁힐 수 있습니다.

- **Stackability**: **Any** / **Stackable Only** / **중첩할 수 없는 아이템만 저장**를 순환합니다. 모든 아이템 ID를 나열하지 않고도 도구와 방어구를 대량 자원과 구분할 수 있습니다.
- **NBT**: **Any** / **Has data** / **No data**를 순환합니다. NBT가 있는 아이템(내구도가 감소한 도구, 이름이 붙은 아이템, 마법이 부여된 책)을 일반 아이템과 구분할 수 있습니다.

세 설정은 모두 함께 적용됩니다. 아이템이 Card에 들어가려면 Stackability, NBT, 규칙 목록을 모두 통과해야 합니다. 예를 들어 `Mode: Allow`, `Stackability: Stackable only`, `NBT: No data`, 규칙 `#minecraft:swords`를 설정하면 실제로 아무것도 받지 못합니다. 검은 중첩되지 않으므로 규칙을 확인하기도 전에 Stackability 검사에서 거부되기 때문입니다. 서로 모순되지 않게 설정하세요.

### 예시

**Cobblestone 대량 저장**

> **Mode:** Allow
> 
> **Stackability:** Any
> 
> **NBT:** Any
> 
> **Rules:** #c:cobblestone

`#c:cobblestones` 태그에 속하는 모든 Cobblestone을 받습니다.

**중첩할 수 없는 아이템만 저장**

> **Mode:** Allow
> 
> **Stackability:** Non-stackable only
> 
> **NBT:** Any
> 
> **Rules:** *Empty*

중첩할 수 없는 아이템을 모두 받는 Storage Card에는 별도의 규칙이 필요하지 않습니다.

## 설치 및 스크립트

설치 방법은 <ItemLink id="io_card" />와 같습니다. 대상 블록에 닿아 있는 Node의 면에 장착하세요. 스크립트 API도 IO Card와 동일합니다. 전체 메서드는 [CardHandle](../lua-api/card-handle.md#inventory-cards)을 참고하세요.

## IO Card와의 차이

<ItemLink id="io_card" />로 연결된 블록의 인벤토리는 스크립트로 직접 제어해야 하며, 아이템을 넣고 빼는 작업도 명시적으로 수행해야 합니다. 반면 Storage Card는 블록을 네트워크의 공유 저장소에 *포함*합니다. `network:find`로 검색할 수 있고, <ItemLink id="inventory_terminal" />과 <ItemLink id="portable_inventory_terminal" />에도 표시되며, 제작 시 재료를 자동으로 가져옵니다.

## 제작법

<RecipeFor id="storage_card" />