---
navigation:
  parent: items-blocks/index.md
  icon: storage_meter
  title: Storage Meter
categories:
  - device
  - requires_controller
description: 지정한 아이템과 유체의 재고량을 감시합니다
item_ids:
- nodeworks:storage_meter
---

# Storage Meter

Storage Meter는 네트워크에서 지정한 아이템의 재고를 감시하다가 설정한 기준치보다 적어지면 레드스톤 신호를 출력합니다. 재고를 채우는 자동 제작 작업을 시작하도록 설정할 수도 있습니다.

> 사용하려면 <ItemLink id="network_controller" />가 필요합니다.

<GameScene interactive={true} zoom="5" paddingLeft="40" paddingRight="40">
  <ImportStructure src="../assets/assemblies/stock_meter_door.snbt" />
  <DiamondAnnotation pos="3.5 0.5 1.5">
    <ItemImage id="minecraft:oak_planks" />
  </DiamondAnnotation>
  <DiamondAnnotation pos="0.5 0.5 0.5">
    <RecipeFor id="minecraft:oak_door" />
  </DiamondAnnotation>
  <BlockAnnotation x="1" color="#00f2ff">
    Autocraft가 활성화되어 네트워크의 Door 재고를 자동으로 보충합니다
  </BlockAnnotation>
</GameScene>

## Storage Meter 사용법

감시할 아이템을 들고 우클릭하세요. 이후 빈손으로 다시 우클릭하면 GUI가 열리며 기준 수량과 채널을 설정할 수 있습니다.

재고가 기준치보다 적어지면 레드스톤 신호를 출력합니다. 기본으로 켜져 있는 Autocraft 기능을 사용하면 재고를 보충할 제작 작업도 시작합니다. 레드스톤 신호로 <ItemLink id="craft_requester" />를 작동시키고 싶다면 Autocraft를 끄세요.

GUI 하단의 상태 표시에서 현재 동작을 확인할 수 있습니다. 마우스를 올리면 자세한 정보가 표시됩니다.

## 서브넷 예시

<GameScene interactive={true} zoom="4" paddingLeft="40" paddingRight="40">
  <ImportStructure src="../assets/assemblies/storage_meter_subnet.snbt" />
  <BlockAnnotation y="2" x="2">
    <ItemLink id="minecraft:raw_iron" />을 <ItemLink id="minecraft:iron_ingot" />으로 제련합니다
  </BlockAnnotation>
  <BlockAnnotation x="4" y="2" z="1">
    <ItemImage id="minecraft:raw_iron" />
  </BlockAnnotation>
  <RemoveBlocks id="minecraft:sandstone" />
  <RemoveBlocks id="minecraft:sandstone" />
</GameScene>

이 예시는 <Color id="green">서브넷</Color>에서 Storage Meter가 상자의 Iron Ingot 재고를 감시하는 구성입니다. 수량이 부족해지면 <Color id="blue">다른 네트워크</Color>의 <ItemLink id="craft_requester" />에 레드스톤 신호를 보내고, <ItemLink id="processing_handler" />를 이용한 자동 제작을 시작합니다.

## 채널

Storage Meter의 GUI에서 채널을 지정하여 감시할 Network Storage의 채널과 제작된 아이템을 보낼 위치를 선택합니다.

> **참고:** 자세한 내용은 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 제작법

<RecipeFor id="storage_meter" />
