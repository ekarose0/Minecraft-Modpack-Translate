---
navigation:
  parent: items-blocks/index.md
  icon: instruction_set
  title: Recipe Sets
categories:
  - autocrafting
  - requires_controller
description: [자동 제작](../nodeworks-mechanics/autocrafting.md)에 사용할 제작법을 저장합니다
item_ids:
- nodeworks:instruction_set
- nodeworks:processing_set
---

# Recipe Sets

[자동 제작](../nodeworks-mechanics/autocrafting.md)에 사용할 제작법을 저장하는 Recipe Set은 두 종류입니다.

Recipe Set은 자동 제작 시스템이 실행할 **제작법 하나를 저장하는 템플릿 아이템**입니다. 각 Set의 GUI에서 제작법을 설정한 다음 해당 [Storage Block](./storage_blocks.md)에 넣어 사용합니다.

제작법 종류에 따라 다음 두 가지로 나뉩니다.

- **Instruction Set:** 바닐라 3×3 제작대 제작법(정형·비정형)
- **Processing Set:** 그 밖의 제작법(제련, 모드 기계, 결과물이 여러 개인 가공, 처리 대기 시간이 있는 제작법 등)

---

## Instruction Set

<ItemImage scale="4" id="instruction_set" />

3×3 제작 템플릿입니다. 일반 제작대에서 만들 수 있는 아이템이라면 이 방식으로 제작할 수 있습니다.

### 제작법 만들기

우클릭으로 GUI를 엽니다. 아이템을 든 상태에서 빈 가상 슬롯을 클릭하면 실제 아이템을 소모하지 않고 해당 아이템의 가상 복사본을 배치합니다. 슬롯을 다시 클릭하면 지울 수 있습니다. 배치한 패턴이 알려진 제작법과 일치하면 결과 슬롯이 자동으로 채워집니다. **Clear All**을 누르면 전체 칸을 초기화합니다.

GUI에는 **태그 대체(tag substitutions)** 설정도 있습니다. 기본적으로 활성화되어 있으며, 켜져 있으면 등록한 재료와 같은 태그의 아이템을 대신 사용할 수 있습니다. 예를 들어 참나무 판자를 등록해도 `#minecraft:planks` 태그에 속하는 자작나무·가문비나무 판자 등을 사용할 수 있습니다. 끄면 정확히 지정한 아이템 ID만 허용합니다.

> **팁:** 이 GUI에서도 JEI의 제작법 전송 **(+)** 버튼을 사용할 수 있습니다. JEI에서 원하는 제작법을 선택하고 (+)를 누르면 제작 칸이 한 번에 채워집니다.

### 등록하기

설정한 Set을 <ItemLink id="instruction_storage" />에 넣으세요. 서로 인접한 Instruction Storage는 하나의 묶음이 됩니다. 묶음 안의 블록 중 **하나라도** 네트워크에 연결되어 있으면 CPU에서 그 안의 모든 Set을 사용할 수 있습니다.

---

## Processing Set

<ItemImage scale="4" id="processing_set" />

입력 최대 9개, 출력 최대 3개와 선택적인 제작별 대기 시간을 지정할 수 있는 자유 형식 제작법입니다. 3×3 제작 칸으로 표현할 수 없는 제련, 용광로 가공, 모드 기계 제작, 여러 결과물이 나오는 작업이나 *"결과물이 나오기까지 N틱이 걸리는"* 작업 등에 사용합니다.

### 제작법 만들기

우클릭으로 GUI를 열면 다음 설정이 있습니다.

- **Input grid:** 입력 재료를 원하는 위치에 등록하는 3×3 가상 슬롯
- **Output column:** 결과물을 등록하는 가상 슬롯 3개
- **Timeout field:** 0~999틱(0은 대기 시간 없음). `+`, `-` 버튼으로 20틱씩, Shift를 누르고 클릭하면 100틱씩 조절
- **Serial toggle:** 켜면 CPU가 동일한 제작법을 병렬 실행하지 않음
- **Substitutions toggle:** 켜면 태그 제작법으로 등록한 입력 슬롯에서 해당 태그의 모든 아이템을 허용하며, 각 입력 아이템의 구성 요소가 다른 변형도 허용함. 끄면 화면에 지정한 정확한 아이템만 사용
- **Clear All:** 모든 설정 초기화

아이템이 들어 있는 슬롯 위에서 마우스 휠을 움직여 수량을 조절합니다. 위로 올리면 +1, 아래로 내리면 -1이며 수량 1에서 아래로 내리면 슬롯이 비워집니다.

결과물이 들어 있는 슬롯을 커서에 아이템을 들지 않은 채 우클릭하면 **선택적 결과물**로 표시할 수 있습니다(`?` 배지). 예를 들어 Sag Mill에서 확률적으로 나오는 추가 가루에 사용합니다. 제작 작업은 필수 결과물만 기다리며, 선택적 결과물은 나오는 즉시 지정된 수량 한도까지 네트워크 저장소로 보냅니다. 주 결과물과 같은 아이템이 같은 틱에 추가로 생성되어도 그 추가분을 보너스로 셀 수 있습니다. CPU는 선택적 결과물을 목표로 제작 계획을 세우지 않으므로, 각 Set에는 최소 하나의 필수 결과물이 있어야 합니다. 마지막 필수 결과물은 선택적으로 표시할 수 없습니다.

모드 제작법에서 결과물별 확률을 기록하고 있다면 JEI의 (+) 버튼이 확률 결과물을 자동으로 표시합니다. 확률 정보가 기록되지 않은 모드는 직접 설정해야 합니다.

> **팁:** Processing Set에서도 JEI의 **(+)** 버튼을 사용할 수 있으며, JEI가 인식하는 제련·용광로·모드 제작법 등 모든 제작법 범주를 지원합니다. JEI에서 `#minecraft:smelts_to_glass` 태그에 속한 여러 종류의 모래처럼 입력 재료가 여러 개로 표시된다면 해당 태그가 저장됩니다. Substitutions를 켜면 보유 중이거나 제작 가능한 태그 구성원을 재료로 사용합니다.

### 등록하기

설정한 Set을 <ItemLink id="processing_storage" />에 넣으세요. Instruction Storage와 마찬가지로 인접한 Processing Storage는 하나의 묶음이 됩니다. CPU는 실제로 제작법을 수행하는 외부 기계와 연동하여 작업을 진행합니다.

## 제작법

<Row>
    <RecipeFor id="instruction_set" />
    <RecipeFor id="processing_set" />
</Row>
