---
navigation:
  parent: items-blocks/index.md
  icon: celestine_receiver_dish
  title: Celestine Receiver Dish
categories:
  - infrastructure
description: <ItemLink id="receiver_antenna" /> 제작 재료
item_ids:
- nodeworks:celestine_receiver_dish
---

# Celestine Receiver Dish

<ItemLink id="receiver_antenna" />를 제작하는 데 사용하는 재료입니다.

<ItemImage scale="6" id="celestine_receiver_dish" />

## 제작법

<RecipeFor id="celestine_receiver_dish" />