---
navigation:
  parent: items-blocks/index.md
  icon: breaker
  title: Breaker
categories:
  - device
description: 앞쪽 블록을 채굴하고 수확합니다
item_ids:
- nodeworks:breaker
---

# Breaker Block

Breaker는 정면의 블록을 일정 시간에 걸쳐 파괴하고 드롭된 아이템을 [Network Storage](../nodeworks-mechanics/network-storage.md)(또는 스크립트에서 지정한 핸들러)로 보냅니다. 채굴 등급은 Diamond Pickaxe와 같지만, 파괴 시간은 Wooden Pickaxe 공식을 사용하므로 단단한 블록일수록 채굴에 더 오래 걸립니다.

<BlockImage scale="6" id="breaker" />

## 설치

Breaker를 설치할 때 바라보던 방향이 전면이 됩니다(피스톤이나 발사기와 동일). 전면에 있는 블록이 `:mine()`의 채굴 대상입니다.

## 대상 필터

Breaker의 GUI에서 채굴할 블록을 필터로 지정할 수 있습니다. 비워 두면 전면의 모든 블록을 채굴하고, 특정 블록을 지정하면 해당 블록만 채굴합니다.

## 나무 벌목

나무 밑동에 Breaker를 설치하면 나무 전체를 벌목할 수 있습니다.

<GameScene zoom="4" paddingTop="30" paddingLeft="60" paddingRight="60" interactive={true} >
  <ImportStructure src="../assets/assemblies/breaker_tree_felling.snbt" />
  <BlockAnnotation x="2" y="1" z="2">
  나무를 지탱하는 마지막 원목을 자르면 나무 전체가 쓰러집니다
  </BlockAnnotation>
  <RemoveBlocks id="minecraft:sandstone" />
  <RemoveBlocks id="minecraft:sandstone" />
</GameScene>

## 레드스톤

GUI의 레드스톤 설정으로 Breaker가 작동할 조건을 지정합니다:

- **High**: 레드스톤 신호가 있을 때 작동합니다.
- **Low**: 레드스톤 신호가 없을 때 작동합니다.
- **Ignored**: 레드스톤 신호를 무시합니다. 스크립트가 `:mine()`을 호출할 때만 작동합니다.

## 채널

Breaker의 GUI에서 이름과 채널을 지정할 수 있습니다. 어떤 스크립트가 이 장치에 접근할 수 있는지는 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 스크립트

스크립트 API는 [BreakerHandle](../lua-api/breaker-handle.md) 문서를 참고하세요.

## 제작법

<RecipeFor id="breaker" />
