---
navigation:
  parent: items-blocks/index.md
  icon: celestine_antenna_array
  title: Celestine Antenna Array
categories:
  - infrastructure
description: <ItemLink id="broadcast_antenna" /> 제작 재료
item_ids:
- nodeworks:celestine_antenna_array
---

# Celestine Antenna Array

<ItemLink id="broadcast_antenna" />를 제작하는 데 사용하는 재료입니다.

<ItemImage scale="6" id="celestine_antenna_array" />

## 제작법

<RecipeFor id="celestine_antenna_array" />