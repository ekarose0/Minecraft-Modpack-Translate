---
navigation:
  parent: items-blocks/index.md
  icon: craft_requester
  title: Craft Requester
categories:
  - device
  - requires_controller
description: 레드스톤 신호를 받으면 자동 제작을 요청하는 장치
item_ids:
- nodeworks:craft_requester
---

# Craft Requester

Craft Requester는 레드스톤 신호를 받으면 자동 제작 작업을 시작합니다. 제작할 아이템과 한 번에 제작할 수량을 설정하세요.

> 사용하려면 <ItemLink id="network_controller" />가 필요합니다.

<GameScene interactive={true} zoom="5" paddingLeft="40" paddingRight="40">
  <ImportStructure src="../assets/assemblies/craft_requester_door.snbt" />
  <DiamondAnnotation pos="3.5 0.5 1.5">
    <ItemImage id="minecraft:oak_planks" />
  </DiamondAnnotation>
  <DiamondAnnotation pos="0.5 0.5 0.5">
    <RecipeFor id="minecraft:oak_door" />
  </DiamondAnnotation>
  <BoxAnnotation min="1.2 1 0.3" max="1.8 1.2 0.7" color="#00f2ff">
    레드스톤 신호가 Craft Requester를 작동시켜 설정한 아이템을 제작합니다.
  </BoxAnnotation>
</GameScene>

## Craft Requester 사용법

제작할 아이템을 손에 들고 우클릭하여 대상을 지정합니다. 빈손으로 다시 우클릭하면 GUI가 열리며, 한 번에 제작할 수량과 [출력 채널](./craft_requester.md#channel)을 설정할 수 있습니다.

레드스톤 신호가 유지되는 동안 한 번에 한 묶음씩 제작 작업을 계속 대기열에 추가합니다. 신호가 끊기면 중지됩니다.

버튼과 연결하면 한 번만 제작할 수 있고, <ItemLink id="storage_meter" />와 연결하면 재고에 따라 자동으로 보충할 수 있습니다. Storage Meter는 재고가 줄거나 회복될 때 신호를 자동으로 전환합니다.

GUI 아래쪽의 상태 표시에는 현재 작업 내용이 나타납니다. 마우스를 올리면 자세한 정보를 볼 수 있습니다.

## 채널

Craft Requester의 GUI에서 제작된 아이템을 보낼 채널을 선택할 수 있습니다.

> **참고:** 자세한 내용은 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 제작법

<RecipeFor id="craft_requester" />
