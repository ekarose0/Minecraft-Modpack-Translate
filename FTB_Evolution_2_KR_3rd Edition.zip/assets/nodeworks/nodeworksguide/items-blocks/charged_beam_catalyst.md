---
navigation:
  parent: items-blocks/index.md
  icon: charged_beam_catalyst
  title: Charged Beam Catalyst
categories:
  - ingredient
description: Grapple Beam 제작에 사용하는 재료
item_ids:
- nodeworks:charged_beam_catalyst
---

# Charged Beam Catalyst

<GameScene zoom="6" paddingLeft="45" paddingRight="45" paddingTop="45" paddingBottom="45" interactive={true} background="transparent">
  <Entity id="minecraft:item_display" y="0.5" data="{item:{id:'nodeworks:charged_beam_catalyst',count:1}}" />
</GameScene>

<ItemLink id="grapple_beam" />을 제작하는 데 사용합니다.

## 제작법

<RecipeFor id="charged_beam_catalyst" />