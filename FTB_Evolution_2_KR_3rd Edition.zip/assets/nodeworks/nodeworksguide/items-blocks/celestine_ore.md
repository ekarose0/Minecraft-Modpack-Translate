---
navigation:
  parent: items-blocks/index.md
  icon: celestine_ore
  title: Celestine Ore
categories:
  - misc
description: 동굴에서 발견되며 Celestine Shard가 들어 있는 광석
item_ids:
- nodeworks:celestine_ore
---

# Celestine Ore

Celestine Ore는 월드의 Y 좌표 0 아래에서 자연 생성됩니다.

재생 가능한 공급원을 원한다면 [Budding Celestine](./budding_celestine.md)을 참고하세요.

<BlockImage scale="6" id="celestine_ore" />

