---
navigation:
  parent: items-blocks/index.md
  icon: network_controller
  title: Network Controller
categories:
  - infrastructure
description: 네트워크의 핵심 장치로, 네트워크마다 하나씩 필요
item_ids:
- nodeworks:network_controller
---

# Network Controller

자동 제작 CPU나 스크립트 기능을 사용하는 Nodeworks 네트워크에는 **Controller가 정확히 하나** 필요합니다.

<GameScene interactive={true} zoom="5">
  <IsometricCamera yaw="200" pitch="10" />
  <ImportStructure src="../assets/assemblies/controller_node_terminal.snbt" />
</GameScene>

Controller를 설치하고 Pipe를 연결하면,
그 Pipe에 연결된 모든 블록이 네트워크에 참여합니다.

## Controller가 필요한 장치

<CategoryIndexDescriptions category="requires_controller" />

## 네트워크 식별

Controller의 GUI에서 네트워크 이름과 색상을 지정할 수 있습니다.
이름은 표시용이며, 색상은 Node의 발광 색에 적용되어
같은 장소에 여러 네트워크가 있어도 쉽게 구분할 수 있습니다.

## 청크 로딩

GUI에서 청크 로딩을 활성화하면 네트워크가 걸쳐 있는 모든 청크가
강제로 로딩된 상태로 유지됩니다. 멀리 떨어져 있어도 계속 작동해야 하는
자동 제작 설비에 유용합니다.

## 네트워크당 하나

같은 Pipe에 Controller 두 개가 연결되면 충돌이 발생하며,
하나를 제거할 때까지 두 네트워크 모두 작동을 멈춥니다.

## 제작법

<RecipeFor id="network_controller" />
