---
navigation:
  parent: items-blocks/index.md
  icon: card_programmer
  title: Card Programmer
categories:
  - tool
description: 템플릿 [Card](../nodeworks-mechanics/cards.md)의 설정을 복사하는 도구
item_ids:
- nodeworks:card_programmer
---

# Card Programmer

Card Programmer는 템플릿 [Card](../nodeworks-mechanics/cards.md)의 설정을 다른 카드에 복사하는 도구입니다.

<ItemImage scale="6" id="card_programmer" />

## 사용 방법

손에 든 상태에서 우클릭하면 두 개의 슬롯이 있는 GUI가 열립니다.

- **Template (왼쪽):** 복사할 설정이 들어 있는 [Card](../nodeworks-mechanics/cards.md)를 넣습니다. 원본 카드는 소모되지 않습니다.
- **Target (오른쪽):** 설정을 적용할 카드를 넣습니다. 템플릿의 설정이 이 카드로 복사됩니다.

![](../assets/images/card_programmer_gui.png)

템플릿의 이름과 채널을 함께 복사할지 선택하는 토글 버튼도 두 개 있습니다.

> **참고:** "Target" 슬롯에 넣거나 Shift+클릭으로 옮긴 카드는
> 복사가 완료되면 즉시 인벤토리로 돌아옵니다.

## 제작법

<RecipeFor id="card_programmer" />