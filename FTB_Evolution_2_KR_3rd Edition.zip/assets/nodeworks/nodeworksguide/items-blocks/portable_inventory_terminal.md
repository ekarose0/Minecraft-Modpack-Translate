---
navigation:
  parent: items-blocks/index.md
  icon: portable_inventory_terminal
  title: Portable Inventory Terminal
categories:
  - tool
  - requires_controller
description: 연결된 네트워크의 저장소를 무선으로 확인하는 휴대용 터미널
item_ids:
- nodeworks:portable_inventory_terminal
---

# Portable Inventory Terminal

휴대용 터미널입니다.

<ItemLink id="inventory_terminal" />의 휴대용 버전입니다. <ItemLink id="network_controller" /> 위의 <ItemLink id="broadcast_antenna" />와 연결된 <ItemLink id="link_crystal" />을 이용해 무선으로 접속합니다.

<ItemImage scale="6" id="portable_inventory_terminal" />

## 네트워크 연결하기

Portable Inventory Terminal을 네트워크에 연결하려면 먼저 다음 세 가지 구성 요소가 필요합니다.

<GameScene zoom="3" interactive={true} paddingTop="20">
  <ImportStructure src="../assets/assemblies/broadcast_antenna_network_controller.snbt" />
</GameScene>

- 대상 네트워크의 <ItemLink id="network_controller" />
- Controller 위에 설치한 <ItemLink id="broadcast_antenna" />
- 해당 안테나와 연결한 <ItemLink id="link_crystal" /> *(Processing Storage가 아닌 안테나에 연결해야 합니다.)*

<br clear="all" /><br clear="all" /><br clear="all" /><br clear="all" />
<FloatingImage src="../assets/images/portable_inventory_terminal_link_slot.png" align="left" />

연결한 Link Crystal을 Portable Inventory Terminal의 오른쪽 위 슬롯에 넣으세요.

연결이 활성화되면 Portable Inventory Terminal의 아이템 텍스처가 네트워크 색상으로 빛납니다.

<br clear="all" />

## 범위

송신 범위는 <ItemLink id="broadcast_antenna" /> 페이지를 참고하세요.

## 터미널 사용법

GUI의 모든 기능은 <ItemLink id="inventory_terminal" />과 동일합니다.

## 제작법

<RecipeFor id="portable_inventory_terminal" />
