---
navigation:
  parent: items-blocks/index.md
  icon: observer_card
  title: Observer Card
categories:
  - card
  - requires_controller
description: 장착된 Node 면 앞 블록의 ID, 상태 속성 및 변경 이벤트를 읽습니다
item_ids:
- nodeworks:observer_card
---

# Observer Card

장착된 면 앞에 있는 블록을 읽습니다. 블록 ID와 상태 속성(성장 단계 `age`, `facing`, `waterlogged`, `lit` 등)을 확인할 수 있으며, 블록이 원하는 상태로 변하는 순간 스크립트가 반응하도록 변경 콜백도 제공합니다.

> Observer Card를 스크립트로 사용하려면 <ItemLink id="network_controller" />와 <ItemLink id="terminal" />이 필요합니다.

<ItemImage scale="6" id="observer_card" />

## 활용 방법

대표적인 활용 사례는 성장 단계에 맞춰 작동하는 농장입니다. 일반 Observer에 연결된 피스톤은 작물이 성장할 때마다 작동하므로, 완전히 자라서 4개의 Shard를 얻을 수 있는 Cluster를 기다리지 않고 작은 Bud를 부숴 1개만 얻을 수 있습니다. Observer Card를 사용하면 스크립트가 실제 성장 단계를 확인하여 최종 형태가 되었을 때만 Breaker를 작동시킬 수 있습니다.

레드스톤 신호만으로 확인하기 어려운 상태를 읽는 데도 유용합니다. Trapdoor의 개폐, Door 상태, Beehive의 꿀 수치, Dripstone의 충전 상태, Daylight Sensor 수치, Sweet Berry·Kelp·Sugar Cane의 성장, 블록 아래의 얼음·눈 생성 등 비교 가능한 `BlockState` 속성이 있는 모든 상태를 감지할 수 있습니다.

## 장착 및 스크립트

<ItemLink id="io_card" />와 같은 방식으로 Node의 면에 장착합니다. 자세한 방법은 [IO Card 장착](./io_card.md#installing)을 참고하세요. Card는 *장착된 면* 바로 앞의 블록을 읽습니다.

사용 가능한 메서드는 [ObserverCard 스크립트 API](../lua-api/card-handle.md#observer-card)를 참고하세요.

## 채널

Observer Card의 GUI에서 채널을 지정할 수 있습니다. 어떤 스크립트가 Card에 접근할 수 있는지는 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 제작법

<RecipeFor id="observer_card" />
