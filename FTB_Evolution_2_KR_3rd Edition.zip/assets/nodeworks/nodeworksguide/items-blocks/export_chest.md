---
navigation:
  parent: items-blocks/index.md
  icon: export_chest
  title: Export Chest
categories:
  - infrastructure
description: 네트워크 저장소에서 아이템을 꺼내 보관하는 상자
item_ids:
- nodeworks:export_chest
---

# Export Chest

[네트워크 저장소](../nodeworks-mechanics/network-storage.md)에서 아이템을 자동으로 꺼내 내부 버퍼에 보관하는 9칸 상자입니다.

<GameScene zoom="6">
  <ImportStructure src="../assets/assemblies/export_chest.snbt" />
</GameScene>

## 필터

상자의 GUI에서 <ItemLink id="storage_card" />와 같은 패턴 문법으로 필터 규칙을 지정합니다. 규칙과 일치하는 아이템만 내보냅니다. 필터가 비어 있으면 상자가 대기하므로, 처음 설치하자마자 네트워크의 아이템이 빠져나가지 않습니다.

## 출력 면

GUI에서 출력 방향을 선택하면 버퍼의 아이템이 해당 방향에 붙은 인벤토리로 자동 이동합니다. 스크립트 없이 호퍼, 화로 또는 기계에 아이템을 공급할 때 유용합니다. 방향을 지정하지 않으면 버퍼에서 수동으로 꺼낼 수 있습니다.

## 채널

채널을 설정하면 해당 채널의 Storage Card에서만 아이템을 가져옵니다. 기본 설정은 네트워크의 모든 Storage Card를 대상으로 합니다. [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 레드스톤

GUI의 레드스톤 설정으로 작동 조건을 정합니다.

- **High**: 레드스톤 신호가 있을 때 작동합니다.
- **Low**: 레드스톤 신호가 없을 때 작동합니다.
- **Ignored**: 레드스톤 신호를 무시합니다.

## 무선 전송

상자 위에 <ItemLink id="broadcast_antenna" />를 설치하고 다른 네트워크의 <ItemLink id="receiver_antenna" />와 연결하세요. 상자에 들어간 아이템이 수신 네트워크의 저장소로 바로 전달됩니다.

## 제작법

<RecipeFor id="export_chest" />
