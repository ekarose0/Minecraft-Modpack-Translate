---
navigation:
  parent: items-blocks/index.md
  icon: multi_dimension_range_upgrade
  title: Multi-Dimension Range Upgrade
categories:
  - infrastructure
description: <ItemLink id="broadcast_antenna" />의 범위를 차원 전체로 확장하는 업그레이드
item_ids:
- nodeworks:multi_dimension_range_upgrade
---

# Multi-Dimension Range Upgrade

<ItemLink id="broadcast_antenna" />의 범위를 확장하여
모든 차원에서 접근할 수 있도록 합니다.

<ItemImage scale="6" id="multi_dimension_range_upgrade" />

## 제작법

<RecipeFor id="multi_dimension_range_upgrade" />