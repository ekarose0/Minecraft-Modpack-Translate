---
navigation:
  parent: items-blocks/index.md
  icon: processing_handler
  title: Processing Handler
categories:
  - autocrafting
  - requires_controller
description: 마이크로 네트워크를 이용해 Processing Set 처리기를 등록합니다
item_ids:
- nodeworks:processing_handler
---

# Processing Handler

[Processing Set](./recipe_sets.md#processing-set) 제작법을 처리하는 블록 기반 Handler입니다. 네트워크에 설치하고 제작법을 연결하면, Lua 스크립트를 작성하지 않아도 [Crafting CPU](./crafting_cpu.md)가 재료를 기계로 보내고 완성된 결과물을 다시 가져옵니다.

> 사용하려면 <ItemLink id="network_controller" />가 필요합니다.

<GameScene zoom="5" interactive={true} paddingLeft="30" paddingRight="30">
  <IsometricCamera yaw="160" roll="0" pitch="10" />
  <ImportStructure src="../assets/assemblies/basic_processing_handler.snbt" />
  <BoxAnnotation min="0 2 0" max="1 2.25 1" color="#3C44AA">
    <ItemImage id="storage_card" /> 파란색 채널의 Storage Card
  </BoxAnnotation>
  <BoxAnnotation min="0 0.75 0" max="1 1 1" color="#B02E26">
    <ItemImage id="storage_card" /> 빨간색 채널의 Storage Card
  </BoxAnnotation>
</GameScene>

## 두 방향의 연결

Handler에는 앞면과 뒷면이 있습니다.

- **뒷면**: <ItemLink id="crafting_core" />와 <ItemLink id="processing_storage" />가 있는 상위 네트워크에 연결됩니다.
- **앞면**: 파이프, Node, Storage Card로 이루어진 독립적인 **마이크로 네트워크**를 구성합니다. 이쪽에서는 Handler가 Controller 역할을 하므로 별도의 <ItemLink id="network_controller" />가 필요하지 않으며, 설치해서도 안 됩니다.

뒷면을 메인 네트워크에 연결하고, 앞면에는 제작법을 실제로 수행할 기계까지 작은 파이프 네트워크를 구성하세요.

## 제작법 연결하기

Handler를 우클릭해 GUI를 열고 상위 네트워크의 Processing Storage에 저장된 <ItemLink id="processing_set" />을 선택합니다. GUI에는 각 재료가 채널 색상과 함께 한 줄씩 표시되고, 결과물에 사용할 채널 색상도 별도로 표시됩니다.

## 채널별 경로 지정

Handler는 채널을 기준으로 마이크로 네트워크의 어느 <ItemLink id="storage_card" />에 아이템을 보낼지 결정합니다.

- **입력 채널**: 재료마다 하나씩 지정되며 기본색은 파란색입니다. CPU가 제작을 시작하면 해당 재료의 채널 색상과 일치하는 Storage Card로 재료를 보냅니다.
  - 아이템의 표현식, 데이터, 중첩 가능 여부 등을 기준으로 세부 경로를 지정하려면 Storage Card의 필터도 적용할 수 있습니다.
- **출력 채널**: 모든 결과물이 공유하는 하나의 채널이며 기본색은 빨간색입니다. Handler는 이 채널을 사용하는 Storage Card를 감시하고 완성된 결과물을 상위 네트워크로 가져옵니다.

위 그림의 화로 예시에서는 화로 위쪽의 파란색 Storage Card가 원재료를 받고, 화로에서 가공한 뒤 아래쪽의 빨간색 Storage Card가 결과물을 수집합니다.

기계가 연료와 원재료를 서로 다른 슬롯으로 받아야 한다면 재료별로 다른 채널 색상을 지정할 수 있습니다.

## 스크립트 Handler와 비교

Processing Handler는 [`network:handle(...)`](../lua-api/network.md#handle)을 스크립트 없이 구현한 장치입니다. 재료를 넣고 결과물을 꺼내는 단순한 제작에는 Processing Handler를 사용하세요. 맞춤형 처리 시간이나 여러 단계의 작업이 필요하면 스크립트 Handler를 사용하면 됩니다.

## 제작법

<RecipeFor id="processing_handler" />
