---
navigation:
  parent: items-blocks/index.md
  icon: budding_celestine
  title: Budding Celestine
categories:
  - misc
description: 표면에 Celestine 싹이 자라는 블록
item_ids:
- nodeworks:budding_celestine
- nodeworks:celestine_cluster
- nodeworks:large_celestine_bud
- nodeworks:medium_celestine_bud
- nodeworks:small_celestine_bud
---

# Budding Celestine

<GameScene zoom="5">
  <IsometricCamera yaw="200" pitch="20" />
  <ImportStructure src="../assets/assemblies/budding_celestine_growth.snbt" />
</GameScene>

## Budding Celestine 얻기

Budding Celestine을 재배하려면 섬세한 손길(Silk Touch)이 부여된 곡괭이로 채굴하세요.
이 블록에서는 Celestine 싹이 계속 자랍니다.

## 발견 장소

<GameScene interactive={true} zoom="1" paddingTop="30" paddingLeft="60" paddingRight="60">
  <IsometricCamera yaw="210" pitch="10" />
  <ImportStructure src="../assets/assemblies/celestine_geode.snbt" />
  <RemoveBlocks id="minecraft:stone" />
</GameScene>

Budding Celestine은 Amethyst 정동석과 마찬가지로
월드에 자연 생성되는 Celestine 정동석에서 찾을 수 있습니다.
