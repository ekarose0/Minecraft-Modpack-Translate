---
navigation:
  parent: items-blocks/index.md
  icon: celestine_shard
  title: Celestine Shard
categories:
  - ingredient
description: Nodeworks 네트워크의 핵심 제작 재료
item_ids:
- nodeworks:celestine_shard
---

# Celestine Shard

[Budding Celestine](./budding_celestine.md)도 참고하세요.

<ItemImage scale="6" id="celestine_shard" />

Celestine Shard는 Nodeworks 네트워크에 사용하는 다양한 블록과 아이템의 핵심 제작 재료입니다.