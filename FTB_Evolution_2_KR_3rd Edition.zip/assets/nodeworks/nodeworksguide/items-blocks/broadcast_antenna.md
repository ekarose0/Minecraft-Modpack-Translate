---
navigation:
  parent: items-blocks/index.md
  icon: broadcast_antenna
  title: Broadcast Antenna
categories:
  - infrastructure
description: Network Controller, Processing Storage, Export Chest에 무선 연결을 제공합니다
item_ids:
- nodeworks:broadcast_antenna
---

# Broadcast Antenna

Broadcast Antenna는 설치하는 블록에 따라 다음과 같은 기능을 수행합니다:

- <ItemLink id="network_controller" /> 위: 네트워크에 무선으로 접근할 수 있게 합니다. 이 안테나와 연결된 <ItemLink id="portable_inventory_terminal" />은 범위 안 어디서든 네트워크의 아이템을 조회하거나 넣고 꺼낼 수 있습니다.
- <ItemLink id="processing_storage" /> 위: 해당 블록과 서로 맞닿은 다른 <ItemLink id="processing_storage" />에 저장된 <ItemLink id="processing_set" />을 방송합니다. 다른 네트워크에서도 이를 [자동 제작](../nodeworks-mechanics/autocrafting.md)에 사용할 수 있습니다.
- <ItemLink id="export_chest" /> 위: 상자를 무선 아이템 전달 지점으로 사용합니다. 다른 네트워크에 연결된 <ItemLink id="receiver_antenna" />가 이 상자로 보낸 아이템을 해당 네트워크로 즉시 전달합니다.

<GameScene zoom="4" paddingTop="30" paddingLeft="60" paddingRight="60">
  <IsometricCamera yaw="180" roll="0" pitch="0" />
  <ImportStructure src="../assets/assemblies/broadcast_antenna_uses.snbt" />
  <BoxAnnotation min="2 0 0" max="4 1 1">
    두 Processing Storage 블록이 모두 방송되고 있습니다
  </BoxAnnotation>
  <BoxAnnotation min="5 0 0" max="6 1 1">
    Portable Inventory Terminal에 무선 접근을 제공합니다
  </BoxAnnotation>
  <BoxAnnotation min="0 0 0" max="1 1 1">
    연결된 Import Chest로 아이템을 보냅니다
  </BoxAnnotation>
</GameScene>

## 연결하기

1. Broadcast Antenna의 GUI를 엽니다.
1. 위쪽 슬롯에 <ItemLink id="link_crystal" />을 넣습니다.
1. Crystal을 다시 꺼내면 연결이 완료됩니다.

## 범위

기본 방송 범위는 128블록입니다. <ItemLink id="dimension_range_upgrade" /> 또는 <ItemLink id="multi_dimension_range_upgrade" />로 범위를 확장할 수 있습니다.

## 제작법

<RecipeFor id="broadcast_antenna" />