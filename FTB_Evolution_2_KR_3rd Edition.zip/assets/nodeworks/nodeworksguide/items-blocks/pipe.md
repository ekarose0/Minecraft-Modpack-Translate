---
navigation:
  parent: items-blocks/index.md
  icon: pipe
  title: Vacuum Pipe
categories:
  - infrastructure
description: 모든 네트워크를 구성하는 기본 연결 블록
item_ids:
- nodeworks:pipe
- nodeworks:covered_pipe
---

# Vacuum Pipe

Nodeworks 네트워크에서 전선 역할을 합니다. Pipe는 네트워크에 연결된
블록 사이에서 아이템과 신호, 경로 정보를 전달합니다.

<GameScene interactive={true} zoom="5" paddingLeft="20" paddingTop="20" paddingBottom="20">
  <IsometricCamera yaw="200" pitch="10" />
  <ImportStructure src="../assets/assemblies/vacuum_pipe.snbt" />
</GameScene>

Pipe끼리 또는 네트워크 블록 옆에 설치하면
자동으로 연결됩니다.

## Pipe 숨기기

### Covered Pipe

제작대에서 블록 하나를 Vacuum Pipe 8개로 둘러싸면
Pipe를 숨기는 데 사용하는 Covered Pipe를 제작할 수 있습니다.

<GameScene interactive={true} zoom="5" paddingLeft="20" paddingTop="20" paddingBottom="20">
  <IsometricCamera yaw="200" pitch="10" />
  <ImportStructure src="../assets/assemblies/covered_pipe.snbt" />
</GameScene>

### Focus Node

<ItemLink id="focus_node" />를 사용하면 유리를 통과하도록 연결해 벽 너머까지 네트워크를 확장할 수 있습니다.

<GameScene interactive={true} zoom="5" paddingLeft="20" paddingTop="20" paddingBottom="20">
  <IsometricCamera yaw="200" pitch="10" />
  <ImportStructure src="../assets/assemblies/focus_node_glass.snbt" />
</GameScene>

## 제작법

<RecipeFor id="pipe" />
