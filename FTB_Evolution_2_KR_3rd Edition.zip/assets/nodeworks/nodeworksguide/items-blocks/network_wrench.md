---
navigation:
  parent: items-blocks/index.md
  icon: network_wrench
  title: Network Wrench
description: 파이프 연결을 전환하고 Focus Node를 연결하는 도구
item_ids:
- nodeworks:network_wrench
---

# Network Wrench

Network Wrench는 블록을 부수지 않고 네트워크 연결 구조를 조정하는 도구입니다. 블록 사이의 개별 파이프 연결을 켜거나 끌 수 있고, 떨어져 있는 <ItemLink id="focus_node" />끼리 연결할 수도 있습니다.

<ItemImage scale="6" id="network_wrench" />

## 파이프 연결 전환

두 네트워크 블록이 맞닿은 면을 Shift+우클릭하면 그 사이의 파이프 연결을 전환합니다. 블록은 제자리에 있지만 네트워크에서는 해당 면에 파이프가 없는 것처럼 처리합니다.

이 기능은 다음 상황에서 유용합니다.

- <ItemLink id="node" />와 <ItemLink id="pipe" />가 나란히 있어도 하나의 네트워크 분기로 합쳐지지 않게 하기
- 파이프의 한쪽 연결을 끊어 네트워크 하나를 둘로 나누기
- <ItemLink id="terminal" />이나 장치가 옆 네트워크에 실수로 연결되지 않도록 하기

같은 면에 다시 사용하면 연결이 복구됩니다.

## Focus Node 연결

<ItemLink id="focus_node" />는 예외적으로 Network Wrench를 사용해 멀리 떨어진 두 블록을 연결할 수 있습니다.

1. 다른 네트워크 블록과 맞닿지 않은 Focus Node의 면을 Shift+우클릭하여 연결 시작점으로 선택합니다. 선택된 블록에는 테두리가 나타납니다.
2. 다른 Focus Node를 우클릭하여 두 블록 사이의 연결을 전환합니다.

연결에 성공한 뒤에도 시작점 선택은 유지되므로, 매번 다시 선택하지 않고 하나의 시작점에서 여러 대상에 연속으로 연결할 수 있습니다.

### 제한 사항

- 두 Focus Node는 선택한 시작점과 **같은 차원**에 있어야 합니다.
- 두 Focus Node는 **같은 Network Controller**에 속해야 합니다. 서로 다른 네트워크를 연결할 수는 없습니다.

규칙을 만족하지 않으면 채팅 메시지로 이유가 표시됩니다.

## 제작법

<RecipeFor id="network_wrench" />
