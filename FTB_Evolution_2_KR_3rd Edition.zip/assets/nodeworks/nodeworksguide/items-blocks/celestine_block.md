---
navigation:
  parent: items-blocks/index.md
  icon: celestine_block
  title: Block of Celestine
categories:
  - misc
description: Celestine 장식 블록
item_ids:
- nodeworks:celestine_block
---

# Block of Celestine

<BlockImage scale="6" id="celestine_block" />

[Celestine 정동석](./budding_celestine.md#where-to-find)에서 발견하거나 <ItemLink id="celestine_shard" />로 제작할 수 있습니다.

## 제작법

<RecipeFor id="celestine_block" />