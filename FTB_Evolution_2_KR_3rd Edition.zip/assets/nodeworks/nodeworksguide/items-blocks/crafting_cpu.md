---
navigation:
  parent: items-blocks/index.md
  icon: crafting_core
  title: Crafting CPU
categories:
  - autocrafting
  - requires_controller
description: 네트워크 자동 제작 시스템의 핵심 장치
item_ids:
- nodeworks:crafting_core
- nodeworks:crafting_storage
- nodeworks:substrate
- nodeworks:stabilizer
- nodeworks:co_processor
---

# Crafting CPU

Crafting CPU는 자동 제작 시스템의 핵심 장치입니다. 네트워크 내부와 무선으로 공유된 Subnet의 Processing Set을 포함해 [Storage Block](./storage_blocks.md)에 저장된 제작법을 읽습니다. 그런 다음 네트워크에서 재료를 가져와 제작을 실행하고 결과물을 다시 저장합니다. 설치한 CPU로 실제 제작을 실행하는 방법은 [Auto Crafting](../nodeworks-mechanics/autocrafting.md)을 참고하세요.

> 사용하려면 <ItemLink id="network_controller" />가 필요합니다.

## CPU 구성하기

CPU의 중심에는 반드시 <ItemLink id="crafting_core" /> **하나**가 있어야 합니다. 하지만 Core만으로는 작동하지 않으며, 어느 한 면에 <ItemLink id="crafting_storage" />("Buffer")가 최소 하나 닿아 있어야 합니다. Buffer가 없으면 제작 도중 아이템을 임시 보관할 공간이 없어 CPU가 켜지지 않습니다.

배치 형태는 자유롭습니다. 렌치나 정해진 구조가 필요하지 않습니다. Core를 놓고 한 면에 Buffer를 붙인 뒤 Core를 Node에 연결하면 작동합니다.

<GameScene zoom="5" interactive={true} paddingLeft="50" paddingRight="60">
  <ImportStructure src="../assets/assemblies/basic_crafting_cpu.snbt" />
  <BlockAnnotation x="1" y="0" z="0">
    열이 발생하므로 Coolant 블록 2개를 함께 사용하는 것이 좋습니다
  </BlockAnnotation>
</GameScene>

> **팁:** 처음 구성하는 Crafting CPU에는 <ItemLink id="crafting_storage" />에 <ItemLink id="stabilizer" /> 블록 2개를 연결해 **효율(Efficiency)**을 최소 100%로 유지하는 것을 권장합니다.

## CPU 확장하기

다른 CPU 구성 블록을 추가하면 같은 CPU의 용량이나 속도를 높일 수 있습니다.

- <ItemLink id="crafting_storage" /> (**Crafting Buffer**): 최소 1개 필수입니다. Buffer가 많을수록 제작 중 재료와 중간 결과물을 더 많이 보관할 수 있습니다. 블록 하나당 **열 2**가 발생합니다.
- <ItemLink id="co_processor" /> (**Crafting Co-Processor**): 하나당 CPU에서 제작 작업을 하나 더 병렬 실행할 수 있습니다. 블록 하나당 **열 3**이 발생합니다.
- <ItemLink id="stabilizer" /> (**Crafting Coolant**): 열을 상쇄합니다. Coolant가 단독으로 있으면 **냉각 1**을 제공하지만, 서로 맞닿은 다른 Coolant마다 냉각량이 **1씩 증가**합니다. 사방의 Coolant 4개와 닿은 블록은 **냉각 5**를 제공하므로, 흩어 놓는 것보다 모아서 설치하는 것이 효과적입니다.
- <ItemLink id="substrate" /> (**Crafting Substrate**): 제작 속도를 높입니다. Buffer나 Co-Processor가 Substrate와 맞닿은 면마다 CPU 속도가 **10%씩 증가**하며, 최대 **4배(400%)**까지 빨라집니다. Core, 다른 Substrate 또는 Coolant에 닿은 면은 효과가 없습니다. 따라서 Buffer와 Co-Processor 사이에 Substrate를 끼워 넣는 것이 효율적입니다.

이 블록들은 Core에 직접 닿거나 이미 CPU에 포함된 블록에 이어 붙이기만 하면 됩니다. 렌치나 GUI 설정은 필요하지 않으며, 다음 틱에 CPU 구성에 반영됩니다.

### 열, 냉각, 속도

각 Buffer와 Co-Processor는 열을 발생시키며, Coolant는 직접 맞닿은 열원에서 열을 흡수합니다. 따라서 블록 수만큼이나 배치도 중요합니다.

- 열원 블록끼리 면이 맞닿으면 각 블록의 기본 발열량에 더해 **공유 면마다 열 1**이 추가됩니다. Buffer와 Co-Processor를 빽빽한 정육면체로 배치하면 같은 블록을 띄엄띄엄 놓았을 때보다 훨씬 뜨거워집니다.
- Coolant는 단독일 때 1, 서로 연결되어 있으면 더 높은 냉각량을 제공하지만, 이 값은 **닿아 있는 열원에 균등하게 분배**됩니다. Buffer 두 개 사이의 Coolant는 냉각량을 절반씩 나눠 주며, 열원 6개 사이에 끼어 있으면 각각에 제공하는 냉각 효과가 매우 작아집니다.
- 전체 냉각량이 전체 발열량을 감당하지 못하면 CPU 속도가 비례해서 **감소**하며, 최저 **25%**까지 떨어집니다. CPU가 완전히 멈추지는 않지만 매우 느려집니다.
- Coolant는 열만 상쇄할 뿐 속도를 100% 이상 높이지 않습니다. 4배 한도까지 속도를 높이는 블록은 Substrate뿐입니다.

<GameScene zoom="5" interactive={false} paddingLeft="60" paddingRight="60">
  <IsometricCamera yaw="180" roll="0" pitch="0" />
  <ImportStructure src="../assets/assemblies/overheating_crafting_cpu.snbt" />

  <LineAnnotation from="2.5 0 0" to="4.5 3 0" color="#ff0000" thickness="0.05" />
  <LineAnnotation from="2.5 3 0" to="4.5 0 0" color="#ff0000" thickness="0.05" />

  <LineAnnotation from="1 0 0" to="2.5 1.25 0" color="#00ff00" thickness="0.05" />
  <LineAnnotation from="1.02 0 0" to="-0.8 3 0" color="#00ff00" thickness="0.05" />
</GameScene>

> **팁:** 블록이 과열되면 노랑·주황·빨강으로 색이 변하거나 연기가 발생하는 시각 효과도 나타납니다.

실제로는 Buffer와 Co-Processor를 한데 모아 놓고 Coolant 몇 개를 옆에 붙이는 방식은 피하는 것이 좋습니다. Coolant끼리 서로 닿도록 별도의 벽이나 날개 형태로 구성하고, 각 Coolant가 처리해야 할 열원 면이 한두 개 정도가 되도록 배치하세요. 그런 다음 Buffer와 Co-Processor의 남는 면에 Substrate를 붙여 속도를 높이면 됩니다.

## 제작법

<Row>
    <RecipeFor id="nodeworks:crafting_core" />
    <RecipeFor id="nodeworks:crafting_storage" />
    <RecipeFor id="nodeworks:substrate" />
    <RecipeFor id="nodeworks:stabilizer" />
    <RecipeFor id="nodeworks:co_processor" />
</Row>
