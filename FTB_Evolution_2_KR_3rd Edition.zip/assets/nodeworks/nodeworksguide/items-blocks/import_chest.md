---
navigation:
  parent: items-blocks/index.md
  icon: import_chest
  title: Import Chest
categories:
  - infrastructure
description: 내부 아이템을 네트워크 저장소로 보내는 상자
item_ids:
- nodeworks:import_chest
---

# Import Chest

안에 넣은 아이템을 [네트워크 저장소](../nodeworks-mechanics/network-storage.md)로 자동 전송하는 9칸 상자입니다. 직접 아이템을 넣거나 호퍼, 다른 모드의 파이프로 공급할 수 있으며, 상자는 아이템을 네트워크로 비웁니다.

<GameScene zoom="6">
  <ImportStructure src="../assets/assemblies/import_chest.snbt" />
</GameScene>

필터 제한이나 저장 공간 부족 등으로 받아들일 수 없는 아이템은 상자에 남으므로 어떤 아이템이 막혔는지 확인할 수 있습니다.

## 채널

GUI에서 채널을 설정하면 해당 채널의 Storage Card로만 아이템을 보냅니다. 기본 설정에서는 네트워크의 모든 Storage Card를 대상으로 합니다. [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 순차 분배

GUI에서 Round robin을 켜면 첫 번째 저장 대상만 채우지 않고 여러 Storage Card에 아이템을 돌아가며 분배합니다. 여러 저장소로 들어오는 아이템을 균등하게 분산할 때 유용합니다.

## 틱 간격

GUI에서 아이템 전송 시도 간격을 설정할 수 있습니다. 기본값은 1초마다 한 번입니다. 간격을 줄이면 더 빠르게 전송하지만 네트워크 작업량이 늘고, 늘리면 한가한 구성에 적합합니다.

## 레드스톤

GUI의 레드스톤 설정으로 작동 조건을 정합니다.

- **High**: 레드스톤 신호가 있을 때 작동합니다.
- **Low**: 레드스톤 신호가 없을 때 작동합니다.
- **Ignored**: 레드스톤 신호를 무시합니다.

## 무선 전송

상자 위에 <ItemLink id="receiver_antenna" />를 설치하고 다른 네트워크의 <ItemLink id="export_chest" /> 위에 있는 <ItemLink id="broadcast_antenna" />와 연결하세요. 송신 측 Export Chest에 들어간 아이템이 이 상자로 전달된 뒤 일반적인 입력처럼 로컬 네트워크 저장소로 이동합니다.

## 제작법

<RecipeFor id="import_chest" />
