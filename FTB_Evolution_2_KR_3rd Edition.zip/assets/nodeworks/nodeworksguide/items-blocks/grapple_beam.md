---
navigation:
  parent: items-blocks/index.md
  icon: grapple_beam
  title: Grapple Beam
categories:
  - tool
description: 플레이어를 빠르게 이동시키는 Grapple Beam
item_ids:
- nodeworks:grapple_beam
---

# Grapple Beam

<GameScene zoom="6" paddingLeft="45" paddingRight="45" paddingTop="75" paddingBottom="75" interactive={true} background="transparent">
  <Entity id="minecraft:item_display" y="0.5" data="{item:{id:'nodeworks:grapple_beam',count:1}}" />
</GameScene>

자신을 멀리 날려 빠르게 이동할 수 있습니다. :)

서버에서 허용하거나 싱글플레이 중이라면 몹을 붙잡는 데도 사용할 수 있습니다.

## 제작법

<RecipeFor id="grapple_beam" />