---
navigation:
  parent: items-blocks/index.md
  icon: variable
  title: Variable
categories:
  - device
  - requires_controller
description: 네트워크 전체에서 공유하는 변수
item_ids:
- nodeworks:variable
---

# Variable 블록

Variable 블록은 네트워크 전체에서 공유할 수 있는 값을 저장합니다.

> 사용하려면 <ItemLink id="network_controller" />가 필요합니다.

<BlockImage scale="6" id="variable" />

## 설정

Variable을 네트워크에 연결하면 **자료형**을 선택하고 **이름**을 지정할 수 있습니다.
두 설정 모두 <ItemLink id="terminal" />에서 변수를 확인하는 데 중요합니다.

![](../assets/images/variable_gui_count.png)

이 예시에서는 이름이 `count`인 **number** 변수입니다.

같은 네트워크의 <ItemLink id="terminal" />을 열면 사이드바에 변수가 표시되며 스크립트에서 참조할 수 있습니다.

![](../assets/images/variable_in_terminal.png)

### 자료형

- **number**
  - 숫자 값(정수 또는 소수)
- **string**
  - 최대 256자의 텍스트
- **bool**
  - `true` 또는 `false`

## 채널

Variable의 GUI에서도 채널을 선택할 수 있습니다.
어떤 스크립트가 이 변수를 사용할 수 있는지는 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 스크립트

스크립트 API는 [VariableHandle](../lua-api/variable-handle.md) 페이지를 참고하세요.

## 제작법

<RecipeFor id="variable" />