---
navigation:
  parent: items-blocks/index.md
  icon: io_card
  title: IO Card
categories:
  - card
  - requires_controller
description: 스크립트에서 인접 인벤토리와 탱크를 읽고 쓸 수 있습니다
item_ids:
- nodeworks:io_card
---

# IO Card

IO Card를 사용하면 네트워크가 인접한 블록의 인벤토리를 필요할 때 읽고 쓸 수 있습니다. IO Card를 장착하면 스크립트로 해당 블록의 내용물을 확인하고 아이템이나 유체를 옮길 수 있습니다.

> 스크립트에서 IO Card를 사용하려면 먼저 <ItemLink id="network_controller" />가 필요합니다.

<ItemImage scale="6" id="io_card" />

## 장착 방법

IO Card는 <ItemLink id="node" />의 면에 있는 슬롯에 장착합니다. 제어하려는 블록과 맞닿은 Node의 면을 우클릭하고 9개 슬롯 중 하나에 IO Card를 넣으세요. Card는 *장착한 면*에만 적용되므로, 하나의 Node에 서로 다른 면을 제어하는 여러 IO Card를 장착할 수 있습니다.

![](../assets/images/node_gui.png)

## 기능

IO Card가 연결된 블록은 스크립트로 접근할 수 있는 인벤토리로 네트워크에 표시됩니다:

- `card:find(filter)`는 조건에 맞는 내용물을 가리키는 [ItemsHandle](../lua-api/items-handle.md)을 반환합니다.
- `card:insert(items)` / `card:tryInsert(items)`는 아이템을 해당 인벤토리에 넣습니다.
- `card:count(filter)`는 조건에 맞는 아이템(및 mB 단위의 유체) 수량을 합산합니다.

<ItemLink id="storage_card" />와 달리 IO Card가 연결된 블록은 **[Network Storage](../nodeworks-mechanics/network-storage.md)에 포함되지 않습니다.** 스크립트가 아이템을 직접 옮겨야 하며, 네트워크 전체를 조회하는 `network:find`에서도 해당 내용물이 보이지 않습니다. <ItemLink id="inventory_terminal" />과 <ItemLink id="portable_inventory_terminal" />에도 표시되지 않습니다.

## 채널

IO Card의 GUI에서 채널을 선택할 수 있습니다. 어떤 스크립트나 Preset이 이 Card에 접근할 수 있는지는 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 스크립트

사용 가능한 전체 메서드는 [CardHandle 문서](../lua-api/card-handle.md#inventory-cards)를 참고하세요.

## 제작법

<RecipeFor id="io_card" />