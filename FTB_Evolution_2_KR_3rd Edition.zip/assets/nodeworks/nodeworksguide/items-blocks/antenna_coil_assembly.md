---
navigation:
  parent: items-blocks/index.md
  icon: antenna_coil_assembly
  title: Antenna Coil Assembly
categories:
  - infrastructure
description: <ItemLink id="broadcast_antenna" />와 <ItemLink id="receiver_antenna" /> 제작 재료
item_ids:
- nodeworks:antenna_coil_assembly
---

# Antenna Coil Assembly

<ItemLink id="broadcast_antenna" />와 <ItemLink id="receiver_antenna" />를 제작할 때 사용하는 재료입니다.

<ItemImage scale="6" id="antenna_coil_assembly" />

## 제작법

<RecipeFor id="antenna_coil_assembly" />