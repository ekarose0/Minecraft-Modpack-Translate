---
navigation:
  parent: items-blocks/index.md
  icon: user
  title: User
categories:
  - device
description: 앞쪽 블록에 아이템을 사용하여 우클릭 동작을 수행합니다
item_ids:
- nodeworks:user
---

# User Block

User는 [Network Storage](../nodeworks-mechanics/network-storage.md)에서 아이템을 꺼내 정면의 대상에 우클릭으로 사용합니다. Bone Meal로 작물을 성장시키거나, 수상한 블록을 Brush로 털거나, Flint and Steel로 TNT에 불을 붙이거나, Bucket에 액체를 담는 등 플레이어가 손으로 하는 다양한 작업을 자동화할 수 있습니다.

<BlockImage scale="6" id="user" />

## 설치

User를 설치할 때 바라보던 방향이 전면이 됩니다(피스톤이나 발사기와 동일). 전면으로 최대 2블록 떨어진 위치까지 확인하여 공기가 아닌 첫 번째 블록을 대상으로 삼습니다. 따라서 작물 위에 빈 공간이 있어도 아래의 작물에 도달할 수 있습니다.

## 아이템 필터

User의 GUI에는 사용할 아이템을 지정하는 슬롯이 있습니다. 작동 시 Network Storage에서 조건에 맞는 아이템을 꺼내 사용하고, 작업이 끝나면 다시 돌려놓습니다. 필터 문법은 <ItemLink id="storage_card" />와 같으므로 아이템 ID, 태그, 와일드카드를 사용할 수 있습니다.

## 모드

User에는 두 가지 작동 모드가 있습니다:

- **Instant:** 작동할 때마다 우클릭을 한 번 수행합니다. Bone Meal이나 Flint and Steel처럼 한 번 사용하면 되는 작업에 적합합니다.
- **Hold:** 해제할 때까지 여러 틱 동안 우클릭을 누른 상태로 유지합니다. Brush처럼 길게 사용해야 하는 도구에 적합합니다. 30초가 지나면 자동으로 해제됩니다.

## 레드스톤

GUI의 레드스톤 설정으로 User의 작동 조건을 지정합니다:

- **High:** 레드스톤 신호가 있을 때 작동합니다.
- **Low:** 레드스톤 신호가 없을 때 작동합니다.
- **Ignored:** 레드스톤 신호를 무시합니다. 스크립트가 User를 호출할 때만 작동합니다.

## 채널

User의 GUI에서 이름과 채널을 지정할 수 있습니다. 어떤 스크립트가 장치에 접근할 수 있는지는 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 스크립트

스크립트 API는 [UserHandle](../lua-api/user-handle.md)를 참고하세요.

## 제작법

<RecipeFor id="user" />
