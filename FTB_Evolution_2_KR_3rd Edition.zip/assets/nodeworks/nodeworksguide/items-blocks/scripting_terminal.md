---
navigation:
  parent: items-blocks/index.md
  icon: terminal
  title: Scripting Terminal
categories:
  - terminal
  - requires_controller
description: 네트워크를 제어하는 Lua 스크립트를 작성하고 실행하는 장치
item_ids:
- nodeworks:terminal
---

# Scripting Terminal

Scripting Terminal에서는 네트워크를 제어하는 Lua 스크립트를 작성하고 실행할 수 있습니다.

> 사용하려면 <ItemLink id="network_controller" />가 필요합니다.

<BlockImage scale="6" id="terminal" />

## 편집기 열기

Terminal을 우클릭하면 편집기가 열립니다. 편집기는 세 영역으로 구성됩니다:

- **Sidebar:** 네트워크의 모든 Card와 Variable을 표시합니다. 클릭하면 커서 위치에 `network:get("…")` 코드가 삽입됩니다.
- **Script tabs:** `main`과 직접 만든 모듈을 표시합니다. Start를 누르면 `main`이 실행되며, 다른 탭은 [`require(name)`](../lua-api/index.md)으로 불러옵니다.
- **Output panel:** `print(…)` 출력과 스크립트 오류를 표시합니다.
  - 왼쪽 화살표로 출력 영역을 펼치거나 접고, 구분선을 드래그하여 크기를 조절할 수 있습니다.

![](../assets/images/terminal_gui.png)

## 스크립트 실행

네트워크 조회, 제작, Scheduler 콜백, Variable 등 스크립트 기능 전체는 [Scripting API](../lua-api/index.md)도 참고하세요.

Start를 누르면 현재 `main` 탭을 불러와 실행합니다. 실행을 유지하는 콜백을 등록하지 않았다면 `main`이 끝날 때 스크립트도 종료됩니다. Stop을 누르면 스크립트가 중지됩니다.

### 자동 실행(AutoRun)

편집기에서 AutoRun을 켜면 Terminal이 로드될 때 스크립트가 자동 시작됩니다. 하지만 Terminal은 해당 청크가 로드될 때만 작동하므로 **서버가 켜져 있는 동안 항상 실행된다는 뜻은 아닙니다.** 플레이어가 근처에 있어 청크가 로드되거나, <ItemLink id="network_controller" />의 청크 로딩 기능을 켜서 플레이어가 없어도 청크가 유지되어야 합니다.

![](../assets/images/autorun.png)

### 레드스톤

Terminal에 레드스톤 펄스가 들어오면 스크립트 실행 상태가 전환됩니다. 중지 상태에서는 시작하고, 실행 중에는 중지합니다. 버튼, 압력판, 새로 설치한 횃불 등 상승 에지 신호라면 모두 사용할 수 있습니다.

> 스크립트가 실제 시간 제한 초과로 강제 종료되었다면, 편집기를 열어 스크립트를 수정하기 전까지 레드스톤으로 다시 시작할 수 없습니다. 문제가 있는 스크립트를 레드스톤 클록이 매 주기마다 반복 실행하는 것을 방지하기 위한 장치입니다.

## 제작법

<RecipeFor id="terminal" />