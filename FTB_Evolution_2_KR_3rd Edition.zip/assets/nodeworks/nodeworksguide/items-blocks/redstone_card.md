---
navigation:
  parent: items-blocks/index.md
  icon: redstone_card
  title: Redstone Card
categories:
  - card
  - requires_controller
description: 장착한 Node 면의 레드스톤 신호를 읽고 출력하는 카드
item_ids:
- nodeworks:redstone_card
---

# Redstone Card

장착한 면의 레드스톤 신호를 읽고 출력합니다.

> 이 카드를 사용하려면 먼저 네트워크에 <ItemLink id="network_controller" />가 있어야 합니다.

<ItemImage scale="6" id="redstone_card" />

## 설치 및 스크립트

이 카드는 <ItemLink id="io_card" />와 같은 방법으로 Node의 면에 장착합니다.
자세한 절차는 [IO Card 설치](./io_card.md#installing)를 참고하세요.
카드는 *장착된 면*의 레드스톤 신호를 읽고 출력합니다.

다른 카드와 사용법이 다른 부분은 [RedstoneCard 스크립트 API](../lua-api/card-handle.md#redstone-card)를 참고하세요.

## 채널

Redstone Card의 GUI에서는 채널을 선택할 수 있습니다.
채널에 따라 어떤 스크립트가 이 카드를 제어할 수 있는지는 [채널 선택](../lua-api/channel.md#choosing-a-channel)을 참고하세요.

## 제작법

<RecipeFor id="redstone_card" />