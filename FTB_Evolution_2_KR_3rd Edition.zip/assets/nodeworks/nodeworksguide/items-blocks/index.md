---
navigation:
  title: Nodeworks 아이템/블록
  position: 20
---

# 아이템/블록

## 재료 및 기타 블록

<CategoryIndexDescriptions category="ingredient" />
<CategoryIndexDescriptions category="misc" />

## 도구 <ItemImage scale="0.5" id="network_wrench" />

<CategoryIndexDescriptions category="tool" />

## 카드 <ItemImage scale="0.5" id="blank_card" />

<CategoryIndexDescriptions category="card" />

## 네트워크 설비 <ItemImage scale="0.5" id="link_crystal" />

<CategoryIndexDescriptions category="infrastructure" />

## 터미널 <ItemImage scale="0.5" id="inventory_terminal" />

<CategoryIndexDescriptions category="terminal" />

## 장치 <ItemImage scale="0.5" id="breaker" />

<CategoryIndexDescriptions category="device" />

## 자동 제작 <ItemImage scale="0.5" id="crafting_core" />

<CategoryIndexDescriptions category="autocrafting" />
