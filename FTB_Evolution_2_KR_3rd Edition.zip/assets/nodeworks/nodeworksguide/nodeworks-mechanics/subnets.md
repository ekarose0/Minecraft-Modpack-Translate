---
navigation:
  parent: nodeworks-mechanics/index.md
  title: Subnets
  icon: broadcast_antenna
categories:
  - networking
  - mechanic
---

# Subnets

Subnet은 별도로 구성한 두 번째 네트워크의 기능 일부를 다른 네트워크에 무선으로 제공하는 방식입니다. 각 Subnet은 자체 <ItemLink id="network_controller" />, 저장소, 제작 설비를 갖습니다. 메인 네트워크와는 서로 짝지어진 <ItemLink id="broadcast_antenna" />와 <ItemLink id="receiver_antenna" />를 통해 통신합니다.

<GameScene zoom="3" interactive={true} paddingTop="30" paddingLeft="50" paddingRight="50">
  <ImportStructure src="../assets/assemblies/subnet.snbt" />
</GameScene>

## 네트워크를 나누는 이유

작은 기지에서는 하나의 대형 네트워크로도 충분합니다. 그러나 기계와 제작법이 늘어나면 네트워크를 나누는 것이 관리에 유리합니다.

- **전문화**: 제련, 양조, 광석 처리 등을 담당하는 Subnet을 만들면 관련 기계와 제작법을 한곳에 모을 수 있습니다.
- **재사용**: 제련용 Subnet을 한 번 만들고 여러 기지에서 그 제작법을 이용할 수 있습니다.
- **분리 운영**: 한 Subnet에서 충돌, 렉 또는 제작 정체가 발생해도 다른 네트워크에는 영향을 주지 않습니다. 각 네트워크가 자체 CPU, 저장소, 스크립트를 실행하기 때문입니다.
- **정리**: 메인 네트워크에는 Subnet이 송신하는 제작법만 표시되고, 그 뒤에 연결된 파이프나 기계는 보이지 않습니다.

## 가공 제작법 공유하기

가장 일반적인 구성은 여러 <ItemLink id="processing_storage" />에 <ItemLink id="processing_set" /> 제작법을 저장한 Subnet입니다. 제작법을 무선으로 공유하면 다른 네트워크도 자동 제작 과정에서 이를 사용할 수 있습니다.

1. Subnet에 <ItemLink id="processing_storage" />를 모아 설치하고 제공할 <ItemLink id="processing_set" />을 넣습니다.
2. 해당 묶음의 <ItemLink id="processing_storage" /> 중 하나 바로 위에 <ItemLink id="broadcast_antenna" />를 설치합니다.
3. 안테나 GUI에서 <ItemLink id="link_crystal" />을 사용해 연결합니다.
4. 제작법을 받을 네트워크에 <ItemLink id="receiver_antenna" />를 설치해 네트워크에 연결하고, 같은 <ItemLink id="link_crystal" />을 GUI에 넣습니다.

이제 수신 네트워크에서는 Subnet의 Processing Storage에 저장된 모든 제작법을 로컬 제작법처럼 확인할 수 있습니다. 해당 제작법을 사용하는 자동 제작도 일반적인 제작과 동일하게 작동합니다.

기계와 재료의 소유권은 여전히 Subnet에 있습니다. 수신 네트워크는 결과물 제작을 요청하고, Subnet이 이를 전달하도록 맡기는 방식입니다.

## 무선 아이템 전송

Subnet끼리 아이템을 직접 주고받을 수도 있습니다. 송신 측 <ItemLink id="export_chest" />와 수신 측 <ItemLink id="import_chest" /> 위의 <ItemLink id="receiver_antenna" />를 짝지어 사용합니다. 연결 방법은 Export Chest 및 Receiver Antenna 설명서를 참고하세요.

## 범위

안테나의 기본 범위는 **128블록**입니다. 범위 업그레이드를 사용하면 청크와 차원을 넘어 연결할 수 있으므로, Subnet을 사용하는 네트워크 옆에 설치할 필요가 없습니다. 예를 들면 다음과 같습니다.

- 네더의 제련용 Subnet에서 오버월드의 메인 기지로 재료 공급
- 몬스터 농장 Subnet에서 다른 위치의 분류 기지로 전리품 송신
- 서버의 여러 기지가 공통으로 이용하는 범용 제작법 공유용 Subnet
