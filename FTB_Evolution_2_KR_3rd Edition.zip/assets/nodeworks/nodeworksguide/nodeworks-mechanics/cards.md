---
navigation:
  parent: nodeworks-mechanics/index.md
  title: Cards
  icon: blank_card
categories:
  - mechanic
---

# Cards

"Card"는 일반적으로 <ItemLink id="node" />에 장착하여 네트워크가 상호작용할 수 있도록 하는 구성 요소입니다.

사용할 수 있는 카드는 다음과 같습니다.

<CategoryIndexDescriptions category="card" />
