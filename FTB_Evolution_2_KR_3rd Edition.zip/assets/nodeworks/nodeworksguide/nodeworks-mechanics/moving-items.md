---
navigation:
  parent: nodeworks-mechanics/index.md
  icon: minecraft:hopper
  title: Moving Items
categories:
  - example
---

# 아이템 이동

Nodeworks 네트워크의 가장 기본적인 작업은 상자에 있는 아이템을 네트워크 저장소로 가져오는 것입니다. 먼저 기본 구성을 살펴보고, 이어서 필터를 적용하는 방법을 알아봅니다.

---

## Import/Export Chest 사용하기

### 네트워크에 아이템 넣기

<ItemLink id="import_chest"/>에 넣은 아이템은 [Network Storage](../nodeworks-mechanics/network-storage.md)로 들어갑니다.

<GameScene zoom="5" interactive={true}>
  <ImportStructure src="../assets/assemblies/moving_items_import_chest.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <BoxAnnotation min="1 0.1 0.1" max="1.25 0.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BlockAnnotation x="2">
    Import Chest에 넣은 아이템은 자동으로 네트워크로 이동합니다
  </BlockAnnotation>
</GameScene>

### 네트워크에서 아이템 꺼내기

<ItemLink id="export_chest"/>는 네트워크 저장소에서 아이템을 꺼내 자신의 인벤토리에 담을 수 있습니다.

<GameScene zoom="5" interactive={true}>
  <ImportStructure src="../assets/assemblies/moving_items_export_chest.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <BoxAnnotation min="1 0.1 0.1" max="1.25 0.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BlockAnnotation x="2">
    Import Chest에 넣은 아이템은 자동으로 네트워크로 이동합니다
  </BlockAnnotation>
</GameScene>

### 두 블록 사이에서 아이템 이동하기

서로 다른 두 블록 사이에서 아이템을 이동하려면 <ItemLink id="export_chest"/>와 <ItemLink id="storage_card"/>를 장착한 <ItemLink id="node"/>를 조합하면 됩니다.

<GameScene zoom="5" interactive={true}>
  <ImportStructure src="../assets/assemblies/moving_items_export_push.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <BoxAnnotation min="1 0.1 0.1" max="1.25 0.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BlockAnnotation x="2">
    Export Chest가 Shulker Box에 아이템을 밀어 넣습니다
    ![](../assets/images/export_chest_push_left.png)
  </BlockAnnotation>
</GameScene>

### 네트워크 사이에서 아이템 이동하기

여러 상자로 구성된 네트워크에서 다른 네트워크로 아이템을 보내려면 Import Chest와 Export Chest를 함께 사용합니다. Export Chest의 내용물을 Import Chest로 밀어 넣도록 설정하면 됩니다.

<GameScene zoom="3" interactive={true} paddingTop="20" paddingBottom="20">
  <ImportStructure src="../assets/assemblies/moving_items_net_to_net.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <BoxAnnotation min="2 0.1 0.1" max="2.25 1.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BoxAnnotation min="6 0.1 0.1" max="5.75 1.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BlockAnnotation x="3">
    Export Chest가 Import Chest로 아이템을 보냅니다
    ![](../assets/images/export_chest_push_left.png)
  </BlockAnnotation>
</GameScene>

---

## Scripting Terminal 사용하기

### 모든 아이템 가져오기

필터 없이 Shulker Box의 모든 아이템을 네트워크 저장소로 가져오는 예시입니다.

<GameScene zoom="5" interactive={true}>
  <ImportStructure src="../assets/assemblies/moving_items.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <BoxAnnotation min="1 0.1 0.1" max="1.25 0.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BoxAnnotation min="4.75 0.1 0.1" max="5 0.9 0.9" color="#83E086">
    이름을 **"shulkerBox"**로 변경 <ItemImage id="nodeworks:io_card" />
  </BoxAnnotation>
</GameScene>

스크립트:

<LuaCode>
```lua
importer
    :from(shulkerBox)
    :to(network)
    :start()
```
</LuaCode>

> **참고:** 반대 방향으로 옮기려면 `:from(shulkerBox)`를 `:from(network)`로, `:to(network)`를 `:to(shulkerBox)`로 바꾸면 됩니다.

이 스크립트를 실행하면 Shulker Box에 들어오는 모든 아이템이 네트워크 저장소로 이동합니다. 단, 필터 때문에 거부되지 않는 Storage Card가 있어야 합니다.

## 필터링: 아이템 종류별로 경로 지정하기

같은 네트워크에서 원목은 한 Storage Card에, 조약돌은 다른 Storage Card에, 나머지는 기본 저장소에 넣는 예시입니다.

<GameScene zoom="5" interactive={true}>
  <ImportStructure src="../assets/assemblies/item_filtering.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <BoxAnnotation min="2 0.1 1.1" max="2.25 0.9 1.9" color="#AA83E0">
    **규칙**: `#c:cobblestones`
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BoxAnnotation min="2 1.1 1.1" max="2.25 1.9 1.9" color="#AA83E0">
    **규칙**: `#c:logs`
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BoxAnnotation min="2 2.1 1.1" max="2.25 2.9 1.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" />
  </BoxAnnotation>
  <BoxAnnotation min="5.75 0.1 1.1" max="6 0.9 1.9" color="#83E086">
    이름을 **"shulkerBox"**로 변경 <ItemImage id="nodeworks:io_card" />
  </BoxAnnotation>
</GameScene>

스크립트는 앞의 예시와 같지만, 이번에는 Storage Card마다 서로 다른 [필터 설정](../items-blocks/storage_card.md#filters)을 적용합니다.
