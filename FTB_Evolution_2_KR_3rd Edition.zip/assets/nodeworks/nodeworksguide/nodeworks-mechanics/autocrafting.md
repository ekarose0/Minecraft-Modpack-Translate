---
navigation:
  parent: nodeworks-mechanics/index.md
  title: Auto-Crafting
  icon: crafting_core
categories:
  - mechanic
---

# Auto-Crafting

Auto-Crafting은 "Iron Pickaxe 64개가 필요하다"는 요청을 실제 Iron Pickaxe 64개로 바꾸는 기능입니다. 네트워크에 제작법을 등록하고 재료를 공급하면 <ItemLink id="crafting_core" />가 제작을 수행합니다.

<GameScene zoom="2" interactive={true} paddingTop="5" paddingLeft="30" paddingRight="30">
  <IsometricCamera yaw="160" pitch="20" />
  <ImportStructure src="../assets/assemblies/autocrafting_example.snbt" />
</GameScene>

## 자동 제작 설정

같은 네트워크에 다음 구성 요소가 필요합니다.

1. **Network Controller.** 자동 제작을 사용하려면 네트워크에 <ItemLink id="network_controller" />가 있어야 합니다.
1. **CPU.** <ItemLink id="crafting_core" />를 설치하고 <ItemLink id="crafting_storage" />를 하나 이상 붙인 다음, Core를 <ItemLink id="node" />에 연결합니다. 버퍼 확장, 냉각제, Substrate에 대해서는 [Crafting CPU](../items-blocks/crafting_cpu.md)를 참고하세요.
1. **제작법.** 각 제작법을 <ItemLink id="instruction_set" />(바닐라 3×3 조합) 또는 <ItemLink id="processing_set" />(그 외 제작)에 기록합니다. 이를 <ItemLink id="instruction_storage" />나 <ItemLink id="processing_storage" />에 넣고 네트워크에 연결하세요.
1. **재료.** 원재료는 [Network Storage](./network-storage.md)에 있어야 합니다. <ItemLink id="storage_card" />로 연결된 상자도 저장소로 인정됩니다.
1. **제작 요청 수단.** <ItemLink id="inventory_terminal" />에서 직접 요청하거나, <ItemLink id="terminal" />의 스크립트에서 `network:craft(...)`를 호출할 수 있습니다.

위의 구성 요소가 준비되면 제작 가능한 아이템이 Inventory Terminal에 나타납니다(필터를 사용하거나 Left-Alt를 누르면 더하기 아이콘으로 표시). 또한 `network:craft("...")`가 `nil` 대신 Builder를 반환합니다.

## 제작 요청

### Inventory Terminal에서 요청

Terminal을 열고 아이템을 찾아 `Alt+클릭`한 다음 수량을 입력하고 확인합니다. 상단의 **Craft Queue**에는 대기 중인 제작이 표시됩니다. 제작이 끝나면 아이템에 작은 표시가 나타나며 꺼낼 수 있습니다. 다음에 Terminal을 열면 다른 아이템과 함께 표시됩니다.

`Alt`를 누르고 있으면 현재 재고가 0개인 경우까지 포함하여 네트워크가 제작할 수 있는 모든 아이템이 강조 표시됩니다.

### 스크립트에서 요청

스크립트에서 `network:craft`로 제작을 요청하고 결과물의 목적지를 지정할 수 있습니다.

<LuaCode>
```lua
-- 제작 완료 시 결과물이 Network Storage에 자동 저장됩니다
network:craft("minecraft:door")
```
</LuaCode>

또는 `:connect(fn)`을 연결해 제작이 완료되는 순간 사용자 지정 코드를 실행할 수 있습니다.

<LuaCode>
```lua
local furnace = network:get("someFurnaceCard")
network:craft("minecraft:charcoal"):connect(function(item: ItemsHandle?)
  if item then
    furnace:insert(item)
  end
end)
```
</LuaCode>

전체 API는 [network:craft](../lua-api/network.md#craft) 및 [CraftBuilder](../lua-api/craft-builder.md)를 참고하세요.

## 제작 취소

<ItemLink id="crafting_core" />를 우클릭하여 GUI를 엽니다. 제작 중에는 **"Cancel"** 버튼이 표시됩니다. 이 버튼을 누르면 제작이 취소되고, 버퍼의 모든 아이템이 Network Storage로 반환되며 CPU를 다시 사용할 수 있습니다.

## Processing Sets need a handler

<ItemLink id="instruction_set" /> 제작법은 별도 설정 없이 작동합니다. 바닐라 3×3 조합은 CPU 자체에서 수행할 수 있기 때문입니다.

반면 <ItemLink id="processing_set" />은 제작법만 선언합니다(예: "Raw Iron 8개로 Iron Ingot 8개 만들기"). 실제로 **어떻게** 변환할지는 알지 못합니다. 누군가 Raw Iron을 Furnace에 넣고 완성된 Ingot을 회수해야 하며, 이를 담당하는 것이 **Handler**입니다.

Handler를 등록하는 방법은 두 가지입니다.

### Processing Handler 블록 사용

<GameScene zoom="5" interactive={true}>
  <IsometricCamera yaw="200" pitch="20" />
  <ImportStructure src="../assets/assemblies/basic_processing_handler.snbt" />
  <BoxAnnotation min="0 2 0" max="1 2.25 1" color="#3C44AA">
    Furnace 윗면을 향하는 Blue 채널 Storage Card
  </BoxAnnotation>
  <BoxAnnotation min="0 0.75 0" max="1 1 1" color="#B02E26">
    Furnace 아랫면을 향하는 Red 채널 Storage Card
  </BoxAnnotation>
</GameScene>

<ItemLink id="processing_handler" />를 네트워크에 설치하고 GUI에서 제작법을 연결합니다. 뒷면을 상위 네트워크에 연결한 다음, 앞면에서 제작을 수행할 기계까지 작은 파이프 서브넷을 구성합니다. CPU가 기계를 제어하므로 스크립트가 필요하지 않습니다. 한쪽에서 재료를 넣고 다른 쪽에서 결과물을 꺼내는 대부분의 기계에 적합합니다.

### 스크립트 Handler 사용

시간 제어, 조건별 전송, 여러 단계의 작업이 필요한 제작법이라면 <ItemLink id="terminal" />에서 Lua Handler를 작성할 수 있습니다.

<LuaCode>
```lua
local furnace = network:get("someFurnaceCard")
network:handle("...", function(job: Job, inputs: InputItems)
  -- Raw Iron을 Furnace 윗면에 넣습니다(윗면 Hopper와 동일)
  furnace:face("top"):insert(inputs.rawIron)
  -- Furnace 아랫면에서 결과물이 나올 때까지 기다린 후 가져옵니다(아랫면 Hopper와 동일)
  job:pull(furnace:face("bottom"))
end)
```
</LuaCode>

Processing Set이 필요한 아이템을 자동 제작할 때 Handler가 등록되어 있지 않으면, 어떤 제작법에 Handler가 없는지 알려 주는 오류와 함께 제작이 실패합니다.

전체 구성 예시는 [network:handle](../lua-api/network.md#handle), [Job](../lua-api/job.md), [InputItems](../lua-api/input-items.md)를 참고하세요.

## 문제가 발생했을 때

제작이 실패하면 <ItemLink id="crafting_core" /> 주변에 빨간 Redstone 가루 입자가 주기적으로 나타납니다. Core GUI를 열어 오류를 확인하거나 새로운 제작에 성공할 때까지 계속 표시됩니다. 문제가 생기면 먼저 빨간 입자를 확인하세요. 어떤 CPU에 문제가 있는지 가장 빠르게 알 수 있습니다.

![](../assets/images/crafting_cpu_erroring.png)

CPU에서 표시하는 오류 메시지는 다음과 같습니다.

| 오류 메시지                                                                                                    | 의미                                                                                                                                                        |
| -------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Crafting CPU at (x, y, z) is not formed                                                                        | Core에 <ItemLink id="crafting_storage" />가 붙어 있지 않거나 Core가 네트워크에 연결되지 않았습니다.                                                         |
| Missing ingredients: N× item, ... No recipe available and not enough in storage.                               | 재료를 공급할 방법이 없고 해당 재료를 만드는 제작법도 없습니다. 네트워크 상자에 재료를 넣거나 제작법을 등록하세요.                                            |
| No handler registered for: X. Add a `network:handle("recipe", ...)` call in a connected Terminal's script.     | X는 Lua Handler가 없는 Processing Set 제작법입니다. 위의 [Processing Set에는 Handler가 필요합니다](./autocrafting.md#processing-sets-need-a-handler)를 참고하세요. |
| Craft needs N unique item types, CPU only holds M. Add more Buffer blocks or upgrade tiers.                    | CPU의 <ItemLink id="crafting_storage" />에 제작 중간 재료의 종류를 모두 저장할 공간이 부족합니다. Buffer를 추가하세요.                                      |
| Craft requires up to N items of one type in buffer, CPU only holds M. Upgrade Buffer tiers or add more blocks. | 제작 과정의 한 단계에서 같은 종류의 아이템이 Buffer의 종류별 용량을 초과합니다. Buffer 등급을 높이거나 블록을 추가하세요.                                      |
