---
navigation:
  parent: nodeworks-mechanics/index.md
  title: Network Storage
  icon: minecraft:chest
categories:
  - mechanic
---

# Network Storage

Network Storage는 Nodeworks 네트워크가 자체 저장소로 취급하는 아이템과 유체의 공유 공간입니다. <ItemLink id="storage_card" />가 설치된 모든 블록이 이 공간에 포함됩니다. 스크립트는 이 저장소에서 아이템을 읽거나 저장하고, <ItemLink id="inventory_terminal" />에서는 내용물을 확인하고 조작할 수 있으며, 자동 제작 시스템도 이곳에서 재료를 가져옵니다.

<GameScene zoom="5" interactive={true} paddingLeft="50" paddingRight="60">
  <ImportStructure src="../assets/assemblies/network_storage.snbt" />
  <BoxAnnotation min="2.25 1.1 0.1" max="2 1.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" /> 이 상자를 Network Storage에 포함합니다
  </BoxAnnotation>
  <BoxAnnotation min="2.25 0.1 0.1" max="2 0.9 0.9" color="#AA83E0">
    <ItemImage id="nodeworks:storage_card" /> 이 상자를 Network Storage에 포함합니다
  </BoxAnnotation>
  <BlockAnnotation x="3" y="1" z="0">
    <ItemLink id="inventory_terminal" />을 사용하면 Network Storage의 내용물을 볼 수 있습니다
  </BlockAnnotation>
</GameScene>

## Network Storage에 포함되는 항목

<ItemLink id="storage_card" />가 연결된 모든 블록의 내용물이 포함됩니다. Storage Card의 노드 연결을 끊으면 해당 블록은 즉시 공유 저장소에서 제외됩니다.

### 포함되지 않는 항목

<ItemLink id="io_card" />가 연결된 블록은 Network Storage에 포함되지 **않습니다**. 스크립트에서 해당 블록으로 아이템을 옮기거나 가져오도록 명시적으로 지정해야 합니다. `network:find`로도 내용물을 찾을 수 없으며, <ItemLink id="inventory_terminal" />과 <ItemLink id="portable_inventory_terminal" />의 목록에도 표시되지 않습니다.

## 우선순위와 경로 지정

각 <ItemLink id="storage_card" />에는 `network:insert`와 `:tryInsert`가 저장소를 채우는 순서를 정하는 **우선순위**가 있습니다. 조건에 맞는 카드 중 우선순위가 가장 높은 카드부터 채우고, 가득 차면 더 낮은 우선순위의 카드로 넘어갑니다. 우선순위가 같으면 연결된 순서대로 채웁니다.

스크립트에서 [`network:route`](../lua-api/network.md#route)로 경로를 등록하면 특정 아이템에 대해 기본 우선순위 순서를 재정의할 수 있습니다.

카드의 GUI에서 우선순위를 직접 지정할 수 있습니다. 사용법은 [Storage Card](../items-blocks/storage_card.md#configuring-priority)를 참고하세요. <ItemLink id="card_programmer" />를 사용하면 우선순위를 비롯한 모든 카드 설정을 여러 카드에 한 번에 복사할 수 있습니다.

## Network Storage 스크립트 작성

스크립트에서 공유 저장소를 읽고 쓰는 함수의 전체 목록은 [Network API](../lua-api/network.md)를 참고하세요.

## Inventory Terminal에서 확인하고 관리하기

<Row align="center">
  <BlockImage scale="3.3" id="inventory_terminal" />
  <ItemImage scale="4" id="portable_inventory_terminal" />
</Row>

<ItemLink id="inventory_terminal" />과 <ItemLink id="portable_inventory_terminal" />은 스크립트를 작성하지 않고도 Network Storage를 확인하고 조작하는 기본 수단입니다. 검색 가능한 목록에서 모든 아이템을 확인하고, 자신의 인벤토리로 꺼내거나 다시 저장하고, 제작을 요청할 수 있습니다. 표시되는 정보는 네트워크에 연결된 Storage Card에서 실시간으로 가져옵니다.

자세한 인터페이스 설명은 [Inventory Terminal](../items-blocks/inventory_terminal.md)을 참고하세요.
