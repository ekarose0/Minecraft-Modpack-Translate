---
navigation:
  parent: nodeworks-mechanics/index.md
  title: Devices
  icon: variable
categories:
  - mechanic
---

# Devices

"Device"는 네트워크에 연결하고 스크립트로 제어할 수 있는 블록을 뜻합니다.

<CategoryIndexDescriptions category="device" />
