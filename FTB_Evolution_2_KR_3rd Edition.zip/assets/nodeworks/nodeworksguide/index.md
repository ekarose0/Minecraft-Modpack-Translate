---
navigation:
  title: 개요
  position: 0
item_ids:
- nodeworks:nodeworks_book
---

# Nodeworks

프로그래밍할 수 있는 물류 및 자동화 네트워크입니다.

<GameScene zoom="3" interactive={false} paddingTop="30" paddingRight="30" paddingLeft="10">
  <ImportStructure src="assets/assemblies/subnet.snbt" />
  <IsometricCamera yaw="200" pitch="20" />
  <RemoveBlocks id="minecraft:sandstone" />
</GameScene>

## 목차

- [시작하기](./getting-started.md)
- [스크립트 참고 자료](./lua-api/index.md)
- [Nodeworks 작동 원리](./nodeworks-mechanics/index.md)
- [아이템/블록](./items-blocks/index.md)
- [구성 예시](./example-setups/index.md)

Scripting Terminal 편집기에서 문서화된 식별자 위에 마우스를 올리면 해당 항목의 함수 시그니처와
간단한 설명이 표시됩니다. 마우스를 올린 상태에서 <Color id="green">[ <KeyBind id="key.nodeworks.open_docs" /> ]</Color> 키를 누르면 관련 가이드 페이지가 열립니다.

이 문서에 내용을 추가하는 방법은 [docs/authoring.md](https://github.com/damienfamed75/nodeworks/blob/main/docs/authoring.md)를 참고하세요.
