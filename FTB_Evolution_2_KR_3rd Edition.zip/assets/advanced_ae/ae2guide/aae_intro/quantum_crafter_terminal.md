[//]: # (---)

[//]: # (navigation:)

[//]: # (  parent: aae_intro/aae_intro-index.md)

[//]: # (  title: Quantum Crafter Terminals)

[//]: # (  icon: advanced_ae:quantum_crafter_terminal)

[//]: # (categories:)

[//]: # (  - advanced devices)

[//]: # (item_ids:)

[//]: # (  - advanced_ae:quantum_crafter_terminal)

[//]: # (  - advanced_ae:wireless_quantum_crafter_terminal)

[//]: # (---)

[//]: # ()
[//]: # (# Quantum Crafter Terminals)

[//]: # ()
[//]: # (<Row gap="20">)

[//]: # (<ItemImage id="advanced_ae:quantum_crafter_terminal" scale="4"></ItemImage>)

[//]: # (<ItemImage id="advanced_ae:wireless_quantum_crafter_terminal" scale="4"></ItemImage>)

[//]: # (</Row>)

[//]: # ()
[//]: # (Quantum Crafter Terminal을 사용하면 네트워크에 있는 모든 <ItemLink id="advanced_ae:quantum_crafter"/>를)

[//]: # (한곳에서 관리할 수 있습니다. 무선 버전은 이동 중 설정을 변경할 때 유용합니다. 장치를)

[//]: # (Wireless Access Point에 넣어 그리드에 연결하면 바로 사용할 수 있습니다!)

[//]: # ()
[//]: # (<Row gap="20">)

[//]: # (<RecipeFor id="advanced_ae:quantum_crafter_terminal" />)

[//]: # (<RecipeFor id="advanced_ae:wireless_quantum_crafter_terminal" />)

[//]: # (</Row>)