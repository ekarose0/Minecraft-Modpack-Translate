---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME Throughput Monitor
  icon: advanced_ae:throughput_monitor
categories:
  - advanced items
item_ids:
  - advanced_ae:throughput_monitor
  - advanced_ae:throughput_monitor_configurator
---

# ME Throughput Monitor

<GameScene zoom="8" background="transparent">
<ImportStructure src="../structure/throughput_monitors.snbt"></ImportStructure>
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Throughput Monitor는 <ItemLink id="ae2:storage_monitor" />와 같은 기능에 처리량 측정 기능을 더한 모니터입니다. 한 종류의 아이템 또는 유체의 수량 변화를 추적하여 초당 변화량을 표시합니다.

이 장치는 *채널을 사용하지 않습니다.*

## 조작 방법

*   아이템을 들고 우클릭하거나 유체 용기를 들고 두 번 우클릭하면 해당 아이템 또는 유체를 모니터링 대상으로 지정합니다.
*   빈손으로 우클릭하면 모니터 설정이 초기화됩니다.
*   빈손으로 Shift+우클릭하면 모니터 설정을 잠급니다.

## Throughput Monitor Configurator

<ItemImage id="advanced_ae:throughput_monitor_configurator" scale="4"></ItemImage>

Throughput Monitor Configurator는 표시되는 데이터의 단위를 변경하는 도구입니다. 손에 들고 모니터를 우클릭하면 다음 세 가지 표시 방식이 차례로 전환됩니다.

* 틱당 아이템 수
* 초당 아이템 수
* 분당 아이템 수

참고: 표시 모드를 바꾸면 측정값이 안정되기까지 시간이 걸릴 수 있으므로 전환 직후의 값은 정확하지 않을 수 있습니다.