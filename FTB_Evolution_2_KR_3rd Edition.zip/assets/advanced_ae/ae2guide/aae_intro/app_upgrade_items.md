---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Advanced Pattern Provider Upgrade Items
  icon: advanced_ae:adv_pattern_provider_upgrade
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_provider_upgrade
  - advanced_ae:adv_pattern_provider_capacity_upgrade
---

# Advanced Pattern Provider Upgrades

Advanced AE는 기존 패턴과 업그레이드를 일일이 옮기지 않고 Pattern Provider를 업그레이드할 수 있는 아이템을 제공합니다.

## Advanced Pattern Provider Upgrade

<ItemImage id="advanced_ae:adv_pattern_provider_upgrade" scale="3"></ItemImage>

이 업그레이드는 일반 AE Pattern Provider와 ExtendedAE의 Extended Pattern Provider에 사용할 수 있습니다. 기존 슬롯 수를 유지한 채 고급 버전으로 바뀌므로, 일반 장치를 확장형으로 만들 때 사용한 재료도 낭비되지 않습니다.

## Advanced Pattern Provider Capacity Upgrade

<ItemImage id="advanced_ae:adv_pattern_provider_capacity_upgrade" scale="3"></ItemImage>

Capacity Upgrade를 사용하면 일반 Pattern Provider를 패턴 슬롯 36개가 있는 Advanced Pattern Provider로 바로 업그레이드할 수 있습니다.
