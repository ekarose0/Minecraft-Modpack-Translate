---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Reaction Chamber
  icon: advanced_ae:reaction_chamber
categories:
  - advanced devices
item_ids:
  - advanced_ae:reaction_chamber
---

# Reaction Chamber

<BlockImage id="advanced_ae:reaction_chamber" scale="4"></BlockImage>

Reaction Chamber는 촉매 액체와 많은 전력을 사용하여 화학 반응을 가속하는 장치입니다. 자연적으로 발생하는 반응을 장치 내부에서 강제로 진행하며, 제어된 환경 덕분에 대부분 더 효율적인 결과를 얻을 수 있습니다.

## 장치에 전력 공급하기

Reaction Chamber는 속도를 높일수록 전력 소비가 크게 증가합니다. Acceleration Card를 장착하면 전체 전력 소모량이 더 빠른 속도로 소비되므로 틱당 필요한 전력이 증가합니다. ME 시스템을 통해 직접 전력을 공급할 때는 장치가 매 틱 처리에 필요한 양을 끌어옵니다. 필요한 전력을 공급하지 못하면 시스템 전원이 켜졌다 꺼지기를 반복하는 현상이 발생할 수 있습니다. 이를 방지하려면 AE 시스템에 <ItemLink id="ae2:dense_energy_cell" />을 설치하여 에너지 버퍼를 확보하세요.

드라이브에 Applied Flux의 Energy Cell이 있다면, Reaction Chamber는 해당 셀에서 직접 전력을 끌어와 자체 저장 공간을 충전하고 ME 전력 버퍼를 소모하지 않고 제작할 수도 있습니다. 현재 발전량을 더 늘릴 수 없다면 Acceleration Card의 수를 줄이는 방법도 있습니다. 아래에서 여러 전력 공급 방식을 설명합니다.

* 참고: 케이블에 부착하는 부품 형태의 Pattern Provider나 Interface는 그 자체로 그리드 연결을 제공하지 않습니다. 이런 부품을 사용하여 장치에 전력을 공급하려면 Fluix Cable도 Reaction Chamber에 직접 연결해야 합니다.

### 블록 형태 Pattern Provider

완전한 블록 형태의 Pattern Provider를 사용하면 Reaction Chamber를 AE2 그리드에 직접 연결할 수 있습니다. 필요할 때 그리드에서 전력을 끌어올 수 있어 장치의 내부 전력 버퍼에 대한 의존도를 줄입니다. 그리드에 저장된 전체 전력이 틱당 요구량보다 적으면 진행 속도가 느려지고 화면에 경고가 표시됩니다. 이 방식에는 그리드에 <ItemLink id="ae2:dense_energy_cell" />을 여러 개 연결하는 것을 권장합니다.

### 외부 전력

다른 방법으로 외부 전력원을 직접 연결할 수 있습니다. 에너지를 출력할 수 있는 전력원이라면 장치의 버퍼를 충전하고 처리를 시작할 수 있습니다. 공급 속도가 충분하지 않으면 Reaction Chamber 화면에 경고가 표시됩니다.

### Induction Card (추가 모드 필요: Applied Flux)

Induction Card를 케이블 부품 형태의 Pattern Provider나 방향 지정형 Pattern Provider에 넣으면 Energy Cell에 저장된 전력을 내보낼 수 있습니다. 올바르게 연결하면 Reaction Chamber의 에너지 저장 공간을 충전하여 장치를 작동시킵니다.

다만 Induction Card는 일부 AE2 구성 요소와 마찬가지로 출력이 서서히 증가하는 준비 시간이 있습니다. 처음에는 전력 부족으로 제작 속도가 최대치에 도달하지 못할 수 있지만, 제작이 계속되면 Induction Card가 충분한 전력을 공급하게 됩니다.
