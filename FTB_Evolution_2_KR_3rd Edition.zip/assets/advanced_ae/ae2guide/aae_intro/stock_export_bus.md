---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Stock Export Bus
  icon: advanced_ae:stock_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:stock_export_bus_part
---

# Stock Export Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_stock_export_bus.snbt"></ImportStructure>
</GameScene>

Stock Export Bus는 필터에 지정된 아이템을 정확히 설정 수량만큼 내보내도록 구성할 수 있습니다. 대상 인벤토리의 현재 수량을 확인하고 설정 수량을 초과하여 넣지 않습니다. 설정하려면 GUI를 열고 원하는 아이템을 필터 슬롯에 드래그한 다음 휠 클릭으로 수량을 지정하세요. 단, 설정 수량을 초과한 아이템이나 유체를 다시 꺼내지는 않으므로 출력 재고를 역방향으로 조절하지는 않습니다.