---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Advanced Pattern Encoder
  icon: advanced_ae:adv_pattern_encoder
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_encoder
  - advanced_ae:adv_processing_pattern
---

# Advanced Pattern Encoder

ME Advanced Pattern Provider가 아이템을 어느 면으로 보낼지 지정하려면 해당 정보를 인코딩하는 전용 장치가 필요합니다. 이 아이템을 손에 들고 우클릭하면 GUI가 열립니다.

<ItemImage id="advanced_ae:adv_pattern_encoder" scale="4"></ItemImage>

인코딩된 Processing Pattern을 왼쪽 슬롯에 넣으면 패턴이 해석되고 모든 입력 재료가 목록으로 표시됩니다.

![PEGui1](../pic/ape_pattern.png)

각 행에는 재료를 보낼 수 있는 블록의 면을 선택하는 버튼이 있습니다. "A" 버튼을 선택한 상태에서는 Pattern Provider와 직접 맞닿은 면으로 아이템을 보내며, 특정 면을 선택하면 그 방향으로만 넣도록 지정합니다. 고급 패턴은 <ItemLink id="advanced_ae:adv_pattern_provider" />에서만 정상적으로 해석되며, 다른 종류의 Pattern Provider에 넣으면 일반 패턴처럼 작동합니다.
지정한 면에 아이템 하나라도 넣을 수 없다면 방향별 삽입을 수행하지 않고 일반 Pattern Provider 방식으로 처리합니다.