---
navigation:
  title: Advanced AE 소개
  position: 70
---

# Advanced AE!

Advanced AE는 ME 시스템을 더 편리하게 사용하고 게임 후반의 자동화 가능성을 확장하는 모드입니다. Pattern Provider를 업그레이드해 기계의 특정 면으로 아이템을 공급할 수 있고, 제작 저장 공간이 남아 있는 동안 보조 프로세서를 공유하면서 제한 없이 여러 제작 작업을 실행하는 멀티블록 컴퓨터도 만들 수 있습니다. 그 밖에도 다양한 편의 기능이 추가됩니다.

![PEGui1](../pic/aae_intro.png)

추가된 블록과 아이템의 전체 목록은 다음 가이드 페이지에서 확인하세요.

## 고급 장치

<CategoryIndex category="advanced devices"></CategoryIndex>

## 고급 아이템

<CategoryIndex category="advanced items"></CategoryIndex>

문제가 있거나 필요한 기능이 있다면 다음 링크에 제보해 주세요.
[Advanced AE GitHub](https://github.com/pedroksl/AdvancedAE)