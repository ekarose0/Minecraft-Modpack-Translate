---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Quantum Crafter
  icon: advanced_ae:quantum_crafter
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_crafter
---

# Quantum Crafter

<BlockImage id="advanced_ae:quantum_crafter" p:working="true" scale="4"></BlockImage>

Quantum Crafter는 성능이 뛰어나고 세부 설정이 가능한 자동 제작 장치입니다. AE 시스템의 모든 인벤토리에 접근할 수 있으므로 필요한 아이템을 지속적으로 제작하기 쉽습니다. 중요한 자원이 고갈되지 않도록 관리하면서 제작 작업을 매우 빠르게 처리할 수 있습니다. 액체를 대체 재료로 사용하는 제작이나, 입력 재료가 결과물로 다시 나오는 재귀 제작도 지원합니다.

## Quantum Crafter 사용법

Quantum Crafter를 사용하려면 네트워크에 설치하고 케이블로 연결하세요. 작동하려면 채널 1개가 필요합니다. 반복해서 제작할 레시피를 선택한 뒤 Crafting Pattern에 기록하고, Quantum Crafter의 해당 슬롯에 넣으세요.

![QCGUI](../pic/quantum_crafter_ui.png)

패턴을 넣으면 패턴마다 설정할 수 있는 버튼 두 개가 표시됩니다. 아래쪽의 사각형 버튼은 해당 패턴을 활성화하거나 비활성화합니다. 비활성화한 패턴은 제작하지 않으며, 활성화한 패턴도 설정된 조건을 충족해야 제작됩니다. 조건을 변경하려면 톱니바퀴 버튼을 눌러 Pattern Configuration UI를 여세요.

![PCGUI](../pic/pattern_configuration_ui.png)

패턴 설정 화면에는 모든 재료와 주요 결과물이 표시됩니다. 숫자 입력란에서 ME 시스템에 항상 유지할 재료별 최소 수량을 지정할 수 있으며, 비싼 아이템이 과도하게 제작되지 않도록 최종 결과물의 최대 수량도 제한할 수 있습니다. 원하는 숫자나 수학식을 입력한 뒤 Enter를 눌러 적용하세요. 오른쪽 표시를 통해 값이 정상적으로 적용되었는지 확인할 수 있습니다. 특히 결과물 제한을 0으로 설정하면 제한이 해제되며, 입력 재료가 떨어질 때까지 계속 제작합니다.

## 결과물 출력

Quantum Crafter의 제작 결과물 출력 방식은 세부적으로 설정할 수 있습니다. 기본 설정에서는 출력 슬롯의 아이템을 ME 시스템으로 직접 보냅니다. 왼쪽 도구 모음의 Cell 버튼을 좌클릭하면 인접한 인벤토리로 내보내도록 변경할 수 있습니다. 이 설정을 켜면 추가 버튼이 나타나며, 해당 버튼에서 자동 출력에 사용할 면을 선택할 수 있습니다. 두 설정을 조합하여 원하는 방식으로 출력 경로를 제어할 수 있습니다.

## 업그레이드

Quantum Crafter의 성능을 최대한 활용하려면 업그레이드 카드를 설치하세요. <ItemLink id="ae2:speed_card" />와 <ItemLink id="ae2:redstone_card" />를 장착할 수 있습니다. Speed Card는 제작 속도를 크게 높여 각 패턴을 틱당 최대 64회 제작할 수 있게 하며, Redstone Card는 레드스톤 신호로 장치를 제어할 수 있게 합니다.
