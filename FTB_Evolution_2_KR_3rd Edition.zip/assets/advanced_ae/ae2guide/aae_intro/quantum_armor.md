---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Quantum Armor Set
  icon: advanced_ae:quantum_helmet
categories:
  - advanced items
item_ids:
  - advanced_ae:quantum_helmet
  - advanced_ae:quantum_chestplate
  - advanced_ae:quantum_leggings
  - advanced_ae:quantum_boots
  - advanced_ae:quantum_upgrade_base
  - advanced_ae:walk_speed_card
  - advanced_ae:sprint_speed_card
  - advanced_ae:step_assist_card
  - advanced_ae:jump_height_card
  - advanced_ae:lava_immunity_card
  - advanced_ae:flight_card
  - advanced_ae:water_breathing_card
  - advanced_ae:auto_feeding_card
  - advanced_ae:auto_stock_card
  - advanced_ae:magnet_card
  - advanced_ae:hp_buffer_card
  - advanced_ae:evasion_card
  - advanced_ae:regeneration_card
  - advanced_ae:strength_card
  - advanced_ae:attack_speed_card
  - advanced_ae:luck_card
  - advanced_ae:reach_card
  - advanced_ae:swim_speed_card
  - advanced_ae:night_vision_card
  - advanced_ae:flight_drift_card
  - advanced_ae:recharging_card
  - advanced_ae:portable_workbench_card
  - advanced_ae:pick_craft_card
  - advanced_ae:camo_card
---

# Quantum Armor Set

<Row gap="10">
<ItemImage id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
</Row>

<ItemGrid>
<ItemIcon id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d"></ItemIcon>
</ItemGrid>

AE 시스템을 직접 입는다면 어떨까요? Quantum Armor Set는 AE2 시스템에 연결되는 첨단 장비로, 이동 중에도 시스템의 여러 기능을 편리하게 사용할 수 있습니다. 기본적으로 에너지로 작동하며 Netherite 장비에 필적하는 방어력을 갖추고 있습니다. 저장된 에너지로 보호막을 형성해 피해를 흡수할 수 있습니다. Boots는 낙하 피해를 막고 Chestplate는 비행 중 채굴 속도 감소를 없애 줍니다. 하지만 이 장비의 진정한 성능은 업그레이드 카드를 장착했을 때 발휘됩니다!

<br/>

## 방어구 연결

각 방어구를 <ItemLink id="ae2:wireless_access_point" />의 해당 슬롯에 넣으면 개별적으로 AE 시스템과 연결할 수 있습니다. 연결하면 장비 부위와 장착된 업그레이드 카드에 따라 다양한 추가 기능을 사용할 수 있습니다. 자세한 내용은 아래에서 설명합니다. 이러한 추가 기능을 정상적으로 사용하려면 연결된 Access Point의 범위 안에 있어야 합니다.

<br/>

## 업그레이드 설치

업그레이드를 설치하려면 방어구를 착용한 상태에서 단축키(기본값 N)를 눌러 Quantum Armor 설정 메뉴를 여세요.

![QAGUI](../pic/quantum_armor_config.png)

이 화면에서 업그레이드를 장착하거나 제거하고, 기능을 켜고 끄거나 업그레이드별 세부 설정을 변경할 수 있습니다.

<br/>

## Quantum Upgrade Base Card

<ItemImage id="advanced_ae:quantum_upgrade_base" scale="2"></ItemImage>

<ItemLink id="advanced_ae:quantum_upgrade_base" /> 자체에는 특별한 기능이 없지만 모든 업그레이드 카드의 제작 재료로 사용됩니다.

<br/>

## Auto Feeding Card

<ItemImage id="advanced_ae:auto_feeding_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_feeding_card" />는 플레이어가 먹을 음식을 지정할 수 있게 합니다. 원하는 음식을 필터 슬롯으로 드래그하세요. 방어구가 AE2 그리드에 연결되어 있다면 배가 고플 때 시스템에서 해당 음식을 찾아 자동으로 먹습니다.

<br/>

## Auto Stock Card

<ItemImage id="advanced_ae:auto_stock_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_stock_card" />도 방어구가 AE2 시스템에 연결되어 있고 Access Point 범위 안에 있어야 작동합니다. 인벤토리에 특정 아이템을 설정한 수량만큼 항상 유지하도록 지정할 수 있습니다. 설정 수량은 한 스택으로 제한되지 않으므로 여러 슬롯을 채울 만큼 비축할 수도 있습니다.

<br/>

## Speed Cards

<Row gap="10">
<ItemImage id="advanced_ae:walk_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:sprint_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:swim_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:walk_speed_card" />
* <ItemLink id="advanced_ae:sprint_speed_card" />
* <ItemLink id="advanced_ae:swim_speed_card" />

이 업그레이드 카드는 착용자의 이동 속도를 높입니다. 각 카드의 속도 수치를 조절할 수 있으며 웅크리거나 비행할 때의 이동에도 영향을 줍니다. 다른 이동 속도 증가 효과가 적용된 상태에서는 오히려 속도를 낮춰 조작을 더 쉽게 만드는 용도로도 사용할 수 있습니다.

<br/>

## Height Cards

<Row gap="10">
<ItemImage id="advanced_ae:jump_height_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:step_assist_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:jump_height_card" />
* <ItemLink id="advanced_ae:step_assist_card" />

이 업그레이드는 수직 이동에 영향을 줍니다. 점프 높이를 조절하거나 턱을 자동으로 올라가는 기능을 제공합니다.

<br/>

## Flight Cards

<Row gap="10">
<ItemImage id="advanced_ae:flight_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:flight_drift_card" scale="2"></ItemImage>
</Row>

### Flight Card

<ItemLink id="advanced_ae:flight_card" />를 장착하면 크리에이티브 비행이 가능해집니다. UI의 슬라이더로 비행 속도를 조절할 수 있으며, 걷기 및 달리기 속도 업그레이드의 효과도 추가로 적용됩니다.

### Flight Drift Card

<ItemLink id="advanced_ae:flight_drift_card" />는 Flight Card를 장착했을 때만 작동합니다. 비행 시 관성을 조절하는 슬라이더가 추가됩니다. 수치가 낮을수록 더 빨리 멈추며, 0으로 설정하면 즉시 정지합니다.

<br/>

## ME Recharging Card

<ItemImage id="advanced_ae:recharging_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:recharging_card" />는 장착한 방어구 부위를 무선으로 충전합니다. 그리드 연결과 Access Point 범위 내 위치가 필요합니다. Chestplate에 장착하면 인벤토리 슬롯의 아이템도 충전하는 추가 효과가 있습니다.

<br/>

## Portable Workbench Card

<ItemImage id="advanced_ae:portable_workbench_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:portable_workbench_card" />는 Quantum Armor에 휴대용 Cell Workbench를 추가합니다. 지정된 단축키를 누르면 열 수 있으며, 블록 형태의 Cell Workbench와 동일하게 작동합니다.

<br/>

## Pick Craft Card

<ItemImage id="advanced_ae:pick_craft_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:pick_craft_card" />는 방어구에 새로운 단축키 기능을 추가합니다. 단축키를 누르면 현재 바라보는 블록의 제작을 요청합니다. 그리드에 연결되어 있어야 하고 대상 블록과 일치하는 패턴이 필요합니다. 원하는 수량을 입력하는 팝업이 나타나며 이후 과정은 일반적인 자동 제작 요청과 같습니다.

<br/>

## Utilities Cards

<Row gap="10">
<ItemImage id="advanced_ae:night_vision_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:lava_immunity_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:water_breathing_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:magnet_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:camo_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:night_vision_card" />
* <ItemLink id="advanced_ae:lava_immunity_card" />
* <ItemLink id="advanced_ae:water_breathing_card" />
* <ItemLink id="advanced_ae:magnet_card" />
* <ItemLink id="advanced_ae:camo_card" />

이 카드들은 착용자에게 다양한 편의 기능을 제공합니다. 일부 피해에 면역을 부여하거나 야간 투시를 사용할 수 있게 합니다. 특히 Magnet Card는 전용 설정 화면에서 주울 아이템과 제외할 아이템을 필터링하고 작동 범위를 조절할 수 있습니다.

<br/>

## Defensive Cards

<Row gap="10">
<ItemImage id="advanced_ae:hp_buffer_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:regeneration_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:evasion_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:hp_buffer_card" />
* <ItemLink id="advanced_ae:regeneration_card" />
* <ItemLink id="advanced_ae:evasion_card" />

이 업그레이드는 여러 방식으로 착용자의 방어 능력을 높입니다. HP Buffer Card는 최대 체력을 늘리고 Regeneration Card는 체력 회복 속도를 높입니다. Evasion Card는 일정 확률로 모든 종류의 피해를 완전히 무효화합니다.

<br/>

## Offensive Cards

<Row gap="10">
<ItemImage id="advanced_ae:strength_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:attack_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:strength_card" />
* <ItemLink id="advanced_ae:attack_speed_card" />

이 업그레이드는 착용자의 공격 능력을 높여 공격 피해량과 공격 속도를 증가시킵니다.

<br/>

## Stats Cards

<Row gap="10">
<ItemImage id="advanced_ae:luck_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:reach_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:luck_card" />
* <ItemLink id="advanced_ae:reach_card" />

이 업그레이드 카드는 착용자의 능력치를 고정 수치만큼 높입니다. Luck Card는 전리품 획득에 영향을 주는 행운을 높이고 Reach Card는 블록에 닿는 거리를 늘립니다. Reach Card는 원하는 수치로 설정할 수 있습니다.

<br/>

## 향후 추가 예정

이 장비 세트는 기본 기능을 갖춘 초기 버전으로 출시되었습니다. 앞으로 다양한 기능이 추가될 예정이니 기대해 주세요!