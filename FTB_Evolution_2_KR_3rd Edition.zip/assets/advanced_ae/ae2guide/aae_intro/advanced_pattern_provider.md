---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME Advanced Pattern Provider
  icon: advanced_ae:adv_pattern_provider
categories:
  - advanced devices
item_ids:
  - advanced_ae:adv_pattern_provider
  - advanced_ae:small_adv_pattern_provider
  - advanced_ae:adv_pattern_provider_part
  - advanced_ae:small_adv_pattern_provider_part
---

# ME Advanced Pattern Provider

<Row gap="20">
<BlockImage id="advanced_ae:adv_pattern_provider" scale="8"></BlockImage>
<BlockImage id="advanced_ae:adv_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_app_part.snbt"></ImportStructure>
</GameScene>
</Row>

ME Advanced Pattern Provider는 일반 <ItemLink id="ae2:pattern_provider" /> 또는 Extended AE의 Extended Pattern Provider를 개선한 장치입니다. 패턴에 들어 있는 재료마다 어느 면으로 공급할지 지정할 수 있습니다. 덕분에 특정 면으로만 재료를 받는 기계도 파이프 없이 블록 하나로 자동화할 수 있습니다.

*특히 Mekanism 같은 기계에 유용합니다.*

이 기능을 사용하려면 인코딩된 패턴을 <ItemLink id="advanced_ae:adv_pattern_encoder" />에 넣고 고급 버전으로 변환해 얻은 <ItemLink id="advanced_ae:adv_processing_pattern" />을 장치에 넣어야 합니다.

Pattern Provider 하나에 최대 36개의 패턴을 보관할 수 있는 확장형 버전도 있습니다.

![AAEGui](../pic/app_gui.png)
