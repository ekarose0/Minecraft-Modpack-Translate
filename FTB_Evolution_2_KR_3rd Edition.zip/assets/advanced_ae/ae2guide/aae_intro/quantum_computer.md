---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Quantum Computer
  icon: advanced_ae:quantum_core
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_unit
  - advanced_ae:quantum_core
  - advanced_ae:quantum_structure
  - advanced_ae:quantum_accelerator
  - advanced_ae:quantum_multi_threader
  - advanced_ae:quantum_storage_128
  - advanced_ae:quantum_storage_256
  - advanced_ae:data_entangler
---

# Quantum Computer

Quantum Computer는 특수한 제작 컴퓨터입니다. 제작 저장 공간이 충분하다면 개수 제한 없이 제작 요청을 동시에 처리할 수 있습니다.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../structure/quantum_computer_multiblock.snbt"></ImportStructure>
</GameScene>

## Quantum Core

<BlockImage id="advanced_ae:quantum_core" p:powered="true" p:formed="true" scale="4"></BlockImage>

Quantum Core는 Quantum Computer의 핵심 부품입니다. 단독으로 제작 저장 공간 256M과 보조 프로세서 스레드 8개를 제공합니다. 이 블록은 다른 부품 없이도 완성된 Quantum Computer로 작동할 수 있는 유일한 블록이며, Quantum Computer의 모든 기본 기능을 제공합니다. 다만 멀티블록 구조로 조립하면 훨씬 강력한 컴퓨터를 만들 수 있습니다. 단독으로 사용할 때는 연결부가 있는 위쪽 또는 아래쪽 면을 통해 전력을 공급해야 합니다.

## Quantum Storages

<Row gap="20">
<BlockImage id="advanced_ae:quantum_storage_128" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_storage_256" scale="4"></BlockImage>
</Row>

이 블록은 Quantum Core의 제작 저장 공간을 확장합니다. 저장 공간이 늘어나면 Quantum Computer가 동시에 실행할 수 있는 작업량도 증가합니다. 용량이 128M인 제품과 256M인 제품, 두 종류가 있습니다.

## Quantum Data Entangler

<BlockImage id="advanced_ae:data_entangler" scale="4"></BlockImage>

Data Entangler는 멀티블록에 포함된 모든 저장 블록에 영향을 주는 특수 블록입니다. 저장 블록이 여러 차원에 데이터를 저장하도록 하여 저장 용량을 실질적으로 4배 늘립니다. Quantum Computer 멀티블록 하나에는 1개만 설치할 수 있습니다.

## Quantum Accelerator

<BlockImage id="advanced_ae:quantum_accelerator" scale="4"></BlockImage>

Quantum Accelerator는 Quantum Computer 멀티블록에 보조 프로세서 8개를 추가합니다. Quantum Computer에서 실행 중인 모든 제작 패턴이 보조 프로세서를 공유할 수 있으므로, 여러 개 설치하는 것이 유용합니다.

## Quantum Multi-threader

<BlockImage id="advanced_ae:quantum_multi_threader" scale="4"></BlockImage>

Data Entangler와 마찬가지로 Quantum Multi-threader는 가속기가 다른 차원에서 추가 스레드를 실행하도록 하여 보조 처리 성능을 4배 높입니다. Quantum Computer 멀티블록 하나에는 1개만 설치할 수 있습니다.

## Quantum Structure

<Row gap="20">
<BlockImage id="advanced_ae:quantum_structure" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_structure" p:formed="true" p:powered="true" scale="4"></BlockImage>
</Row>

이 블록은 Quantum Computer의 외곽 프레임을 구성합니다. 컴퓨터를 조립할 때 구조를 지지하고 각 부품을 연결하는 데 사용합니다.

## 멀티블록 구조

Quantum Computer 멀티블록을 만들려면 다음 규칙을 따라야 합니다.
- 최대 크기는 7×7×7입니다(외부 치수 기준).
- 멀티블록 내부에 빈 공간이 없어야 합니다. 추가 효과 없이 공간을 채우려면 <ItemLink id="advanced_ae:quantum_unit" />을 사용할 수 있습니다.
- <ItemLink id="advanced_ae:quantum_core" />는 정확히 1개 필요합니다.
- <ItemLink id="advanced_ae:data_entangler" />는 최대 1개까지 설치할 수 있습니다.
- <ItemLink id="advanced_ae:quantum_multi_threader" />는 최대 1개까지 설치할 수 있습니다.
- 외부 표면의 모든 블록은 <ItemLink id="advanced_ae:quantum_structure" />여야 합니다.
- 내부에는 <ItemLink id="advanced_ae:quantum_structure" />를 설치할 수 없습니다.

## 서버 설정

서버 설정에서 다음과 같은 값을 변경할 수 있습니다.
- 멀티블록의 최대 크기
- Quantum Accelerator 하나당 보조 프로세서 수
- Quantum Multi-threader의 최대 설치 수
- Multi-threader의 스레드 배율
- Data Entangler의 최대 설치 수
- Data Entangler의 저장 용량 배율

현재 서버에 적용된 제한은 아이템 툴팁에서 확인할 수 있습니다.
