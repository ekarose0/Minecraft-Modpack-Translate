---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Import Export Bus
  icon: advanced_ae:import_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:import_export_bus_part
---

# Import Export Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_import_export_bus.snbt"></ImportStructure>
</GameScene>

Import Export Bus는 <ItemLink id="ae2:import_bus" />와 <ItemLink id="ae2:export_bus" />의 기능을 합친 장치입니다. 필터로 내보낼 아이템 스택을 지정할 수 있으며, 필터에 없는 아이템은 가져오기 대상으로 처리합니다.