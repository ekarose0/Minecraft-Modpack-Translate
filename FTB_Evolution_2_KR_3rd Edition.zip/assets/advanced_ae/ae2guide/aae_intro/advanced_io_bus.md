---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Advanced IO Bus
  icon: advanced_ae:advanced_io_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:advanced_io_bus_part
---

# Advanced IO Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_advanced_io_bus.snbt"></ImportStructure>
</GameScene>

Advanced IO Bus는 외부 인벤토리와 아이템을 주고받는 강력한 장치입니다. <ItemLink id="advanced_ae:import_export_bus_part"/>와 <ItemLink id="advanced_ae:stock_export_bus_part"/>를 결합하여 만들며 두 장치의 기능을 모두 사용할 수 있습니다. 기본 전송 속도는 <ItemLink id="ae2:export_bus"/>의 8배입니다. 최고 속도에 도달하기까지 시간이 걸리지만 업그레이드를 완료하면 매우 빠르게 작동합니다.

## 내보내기

Advanced IO Bus는 필터에 지정된 아이템을 설정 수량까지 내보낸 뒤 멈춥니다. UI 왼쪽에는 아이템 재고 수량을 조절할지 선택하는 설정도 있습니다.

## 가져오기

Advanced IO Bus는 내보내기 필터에 지정되지 않은 아이템도 가져옵니다. 가져오기와 내보내기는 별도의 작업으로 계산되므로 한쪽 작업 때문에 다른 쪽이 멈추지 않습니다. 재고 조절 기능을 켜면 설정 수량을 초과한 아이템을 우선 가져오며, 남은 작업 여유가 있으면 필터에 없는 아이템도 가져옵니다.

<RecipeFor id="advanced_ae:advanced_io_bus_part"/>