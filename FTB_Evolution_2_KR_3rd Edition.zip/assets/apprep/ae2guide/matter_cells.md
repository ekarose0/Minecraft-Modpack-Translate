---
navigation:
    title: ME Matter Storage Cell
    icon: matter_cell_256k
    parent: index.md
item_ids:
    - matter_cell_housing
    - matter_cell_1k
    - matter_cell_4k
    - matter_cell_16k
    - matter_cell_64k
    - matter_cell_256k
#    - mega_matter_cell_housing
#    - matter_cell_1m
#    - matter_cell_4m
#    - matter_cell_16m
#    - matter_cell_64m
#    - matter_cell_256m
---

# Applied Replicatics: ME Matter Storage Cell

<Row>
  <ItemImage id="matter_cell_housing" scale="4"/>
  <ItemImage id="matter_cell_1k" scale="4"/>
  <ItemImage id="matter_cell_4k" scale="4"/>
  <ItemImage id="matter_cell_16k" scale="4"/>
  <ItemImage id="matter_cell_64k" scale="4"/>
  <ItemImage id="matter_cell_256k" scale="4"/>
</Row>

Replication의 Matter를 저장할 수 있는 [Storage Cell](ae2:items-blocks-machines/storage_cells.md)입니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="structures/matter_cells.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 0.3">
    화면에 표시하려면 Matter Tank가 가득 찬 상태에서 두 번 사용하세요.
  </BoxAnnotation>
</GameScene>

기본 사양은 [Storage Cell](ae2:items-blocks-machines/storage_cells.md)과 같지만, Matter 256개를 저장할 때마다 1바이트를 사용합니다.

---

## 참고

Replication 네트워크와 Matter를 주고받으려면 <ItemLink id="replication_connector" />가 필요합니다.
비슷한 기능을 수행하는 다른 모드의 블록과는 호환되지 않으니 주의하세요.
