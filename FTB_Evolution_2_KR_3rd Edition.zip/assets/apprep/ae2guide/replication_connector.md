---
navigation:
    title: ME Replication Connector
    icon: replication_connector
    parent: index.md
item_ids:
    - replication_connector
---

# Applied Replicatics: ME Replication Connector

<BlockImage id="replication_connector" scale="4" />

이 블록은 Replication 네트워크와 ME 네트워크를 연결합니다.

Replication 네트워크의 Matter를 ME 네트워크에 저장할 수 있으며, 반대로 ME 네트워크에 저장된 Matter를 Replication 네트워크로 꺼낼 수도 있습니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="structures/replication_connector_basic.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 자동 제작

Chip Storage에 저장된 패턴은 ME 네트워크에서 제작 가능한 항목으로 등록됩니다.
Replicator의 출력물은 ME Replication Connector를 통해 ME 네트워크로 들어갑니다.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="structures/auto_craft.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <BlockAnnotation color="#dddddd" x="0" y="0" z="1">
    자동 제작에는 ME Matter Storage Cell에 저장된 Matter를 사용합니다.
  </BlockAnnotation>
</GameScene>
