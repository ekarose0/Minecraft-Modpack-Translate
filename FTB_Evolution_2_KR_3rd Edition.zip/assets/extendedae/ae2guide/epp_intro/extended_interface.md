---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Interface
    icon: extendedae:ex_interface
categories:
- extended devices
item_ids:
- extendedae:ex_interface
- extendedae:ex_interface_part
---

# ME Extended Interface

<Row gap="20">
<BlockImage id="extendedae:ex_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_interface.snbt"></ImportStructure>
</GameScene>
</Row>

ME Extended Interface는 설정 슬롯이 더 많은 <ItemLink id="ae2:interface" />입니다.

*이 정도로 많은 슬롯이 정말 필요할까요?*

![EIGui](../pic/ei_gui.png)
