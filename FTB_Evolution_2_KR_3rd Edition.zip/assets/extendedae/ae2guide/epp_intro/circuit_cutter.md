---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Circuit Slicer
    icon: extendedae:circuit_cutter
categories:
- extended devices
item_ids:
- extendedae:circuit_cutter
---

# Circuit Slicer

<Row gap="20">
<BlockImage id="extendedae:circuit_cutter" scale="8"></BlockImage>
</Row>

Inscriber의 느린 처리 속도가 답답하신가요? Circuit Slicer를 사용해 보세요! 재료 블록을 프로세서 [인쇄물](ae2:items-blocks-machines/processors.md)로 직접 절단하므로, 대부분의 상황에서 Inscriber보다 최대 9배 빠릅니다.

**주의: 포트가 없는 유리 면은 네트워크에 연결할 수 없습니다.**
