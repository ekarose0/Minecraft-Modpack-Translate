---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Tag Storage Bus
    icon: extendedae:tag_storage_bus
categories:
- extended devices
item_ids:
- extendedae:tag_storage_bus
---

# ME Tag Storage Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Tag Storage Bus는 아이템 또는 유체 태그로 필터를 지정할 수 있으며, 기본 논리 연산자도 지원하는 <ItemLink id="ae2:storage_bus" />입니다.

사용 예시는 다음과 같습니다.

- 원광석만 허용

`c:raw_materials/*`

- 모든 주괴와 보석 허용

`c:ingots/* | c:gems/*`
