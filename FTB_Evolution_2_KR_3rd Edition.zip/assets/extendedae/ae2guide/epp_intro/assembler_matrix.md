---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Assembler Matrix
    icon: extendedae:assembler_matrix_frame
categories:
- extended devices
item_ids:
- extendedae:assembler_matrix_frame
- extendedae:assembler_matrix_wall
- extendedae:assembler_matrix_glass
- extendedae:assembler_matrix_pattern
- extendedae:assembler_matrix_crafter
- extendedae:assembler_matrix_speed
---

# Assembler Matrix

<Row>
<BlockImage id="extendedae:assembler_matrix_frame" p:formed="true" p:powered="true" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_wall" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_glass" scale="5"></BlockImage>
</Row>
<Row>
<BlockImage id="extendedae:assembler_matrix_pattern" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_crafter" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_speed" scale="5"></BlockImage>
</Row>

Assembler Matrix는 <ItemLink id="ae2:molecular_assembler" />와 <ItemLink id="ae2:pattern_provider" />의 기능을 결합한 멀티블록 구조물입니다.
ME 네트워크에 <ItemLink id="ae2:crafting_accelerator" />가 충분하다면 여러 제작 작업을 동시에 실행하면서 네트워크 채널을 절약할 수 있습니다.

## 구조

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/assembler_matrix.snbt"></ImportStructure>
</GameScene>

가로·세로·높이가 각각 3~7블록인 직육면체 형태입니다.

- 모서리는 Assembler Matrix Frame으로 구성합니다.
- 외부 면은 Assembler Matrix Wall 또는 Assembler Matrix Glass로 구성합니다.
- 내부는 Assembler Matrix Pattern, Craft 또는 Speed Core로 채웁니다.

올바른 Assembler Matrix에는 Pattern Core와 Craft Core가 각각 최소 1개씩 있어야 합니다.
내부를 빈 공간 없이 완전히 채워야 합니다.
구조가 완성되고 전력이 공급되면 프레임의 선이 파란색으로 바뀝니다.

## Assembler Matrix Core 종류

Assembler Matrix Core는 세 종류입니다.

- Assembler Matrix Pattern Core

Assembler Matrix는 Pattern Core에 등록된 패턴만 사용합니다. Pattern Core 하나당 패턴 슬롯 36개를 제공합니다.

- Assembler Matrix Craft Core

Assembler Matrix는 들어온 제작 작업을 Craft Core에 할당합니다. Craft Core 하나당 제작 작업 8개를 동시에 실행할 수 있습니다.

- Assembler Matrix Speed Core

Speed Core는 Assembler Matrix의 <ItemLink id="ae2:speed_card" />와 같은 역할을 합니다. Speed Core 5개를 설치하면 최고 속도로 작동합니다.
5개를 초과하여 설치해도 속도가 더 빨라지지 않습니다.

## GUI

완성되어 온라인 상태인 Assembler Matrix를 우클릭하면 GUI가 열립니다.

![GUI](../pic/assembler_matrix.png)

여기에서 패턴을 넣거나 검색하고 현재 실행 중인 제작 작업 수를 확인할 수 있습니다.
