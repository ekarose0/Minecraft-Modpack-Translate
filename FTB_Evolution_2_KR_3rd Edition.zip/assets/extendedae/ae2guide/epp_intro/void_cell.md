---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Void Cell
    icon: extendedae:void_cell
categories:
- extended items
item_ids:
- extendedae:void_cell
---

# ME Void Cell

Drive 안에 들어가는 소형 Condenser입니다.

<ItemImage id="extendedae:void_cell" scale="4"></ItemImage>

Void Cell은 사용하기 전에 <ItemLink id="ae2:cell_workbench" />에서 필터를 설정해야 합니다. 필터에 일치하는 아이템을 모두 삭제하거나 <ItemLink id="ae2:matter_ball" /> 또는 <ItemLink id="ae2:singularity" />로 응축할 수 있습니다. <ItemLink id="ae2:condenser" />와 같은 방식입니다.

우클릭하면 설정 화면이 열립니다.

![GUI](../pic/void_cell.png)
