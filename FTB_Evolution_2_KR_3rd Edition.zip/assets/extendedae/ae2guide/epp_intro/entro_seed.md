---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Seed
    icon: extendedae:entro_seed
categories:
- entro system
item_ids:
- extendedae:entro_seed
---

# Entro Seed

<Row>
<ItemImage id="extendedae:entro_seed" scale="4"></ItemImage>
</Row>

이 씨앗에는 강력한 Entro 에너지가 들어 있습니다. Entro Seed를 들고 <ItemLink id="ae2:fluix_block" />을 우클릭하면 [Entroized Fluix Budding](./entro_budding.md)으로 바뀝니다. <ItemLink id="extendedae:crystal_assembler" />를 사용하여 씨앗을 주입할 수도 있지만, 이 방법으로 만든 [Entroized Fluix Budding](./entro_budding.md)은 수동 방식보다 등급이 낮습니다.
