---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Mod Storage Bus
    icon: extendedae:mod_storage_bus
categories:
- extended devices
item_ids:
- extendedae:mod_storage_bus
---

# ME Mod Storage Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Mod Storage Bus는 모드 이름이나 모드 ID로 필터를 지정할 수 있는 <ItemLink id="ae2:storage_bus" />입니다.

여러 모드를 필터링하려면 모드 ID를 쉼표로 구분하여 입력하세요.

![PIC](../pic/mod_bus_name.png)
