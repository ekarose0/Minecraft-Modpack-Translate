---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Precise Export Bus
    icon: extendedae:precise_export_bus
categories:
- extended devices
item_ids:
- extendedae:precise_export_bus
---

# ME Precise Export Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_export_bus.snbt"></ImportStructure>
</GameScene>

ME Precise Export Bus는 아이템이나 유체를 지정한 수량만큼 내보냅니다. 대상 저장 공간이 전체 수량을 받아들일 수 있을 때만 내보냅니다.

## 예시

![GUI](../pic/pre_bus_gui1.png)

이 설정에서는 한 번에 조약돌 3개를 내보냅니다. 네트워크에 조약돌이 3개 미만이면 내보내기를 중단합니다.

![GUI](../pic/pre_bus_gui2.png)

대상 저장 공간이 전체 수량을 받을 수 없어도 내보내기를 중단합니다. 이 상자에는 조약돌을 2개만 더 넣을 수 있으므로 Export Bus가 멈춥니다.
