---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Concurrent Processor
    icon: extendedae:concurrent_processor
categories:
- extended foundation
item_ids:
- extendedae:concurrent_processor
- extendedae:concurrent_processor_press
- extendedae:concurrent_processor_print
---

# Concurrent Processor

<Row>
<ItemImage id="extendedae:concurrent_processor" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_press" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_print" scale="4"></ItemImage>
</Row>

Concurrent Processor는 여러 작업을 동시에 처리하는 다중 스레드 기계에 주로 사용됩니다.
