---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Oversize Interface
    icon: extendedae:oversize_interface
categories:
- extended devices
item_ids:
- extendedae:oversize_interface
- extendedae:oversize_interface_part
---

# ME Oversize Interface

<Row gap="20">
<BlockImage id="extendedae:oversize_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_oversize_interface.snbt"></ImportStructure>
</GameScene>
</Row>

ME Oversize Interface의 슬롯 수는 <ItemLink id="extendedae:ex_interface" />와 같지만, 각 슬롯에 기본적으로 16배 많은 아이템을 보관할 수 있습니다(설정 변경 가능). 따라서 슬롯당 1,024개(64 × 16)를 보관합니다.

다른 모드의 특정 아이템에 대해서는 별도의 배율을 설정할 수도 있습니다.
