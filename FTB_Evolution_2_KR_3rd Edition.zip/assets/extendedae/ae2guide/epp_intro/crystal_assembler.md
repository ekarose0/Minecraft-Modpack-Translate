---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Crystal Assembler
    icon: extendedae:crystal_assembler
categories:
- extended foundation
item_ids:
- extendedae:crystal_assembler
---

# Crystal Assembler

<Row>
<BlockImage id="extendedae:crystal_assembler" scale="8"></BlockImage>
</Row>

대부분의 ExtendedAE 장치는 일반 제작대에서 만들기에는 구조가 복잡합니다. 따라서 제작에 Crystal Assembler가 필요합니다.

**주의: 화면이 있는 면은 네트워크에 연결할 수 없습니다.**

Fluix 변환과 같은 일부 월드 내 변환 제작법도 처리할 수 있습니다.
