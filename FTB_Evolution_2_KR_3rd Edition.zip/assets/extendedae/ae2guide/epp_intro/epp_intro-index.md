---
navigation:
    title: Extended AE Introduction
    position: 60
---

# AE 시스템을 확장하세요!

Extended AE는 Minecraft 1.7.10과 1.12.2 시절의 일부 AE 기능을 최신 버전으로 가져온 모드입니다.

[Extended AE GitHub](https://github.com/GlodBlock/ExtendedAE)

## Entro Crystal 시스템
<CategoryIndex category="entro system"></CategoryIndex>

## ExtendedAE 기본 재료
<CategoryIndex category="extended foundation"></CategoryIndex>

## 확장 장치
<CategoryIndex category="extended devices"></CategoryIndex>

## 확장 아이템
<CategoryIndex category="extended items"></CategoryIndex>
