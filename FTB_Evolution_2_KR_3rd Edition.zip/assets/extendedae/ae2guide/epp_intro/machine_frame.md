---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Extended Machine Frame
    icon: extendedae:machine_frame
categories:
- extended foundation
item_ids:
- extendedae:machine_frame
---

# ExtendedAE의 시작

<Row>
<BlockImage id="extendedae:machine_frame" scale="8"></BlockImage>
</Row>

<ItemLink id="extendedae:entro_crystal" />을 충분히 모았다면 첫 Extended Machine Frame을 제작할 수 있습니다. 이 프레임은 ExtendedAE의 기본 재료이며, 대부분의 블록형 기계를 제작할 때 필요합니다.
