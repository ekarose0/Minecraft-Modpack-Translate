---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Infinity Cell
    icon: extendedae:infinity_water_cell
categories:
- extended items
item_ids:
- extendedae:infinity_water_cell
- extendedae:infinity_cobblestone_cell
---

# ME Infinity Cell

물과 조약돌을 무제한으로 공급하거나 받아들일 수 있는 편리한 Storage Cell입니다.

<Row>
<ItemImage id="extendedae:infinity_water_cell" scale="4"></ItemImage>
<ItemImage id="extendedae:infinity_cobblestone_cell" scale="4"></ItemImage>
</Row>

각 셀의 용량은 21억 단위이며, 조약돌이나 물을 제한 없이 꺼내거나 넣을 수 있습니다.
