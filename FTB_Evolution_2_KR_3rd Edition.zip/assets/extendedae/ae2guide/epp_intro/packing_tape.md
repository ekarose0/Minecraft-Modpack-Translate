---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Packing Tape
    icon: extendedae:me_packing_tape
categories:
- extended items
item_ids:
- extendedae:me_packing_tape
- extendedae:package
---

# ME Packing Tape

ME Packing Tape를 사용하면 월드에 설치된 ME 장치를 Packaged Device 아이템으로 포장할 수 있습니다.

<Row>
<ItemImage id="extendedae:me_packing_tape" scale="4"></ItemImage>
<ItemImage id="extendedae:package" scale="4"></ItemImage>
</Row>

## 포장

ME 장치에 테이프를 들고 웅크린 채 우클릭하면 포장된 아이템으로 바뀝니다. 장치의 모든 설정과 인벤토리 내용이 유지되므로 ME 설비를 옮길 때 유용합니다.

ME Packing Tape는 목록에 등록된 장치만 지원합니다. 지원 장치 목록은 설정에서 변경할 수 있습니다.

### 기본 목록

|                                      장치                                       |                                 이름                                  |
|:---------------------------------------------------------------------------------:|:---------------------------------------------------------------------:|
|    <ItemImage id="extendedae:ex_interface_part" scale="3"></ItemImage>     |    <ItemLink id="extendedae:ex_interface_part"></ItemLink>     |
| <ItemImage id="extendedae:ex_pattern_provider_part" scale="3"></ItemImage> | <ItemLink id="extendedae:ex_pattern_provider_part"></ItemLink> |
|       <ItemImage id="extendedae:ex_interface" scale="3"></ItemImage>       |       <ItemLink id="extendedae:ex_interface"></ItemLink>       |
|   <ItemImage id="extendedae:ex_pattern_provider" scale="3"></ItemImage>    |   <ItemLink id="extendedae:ex_pattern_provider"></ItemLink>    |
|            <ItemImage id="ae2:cable_interface" scale="3"></ItemImage>             |            <ItemLink id="ae2:cable_interface"></ItemLink>             |
|         <ItemImage id="ae2:cable_pattern_provider" scale="3"></ItemImage>         |         <ItemLink id="ae2:cable_pattern_provider"></ItemLink>         |
|               <ItemImage id="ae2:interface" scale="3"></ItemImage>                |               <ItemLink id="ae2:interface"></ItemLink>                |
|            <ItemImage id="ae2:pattern_provider" scale="3"></ItemImage>            |            <ItemLink id="ae2:pattern_provider"></ItemLink>            |
|                 <ItemImage id="ae2:drive" scale="3"></ItemImage>                  |                 <ItemLink id="ae2:drive"></ItemLink>                  |

## 포장 해제

원래 장치 블록이나 부품을 설치하듯 포장된 아이템을 들고 우클릭하면 포장이 풀리고 장치가 복원됩니다.
