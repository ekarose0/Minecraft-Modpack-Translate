---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Pattern Provider
    icon: extendedae:ex_pattern_provider
categories:
- extended devices
item_ids:
- extendedae:ex_pattern_provider
- extendedae:ex_pattern_provider_part
---

# ME Extended Pattern Provider

<Row gap="20">
<BlockImage id="extendedae:ex_pattern_provider" scale="8"></BlockImage>
<BlockImage id="extendedae:ex_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_pattern_provider.snbt"></ImportStructure>
</GameScene>
</Row>

ME Extended Pattern Provider는 패턴 슬롯이 더 많은 <ItemLink id="ae2:pattern_provider" />입니다.

*패턴을 전부 블록 하나에 넣을 수 있는데 서브네트워크가 필요할까요?*

![EPPGui](../pic/epp_gui.png)
