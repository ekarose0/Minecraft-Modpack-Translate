---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Dust
    icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# Entro Dust

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

<ItemLink id="extendedae:entro_crystal" />을 분쇄하거나 [Entroized Fluix Budding](./entro_budding.md)을 부수면 얻을 수 있습니다.

일부 ExtendedAE 기계와 <ItemLink id="extendedae:entro_ingot" />을 제작하는 데 사용합니다.
