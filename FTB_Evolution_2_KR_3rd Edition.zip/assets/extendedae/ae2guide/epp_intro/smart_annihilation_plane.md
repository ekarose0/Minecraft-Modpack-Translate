---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Smart Annihilation Plane
    icon: extendedae:smart_annihilation_plane
categories:
- extended devices
item_ids:
- extendedae:smart_annihilation_plane
---

# ME Smart Annihilation Plane

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_smart_annihilation_plane.snbt"></ImportStructure>
</GameScene>

ME Smart Annihilation Plane은 설정 슬롯에 지정한 조건에 따라 블록을 파괴하거나 아이템을 흡수하는 <ItemLink id="ae2:annihilation_plane" />입니다.

별도의 서브네트워크가 필요하지 않습니다. <ItemLink id="ae2:import_bus" />와 비슷하지만, 상자에서 아이템을 가져오는 대신 블록을 파괴합니다.
