---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Export/Import Bus
    icon: extendedae:ex_import_bus_part
categories:
- extended devices
item_ids:
- extendedae:ex_import_bus_part
- extendedae:ex_export_bus_part
---

# ME Extended Import/Export Bus

<Row gap="20">
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_import_bus.snbt"></ImportStructure>
</GameScene>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_export_bus.snbt"></ImportStructure>
</GameScene>
</Row>

ME Extended Import Bus와 Export Bus는 일반 <ItemLink id="ae2:import_bus" /> 및 <ItemLink id="ae2:export_bus" />보다 빠르게 작동합니다. 기본 속도 배율은 8배이며 설정에서 변경할 수 있습니다.

일반 버스보다 업그레이드 슬롯도 더 많습니다.
