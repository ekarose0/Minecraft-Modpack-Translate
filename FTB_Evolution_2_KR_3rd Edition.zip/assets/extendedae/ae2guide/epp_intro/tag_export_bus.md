---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Tag Export Bus
    icon: extendedae:tag_export_bus
categories:
- extended devices
item_ids:
- extendedae:tag_export_bus
---

# ME Tag Export Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_export_bus.snbt"></ImportStructure>
</GameScene>

ME Tag Export Bus는 아이템 또는 유체 태그로 필터를 지정할 수 있는 <ItemLink id="ae2:export_bus" />입니다.

필터 규칙은 <ItemLink id="extendedae:tag_storage_bus" />와 동일합니다.
