---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Pattern Access Terminal
    icon: extendedae:ex_pattern_access_part
categories:
- extended devices
item_ids:
- extendedae:ex_pattern_access_part
- extendedae:wireless_ex_pat
---

# ME Extended Pattern Access Terminal

ME Extended Pattern Access Terminal은 <ItemLink id="ae2:pattern_access_terminal" />보다 세 가지 기능을 추가로 제공합니다.

<Row gap="20">
<GameScene zoom="6" background="transparent">
<ImportStructure src="../structure/cable_ex_pattern_terminal.snbt"></ImportStructure>
<IsometricCamera yaw="180"></IsometricCamera>
</GameScene>
<ItemImage id="extendedae:wireless_ex_pat" scale="4"></ItemImage>
</Row>

## 향상된 패턴 검색

패턴의 입력 재료나 출력 결과물 이름으로 패턴을 검색할 수 있습니다.

![EPA1](../pic/epa_gui1.png)

## 패턴 강조 표시

패턴이 그룹으로 표시되기 때문에 원하는 패턴을 찾기 어려울 수 있습니다. Extended Pattern Access Terminal은 GUI에서 검색 조건에 맞는 패턴을 강조 표시할 수 있습니다.

![EPA2](../pic/epa_gui2.png)

## 월드 내 Pattern Provider 강조 표시

대규모 제작 작업에서 어느 Pattern Provider가 멈췄는지 찾기 어려울 수 있습니다. Extended Pattern Access Terminal은 월드에 있는 해당 Pattern Provider를 강조 표시하여 쉽게 찾도록 도와줍니다.

![EPA3](../pic/epa_gui3.png)

