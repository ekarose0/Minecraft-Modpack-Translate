---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Ingredient Buffer
    icon: extendedae:ingredient_buffer
categories:
- extended devices
item_ids:
- extendedae:ingredient_buffer
---

# ME Ingredient Buffer

<BlockImage id="extendedae:ingredient_buffer" scale="8"></BlockImage>

ME Ingredient Buffer는 아이템부터 유체까지 최대 36종류의 자원을 보관할 수 있는 저장 블록입니다.
