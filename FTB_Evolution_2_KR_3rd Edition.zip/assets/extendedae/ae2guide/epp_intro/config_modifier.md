---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Config Modifier
    icon: extendedae:config_modifier
categories:
- extended items
item_ids:
- extendedae:config_modifier
---

# Config Modifier

Config Modifier는 여러 설정 슬롯의 내용을 한꺼번에 변경하는 도구입니다.

<ItemImage id="extendedae:config_modifier" scale="4"></ItemImage>

우클릭하면 설정 화면이 열립니다.

## 사용법

Config Modifier는 Interface 등의 설정 슬롯에 지정된 수량을 설정에 따라 빠르게 변경할 수 있습니다. 예를 들어 모든 수량을 최댓값으로 바꾸거나 전부 제거할 수 있습니다.

월드에 설치된 대상 장치(블록 또는 부품)에 Config Modifier를 사용하면 해당 장치의 설정이 변경됩니다.

## 설정

주요 설정은 **변경 모드**와 **변경 수량(X)** 두 가지입니다.

버튼을 클릭하면 모드를 변경할 수 있습니다.

![GUI](../pic/cm.png)

- Add/Subtract/Multiply/Divide: 설정된 각 수량에 X를 더하거나 빼고, 곱하거나 나눕니다.
- Maximize: 설정된 각 수량을 최댓값으로 바꿉니다.
- Minimize: 설정된 각 수량을 최솟값으로 바꿉니다.
- Set: 설정된 각 수량을 X로 바꿉니다.
- Clear: 설정된 내용을 모두 지웁니다.
