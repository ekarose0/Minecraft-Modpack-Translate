---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Ingot
    icon: extendedae:entro_ingot
categories:
- entro system
item_ids:
- extendedae:entro_ingot
---

# Entro Ingot

<Row>
<ItemImage id="extendedae:entro_ingot" scale="4"></ItemImage>
</Row>

*"Entro Crystal은 너무 잘 부서져 기계 프레임에 그대로 사용할 수 없지만, 금 주괴와 융합하면 연성을 높일 수 있습니다."*

<ItemLink id="extendedae:machine_frame" />을 비롯한 여러 ExtendedAE 아이템 제작에 사용합니다.
