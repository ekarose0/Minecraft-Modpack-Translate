---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Canner
    icon: extendedae:caner
categories:
- extended devices
item_ids:
- extendedae:caner
---

# ME Canner

<BlockImage id="extendedae:caner" scale="8"></BlockImage>

ME Canner는 유체, Mekanism 가스, Botania 마나, 에너지 등 다양한 자원을 용기에 채우는 기계입니다.

첫 번째 슬롯에는 채울 자원을, 두 번째 슬롯에는 자원을 담을 용기를 넣습니다.

작동하려면 에너지가 필요하며, 작업 한 번에 80 AE를 소비합니다.

![GUI](../pic/caner_gui.png)

기본적으로 유체만 채울 수 있습니다. 다른 자원을 채우려면 해당 애드온을 설치해야 합니다.

## 지원 애드온

- Applied Flux
- Applied Mekanistics
- Applied Botanics Addon

## ME Canner를 이용한 자동 제작

위쪽과 아래쪽 면으로만 에너지를 공급하고 네트워크에 연결할 수 있습니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_example.snbt"></ImportStructure>
</GameScene>

ME Canner의 간단한 구성 예시입니다. <ItemLink id="ae2:pattern_provider" />에서 재료를 받으면 자원이 채워진 아이템을 자동으로 배출합니다.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_auto.snbt"></ImportStructure>
</GameScene>

패턴에는 채울 자원과 용기만 포함해야 합니다. 다음은 설정 예시입니다.

물 양동이 채우기:

![P1](../pic/fill_water.png)

Energy Tablet 충전(Applied Flux 필요):

![P1](../pic/fill_energy.png)


## 자원 비우기

ME Canner는 Empty 모드에서 용기의 자원을 빼낼 수도 있습니다. 이때는 패턴의 입력과 출력을 서로 바꿔야 합니다.
