---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Wireless Connector
    icon: extendedae:wireless_connect
categories:
- extended devices
item_ids:
- extendedae:wireless_connect
- extendedae:wireless_tool
---

# ME Wireless Connector

<Row gap="20">
<BlockImage id="extendedae:wireless_connect" scale="6"></BlockImage>
<ItemImage id="extendedae:wireless_tool" scale="6"></ItemImage>
</Row>

ME Wireless Connector는 <ItemLink id="ae2:quantum_link" />처럼 두 네트워크를 연결할 수 있지만, 연결 거리가 제한되고 차원을 넘어 연결할 수는 없습니다. 일대일 연결만 지원하며, 여러 장치를 서로 연결하려면 <ItemLink id="extendedae:wireless_hub" />를 사용하세요.

## Wireless Connector 연결하기

ME Wireless Setup Kit로 연결할 두 Wireless Connector를 각각 클릭하세요.

웅크린 채 클릭하면 ME Wireless Setup Kit에 저장된 설정이 초기화됩니다.

연결에 성공하면 ME Wireless Connector의 텍스처가 바뀝니다.

연결되지 않은 ME Wireless Connector

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_off.snbt"></ImportStructure>
</GameScene>

연결된 ME Wireless Connector

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_on.snbt"></ImportStructure>
</GameScene>

## 색상

Wireless Connector는 케이블처럼 색상을 지정할 수 있으며 같은 색상의 케이블 및 커넥터에만 연결됩니다.

커넥터의 색상을 바꾸려면 <ItemLink id="ae2:color_applicator" />가 필요합니다.

Wireless Connector는 다음과 같이 배치할 수 있습니다.

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/wireless_connector_setup.snbt"></ImportStructure>
</GameScene>

## 전력 소비

ME Wireless Connector는 연결 거리가 멀수록 더 많은 에너지를 소비합니다. 거리와 소비량이 정비례하지 않으므로 너무 멀리 설치하면 전력 소비가 매우 커질 수 있습니다.

<ItemLink id="ae2:energy_card" />를 사용하면 전력 소비를 줄일 수 있습니다. 카드 하나당 소비 에너지가 10% 감소합니다.

