---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: Quartz Blend
  icon: extendedae:quartz_blend
categories:
  - extended foundation
item_ids:
  - extendedae:quartz_blend
---

# Quartz Blend

<Row>
<ItemImage id="extendedae:quartz_blend" scale="4"></ItemImage>
</Row>

석영, 석탄, 모래를 섞은 재료입니다. Certus Quartz Dust를 직접 제련하는 것보다 더 많은 <ItemLink id="ae2:silicon" />을 얻을 수 있습니다.
