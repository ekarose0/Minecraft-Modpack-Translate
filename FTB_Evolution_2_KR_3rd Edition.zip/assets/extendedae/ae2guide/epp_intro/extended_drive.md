---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Drive
    icon: extendedae:ex_drive
categories:
- extended devices
item_ids:
- extendedae:ex_drive
---

# ME Extended Drive

<Row gap="20">
<BlockImage id="extendedae:ex_drive" scale="8"></BlockImage>
</Row>

ME Extended Drive는 셀 슬롯이 확장된 <ItemLink id="ae2:drive" />입니다. Storage Cell을 최대 20개까지 장착할 수 있습니다.
