---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Precise Storage Bus
    icon: extendedae:precise_storage_bus
categories:
- extended devices
item_ids:
- extendedae:precise_storage_bus
---

# ME Precise Storage Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Precise Storage Bus는 보관 수량 한도를 설정할 수 있는 <ItemLink id="ae2:storage_bus" />입니다. 설정한 수량까지만 아이템을 넣습니다.

![GUI](../pic/pre_storage_bus.png)
