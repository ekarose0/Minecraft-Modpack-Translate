---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Budding Entroized Fluix
    icon: extendedae:entro_budding_fully
categories:
- entro system
item_ids:
- extendedae:entro_budding_fully
- extendedae:entro_budding_mostly
- extendedae:entro_budding_half
- extendedae:entro_budding_hardly
- extendedae:entro_cluster_small
- extendedae:entro_cluster_medium
- extendedae:entro_cluster_large
- extendedae:entro_cluster
---

# Budding Entroized Fluix

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/budding_entro.snbt"></ImportStructure>
  <IsometricCamera yaw="195" pitch="30"></IsometricCamera>
</GameScene>

Budding Entroized Fluix는 <ItemLink id="extendedae:entro_crystal" />을 얻는 데 사용하는 블록입니다. <ItemLink id="ae2:fluix_block" />에 <ItemLink id="extendedae:entro_seed" />를 주입하여 만들 수 있습니다.

Entro Bud의 성장 방식은 [Certus Quartz](ae2:items-blocks-machines/budding_certus.md)와 비슷합니다. 하지만 Budding Entroized Fluix는 사용하면서 반드시 열화되며, 결국 <ItemLink id="ae2:quartz_block" />으로 변합니다.
행운 마법 부여 없이도 Fully Entroized Fluix 하나에서 이론상 <ItemLink id="extendedae:entro_crystal" /> 약 10개를 얻을 수 있습니다.

Budding Entroized Fluix는 상태에 관계없이 부수면 <ItemLink id="extendedae:entro_dust" /> **1개**를 떨어뜨립니다.
완전히 자라지 않은 Entro Bud를 부수면 <ItemLink id="extendedae:entro_shard" />를 얻습니다.
