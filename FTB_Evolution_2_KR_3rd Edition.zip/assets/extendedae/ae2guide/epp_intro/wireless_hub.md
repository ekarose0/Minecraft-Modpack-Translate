---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Wireless Hub
    icon: extendedae:wireless_hub
categories:
- extended devices
item_ids:
- extendedae:wireless_hub
---

# ME Wireless Hub

<Row gap="20">
<BlockImage id="extendedae:wireless_hub" scale="6"></BlockImage>
</Row>

ME Wireless Hub는 <ItemLink id="extendedae:wireless_connect" />와 같은 방식으로 작동하지만, 허브나 커넥터를 최대 8개까지 동시에 연결할 수 있습니다.

## 연결 설정

ME Wireless Hub에는 포트가 8개 있습니다. <ItemLink id="extendedae:wireless_tool" />로 연결하면 사용 가능한 포트를 자동으로 찾습니다.

모든 포트가 사용 중이라면 새 연결을 설정하기 전에 X 버튼을 눌러 기존 연결 하나를 직접 해제해야 합니다.
