---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Extended Molecular Assembler
    icon: extendedae:ex_molecular_assembler
categories:
- extended devices
item_ids:
- extendedae:ex_molecular_assembler
---

# Extended Molecular Assembler

<Row gap="20">
<BlockImage id="extendedae:ex_molecular_assembler" scale="8"></BlockImage>
</Row>

Extended Molecular Assembler는 <ItemLink id="ae2:molecular_assembler" />의 상위 버전입니다.

ME 네트워크에 <ItemLink id="ae2:crafting_accelerator" />가 있다면 제작 작업 8개를 동시에 처리할 수 있으며, 일반 Molecular Assembler보다 처리 속도가 2배 빠릅니다.

단, <ItemLink id="ae2:pattern_provider" />에서 전달하는 제작 작업만 지원하므로 패턴을 직접 넣을 수는 없습니다.
