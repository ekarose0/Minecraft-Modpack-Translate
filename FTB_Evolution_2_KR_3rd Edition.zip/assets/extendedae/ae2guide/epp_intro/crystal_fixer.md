---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Crystal Fixer
    icon: extendedae:crystal_fixer
categories:
- extended devices
item_ids:
- extendedae:crystal_fixer
---

# ME Crystal Fixer

<BlockImage id="extendedae:crystal_fixer" scale="8"></BlockImage>

ME Crystal Fixer는 Budding Certus Quartz 블록을 복구하고 상위 단계로 바꿀 수 있습니다.

작동하려면 전력과 <ItemLink id="ae2:charged_certus_quartz_crystal" />이 필요합니다. <ItemLink id="ae2:charged_certus_quartz_crystal" />을 손에 들고 우클릭하면 장치에 넣을 수 있습니다.

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>
