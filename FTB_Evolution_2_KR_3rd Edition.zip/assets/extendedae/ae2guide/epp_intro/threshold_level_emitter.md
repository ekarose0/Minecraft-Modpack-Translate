---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Threshold Level Emitter
    icon: extendedae:threshold_level_emitter
categories:
- extended devices
item_ids:
- extendedae:threshold_level_emitter
---

# ME Threshold Level Emitter

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_level_emitter.snbt"></ImportStructure>
</GameScene>

이 장치는 리셋-셋 래치처럼 작동합니다. 네트워크에 있는 아이템 수량이 하한 임계값보다 적으면 레드스톤 신호를 끄고, 상한 임계값보다 많으면 신호를 켭니다.

예를 들어 하한을 100, 상한을 150으로 설정했다고 가정하겠습니다.

처음에는 네트워크가 비어 있으므로 Emitter가 작동하지 않습니다.

아이템 수량이 150개를 초과하면 레드스톤 신호를 출력합니다.

수량이 다시 150개 미만으로 내려가도 신호는 계속 유지됩니다.

수량이 100개 미만으로 떨어지면 신호를 끕니다.
