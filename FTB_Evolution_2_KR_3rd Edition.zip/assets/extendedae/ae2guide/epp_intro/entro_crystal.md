---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Crystal
    icon: extendedae:entro_crystal
categories:
- entro system
item_ids:
- extendedae:entro_crystal
---

# The Entro Crystal

<Row>
<ItemImage id="extendedae:entro_crystal" scale="4"></ItemImage>
</Row>

*"Fluix Crystal에 Ender Dust를 주입하면 Entro Crystal이 매우 강한 차원 친화성을 띠며, 시공간을 가로질러 공명할 수 있게 됩니다."*

Entro Crystal은 대부분의 ExtendedAE 아이템과 기계에 사용되는 핵심 제작 재료입니다. <ItemLink id="extendedae:entro_seed" />로 <ItemLink id="ae2:fluix_block" />을 [Entroized Fluix Budding](./entro_budding.md)으로 바꾼 뒤, Entro Cluster를 수확하면 얻을 수 있습니다.
