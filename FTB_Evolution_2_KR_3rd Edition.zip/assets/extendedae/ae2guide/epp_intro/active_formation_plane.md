---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Active Formation Plane
    icon: extendedae:active_formation_plane
categories:
- extended devices
item_ids:
- extendedae:active_formation_plane
---

# ME Active Formation Plane

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

ME Active Formation Plane은 블록을 직접 설치하거나 아이템을 떨어뜨릴 수 있는 <ItemLink id="ae2:formation_plane" />입니다.

별도의 서브네트워크를 구성할 필요가 없습니다. <ItemLink id="ae2:export_bus" />와 비슷하게 작동하지만, 상자로 아이템을 내보내는 대신 블록을 설치합니다.
