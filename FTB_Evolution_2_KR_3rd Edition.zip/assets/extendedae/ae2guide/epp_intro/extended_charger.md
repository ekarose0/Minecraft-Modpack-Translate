---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Extended Charger
    icon: extendedae:ex_charger
categories:
- extended devices
item_ids:
- extendedae:ex_charger
---

# Extended Charger

<Row gap="20">
<BlockImage id="extendedae:ex_charger" scale="8"></BlockImage>
</Row>

Extended Charger는 <ItemLink id="ae2:charger" />의 상위 버전입니다.

아이템 4개를 동시에 충전할 수 있습니다.
