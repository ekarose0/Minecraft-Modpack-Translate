---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Pattern Modifier
    icon: extendedae:pattern_modifier
categories:
- extended items
item_ids:
- extendedae:pattern_modifier
---

# Pattern Modifier

Pattern Modifier는 여러 패턴을 한꺼번에 수정하는 도구입니다.

<ItemImage id="extendedae:pattern_modifier" scale="4"></ItemImage>

우클릭하면 GUI가 열립니다.

## 배율 모드

해당 버튼을 클릭하여 처리 패턴의 입력·출력 수량을 X배로 늘리거나 X로 나눌 수 있습니다.

![PM](../pic/pm.png)

원본 패턴:

![PM1](../pic/pm1.png)

10배 적용 후:

![PM2](../pic/pm2.png)

Clear 버튼을 클릭하면 모든 패턴의 내용을 지워 빈 패턴으로 만들 수도 있습니다.

### 주의사항

- 나누기 버튼은 수량이 나누어떨어질 때만 작동합니다. 예를 들어 조약돌 3개가 필요한 패턴은 3÷2=1.5이므로 ÷2 버튼을 사용할 수 없습니다.

- 곱하기 기능의 최대 수량은 999999입니다. 단일 재료의 수량을 이보다 높일 수 없습니다.

## 교체 모드

패턴의 특정 입력 또는 출력 재료를 다른 아이템으로 교체합니다.

![PM3](../pic/pm4.png)

슬롯 A에는 교체할 재료를, 슬롯 B에는 대신 사용할 재료를 넣습니다.

예를 들어 아래 설정은 판자를 석탄으로 교체합니다.

![PM4](../pic/pm6.png)

![PM5](../pic/pm5.png)

Replace 버튼을 누르면 교체가 적용됩니다.

![PM6](../pic/pm7.png)

## 속성 모드

제작 패턴의 Substitutions 및 Fluid Substitutions 설정을 변경합니다.

![PM8](../pic/pm8.png)

## 복제 모드

이 모드에서는 원하는 패턴을 복사할 수 있습니다.

![PM7](../pic/pm3.png)

