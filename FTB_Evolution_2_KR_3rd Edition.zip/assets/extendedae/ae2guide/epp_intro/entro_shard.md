---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Shard
    icon: extendedae:entro_shard
categories:
- entro system
item_ids:
- extendedae:entro_shard
---

# Entro Shard

<Row>
<ItemImage id="extendedae:entro_shard" scale="4"></ItemImage>
</Row>

[Entro Bud](./entro_budding.md)가 완전히 자라기 전에 부수면 Entro Shard를 얻습니다. Entro Shard 8개를 조합하면 <ItemLink id="extendedae:entro_crystal" /> 1개로 되돌릴 수 있습니다.
