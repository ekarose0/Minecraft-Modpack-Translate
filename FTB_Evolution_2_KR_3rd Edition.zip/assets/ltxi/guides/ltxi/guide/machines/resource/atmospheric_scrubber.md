---
navigation:
    title: Atmospheric Scrubber
    icon: atmospheric_scrubber
    position: 3
    parent: machines/resource/index.md
item_ids:
  - atmospheric_scrubber
---
# Atmospheric Scrubber

<BlockImage id="atmospheric_scrubber" scale="4" />

## 설명

Atmospheric Scrubber는 주변 환경에서 가스와 유체를 추출하는 데 특화되어 있습니다. 차원 전체에 존재하는 자원을 추출하거나, Overworld의 바다와 늪처럼 특정 위치에서만 얻을 수 있는 자원을 추출하도록 설정할 수 있습니다.

## 기계 사양

- 기본 작동 주기: 30초
- 입력 없음
- 출력: 유체 1~4종, 아이템 0~2개
