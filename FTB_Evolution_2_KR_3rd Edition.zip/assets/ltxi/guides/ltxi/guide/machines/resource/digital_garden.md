---
navigation:
    title: "Bio/ARU Garden"
    icon: digital_garden
    parent: machines/resource/index.md
    position: 2
item_ids:
  - digital_garden
---
# Bio/ARU Garden

<GameScene zoom={4} interactive={false}>
<Block id="mesh_block" y="1" />
<Block id="digital_garden" y="0" />
<BlockAnnotation x="0" y="0" z="0" color="#8bd1f0">
아이템, 에너지, 유체는 이 블록에만 연결할 수 있습니다!
</BlockAnnotation>
</GameScene>

## 설명

Bio/ARU Garden은 수경 재배 시설입니다. 통합 환경 제어 시스템이 습도, 비료, 영양분 수준을 최적으로 유지하므로 까다로운 식물도 잘 자랄 수 있습니다.

## 레시피 사양
- 기본 제작 시간: 레시피에 따라 다르며 기본값은 30초
- 입력: 아이템 1개, 유체 1종
- 출력: 아이템 1~4개
