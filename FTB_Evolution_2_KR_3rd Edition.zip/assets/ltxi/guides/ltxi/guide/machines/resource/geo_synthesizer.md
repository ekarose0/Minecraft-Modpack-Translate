---
navigation:
    title: Geo Synthesizer
    icon: geo_synthesizer
    parent: machines/resource/index.md
    position: 1
item_ids:
  - geo_synthesizer
---
# Geo Synthesizer

<BlockImage id="geo_synthesizer" scale="4" />

## 설명
Geo Synthesizer는 지질을 구성하는 기본 재료를 효율적으로 대량 생산하는 데 특화되어 있습니다. 간단히 말해 돌을 만드는 기계입니다.

## 레시피 사양
- 기본 제작 시간: 레시피에 따라 다르며 기본값은 3초
- 입력: 아이템 1개, 정확히 2종의 유체
- 출력: 아이템 1개
