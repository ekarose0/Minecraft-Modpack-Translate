---
navigation:
    title: Resource Machines
    icon: atmospheric_scrubber
    position: 20
---
# 자원 생산 기계

<SubPages />
