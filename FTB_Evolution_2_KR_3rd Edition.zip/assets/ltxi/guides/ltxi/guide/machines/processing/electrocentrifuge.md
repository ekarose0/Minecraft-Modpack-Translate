---
navigation:
    title: ElectroCentrifuge
    icon: electrocentrifuge
    parent: machines/processing/index.md
    position: 105
item_ids:
    - electrocentrifuge
---
# ElectroCentrifuge

<BlockImage id="electrocentrifuge" scale="4" />

## 설명

전기분해와 원심분리를 하나로 결합한 LTXI의 핵심 발명품 중 하나입니다. 다양한 재료에서 기본 원소를 추출하는 데 특화되어 있습니다.

## 레시피 사양

- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 0~1개, 유체 0~1종
- 출력: 아이템 0~4개, 유체 0~2종
