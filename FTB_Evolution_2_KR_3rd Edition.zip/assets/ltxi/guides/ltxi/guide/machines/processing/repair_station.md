---
navigation:
    title: Repair Station
    icon: repair_station
    parent: machines/processing/index.md
    position: 200
item_ids:
  - repair_station
---
# Repair Station

<BlockImage id="repair_station" scale="4" />

모든 장비가 최첨단 ε-Series 또는 Wonderland 기술을 사용하지는 못하며, 열등한 내구도 시스템에 의존한다는 점을 잘 알고 있습니다. Repair Station은 이런 경우를 위해 만들어졌습니다. 이 기계는 <Color id="energy">Energy</Color>를 사용하여 장비의 분자 구조를 원래 상태로 복원하며, 횟수 제한 없이 수리할 수 있습니다. 물론 수리하기 전에 도구가 완전히 파괴되지 않아야 합니다.

> `#ltxi:repair_blacklist` 태그가 붙은 아이템이나 표준 방식이 아닌 내구도 시스템을 사용하는 아이템은 수리할 수 없습니다.
