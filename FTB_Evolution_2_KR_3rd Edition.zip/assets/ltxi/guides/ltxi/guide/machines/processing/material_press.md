---
navigation:
    title: Material Press
    icon: material_press
    parent: machines/processing/index.md
    position: 102
item_ids:
  - material_press
---
# Material Press

<BlockImage id="material_press" scale="4" />

## 설명

휴대 가능한 다목적 유압 압출·압착·성형 기계입니다. 원재료를 판, 기어, 기타 단순한 형태로 가공합니다.

## 레시피 사양

- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 0~2개, 유체 0~1종
- 출력: 아이템 1~2개
