---
navigation:
    title: Mixer
    icon: mixer
    parent: machines/processing/index.md
    position: 106
item_ids:
  - mixer
---
# Mixer

<BlockImage id="mixer" scale="4" />

## 설명

완전한 Chem Lab 수준의 정밀 제어가 필요하지 않은 화학물질, 재료, 추출물을 혼합하는 데 특화된 기계입니다. 저희 Polymer Panel보다 Concrete를 선호하신다면 그것도 혼합할 수 있습니다.

## 레시피 사양

- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 0~4개, 유체 0~2종
- 출력: 아이템 0~1개, 유체 0~1종
