---
navigation:
    title: Arc Furnace
    icon: arc_furnace
    parent: machines/processing/index.md
    position: 103
item_ids:
  - arc_furnace
---
# Arc Furnace

<BlockImage id="arc_furnace" scale="4" />

## 설명

고온 디지털 제련기로, 금속 합금과 인 기반 Neon Light 같은 원소 복합 재료를 만들 수 있습니다. 일반 화로보다 훨씬 높은 온도와 보호 가스가 필요한 Tungsten-Plated Slatesteel, Rhenium 등의 금속 가루도 제련할 수 있습니다.

## 레시피 사양

- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 1~3개, 유체 0~1종
- 출력: 아이템 1개
