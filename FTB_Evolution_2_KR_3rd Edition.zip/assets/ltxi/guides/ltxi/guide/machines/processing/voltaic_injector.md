---
navigation:
    title: Voltaic Injector
    icon: voltaic_injector
    parent: machines/processing/index.md
    position: 107
item_ids:
    - voltaic_injector
---
# Voltaic Injector

<BlockImage id="voltaic_injector" scale="4" />

## 설명

매우 높은 전압의 광선을 재료에 조사합니다. 일부 염료를 특수 안료로 변환하고, 광석 재료를 깔끔하게 절단하며, Titanium Glass를 푸른색으로 만들 수 있습니다.

## 레시피 사양
- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 1개
- 출력: 아이템 1~3개
