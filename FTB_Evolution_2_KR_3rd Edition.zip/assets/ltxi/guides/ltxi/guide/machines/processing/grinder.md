---
navigation:
    title: Grinder
    icon: grinder
    parent: machines/processing/index.md
    position: 101
item_ids:
    - grinder
---
# Grinder

<BlockImage id="grinder" scale="4" />

## 설명

다양한 재료를 분쇄하여 가치가 높은 생산물이나 후속 가공에 사용할 중간 재료로 만듭니다.

## 레시피 사양

- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 1개
- 출력: 아이템 0~3개, 유체 0~1종
