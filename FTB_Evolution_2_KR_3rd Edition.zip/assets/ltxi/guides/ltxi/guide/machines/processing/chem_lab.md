---
navigation:
    title: Chem Lab
    icon: chem_lab
    parent: machines/processing/index.md
    position: 108
item_ids:
    - chem_lab
---
# Chem Lab

<BlockImage id="chem_lab" scale="4" />

## 설명

화학물질의 반응을 자동으로 정밀 제어하는 통합 시스템입니다. 과학 연구실과 산업 가공 시설에 빠질 수 없는 기계입니다.

## 레시피 사양
- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 0~3개, 유체 0~3종
- 출력: 아이템 0~3개, 유체 0~3종
