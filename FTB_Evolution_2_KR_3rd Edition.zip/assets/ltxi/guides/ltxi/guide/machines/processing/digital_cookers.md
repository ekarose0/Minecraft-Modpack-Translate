---
navigation:
    title: Digital Cooking
    icon: digital_furnace
    parent: machines/processing/index.md
    position: 100
item_ids:
  - digital_furnace
  - digital_smoker
  - digital_blast_furnace
---
# Digital Cooking 기계

<Row>
<BlockImage id="digital_furnace" scale="3" />
<BlockImage id="digital_smoker" scale="3" />
<BlockImage id="digital_blast_furnace" scale="3" />
</Row>

## 설명
Digital Cooking 기계는 **Digital Furnace**, **Digital Smoker**, **Digital Blast Furnace** 세 종류로 구성됩니다. 이름에서 알 수 있듯이, 기본 게임의 조리 블록을 LTXI의 [업그레이드 가능](../../fundamentals/upgrade_system.md)한 기계로 만든 버전입니다.

## 레시피 사양
- 기본 제작 시간: 레시피에 따라 다르며 바닐라 조리 시간을 사용
- 입력: 아이템 1개
- 출력: 아이템 1개
