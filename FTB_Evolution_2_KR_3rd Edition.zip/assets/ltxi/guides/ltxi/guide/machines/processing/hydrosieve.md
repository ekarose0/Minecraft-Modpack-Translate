---
navigation:
    title: HydroSieve
    icon: hydrosieve
    parent: machines/processing/index.md
    position: 104
item_ids:
  - hydrosieve
---
# HydroSieve

<BlockImage id="hydrosieve" scale="4" />

## 설명

연구 부서의 조사에 따르면, 흐르는 물을 사용한 체질 방식은 기존의 건식 방식보다 수율과 효율이 높고 자동화에도 유리합니다.

## 레시피 사양

- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 1개, 유체 1종
- 출력: 아이템 1~6개
