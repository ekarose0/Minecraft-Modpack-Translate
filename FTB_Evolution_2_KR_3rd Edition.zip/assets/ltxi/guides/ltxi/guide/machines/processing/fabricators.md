---
navigation:
    title: "Fabrication"
    icon: fabricator
    parent: machines/processing/index.md
    position: 110
item_ids:
    - fabricator
    - auto_fabricator
    - empty_fabrication_blueprint
    - fabrication_blueprint
---
# Tech Fabrication

일부 업그레이드와 장비는 구조가 너무 복잡해서 일반 가공 기계나 작업대로 만들 수 없습니다. 이러한 제작에는 Fabricator가 필요합니다. Fabrication 레시피는 다른 LTXI 레시피와 방식이 다르므로 아래 사양을 확인하세요.

## 레시피 사양
- 입력: 아이템 1~16개
- 출력: 아이템 1개
- 에너지 비용: 레시피에 따라 다르며, **제작 시간 대신 사용**

제작 시간이 따로 없으므로 Fabricator의 제작 속도는 레시피의 에너지 비용과 기계의 **Energy Usage** 능력치로 결정됩니다. 이 기계에서는 Energy Usage 능력치를 긍정적인 수치로 생각하셔도 됩니다.

## Fabricator
<GameScene zoom={3} interactive={false}>
<Block id="fabricator" y="-1" x="0" />
<Block id="mesh_block" y="-1" x="-1" />
<Block id="mesh_block" y="0" x="0" />
<Block id="mesh_block" y="0" x="-1" />
<BlockAnnotation x="0" y="-1" z="0" color="#8bd1f0">
아이템과 에너지는 이 블록의 앞면, 왼쪽, 뒷면, 아랫면으로만 연결할 수 있습니다!
</BlockAnnotation>
</GameScene>

수동 Fabricator라고도 하며, 처음 만들게 되는 Fabrication 기계입니다. 레시피 목록에서 사용 가능한 제작법을 확인할 수 있습니다. 레시피를 한 번 왼쪽 클릭하면 선택됩니다. 선택한 상태에서 다시 왼쪽 클릭하면 제작하고, 오른쪽 클릭하면 **Empty Fabrication Blueprint**에 레시피를 기록합니다. 이 Fabricator에는 입력 슬롯이 없으며, 편리하게 제작할 수 있도록 플레이어 인벤토리에서 재료를 직접 가져옵니다.

## Fabrication Blueprint
<ItemGrid>
<ItemIcon id="empty_fabrication_blueprint" />
<ItemIcon id="fabrication_blueprint" />
</ItemGrid>

레시피가 기록된 **Fabrication Blueprint**는 Auto Fabricator 또는 AE2 Pattern Provider에서 Fabrication 레시피를 사용하는 데 필요합니다. 아이템 설명을 볼 때 Shift를 누르면 레시피 정보가 표시됩니다. Shift + 오른쪽 클릭으로 기록된 레시피를 지울 수 있습니다.

## Auto Fabricator
<BlockImage id="auto_fabricator" scale="2" />

Fabricator의 자동화에 특화된 버전입니다. 사용 가능한 레시피 종류는 적지만 자동화가 쉽습니다. 일반 Fabricator와 달리 재료 입력 슬롯이 16개 있으며, 플레이어 인벤토리에서 재료를 가져올 수 없습니다.

### Blueprint 하나로 작동시키기

기록된 Fabrication Blueprint를 Blueprint 슬롯에 넣으면 이 모드로 작동합니다. 원하는 아이템 운송 수단으로 정확한 수량의 재료를 공급해야 합니다. 재료와 에너지가 충분하면 Blueprint의 레시피를 계속 제작합니다.

### AE2 Pattern Provider 연동
AE2의 **Pattern Provider**는 Auto Fabricator 및 기록된 Fabrication Blueprint와 기본적으로 호환됩니다. **주의! Blueprint 슬롯이 비어 있어야 Pattern Provider가 Auto Fabricator를 유효한 제작 기계로 인식합니다.**

- Blueprint 자체가 패턴 역할을 합니다. Processing Pattern을 만들 필요 없이 Pattern Provider의 패턴 슬롯에 바로 넣으세요.
- 복합 재료, 태그, 재료 대체를 기본적으로 지원합니다.
- Blocking Mode는 필요하지 않습니다. 아이템과 Blueprint 공급이 자동으로 관리됩니다.
- 패턴을 보낼 때마다 아이템 입출력 설정이 다시 구성됩니다. Pattern Provider가 연결된 면은 자동 출력으로 설정되고 나머지 면은 비활성화됩니다.
