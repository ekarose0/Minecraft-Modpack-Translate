---
navigation:
    title: Assembler
    icon: assembler
    parent: machines/processing/index.md
    position: 109
item_ids:
  - assembler
---
# Assembler

<BlockImage id="assembler" scale="4" />

## 설명

신입 직원들은 수작업 제작만으로 기술을 발전시키는 데 한계가 있다는 사실을 대개 힘들게 깨닫습니다. 다행히 Assembler는 Voltaic Cell, Circuit, Machine Housing처럼 기계를 구성하는 거의 모든 부품을 제작할 수 있습니다.

## 레시피 사양

- 기본 제작 시간: 레시피에 따라 다르며 기본값은 10초
- 입력: 아이템 1~6개, 선택적 유체 1종
- 출력: 아이템 1개
