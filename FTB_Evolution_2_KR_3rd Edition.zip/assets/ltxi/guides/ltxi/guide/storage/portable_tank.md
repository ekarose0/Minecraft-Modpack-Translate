---
navigation:
    title: "Portable Tank"
    position: 2
    parent: storage/index.md
    icon: portable_tank
item_ids:
  - portable_tank
  - infinite_water_tank
  - infinite_lava_tank
---
# Portable Tank

<BlockImage id="portable_tank" scale="4" />

**Portable Tank**는 범용 유체 저장 장치입니다. 입출력 방향을 설정할 수 있으며 [업그레이드](../fundamentals/upgrade_system.md)도 가능합니다. 블록을 부숴도 내부 유체가 유지되며, 아이템과 설치된 블록 양쪽 모두에서 **유체 처리 기능**을 제공합니다. 아이템 상태에서는 전송량 제한이 없고, 설치된 블록 상태에서는 총 용량의 1/10까지 전송할 수 있습니다.

> 용량을 늘려 주는 업그레이드를 제거할 때 주의하세요! 저장된 유체가 변경된 용량을 초과하면 초과분이 소멸합니다.

## Special Infinite Variants

<Row>
<BlockImage id="infinite_water_tank" scale="2" />
<BlockImage id="infinite_lava_tank" scale="2" />
</Row>

이 특수 Portable Tank는 고유한 이름과 외형을 가지고 있습니다. 유체 공급량과 전송 한도가 사실상 무한하며, 정확하게는 `Integer.MAX_VALUE`입니다. 자동 출력 속도도 일반형의 20틱보다 빠른 5틱입니다.
