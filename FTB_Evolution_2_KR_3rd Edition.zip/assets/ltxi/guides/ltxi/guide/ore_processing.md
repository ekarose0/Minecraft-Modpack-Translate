---
navigation:
    title: Ore Processing
    icon: crushed_silver_ore
    position: 21
---
# 광석 가공

시설이 확장될수록 길고 힘든 채굴 여행을 반복하고 싶지 않으실 것입니다. 아마도요. 다행히 저희 기계는 복잡한 **5단계** 공정을 통해 광석 생산량을 평균 **10.125배**까지 늘릴 수 있습니다!

이 정도로도 충분히 매력적이지 않다면, 최소한 Titanium, Olivine, Copper 광석만큼은 가공해야 합니다. 각각 Tungsten, Pyroxene, Rhenium을 추출하는 데 필요하기 때문입니다.

<ItemGrid>
<ItemIcon id="raw_silver" />
<ItemIcon id="silver_ore" />
</ItemGrid>

원재료 또는 광석 블록에서 시작해 Crushed, Washed, Chunk, Solution, Crystal 형태로 차례대로 가공합니다.

<ItemGrid>
<ItemIcon id="crushed_silver_ore" />
<ItemIcon id="washed_silver_ore" />
<ItemIcon id="silver_ore_chunk" />
<ItemIcon id="silver_ore_solution" />
<ItemIcon id="silver_ore_crystal" />
</ItemGrid>

어느 단계에서든 가공을 멈추고 광석 재료를 제련하여 최종 생산물을 얻을 수 있습니다(예: Crushed Silver Ore 또는 Silver Ore Solution을 Silver Ingot으로 제련). 1단계에서는 광석이 반드시 2배로 늘어납니다. 이후 단계마다 처리한 아이템이 50% 확률로 2배가 됩니다. 따라서 *평균적으로* 2~5단계의 총 배율은 각각 3배, 4.5배, 6.75배, 10.125배입니다.

## 1단계

첫 번째 공정은 [Grinder](machines/processing/grinder.md)에서 진행합니다. 원재료나 광석 블록을 분쇄하여 Crushed Ore를 만듭니다.

## 2단계

[HydroSieve](machines/processing/hydrosieve.md)는 Crushed Ore를 Washed Ore로 가공합니다. 이 과정에서는 Water가 소비되지만, 워낙 풍부한 자원이라 크게 걱정할 필요는 없습니다. 거의 그렇습니다.

## 3단계

[Voltaic Injector](machines/processing/voltaic_injector.md)는 Washed Ore를 Ore Chunk로 정제합니다. Voltaic Injector 제작에는 [Olivine](resources/gems.md#olivine) 결정이 필요하므로, 이 단계에 도달하기 전에 HydroSieve를 설치하여 최소한 Olivine을 자동 생산하고 있어야 합니다.

### Pyroxene과 Tungsten

<ItemGrid>
<ItemIcon id="pyroxene" />
<ItemIcon id="tungsten_trioxide" />
</ItemGrid>

Olivine과 Titanium을 가공하면 부산물로 Pyroxene과 Tungsten Trioxide를 얻을 수 있습니다.

## 4단계

[Chem Lab](machines/processing/chem_lab.md)은 소량의 [Sulfuric Acid](resources/acids.md#sulfuric-acid)를 사용하여 Ore Chunk를 녹이고, 병에 담긴 Ore Solution을 만듭니다. 광석 가공만을 위한 Sulfuric Acid 생산 라인을 별도로 구축하는 것이 좋습니다.

## 5단계

[ElectroCentrifuge](machines/processing/electrocentrifuge.md)는 [Hydrochloric Acid](resources/acids.md#hydrochloric-acid)를 사용하여 Ore Solution에서 Ore Crystal을 석출합니다. Silicone Rubber와 Fluoropolymer 생산 과정에서 나오는 폐기물만으로는 산 공급량이 부족하므로, 이 단계에서도 전용 산 공급 라인을 권장합니다.

### Rhenium(VII) Oxide

<ItemGrid>
<ItemIcon id="rhenium_7_oxide" />
</ItemGrid>

Copper 광석을 끝까지 가공하면 Rhenium(VII) Oxide가 나옵니다. 이 정도로 진행했는데도 산 공급이 병목이라면 Copper 광석을 우선 처리하세요. Rhenium은 최고 등급의 업그레이드와 장비에 사용됩니다.
