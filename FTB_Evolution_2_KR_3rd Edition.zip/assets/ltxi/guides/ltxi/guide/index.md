---
navigation:
    title: Welcome
    icon: guide_tablet
    position: 0
---
# LTX Industries에 오신 것을 환영합니다!

이 가이드에는 이 모드에 대해 알아야 할 내용이 *거의* 모두 담겨 있습니다. 먼저 *기본 시스템*과 *자원* 항목부터 읽어 보시는 것을 추천합니다.
