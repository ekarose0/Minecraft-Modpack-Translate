---
navigation:
    title: Wonderland Armor
    icon: wonderland_head
    position: 30
---
# Wonderland Armor

코드명 *Wonderland*인 AL/1C 동력식 모듈형 외골격 슈트는 LTXI의 대표 방어구 세트입니다. [업그레이드](fundamentals/upgrade_system.md)를 통해 방어력, 편의 기능, 가혹한 환경에 대한 보호 성능, 에너지 저장량을 늘릴 수 있습니다.

모든 AL/1C 부위는 표준 방어 업그레이드 2개와 부위별 고유 업그레이드 1개를 갖춘 상태로 [Fabrication](machines/processing/fabricators.md)됩니다. 기본 방어 업그레이드 모듈은 입문용으로, 더 높은 등급으로 강화하면 방어력을 크게 높일 수 있습니다.

## 모든 부위

<Row>
<UpgradeEntry id="armor_defense" rank="1" />
<UpgradeEntry id="armor_passive_shield" rank="1" />
</Row>

## 머리

<Row>
<ItemImage id="wonderland_head" />
<UpgradeEntry id="default/wonderland_head" />
</Row>

## 몸통

<Row>
<ItemImage id="wonderland_body" />
<UpgradeEntry id="default/wonderland_body" />
</Row>

## 다리

<Row>
<ItemImage id="wonderland_legs" />
<UpgradeEntry id="default/wonderland_legs" />
</Row>

## 발

<Row>
<ItemImage id="wonderland_feet" />
<UpgradeEntry id="default/wonderland_feet" />
</Row>
