---
navigation:
    title: Atmos
    icon: rocket_turret
    parent: turrets/index.md
    position: 1
item_ids:
  - rocket_turret
---
# *Atmos* A/DS Turret

<GameScene zoom={4} interactive={false}>
<Block id="mesh_block" y="0" />
<Block id="rocket_turret" y="-1" />
<BlockAnnotation x="0" y="-1" z="0" color="#8bd1f0">
아이템과 에너지는 이 블록에만 연결할 수 있습니다!
</BlockAnnotation>
</GameScene>

## Stats
- 수평 탐색 반경: 50.0
- 수직 탐색 반경: 75.0
- 표적 탐색 간격: 5초
- 일제 사격당 최대 표적 수: 4
- Rocket 피해량: 40.0

## Default targets

`#ltxi:targets/flying` 태그가 있는 개체입니다. 예: Phantom, Ghast, Blaze, Breeze, Ender Dragon, Vex, Wither
