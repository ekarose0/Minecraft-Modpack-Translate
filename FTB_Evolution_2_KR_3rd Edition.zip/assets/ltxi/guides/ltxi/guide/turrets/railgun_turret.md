---
navigation:
    title: Noctis
    icon: railgun_turret
    parent: turrets/index.md
    position: 2
item_ids:
  - railgun_turret
---
# *Noctis* A/DS Turret

<GameScene zoom={4} interactive={false}>
<Block id="mesh_block" y="0" />
<Block id="railgun_turret" y="-1" />
<BlockAnnotation x="0" y="-1" z="0" color="#8bd1f0">
아이템과 에너지는 이 블록에만 연결할 수 있습니다!
</BlockAnnotation>
</GameScene>

## Stats
- 수평 탐색 반경: 25.0
- 수직 탐색 반경: 25.0
- 표적 탐색 간격: 4초
- 한 번에 표적 1개만 공격
- Railgun 탄환 피해량: 200.0

## Default targets

`#ltxi:targets/high_threat` 태그가 있는 개체입니다. 예: Elder Guardian, Ender Dragon, Wither, Warden
