---
navigation:
    title: Ionos
    icon: arc_turret
    parent: turrets/index.md
    position: 0
item_ids:
  - arc_turret
---
# *Ionos* A/DS Turret

<GameScene zoom={4} interactive={false}>
<Block id="mesh_block" y="0" />
<Block id="arc_turret" y="-1" />
<BlockAnnotation x="0" y="-1" z="0" color="#8bd1f0">
아이템과 에너지는 이 블록에만 연결할 수 있습니다!
</BlockAnnotation>
</GameScene>

## Stats
- 수평 탐색 반경: 30.0
- 수직 탐색 반경: 20.0
- 표적 탐색 간격: 1.5초
- 기본 피해량: 틱당 2.0

## Default targets

적대 수준이 **Neutral Enemy** 이상인 모든 개체입니다.

## About

*Ionos*는 **탐색(Search)** 시 최대 16개의 표적을 선정합니다. 가장 가까운 표적을 우선 대상으로 정해 죽거나 사거리에서 벗어날 때까지 계속 공격합니다. 이후 대기열의 다음 유효 표적을 공격하며, 표적이 없으면 다시 **탐색(Search)** 모드로 돌아갑니다.
