---
navigation:
    title: "Turrets"
    icon: arc_turret
    position: 33
---
# A/DS Turrets

자동 방어 시스템 제품군인 A/DS는 지정된 지역에서 위협을 제거하는 데 특화되어 있습니다. 모든 Turret은 [업그레이드 가능한 기계](../fundamentals/upgrade_system.md)입니다.

## Available Turrets

- [*Ionos*](arc_turret.md)
- [*Atmos*](rocket_turret.md)
- [*Noctis*](railgun_turret.md)

## Operation

Turret은 추가 아이템 없이 <Color id="energy">Energy</Color>만으로 작동합니다. 내부 인벤토리는 전리품 회수 업그레이드를 장착했을 때만 사용하는 출력 공간입니다.

## Targeting

Turret마다 기본 표적 필터가 있으며, 일부는 다른 기종보다 선택적으로 대상을 공격합니다. 업그레이드 모듈로 표적 지정 규칙을 변경할 수 있습니다.

## Turret states

Turret에는 **Inactive**, **Searching**, **Charging**, **Firing**, **Cooldown**의 다섯 가지 상태가 있습니다. 각 상태는 고유한 동작을 수행하며 대부분은 이름만으로도 의미를 알 수 있습니다.

### Inactive

새로 제작했거나 에너지가 고갈된 Turret의 상태입니다. 매초 에너지 저장량을 확인하여 한 번이라도 작동할 만큼 에너지가 있으면 Searching 상태로 전환합니다.

### Searching

활성화된 Turret이 대부분의 시간을 보내는 상태입니다. 기종별로 정해진 간격마다 탐색 범위에서 유효한 표적을 찾습니다. 표적을 발견하면 대기열에 등록하고 **Charging** 상태로 전환합니다.

### Charging/Cooldown

두 상태는 작동 방식이 같으며 지속 시간만 다릅니다. 발사 전 준비 또는 발사 사이의 재사용 대기시간에 해당합니다. 기종마다 충전 및 대기시간이 다릅니다.
