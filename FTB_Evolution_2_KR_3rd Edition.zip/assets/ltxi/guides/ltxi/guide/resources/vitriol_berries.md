---
navigation:
    title: Vitriol Berries
    position: 11
    icon: vitriol_berries
    parent: resources/index.md
---
# Vitriol Berries

## About

<ItemImage id="vitriol_berries" scale="2" />

광물이 풍부한 Nether의 오래된 구조물은 혹독한 환경에 적응한 식물에게 훌륭한 영양 공급원입니다. 이곳을 탐험하다 보면 강인한 **Bilevine**을 발견할 수 있습니다. 운이 좋다면 덩굴에 **Vitriol Berries**가 열려 있을 것입니다.

## Natural Generation

**Bilevine**은 Nether Fortress와 Bastion Remnant에 생성되며, 단단한 블록의 아랫면에서 잘 자랍니다. Fortress의 복도나 다리 아래, Bastion의 천장을 확인해 보세요.

<GameScene zoom={2} interactive={true}>
<ImportStructure src="../assets/bilevines.nbt" />
</GameScene>

## Farming

Vitriol Berries를 단단한 블록 아랫면에 심으면 Bilevine이 자랍니다. 덩굴은 단단한 블록에 닿을 때까지 아래로 길어집니다. 새로운 덩굴 블록이 자랄 때 낮은 확률로 열매가 함께 생성됩니다. 이미 자란 덩굴 블록에서는 시간이 지나도 **새 열매가 생기지 않습니다**.

### Breaking the vines

- 열매가 없는 Bilevine을 **Shears 없이** 부수면 아무것도 드롭되지 않습니다.
- 열매가 있는 Bilevine 또는 열매가 없는 Bilevine을 **Shears로** 부수면 Vitriol Berry 1개를 얻습니다.
- Shears로 열매를 수확할 수 있지만 성장 속도가 느릴 수 있습니다.

### Growing berries

- 열매가 없는 Bilevine에 Bone Meal을 사용하면 해당 덩굴 블록에 Vitriol Berry가 즉시 열립니다.
- 열매가 열린 Bilevine을 우클릭하면 덩굴을 파괴하지 않고 Vitriol Berry를 수확합니다.
- Bone Meal이 충분하면 짧은 시간에 많은 열매를 생산할 수 있습니다.

## Usage

### Acidic Biomass

<ItemImage id="acidic_biomass" />

Vitriol Berries는 Nether 대기의 [Sulphurine](elements_compound.md#sulphurine)을 흡수하므로 과육에 유기 황 화합물이 풍부합니다. 열매를 [Grinder](../machines/processing/grinder.md)로 분쇄하고 Water와 [Mixer](../machines/processing/mixer.md)에서 혼합하는 것이 [Sulfuric Acid](acids.md#sulfuric-acid)를 얻는 가장 쉽고 초기부터 가능한 방법입니다.
