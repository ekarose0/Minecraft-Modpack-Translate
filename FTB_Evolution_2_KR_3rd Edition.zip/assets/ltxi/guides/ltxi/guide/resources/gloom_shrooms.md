---
navigation:
    title: Gloom Shroom
    icon: gloom_shroom
    position: 12
    parent: resources/index.md
---
# Gloom Shroom

## About

<ItemImage id="gloom_shroom" scale="2" />

으스스한 Deep Dark는 익숙한 생명체가 살아가기 어려워 보입니다. 하지만 어두운 동굴을 탐험하다 보면 Sculk의 영혼 에너지를 흡수하며 자라는 기묘하고 아름다운 <Color id="blue">Gloom Shroom</Color>을 발견할 수 있습니다.

## Natural Generation

Gloom Shroom은 Deep Dark 생물군계의 Sculk 위에 드물게 생성되며, 청크당 약 1~2개만 나타납니다. 자체적으로 생물 발광을 하지만 주변 공간을 밝히는 광원은 아닙니다.

## Farming

Gloom Shroom은 손으로 즉시 부술 수 있습니다. 특별한 도구나 마법 부여가 필요하지 않습니다.

### Suitable environment

Gloom Shroom은 Sculk 위에만 심을 수 있습니다. 하늘빛에 노출되면 파괴되므로 햇빛이 직접 닿지 않게 해야 합니다.

### Propagation

<GameScene zoom={2} interactive={true}>
<ImportStructure src="../assets/gloom_shroom_farm.nbt" />
<Block id="gloom_shroom" y="1" />
</GameScene>

이 버섯은 자연적으로 자라거나 퍼지지 않으며 Bone Meal도 효과가 없습니다. 증식하려면 Sculk Catalyst와 Sculk를 준비하고 Catalyst 근처에 Gloom Shroom을 심으세요. Sculk Catalyst가 활성화되어 Sculk Charge가 Gloom Shroom을 통과하면 33% 확률로 주변 *3x3x3 범위*에 새 버섯 1개가 퍼집니다. 새 버섯이 생길 공간은 공기나 흐르는 물처럼 대체 가능한 블록이어야 합니다.

## Products

### Echo Serum

<ItemImage id="sculk_chemical" scale="2" />

[Mixer](../machines/processing/mixer.md)에서 Gloom Shroom을 [Sulfuric Acid](acids.md#sulfuric-acid)에 녹이면 Echo Serum을 생산합니다.

### Concentrated Gloom Essence

<ItemImage id="gloom_weapon_chemical" scale="2" />

다량의 Echo Serum을 [Ammonia](elements_compound.md#ammonia)로 환원하면 Concentrated Gloom Essence가 생성됩니다. 산업용으로는 활용도가 낮지만 적을 약화시키는 무기를 만드는 데 유용합니다.

전투를 선호한다면 *Hanabi*의 [Acid Shells](../weapons/hanabi.md#acid)로 Warden에게 마지막 일격을 가하거나 Warden이 [Corroding](../fundamentals/mob_effects.md#corroding) 상태일 때 처치해도 Concentrated Gloom Essence 1개가 반드시 드롭됩니다.
