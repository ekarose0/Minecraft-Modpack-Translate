---
navigation:
    title: Polymers
    icon: polymer
    position: 21
    parent: resources/index.md
---
# Polymers

Titanium과 다른 금속으로 모든 것을 만들고 싶을 수도 있지만 효율적이지 않으며, 기술이 복잡해질수록 불가능한 경우도 생깁니다. 이때 필요한 것이 대부분 유기물에서 만드는 다용도 복합 재료 *Polymers*입니다. 적어도 원료는 한때 유기물이었습니다.

## Polymer

<ItemGrid>
<ItemIcon id="resinous_biomass" />
<ItemIcon id="polymer" />
</ItemGrid>

가장 먼저 만들 Polymer는 Bio Polymer라고도 부릅니다. 정확한 명칭은 아니지만 편의상 그렇게 생각해도 됩니다. Sugar Cane과 Bamboo 같은 수지성 식물을 [Grinder](../machines/processing/grinder.md)로 분쇄하여 Resinous Biomass를 추출합니다. 이를 Water와 [Sulfuric Acid](acids.md#sulfuric-acid)에 [혼합](../machines/processing/mixer.md)하면 굳어져 Polymer Bar가 됩니다.

## Fluoropolymer

<ItemImage id="fluoropolymer" />

Fluoropolymer는 Polymer의 고급 형태입니다. 제작 공정이 복잡하므로 자동화를 강력히 권장합니다. [Chem Lab](../machines/processing/chem_lab.md)에서 [Hydrofluoric Acid](acids.md#hydrofluoric-acid), [Methane](elements_compound.md#methane), [Chlorine](elements_base.md#chlorine)을 반응시키고, 반응 중 소모되지 않는 Titanium Dust를 촉매로 사용하면 Fluoropolymer Bar와 폐기물인 Hydrochloric Acid가 생성됩니다.
