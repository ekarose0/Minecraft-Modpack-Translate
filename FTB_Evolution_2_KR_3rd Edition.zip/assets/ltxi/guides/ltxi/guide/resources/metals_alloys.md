---
navigation:
    title: "Metals/Alloys"
    icon: titanium_ingot
    position: 1
    parent: resources/index.md
---
# Metals and Alloys

## Titanium

<ItemImage id="titanium_ingot" scale="2" />

<ItemGrid>
<ItemIcon id="raw_titanium" />
<ItemIcon id="titanium_ore" />
<ItemIcon id="deepslate_titanium_ore" />
</ItemGrid>

Titanium은 LTXI에서 만드는 거의 모든 장비의 기초 재료입니다. Overworld의 일반 Stone 및 Deepslate 지층에서 생성되며, 세계 바닥에 가까울수록 많이 발견됩니다. Iron보다 약간 희귀합니다.

## Silver

<ItemImage id="silver_ingot" scale="2" />

<ItemGrid>
<ItemIcon id="raw_silver" />
<ItemIcon id="silver_ore" />
<ItemIcon id="deepslate_silver_ore" />
</ItemGrid>

Silver는 중급 전자 부품과 에너지 부품에 사용하는 귀금속입니다. 대부분의 생물군계에서 깊은 지하, 특히 세계 바닥 부근에 생성되며 Gold보다 약간 흔합니다. 산악 생물군계에서는 더 높은 고도에서도 생성되며 발견 확률도 훨씬 높습니다.

## Niobium

<ItemImage id="niobium_ingot" scale="2" />

<ItemGrid>
<ItemIcon id="raw_niobium" />
<ItemIcon id="niobium_ore" />
</ItemGrid>

Niobium은 최고급 전자 부품에 사용하는 희귀 금속입니다. 가루 형태로 [Silicon](elements_base.md#silicon), [Phosphorus](elements_base.md#phosphorus)와 함께 [Argon](elements_base.md#argon) 가스 환경에서 융합하면 나노프로세서 논리 코어를 만들 수 있습니다. End의 외곽 섬에 드물게 생성됩니다. 광석의 보라색 무늬가 빛나므로 지형을 잘 살펴보세요.

## Slatesteel

<ItemImage id="slatesteel_ingot" scale="2" />

<ItemGrid>
<ItemIcon id="minecraft:iron_ingot" />
<ItemIcon id="carbon_dust" />
<ItemIcon id="deepslate_dust" />
</ItemGrid>

Slatesteel은 Iron, Carbon, Deepslate Dust의 광물 성분을 합금하고 [Oxygen](elements_base.md#oxygen) 가스로 불순물을 태워 만든 기본 합금입니다. Titanium만큼 다용도로 쓰이지 않고 무거워서 장비 골격에는 적합하지 않지만, 높은 하중을 견뎌야 하는 부품에 적합합니다.

## Tungsten-Plated Slatesteel

<ItemImage id="tungsten_slatesteel_ingot" scale="2" />

<ItemGrid>
<ItemIcon id="tungsten_trioxide" />
<ItemIcon id="slatesteel_dust" />
<ItemIcon id="tungsten_slatesteel_dust" />
</ItemGrid>

순수한 Tungsten 금속을 분리하는 일은 LTXI 기계에도 어렵습니다. 하지만 매우 튼튼한 금속에 결합하면 놀라운 내구성을 가진 합금을 만들 수 있습니다. 이렇게 탄생한 것이 Tungsten-Plated Slatesteel입니다.

Titanium 광석을 가공 라인의 [3단계](../ore_processing.md#stage-3)까지 처리하면 가끔 Tungsten Trioxide를 부산물로 얻습니다. Slatesteel Dust가 있는 상태에서 [Hydrogen](elements_base.md#hydrogen)으로 Tungsten Trioxide를 환원하면 Tungsten이 Slatesteel에 결합합니다. 이렇게 얻은 가루는 녹는점이 매우 높아 일반 화로에서 공기 중 제련할 수 없습니다. [Arc Furnace](../machines/processing/arc_furnace.md)에서 [Nitrogen](elements_base.md#nitrogen)을 차폐 가스로 사용하여 제련해야 합니다.

## Rhenium

<ItemImage id="rhenium_ingot" scale="2" />

<ItemGrid>
<ItemIcon id="rhenium_7_oxide" />
<ItemIcon id="ammonium_perrhenate" />
<ItemIcon id="rhenium_dust" />
</ItemGrid>

Rhenium은 LTXI 최고급 기술을 만드는 데 사용되는 금속입니다. Tungsten과 마찬가지로 복잡한 회수 공정 없이는 자연에서 얻을 수 없습니다. 먼저 광석 가공 라인의 [5단계](../ore_processing.md#stage-5)에서 Copper 광석으로부터 Rhenium(VII) Oxide를 수집합니다. 이를 [Chem Lab](../machines/processing/chem_lab.md)에서 [Ammonia](elements_compound.md#ammonia)와 반응시키면 Ammonium Perrhenate가 되지만, 아직 사용할 수 있는 형태는 아닙니다. 다시 [Hydrogen](elements_base.md#hydrogen) 가스로 환원하면 Rhenium Dust가 생성됩니다. 마지막으로 Arc Furnace에서 Rhenium Dust를 제련하면 Rhenium Ingot을 얻습니다. 공정이 길고 Argon 차폐 가스가 필요합니다.
