---
navigation:
    title: Resources
    position: 3
    icon: titanium_ingot
---
# Materials and Resources

LTX Industries에는 발견할 수 있는 다양한 천연자원이 있습니다. 일부는 자연에서 바로 얻을 수 있지만, 대부분은 정제하거나 원료부터 직접 합성해야 합니다.

<SubPages />
