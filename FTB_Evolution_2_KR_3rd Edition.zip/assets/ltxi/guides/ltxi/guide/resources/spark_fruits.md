---
navigation:
    title: Spark Fruit
    position: 10
    icon: spark_fruit
    parent: resources/index.md
---
# Spark Fruit

## About

<ItemImage id="spark_fruit" scale="2" />

열대 정글은 행성의 피뢰침 역할을 하므로 <Color id="electric">원시적인 전기</Color> 현상이 자주 일어납니다. 나무 꼭대기에서 발견할 수 있는 독특한 물체 중 하나가 연두색으로 빛나는 **Spark Fruit**입니다.

## Obtaining

### Exploration

Spark Fruit은 Jungle Leaves 아랫면에 생성됩니다. 완전히 자란 열매는 밝기 7의 빛을 내므로 밤에 정글을 탐험하면 더 쉽게 찾을 수 있습니다.

<GameScene zoom={2} interactive={true}>
<ImportStructure src="../assets/spark_fruit_tree.nbt" />
</GameScene>

### Villager Trading

초반 탐험을 선호하지 않거나 지형 생성 운이 나쁘다면 거래로 Spark Fruit을 얻을 수도 있습니다. Farmer 주민의 초기 거래 목록이나 Wandering Trader의 일반 거래 목록에 등장할 수 있습니다.

## Farming

Spark Fruit은 손이나 아무 도구로도 부술 수 있으며 Jungle Leaves의 아랫면에만 심을 수 있습니다. 심은 열매는 성장 단계 2개를 거쳐 완전히 자랍니다.

- 완전히 자란 열매는 Spark Fruit 3개를 드롭하며 <Color id="light_purple">Fortune</Color>으로 수량을 늘릴 수 있습니다.
- 덜 자란 열매는 자기 자신을 드롭합니다.

## Products

### Sodium

[Grinder](../machines/processing/grinder.md)를 사용하여 열매의 즙에 들어 있는 원소 [Sodium](elements_base.md#sodium)을 추출합니다. Sodium은 고급 전기 부품과 업그레이드 제조에 필수적입니다.
