---
navigation:
    title: Compound Elements
    icon: methane_bucket
    position: 0
    parent: resources/index.md
---
# Compound Elements

일부 원소 화합물은 자연에 존재하거나 천연자원에서 쉽게 얻을 수 있습니다. 기본 원소처럼 기계로 가공하여 추출할 수 있습니다.

## Methane

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:methane', amount:16000}" scale="2" />

Methane은 Overworld의 Swamp에서 풍부하게 발견되는 탄화수소 기체입니다. [Atmospheric Scrubber](../machines/resource/atmospheric_scrubber.md)로 수집할 수 있습니다. 효율적인 연료이면서 고급 Polymer와 Silicone 화합물의 원료이기도 합니다.

## Sulphurine

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:sulphurine', amount:16000}" scale="2" />

Sulphurine은 Nether 대기에 존재하는 기체입니다. Nether의 극도로 건조한 환경 덕분에 안정적으로 유지되어 원소 Sulfur로 분해되지 않습니다. [Chem Lab](../machines/processing/chem_lab.md)에서 Water와 반응시키면 Sulfuric Acid를 만들 수 있으며, Silicone Oil을 Rubber로 굳히는 데도 사용됩니다.

## Seawater

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:sea_water', amount:16000}" scale="2" />

Overworld 바닷물에는 해양 식물에서 유래한 Chlorine이 높은 농도로 포함되어 있습니다. Atmospheric Scrubber로 바닷물을 수집한 뒤 [ElectroCentrifuge](../machines/processing/electrocentrifuge.md)로 Chlorine을 추출할 수 있습니다.

## Ammonia

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:ammonia', amount:16000}" scale="2" />

Ammonia는 Nitrogen과 Hydrogen으로 이루어진 독성 화합물입니다. [Bio/ARU Garden](../machines/resource/digital_garden.md)에서 특정 희귀 식물을 재배하거나 Gloom Gas 무기를 제작하는 데 사용됩니다. 특히 Rhenium 금속 가공 공정에 중요한 재료입니다.
