---
navigation:
    title: Base Elements
    icon: sodium_dust
    position: 0
    parent: resources/index.md
---
# Base Elements

원소는 LTXI의 모든 화학 공정과 재료 생산을 구성하는 기본 요소입니다. 대부분의 원소는 자연에서 순수한 상태로 발견되지 않습니다. 다행히 다양한 LTXI 기계를 사용하면 비교적 간단한 공정으로 추출할 수 있습니다.

## Hydrogen

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:hydrogen', amount:16000}" scale="2" />

Hydrogen은 Ammonia와 Hydrochloric Acid의 대량 생산에 사용됩니다. 또한 Tungsten과 Rhenium의 전구체를 사용 가능한 형태로 환원하는 반응과 자체 추진형 발사체 무기의 추진 엔진에도 사용됩니다.

Water를 [ElectroCentrifuge](../machines/processing/electrocentrifuge.md)로 처리하면 얻을 수 있습니다. 이 과정은 느리고 전력 소모가 크므로 안정적인 전력망과 어느 정도 강화된 전력 공급 업그레이드를 준비하는 것이 좋습니다.

## Carbon

<ItemImage id="carbon_dust" />

Coal과 Charcoal을 [Grinder](../machines/processing/grinder.md)로 분쇄하면 얻습니다. Iron과 분쇄한 Deepslate를 합금하면 튼튼하면서도 구하기 쉬운 Slatesteel을 만들 수 있습니다.

## Nitrogen

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:nitrogen', amount:16000}" scale="2" />

Nitrogen은 Overworld 대기에 존재하는 기체입니다. 사실상 무한하며 대량으로 수집할 수 있지만, 전용 [Atmospheric Scrubber](../machines/resource/atmospheric_scrubber.md)가 필요합니다.

## Oxygen

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:oxygen', amount:16000}" scale="2" />

반응성이 매우 높은 원소입니다. Water 또는 Silicon Dioxide 원료를 ElectroCentrifuge로 처리하면 얻습니다. 주된 용도는 Iron, Carbon, Deepslate를 융합하여 Slatesteel을 만드는 것입니다. 대기에서 추출하는 대신 합성하려는 경우 Sulfur를 산화하여 Sulphurine을 만들 수도 있습니다.

## Sodium

<ItemImage id="sodium_dust" />

전기와 관련된 원소입니다. [Spark Fruit](spark_fruits.md)을 분쇄하면 얻으며, 전기 기반 부품과 업그레이드의 기초 재료입니다.

## Silicon

<ItemImage id="silicon_dust" />

모든 전자 기술의 핵심 재료입니다. Sand, Flint, Quartz와 같은 Silicon Dioxide 원료를 ElectroCentrifuge로 처리하여 얻습니다. 가루 상태로는 활용도가 낮지만 [Arc Furnace](../machines/processing/arc_furnace.md)의 고온을 이용하면 Silicon Dust를 주괴로 융합하여 기본 전자 부품에 사용할 수 있습니다. 고급 차폐 가스를 확보하면 고급 전자 부품용 결정-인 복합 재료도 제작할 수 있습니다.

## Phosphorus

<ItemImage id="phosphorus_dust" />

불과 빛을 상징하는 원소입니다. 화염 기반 무기의 기초 재료이자 [Neon Lights](../building_blocks/neon_lights.md)의 기본 원료입니다.

## Sulfur

<ItemImage id="sulfur_dust" />

Sulfur는 반응성 화학 공정에 필수적인 원소입니다. Coal을 분쇄할 때 비교적 높은 확률로 부산물로 얻습니다. 원소 가루 상태로는 쓸모가 많지 않지만, [Chem Lab](../machines/processing/chem_lab.md)에서 Oxygen과 반응시키면 Sulphurine 기체를 만들 수 있습니다.

## Chlorine

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:chlorine', amount:16000}" scale="2" />

Chlorine은 독성이 있지만 Hydrochloric Acid, Fluoropolymer, Silicone Oil 생산에 매우 중요한 기체입니다. Kelp에는 ElectroCentrifuge로 추출할 수 있을 만큼 많은 Chlorine이 들어 있습니다. 또는 Atmospheric Scrubber로 수집한 Seawater를 ElectroCentrifuge로 처리할 수도 있습니다.

## Argon

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:argon', amount:16000}" scale="2" />

Argon은 End 차원의 대기에 존재하는 기체로, 고급 전자 부품과 금속 가공에 필수적입니다. Arc Furnace에서 차폐 가스로 사용하여 Silicon 결정-Phosphorus 복합 재료를 생산하거나 Tungsten-Plated Slatesteel 및 Rhenium을 제련합니다.
