---
navigation:
    title: Gems
    icon: raw_olivine
    position: 2
    parent: resources/index.md
---
# Gems and Minerals

## Olivine

<ItemGrid>
<ItemIcon id="raw_olivine" />
<ItemIcon id="olivine" />
</ItemGrid>

Olivine은 기계, 도구, 무기에 사용하는 레이저 장치의 범용 보석입니다. 에너지를 공급하면 효율적인 디지털 절삭 날을 형성하고, 충분한 에너지를 받으면 빛을 고체 파편으로 결정화할 수도 있습니다. Raw Olivine은 [Peridotite](../building_blocks/peridotite.md) Dust를 [HydroSieve](../machines/processing/hydrosieve.md)로 처리하여 얻습니다. 수율이 낮으므로 초반 기계의 느린 처리 속도를 보완할 수 있도록 가능한 한 빨리 자동화 생산 라인을 구축하는 것이 좋습니다.

## Fluorite

<ItemGrid>
<ItemIcon id="raw_fluorite" />
<ItemIcon id="fluorite" />
</ItemGrid>

Fluorite에는 Fluorine이 높은 농도로 함유되어 있습니다. 결정을 Sulfuric Acid에 녹이면 [Hydrofluoric Acid](acids.md#hydrofluoric-acid)를 추출할 수 있습니다. Raw Fluorite는 Deepslate Dust를 HydroSieve로 처리하여 얻습니다. Hydrofluoric Acid는 고급 Fluoropolymer 생산에 필수적이므로 Olivine과 마찬가지로 전용 생산 시설을 권장합니다.

## Pyroxene

<ItemImage id="pyroxene" />

Pyroxene은 광석 가공 라인의 [3단계](../ore_processing.md#stage-3)에서 Raw Olivine으로부터 회수하는 특수 보석입니다. 독특한 결정 구조를 이용해 최고급 [회로](tech_parts.md#elite-circuitry)에 사용하는 나노프로세서 논리 코어를 만들 수 있습니다.
