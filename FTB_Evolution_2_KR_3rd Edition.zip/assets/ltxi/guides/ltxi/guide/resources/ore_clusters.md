---
navigation:
    title: Ore Clusters
    position: 1
    icon: raw_titanium_cluster
    parent: resources/index.md
---
# Ore Clusters

## About

광물이 특정 장소에 많이 퇴적되면 단단한 표면에 붙어 있는 커다란 원광 덩어리가 만들어지기도 합니다. 형성 조건이 일반 광석보다 훨씬 까다로우며, 생성 위치도 일반 광석과 전혀 다를 수 있습니다.

## Natural Generation

<GameScene zoom={2} interactive={true}>
<Block id="minecraft:basalt" x="0" />
<Block id="minecraft:stone" x="1" />
<Block id="minecraft:purpur_block" x="2" />
<Block id="raw_titanium_cluster" x="0" y="1" />
<Block id="raw_silver_cluster" x="1" y="1" />
<Block id="raw_niobium_cluster" x="2" y="1" />

</GameScene>

불편하게도 Ore Cluster는 일반 광석보다 훨씬 위험한 장소에서 생성됩니다.

### Titanium

- 위치: Nether의 Basalt Deltas
- 높이: 제한 없음
- 조건: 단단한 블록의 *윗면*에만 생성

### Silver

- 위치: 폐광
- 높이: 세계 바닥부터 Y=64까지

### Niobium

- 위치: End City
- 높이: Y=50~150

## Mining

Ore Cluster의 채굴 조건은 해당 일반 광석과 동일합니다. 채굴하면 원광 아이템 3~5개를 드롭하며 **Fortune의 영향을 받지 않습니다**. <Color id="light_purple">Silk Touch</Color>로 채굴하면 Ore Cluster 블록 자체를 얻을 수 있습니다. 이 블록을 [Grinder](../machines/processing/grinder.md)로 가공하면 원광 아이템 5개를 확정적으로 얻습니다.
