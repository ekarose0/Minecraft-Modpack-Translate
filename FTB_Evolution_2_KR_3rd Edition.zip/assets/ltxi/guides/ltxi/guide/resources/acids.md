---
navigation:
    title: Acids
    icon: sulfuric_acid_bucket
    position: 20
    parent: resources/index.md
---
# 산(Acids)

## Sulfuric Acid

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:sulfuric_acid', amount:16000}" scale="2" />

Sulfuric Acid는 고분자 화학, 회로 식각, 유기물 용해의 기초가 되는 산입니다. 광석 가공 공정의 [4단계](../ore_processing.md#stage-4)에서도 사용됩니다. Water와 Vitriol Berries의 Crushed Pulp를 [Mixer](../machines/processing/mixer.md)에서 [혼합](vitriol_berries.md#acidic-biomass)하여 생산할 수 있습니다. 또는 [Sulphurine](elements_compound.md#sulphurine)을 [Chem Lab](../machines/processing/chem_lab.md)에서 Water와 느리지만 제어된 반응을 일으켜 생산할 수도 있습니다.

## Hydrochloric Acid

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:hydrochloric_acid', amount:16000}" scale="2" />

Hydrochloric Acid는 광석 가공 공정의 [5단계](../ore_processing.md#stage-5)에서 사용하는 정제용 산입니다. 이름에서 짐작할 수 있듯이 Chem Lab에서 Hydrogen과 Chlorine을 같은 비율로 혼합하여 만듭니다. Fluoropolymer와 Silicone Oil을 제조할 때 폐기물로도 생성되지만, 이는 보조 공급원 정도로만 활용하는 것이 좋습니다.

## Hydrofluoric Acid

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:hydrofluoric_acid', amount:16000}" scale="2" />

Hydrofluoric Acid는 독성이 매우 강하지만 Fluoropolymer 생산에 필요한 핵심 재료 세 가지 중 하나입니다. Chem Lab에서 [Fluorite](gems.md#fluorite) 보석을 Sulfuric Acid에 녹여 만들 수 있습니다.
