---
navigation:
    title: Silicone Compounds
    icon: silicone_rubber
    position: 22
    parent: resources/index.md
---
# Silicone Compounds

## Silicone Oil

<ItemImage id="portable_tank" components="limacore:fluid={id:'ltxi:silicone_oil', amount:16000}" scale="2" />

Silicone Oil은 독성이 없고 안정적인 윤활제입니다. [Chem Lab](../machines/processing/chem_lab.md)에서 [Silicon](elements_base.md#silicon), [Methane](elements_compound.md#methane), [Chlorine](elements_base.md#chlorine)을 반응시키면 생산되며, 폐기물로 Hydrochloric Acid도 발생합니다. 현재는 Silicone Rubber를 만드는 전구체로만 사용됩니다.

## Silicone Rubber

<ItemImage id="silicone_rubber" />

Chem Lab에서 Silicone Oil에 [Sulphurine](elements_compound.md#sulphurine)을 넣으면 빠르게 촉매 반응이 일어나 Silicone Rubber가 됩니다. 이 재료는 대용량 저장 업그레이드, 고에너지 기술 부품, [Wonderland](../wonderland.md) 방어구의 내장재를 제작하는 데 사용됩니다.
