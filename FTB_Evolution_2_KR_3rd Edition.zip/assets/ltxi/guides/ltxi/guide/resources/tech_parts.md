---
navigation:
    title: Tech Parts
    icon: elite_circuit_board
    position: 3
    parent: resources/index.md
---
# Tech Parts

## Components

<ItemGrid>
<ItemIcon id="small_voltaic_cell" />
<ItemIcon id="medium_voltaic_cell" />
<ItemIcon id="large_voltaic_cell" />
<ItemIcon id="optical_tech_part" />
<ItemIcon id="impulse_tech_part" />
<ItemIcon id="laser_tech_part" />
</ItemGrid>

업그레이드, 기계, 일부 회로의 기본 구성 요소입니다. [Assembler](../machines/processing/assembler.md)로 쉽게 대량 생산할 수 있습니다.

## Basic Circuitry

<ItemGrid>
<ItemIcon id="polymer_sheet" />
<ItemIcon id="copper_plate" />
<ItemIcon id="circuit_board" />
<ItemIcon id="silicon_plate" />
<ItemIcon id="t1_circuit" />
<ItemIcon id="t2_circuit" />
<ItemIcon id="t3_circuit" />
</ItemGrid>

Polymer Sheet에 Copper Plate를 [Sulfuric Acid](acids.md#sulfuric-acid)로 식각하면 초급부터 중급 전자 장치까지 사용할 수 있는 Circuit Board를 얻습니다. Silicon Plate, 전도성 금속판, Titanium 차폐판, 적절한 Voltaic Cell을 사용하면 최대 3등급 회로까지 제작할 수 있습니다. 재료의 한계 때문에 이 방식으로 만든 회로는 이전 단계의 회로 위에 제작해야 합니다. 그래도 Basic Circuit만 비효율적으로 만들 수 있는 Crafting Table 수작업보다는 효율적입니다.

## Elite Circuitry

### Basic Logic

<ItemGrid>
<ItemIcon id="fluoropolymer_sheet" />
<ItemIcon id="silver_plate" />
<ItemIcon id="elite_circuit_board" />
<ItemIcon id="logic_core" />
</ItemGrid>

[Fluoropolymer](polymers.md#fluoropolymer)를 확보하면 Fluoropolymer Sheet에 Silver를 Sulfuric Acid로 식각하여 특수 결정 회로 코어를 지원하는 고급 Circuit Board를 만들 수 있습니다. [Arc Furnace](../machines/processing/arc_furnace.md)에서 [Silicon](elements_base.md#silicon), [Phosphorus](elements_base.md#phosphorus), [Olivine](gems.md#olivine)을 [Argon](elements_base.md#argon) 차폐 가스와 함께 융합하면 Logic Core가 생성됩니다. Logic Core 1~2개와 전도성 금속판 1개만으로도 이전 등급 회로 없이 Basic, Advanced, Precision Circuit을 더 많이 생산할 수 있습니다.

### Nano Logic

<ItemGrid>
<ItemIcon id="nano_logic_core" />
<ItemIcon id="t4_circuit" />
<ItemIcon id="t5_circuit" />
</ItemGrid>

Logic Core를 Pyroxene 및 [Niobium](metals_alloys.md#niobium) Dust와 융합하면 LTXI의 최고급 컴퓨터 코어인 Nano Logic Core가 만들어집니다. Nano Logic Core, High-Energy Voltaic Cell, Titanium 차폐판, 특수 화학물질을 사용하면 Nano-Core Processor와 Real Virtuality Processor를 제작할 수 있습니다.
