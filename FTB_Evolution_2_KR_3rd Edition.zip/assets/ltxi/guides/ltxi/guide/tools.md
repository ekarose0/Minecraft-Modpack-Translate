---
navigation:
    title: Tools
    icon: epsilon_drill
    position: 31
---
# ε-Series 도구

ε(epsilon) 시리즈는 저희의 표준 도구 제품군입니다. 모든 도구는 파괴되지 않으며 <Color id="energy">Energy</Color>로 작동하고, [업그레이드](fundamentals/upgrade_system.md)할 수 있습니다.

## 모듈형 채굴 도구

<ItemGrid>
<ItemIcon id="epsilon_drill" />
<ItemIcon id="epsilon_shovel" />
<ItemIcon id="epsilon_axe" />
<ItemIcon id="epsilon_hoe" />
</ItemGrid>

### 기본 업그레이드

<Row>
<UpgradeEntry id="default/epsilon_shovel" />
<UpgradeEntry id="tree_vein_mine" />
</Row>

Drill, Shovel, Axe, Hoe는 *모듈형 채굴 도구*입니다. 장비 모드를 전환하면 다음 5가지 기본 채굴 속도가 순환됩니다.

- **Off**: 크리에이티브 모드를 포함하여 블록 파괴 불가.
- **Slow**: 3.0
- **Normal**: 9.0
- **Fast**: 20.0
- **Turbo**: 75.0

업그레이드 시스템으로 채굴 등급(한계)을 높이고 도구가 효과적으로 채굴할 수 있는 블록 종류를 늘릴 수 있습니다. Shovel, Axe, Hoe는 각각의 재료에 효과적입니다. Drill은 채굴 편의를 위해 *곡괭이*와 *삽*으로 채굴하는 재료 모두에 효과적입니다.

> ε-Series Shovel의 기본 업그레이드 모듈에는 Silk Touch가 적용됩니다.

## 기타 채굴 도구

<ItemGrid>
<ItemIcon id="epsilon_shears" />
<ItemIcon id="epsilon_wrench" />
</ItemGrid>

### 기본 업그레이드

<UpgradeEntry id="default/epsilon_wrench" />

Wrench와 Shears는 가변 속도를 지원하지 않으며, 업그레이드 시스템으로 유효 블록을 변경할 수도 없습니다. 하지만 마법 부여 업그레이드 모듈은 사용할 수 있습니다.

## 근접 무기

<ItemGrid>
<ItemIcon id="epsilon_sword" />
<ItemIcon id="epsilon_axe" />
</ItemGrid>

### 기본 업그레이드

<UpgradeEntry id="default/epsilon_melee" />

Sword와 Axe는 *근접 무기*입니다. Razor와 Looting 같은 마법 부여 모듈, 대상 필터를 포함하여 [시그니처 시리즈 무기](weapons/index.md)와 일부 업그레이드 모듈을 공유합니다.

> [Equipment Damage Modifier](fundamentals/damage_modifiers.md) 시스템은 모든 ε-Series 근접 무기에 적용됩니다.

## 기타 도구

<ItemGrid>
<ItemIcon id="epsilon_fishing_rod" />
<ItemIcon id="epsilon_brush" />
<ItemIcon id="epsilon_lighter" />
</ItemGrid>

이 도구들은 현재 기본 기능 이외의 추가 능력을 제공하지 않습니다. 그래도 Fabrication 비용이 저렴하므로 확보해 두는 것을 추천합니다.
