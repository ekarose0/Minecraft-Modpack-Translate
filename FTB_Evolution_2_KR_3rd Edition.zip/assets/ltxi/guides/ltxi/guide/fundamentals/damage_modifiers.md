---
navigation:
    title: "Damage Modifiers"
    icon: epsilon_sword
    parent: fundamentals/index.md
    position: 2
---
# 전역 피해 보정

모든 무기가 모든 상황에서 효과적인 것은 아닙니다. 일부 무기는 특정 적에게 불리합니다. 예를 들어 기본형 무기는 중간 및 높은 위협 등급의 적에게 주는 피해가 감소합니다.

## 적용 순서

전역 피해 보정은 **모든 업그레이드가 적용된 이후**에 계산됩니다.

## 피해 보정표

| 무기 종류 | 대상 유형 | 보정치 |
|-------------|---------------|----------|
| Lightweight | High Threat | -80% |
| Lightweight | Medium Threat | -50% |
| Specialist | High Threat | -40% |
| Specialist | Medium Threat | -25% |
