---
navigation:
    title: Fundamentals
    icon: empty_upgrade_module
    position: 1
---
# 기본 시스템

LTX Industries에는 알아 두어야 할 여러 시스템이 추가됩니다. 나중에 혼동하지 않도록 특히 *업그레이드 시스템*과 *피해 보정*을 확인해 두세요.

<SubPages />
