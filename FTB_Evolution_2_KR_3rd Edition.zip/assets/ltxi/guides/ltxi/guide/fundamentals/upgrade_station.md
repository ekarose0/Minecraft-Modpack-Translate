---
navigation:
    title: Upgrade Station
    icon: upgrade_station
    parent: fundamentals/index.md
item_ids:
  - upgrade_station
---
# Upgrade Station

<BlockImage id="upgrade_station" scale="4" />

Upgrade Station에서는 ε-Series 및 Signature Series 장비를 한곳에서 조정할 수 있습니다. 호환되는 장비를 넣으면 업그레이드와 조명 색상을 관리할 수 있습니다.

## 조명 색상

장비의 기본(Primary, P), 보조(Secondary, S), 에너지(Energy, E) 조명 채널 색상을 원하는 RGB 값으로 변경할 수 있습니다. 단, 해당 장비가 그 채널을 지원해야 합니다. 설정 화면에 채널이 표시되지 않는다면 그 장비에서는 색상을 변경할 수 없습니다.

> 색상 변경 사항은 적용 버튼을 눌러야 실제로 반영됩니다!
