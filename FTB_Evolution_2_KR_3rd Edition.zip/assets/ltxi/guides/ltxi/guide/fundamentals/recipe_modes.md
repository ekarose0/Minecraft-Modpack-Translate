---
navigation:
    title: Recipe Modes
    icon: minecraft:crafting_table
    parent: fundamentals/index.md
    position: 2
---
# 레시피 모드

일부 기계 레시피는 투입 재료 조합이 서로 같아 어느 레시피를 사용할지 구별할 수 없습니다. 이를 해결하는 것이 Recipe Mode입니다. 레시피의 하위 유형 또는 사용할 레시피를 지정하는 특별한 '열쇠' 재료라고 생각하시면 됩니다. 언제든 모드를 바꿀 수 있지만, **기계마다 하나의 레시피 모드를 전담하도록 설정하는 것을 강력히 권장합니다.** Element Extraction 대신 Dye Extraction으로 설정해 둔 사실을 잊으면, Spark Fruits 한 묶음을 넣고 돌아왔을 때 Sodium Dust 대신 Electric Chartreuse Pigment가 나오는 불상사가 생길 수 있습니다.

## 선택

![](../assets/recipe_modes_button.png)

레시피 모드를 지원하는 기계에는 왼쪽 아래 측면 메뉴에 선택 버튼이 있습니다. 버튼에는 현재 모드의 아이콘이 표시되며, 마우스를 올리면 이름도 확인할 수 있습니다.

## 사용 가능 모드

![](../assets/recipe_modes_screen.png)

각 레시피 유형(및 기계)은 최대 23개의 레시피 모드를 선택할 수 있으며, 첫 번째 버튼은 항상 None으로 예약되어 있습니다. 선택 가능한 모드는 두 가지 경로로 제공됩니다. 레시피 유형에 기본으로 할당된 모드와 [업그레이드 모듈](../fundamentals/upgrade_system.md)로 추가되는 모드입니다. 기본 레시피 모드는 항상 사용할 수 있습니다. 업그레이드 모듈로 제공되는 모드는 해당 모듈을 장착한 동안에만 사용할 수 있으며, 모듈을 제거하면 None으로 초기화됩니다.
