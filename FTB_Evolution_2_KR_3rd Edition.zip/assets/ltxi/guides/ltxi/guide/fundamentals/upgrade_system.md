---
navigation:
    title: "Upgrade System"
    icon: empty_upgrade_module
    parent: fundamentals/index.md
    position: 1
item_ids:
    - empty_upgrade_module
    - upgrade_module
    - upgrade_station
---
# LTXI 업그레이드 시스템

LTXI 장비(도구, 방어구, 무기)와 기계는 업그레이드 시스템을 통해 폭넓게 강화할 수 있습니다.

## 업그레이드 모듈

<ItemImage id="upgrade_module" />

작은 모듈 하나에는 등급이 지정된 업그레이드 항목이 들어 있습니다. 모듈 아이템에 Shift를 누르면 이름, 등급, 효과 설명, 장착 가능한 대상을 확인할 수 있습니다. 대부분의 업그레이드는 장비 또는 기계 중 한쪽에만 적용되지만, 둘 다 호환되는 것도 있습니다. 예를 들어 전투 마법 부여 업그레이드 모듈은 무기와 터렛 모두에 사용할 수 있습니다.

## 기계에 설치하기

![](../assets/machine_upgrades_button.png)

업그레이드 가능한 기계에는 관리 기능이 내장되어 있습니다. 오른쪽 사이드바의 가장 위에 있는 버튼으로 열 수 있습니다.

## 장비에 설치하기

<BlockImage id="upgrade_station" scale="2.5" />

장비에 적용할 업그레이드를 설정하려면 [Upgrade Station](upgrade_station.md)이 필요합니다.
