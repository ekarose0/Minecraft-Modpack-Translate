---
navigation:
    title: "Mob Effects"
    parent: fundamentals/index.md
    position: 2
---
# 몹 효과(포션 효과)

## Frostbite
Frostbite는 대상의 속도를 늦추고 효과가 지속되는 동안 얼립니다.
### 속성 보정
- 공격 속도: 효과 레벨당 -25%.
- 이동 속도: 효과 레벨당 -25%.
- 비행 속도: 효과 레벨당 -25%.
- 채굴 속도: 효과 레벨당 -25%.

-------

## Corroding
Corroding은 대상의 방어력을 약화합니다.
### 속성 보정
- 방어력: 효과 레벨당 -33%.
- 방어 강도: 효과 레벨당 -33%.

-------

## Gloom
Gloom은 해당 대상에게서 비롯된 *모든* 공격 피해를 감소시킵니다. 또한 효과가 지속되는 동안 대상이 포션 효과를 부여하지 못하게 합니다.

### 속성 보정
- `limacore:damage_multiplier`: 효과 레벨당 -25%.
