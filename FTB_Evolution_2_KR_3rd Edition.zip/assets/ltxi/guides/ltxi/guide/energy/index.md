---
navigation:
    title: Energy
    icon: solar_panel
    position: 20
---
# 에너지

Common Energy(CE)는 LTX Industries에서 NeoForge의 에너지 API를 부르는 명칭입니다. Forge Energy, FE, Redstone Flux, RF 등의 이름으로 알고 계실 수도 있습니다.

<Color id="energy">이 연한 파란색</Color>은 에너지를 사용하거나 언급하거나 업그레이드하는 곳에서 안내 표시로 사용됩니다.

기술 발전을 시작하려면 먼저 에너지를 생산해야 합니다. 에너지 저장 장치도 함께 마련하는 것이 좋습니다. 초반에는 기계에 내장된 에너지 버퍼만으로도 버틸 수 있지만, 곧 용량이 부족해질 것입니다.

## 저장 장치

- [Energy Cell Array](eca.md)

## 발전기

- [Portable Generator](portable_generator.md)
- [Solar Panel](solar_panel.md)
