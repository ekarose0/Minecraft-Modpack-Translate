---
navigation:
    title: "Portable Generator"
    parent: energy/index.md
    position: 10
    icon: portable_generator
item_ids:
  - portable_generator
---
# Portable Generator

<BlockImage id="portable_generator" scale="4" />

Portable Generator는 연료를 태워 에너지를 생산하는 가장 단순하고 안정적인 발전기입니다. 시간과 장소에 상관없이 작동하며, 놀랍게도 물속에서도 사용할 수 있습니다. 화로에서 연료로 쓰이는 모든 아이템으로 연료를 보충할 수 있습니다.

> 일부만 소모한 Fuel Unit도 정확히 기록됩니다! Portable Generator는 효율이 100%이며 남는 에너지를 생산하지 않습니다.

연료마다 연소 시간이 다르므로, 아이템은 먼저 **Fuel Unit**으로 변환되어 발전기의 연료 게이지에 저장됩니다. 연소 시간 100틱마다 Fuel Unit 1개를 얻으며, 매우 빨리 타는 연료도 최소 1개를 얻습니다. 연료 게이지에 마우스를 올리면 저장된 Fuel Unit 수, 최대 저장량, Fuel Unit당 에너지 생산량을 확인할 수 있습니다.
