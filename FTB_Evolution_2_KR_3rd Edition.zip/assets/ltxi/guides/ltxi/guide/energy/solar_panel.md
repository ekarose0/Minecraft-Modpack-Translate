---
navigation:
    title: "Solar Panel"
    parent: energy/index.md
    position: 11
    icon: solar_panel
item_ids:
  - solar_panel
---
# Solar Panel

<BlockImage id="solar_panel" scale="4" />

Solar Panel은 수동적으로 에너지를 생산하는 발전기입니다. 발전 속도가 매우 낮고 오버월드 계열 차원의 낮에만 작동합니다. 하지만 에너지가 무료이고 시동을 걸 필요도 없으므로, 디지털 아이템 저장 장치나 주 발전소 같은 핵심 시설의 비상 전력원으로 매우 안정적입니다.

> Solar Panel은 비가 와도 작동하지만, 뇌우가 치는 동안에는 작동하지 않습니다.
