---
navigation:
    title: Gas Turbine
    icon: gas_turbine
    parent: energy/index.md
    position: 12
item_ids:
  - gas_turbine
---
# Gas Turbine

<GameScene zoom={4} interactive={false}>
<Block id="gas_turbine" />
<Block id="mesh_block" x="1" z="1" />
<Block id="mesh_block" x="1" y="1" z="1" />
<Block id="mesh_block" x="-1" y="1" z="2" />

<BoxAnnotation min="1 0 1" max="2 2 2" color="#8bd1f0">
이 두 포트에 유체와 에너지를 연결할 수 있습니다. 에너지는 매 틱 자동으로 출력되지만, 유체는 수동으로 밀어 넣어야 합니다.
</BoxAnnotation>
</GameScene>

Portable Generator와 Solar Panel만으로도 전초기지나 초반 기지의 운영을 시작할 수 있지만, 결국 더 안정적이고 강력한 전력원으로 전환해야 합니다. [Methane](../resources/elements_compound.md#methane)에는 많은 에너지가 담겨 있지만, 이를 전력으로 효율적으로 바꾸려면 고급 기술이 필요합니다.

Gas Turbine은 소형 발전기보다 훨씬 비싸고 [Fabrication](../machines/processing/fabricators.md)으로 제작해야 하며 설치 공간도 더 많이 차지합니다. 하지만 발전량과 효율은 다른 발전 수단을 크게 앞섭니다.
