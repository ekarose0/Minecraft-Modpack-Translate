---
navigation:
    title: "Energy Cell Array"
    parent: energy/index.md
    position: 1
    icon: energy_cell_array
item_ids:
  - energy_cell_array
---
# Energy Cell Array

<BlockImage id="energy_cell_array" scale="4" />

**Energy Cell Array**는 주요 에너지 저장 블록입니다. 아이템과 에너지의 입출력 방향을 측면별로 설정할 수 있습니다. 에너지를 공급하는 아이템 슬롯 1개와 충전 슬롯 4개가 있습니다.

스마트 자동화 기능 덕분에 아이템이 완전히 충전되기 전에는 파이프나 케이블 등으로 꺼낼 수 없습니다. 다만 플레이어는 언제든 직접 꺼낼 수 있습니다.
