---
navigation:
    title: Stargazer
    icon: stargazer
    parent: weapons/index.md
    position: 137
---
# *Stargazer* 37/LF

<ItemImage id="stargazer" scale="3" />

### Default upgrade

<UpgradeEntry id="default/stargazer" />

## Stats

- 기본 피해량: 45.0
- 사거리: 200.0
- 발사체: [LightFrag](index.md#lightfrags)
- 방아쇠 방식: 충전식 융합 발사
- 충전 시간: 0.5초
- 발사 간격: 0.25초
