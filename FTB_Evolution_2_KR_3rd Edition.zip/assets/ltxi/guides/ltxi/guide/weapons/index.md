---
navigation:
    title: Weapons
    position: 32
    icon: hanabi
---
# Signature series weaponry

효율성, 세련된 아름다움, 치명적인 위력을 결합한 무기 제품군입니다. 모든 무기는 [업그레이드 가능한 장비](../fundamentals/upgrade_system.md)입니다.

## Controls

- **좌클릭**: 무기 발사
- **우클릭**: 지원하는 경우 조준선에 집중
- **<KeyBind id="key.ltxi.reload_weapon" />** 키: 무기 재장전
- **SHIFT+마우스 휠 위/아래**: 지원하는 경우 장비 모드 변경

## LightFrags

**LightFrags**(빛 파편)는 불안정한 빛을 고체로 만든 조각입니다. LightFrag를 발사체로 사용하는 무기는 '히트스캔(Hitscan)' 방식이므로 발사와 명중이 즉시 이루어집니다. 궤적에 나타나는 광학적 흔들림은 시각 효과일 뿐입니다.

---

### Lightweight weapons

- 05/ID, '*[Wayfinder](wayfinder.md)*'
- 11/PX, '*[Serenity](serenity.md)*'
- 13/CX, '*[Mirage](mirage.md)*'

### Specialist weapons

- 21/SG, '*[Aurora](aurora.md)*'
- 37/LF, '*[Stargazer](stargazer.md)*'

### Explosive weapons

- 33/GL, '*[Hanabi](hanabi.md)*'
- 41/RL, '*[Daybreak](daybreak.md)*'

### Heavy weapons

- 77/HX, '*[Nova](nova.md)*'
