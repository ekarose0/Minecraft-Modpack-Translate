---
navigation:
    title: Wayfinder
    icon: wayfinder
    parent: weapons/index.md
    position: 105
---
# *Wayfinder* 05/ID

<ItemImage id="wayfinder" scale="3" />

*Wayfinder*는 공격 능력은 없지만 Signature Series 장비에 속합니다. 원거리에서 조명 장치를 배치하는 데 특화되어 있습니다. 발사체는 공중에서 최대 5초 동안 유지되며, 유효한 표면에 충돌하면 지속적으로 남는 블록으로 설치됩니다. *Wayfinder*의 표식은 모든 블록 면과 물속에도 설치할 수 있습니다.

## Stats

- 발사체: Glowstick
- 발사체 속도: 78m/s
- 방아쇠 방식: 반자동
- 발사 간격: 0.5초
