---
navigation:
    title: Nova
    icon: nova
    parent: weapons/index.md
    position: 177
---
# *Nova* 77/HX

<ItemImage id="nova" scale="3" />

### Default upgrade

<UpgradeEntry id="default/nova" />

## Stats
- 기본 피해량: 75.0
- 사거리: 50.0
- 발사체: [LightFrag](index.md#lightfrags)
- 방아쇠 방식: 반자동
- 발사 간격: 0.65초
