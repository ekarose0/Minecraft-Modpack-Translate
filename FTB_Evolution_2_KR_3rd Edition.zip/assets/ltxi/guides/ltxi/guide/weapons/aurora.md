---
navigation:
    title: Aurora
    icon: aurora
    parent: weapons/index.md
    position: 121
---
# *Aurora* 21/SG

<ItemImage id="aurora" scale="3" />

### Default upgrade

<UpgradeEntry id="default/aurora" />

## Stats

- 기본 피해량: 산탄 1발당 9.0, 최대 63.0
- 사거리: 13.0
- 발사체: [LightFrag](index.md#lightfrags) 산탄 7발
- 방아쇠 방식: 반자동
- 발사 간격: 0.5초
