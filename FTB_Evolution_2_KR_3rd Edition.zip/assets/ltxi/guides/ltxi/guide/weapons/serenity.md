---
navigation:
    title: Serenity
    icon: serenity
    parent: weapons/index.md
    position: 111
---
# *Serenity* 11/PX

<ItemImage id="serenity" scale="3" />

### Default upgrade

<UpgradeEntry id="default/serenity" />

크기가 작다고 얕보지 마세요. *Serenity*의 LightFrag는 가까운 거리에서 방어력이 낮고 위협도가 낮은 적을 파괴하도록 설계되었습니다. 대신 방어력이 높거나 위협도가 높은 표적에게는 [고전](../fundamentals/damage_modifiers.md)합니다.

## Stats

- 기본 피해량: 3.0
- 사거리: 20.0
- 발사체: [LightFrag](index.md#lightfrags)
- 방아쇠 방식: 자동
- 발사 속도: 1200RPM
