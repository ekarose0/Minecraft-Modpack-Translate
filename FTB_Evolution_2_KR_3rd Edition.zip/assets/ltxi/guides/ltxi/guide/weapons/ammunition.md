---
navigation:
    title: "Ammunition Basics"
    icon: medium_voltaic_cell
    parent: weapons/index.md
    position: 0
---
# Ammunition Mechanics

모든 Signature Series 무기는 내부 탄창 공급 시스템으로 작동합니다. 재장전 자원에는 **3가지** 종류가 있습니다. 아이템, <Color id="energy">Energy</Color>, <Color id="light_purple">Infinite</Color>이며, [업그레이드 모듈](../fundamentals/upgrade_system.md)로 변경할 수 있습니다.

> 주의: 재장전하면 탄창에 남아 있는 탄약이 **모두 사라집니다**. 특히 Explosive 또는 Heavy 무기를 사용할 때 불필요한 재장전을 피하세요!

## Reload Source: Items

지정된 아이템 1개를 소비하여 탄창을 재충전합니다.

## Reload Source: Energy

<Color id="energy">Common Energy</Color>를 소비하여 **탄창을 재충전**합니다. 에너지가 무기에 직접 공급되는 것은 아닙니다. 재장전 시 소비하는 에너지 양은 장비의 **Energy Usage** 능력치에 따라 달라집니다.

## Reload Source: Infinite

탄창이 무한으로 바뀝니다. 장착하면 탄창이 '비어' 있더라도 언제든 발사할 수 있습니다.
