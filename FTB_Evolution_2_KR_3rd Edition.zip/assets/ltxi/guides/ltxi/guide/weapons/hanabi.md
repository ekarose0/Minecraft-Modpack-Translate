---
navigation:
    title: Hanabi
    icon: hanabi
    parent: weapons/index.md
    position: 133
---
# *Hanabi* 33/GL

<ItemImage id="hanabi" scale="3" />

## Stats

- 기본 피해량: 탄종에 따라 다름(아래 참조)
- 발사체: Shell Grenades
- 발사체 속도: 30m/s
- 방아쇠 방식: 반자동
- 발사 간격: 0.75초

## Shells

Hanabi는 여러 종류의 Shell을 발사할 수 있습니다. 장기간 현장 연구 끝에 표준 폭발탄을 새로운 Sparkler Shell로 교체했습니다. 다른 탄종은 [Equipment Upgrade Modules](../fundamentals/upgrade_system.md)로 해금해야 합니다.

### Sparkler

강력한 첫 폭발을 일으킨 뒤 소형 폭탄 14개로 분열하여 넓은 원형 범위에 막대한 폭발 피해를 줍니다.

- 폭발 반경: 10.0
- 기본 피해량: 30.0
- 소형 폭탄 피해량: 10.0
- 피해 태그: `#minecraft:is_explosion`

### Flame

<UpgradeEntry id="flame_grenade_core" />

**5초** 동안 지속되는 고정 화염 지대를 생성하여 내부의 모든 대상을 계속 태웁니다. 이동이 빠른 표적에게는 권장하지 않습니다.

- 폭발 반경: 9.0
- 기본 피해량: 10.0
- 화염 지대 피해량: 4틱마다 4.0(총 최대 100.0)
- 충격 및 화염 피해 태그: `#minecraft:is_fire`
- `#ltxi:weak_to_flame` 적에게 피해량 3배
  - Strays, Polar Bears, Snow Golems

### Cryo

<UpgradeEntry id="cryo_grenade_core" />

넓은 범위의 적을 얼음으로 공격합니다. 군중 제어 또는 냉기에 약한 적을 상대할 때 권장합니다.

- 폭발 반경: 12.0
- 기본 피해량: 4.0
- `#ltxi:weak_to_cryo` 적에게 피해량 8배
  - 기본적으로 `#minecraft:freeze_hurts_extra` 태그 사용: Striders, Blazes, Magma Cubes
- [*Frostbite III*](../fundamentals/mob_effects.md#frostbite) 효과를 20초 동안 부여

### Electric

<UpgradeEntry id="electric_grenade_core" />

Electric Shell은 비가 오는 환경과 수중 전투에 특화되어 있습니다.

- 폭발 반경: 10.0, *비나 물속에서 충돌하면 20.0*
- 기본 피해량: 30.0
- 다음 조건 중 하나를 충족하면 피해량 3배
  - 표적이 비 또는 물속에 있음
  - `#ltxi:weak_to_electric` 태그 보유: Turtles, Axolotls, Guardians, Elder Guardians, Fish, Dolphins, Squids, Glow Squids, Tadpoles

### Acid

<UpgradeEntry id="acid_grenade_core" />

Acid Shell은 방어력이 높거나 위협적인 표적에 특화되어 있습니다. 폭발 반경은 작지만 피해량이 더 높습니다.

- 폭발 반경: 5.0
- 기본 피해량: 60.0
- [*Corroding III*](../fundamentals/mob_effects.md#corroding) 효과를 10초 동안 부여

### Gloom Gas

<UpgradeEntry id="gloom_gas_grenade_core" />

Gloom Gas Shell은 적의 피해량과 능력을 약화시킵니다.

- 폭발 반경: 5.0
- 기본 피해량: 4.0
- [*Gloom III*](../fundamentals/mob_effects.md#gloom) 효과를 30초 동안 부여
