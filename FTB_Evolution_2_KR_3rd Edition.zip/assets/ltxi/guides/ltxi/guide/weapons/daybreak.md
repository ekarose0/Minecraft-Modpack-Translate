---
navigation:
    title: Daybreak
    icon: daybreak
    parent: weapons/index.md
    position: 141
---
# *Daybreak* 41/RL

<ItemImage id="daybreak" scale="3" />

*Daybreak*는 위협도가 높은 표적을 제거하는 데 특화된 중형 Rocket Launcher입니다. 탄착 시 유도 소형 폭탄(Homing Bomblet) 7개가 생성됩니다. 직접 명중했다면 폭탄 모두가 맞은 개체를 추적합니다. 대상이 살아 있지 않다면 유효한 표적이 범위에 들어올 때까지 대기합니다. 이 폭탄은 표적을 한 번만 획득할 수 있으며 해당 표적에만 피해를 줍니다. 넓은 범위를 파괴하려면 [Hanabi](hanabi.md)를 고려해 보세요.

## Stats

- 기본 직격 피해량: 100.0
- 기본 폭발 범위 피해량: 40.0
- 기본 소형 폭탄 피해량: 15.0
- 발사체: Rockets
- 발사체 속도: 30m/s
- 방아쇠 방식: 반자동
- 발사 간격: 1.5초
