---
navigation:
    title: Mirage
    icon: mirage
    parent: weapons/index.md
    position: 113
---
# *Mirage* 13/CX

<ItemImage id="mirage" scale="3" />

### Default upgrade

<UpgradeEntry id="default/mirage" />

## Stats

- 기본 피해량: 4.5
- 사거리: 45.0
- 발사체: [LightFrag](index.md#lightfrags)
- 방아쇠 방식: 자동
- 발사 속도: 600RPM
