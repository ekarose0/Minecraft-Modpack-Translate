---
navigation:
    title: Enchantments
    icon: minecraft:enchanted_book
    position: 11
---
# 마법 부여

## Razor

- 호환 대상: `#minecraft:enchantable/sharp_weapon`
- 마법 부여대/모루 최대 레벨: 3

Razor 마법 부여는 주로 처치한 몹의 머리를 수집하는 데 사용됩니다. 일부 적에게서는 추가 전리품을 얻을 수도 있습니다.

### 몹 참수

- 일반 머리/해골의 드롭 확률: 레벨당 10%.
- **레벨 4 이상에서만 적용**: 4레벨부터 레벨당 50% 확률로 Ender Dragon 머리 드롭.

### 기타 전리품

- 토끼를 처치하면 레벨당 33% 확률로 Rabbit Foot을 얻습니다.
