---
navigation:
    title: Metal Panels
    icon: titanium_panel
    parent: building_blocks/index.md
---
# Metal Panels

## Titanium
<Row>
<BlockImage id="titanium_panel" scale="3"/>
<BlockImage id="smooth_titanium_panel" scale="3"/>
<BlockImage id="tiled_titanium_panel" scale="3" />
</Row>

## Slatesteel
<Row>
<BlockImage id="slatesteel_panel" scale="3" />
<BlockImage id="smooth_slatesteel_panel" scale="3" />
<BlockImage id="tiled_slatesteel_panel" scale="3" />
</Row>

고분자-금속 복합재는 시설 건축에 매우 적합합니다. 고분자 생산 라인을 구축하고 나면 Titanium 및 Slatesteel 패널을 손쉽게 대량 생산할 수 있습니다. 이 블록들의 폭발 저항은 **36.0**으로, 바로 옆에서 터지는 TNT와 일반적인 적대적 몹의 폭발 대부분을 견딜 수 있습니다.
