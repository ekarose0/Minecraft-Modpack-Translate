---
navigation:
    title: "Composite Glasses"
    icon: titanium_glass
    parent: building_blocks/index.md
---
# Composite Glasses

[Arc Furnace](../machines/processing/arc_furnace.md)에서 Quartz와 Titanium을 제련하면 매우 투명하면서도 단단한 유리를 만들 수 있습니다. 이 유리 블록은 Obsidian과 맞먹을 정도로 일반적인 폭발에 강합니다. 채굴할 때 Silk Touch는 필요 없지만, 등급에 관계없이 곡괭이는 필요합니다.

## Titanium Glass

<BlockImage id="titanium_glass" scale="2" />

기본 복합 유리입니다. 기지의 유리 부분을 보강하는 데 유용하며, Creeper나 Ghast 같은 중하위 위협의 폭발에도 완전히 견딥니다.

## Glacia Glass

<BlockImage id="glacia_glass" scale="2" />

*Glacia*는 Titanium Glass를 [Energizing](../machines/processing/voltaic_injector.md)하여 만드는 저희의 대표 유리입니다. 일반 Titanium Glass보다 구조적으로 더 강하지는 않지만, 외관을 바꾸는 데 사용할 수 있습니다.
