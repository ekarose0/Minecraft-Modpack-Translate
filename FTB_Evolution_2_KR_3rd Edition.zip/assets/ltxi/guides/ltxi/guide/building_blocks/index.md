---
navigation:
    title: Building Blocks
    icon: glacia_glass
    position: 10
---
# 건축 블록

<GameScene zoom={2} interactive={true}>
<ImportStructure src="../assets/building_sample.nbt" />
</GameScene>

최첨단 기술에는 탁 트인 들판보다 훌륭한 시설이 어울리지 않을까요? LTXI는 첨단 연구실과 기지를 만들 수 있도록 다양한 건축 블록을 제공합니다.

<SubPages />
