---
navigation:
    title: Peridotite
    icon: peridotite
    parent: building_blocks/index.md
---
# Peridotite

<ItemGrid>
<ItemIcon id="peridotite" />
<ItemIcon id="peridotite_stairs" />
<ItemIcon id="peridotite_slab" />
<ItemIcon id="peridotite_wall" />

<ItemIcon id="polished_peridotite" />
<ItemIcon id="polished_peridotite_stairs" />
<ItemIcon id="polished_peridotite_slab" />
<ItemIcon id="polished_peridotite_wall" />
</ItemGrid>

Peridotite는 Andesite, Granite, Diorite처럼 지하에서 흔히 발견되는 아름다운 녹색 암석입니다. Polished 형태로 가공하거나 계단, 반 블록, 담장으로 제작할 수 있습니다.

## Peridotite Dust

<ItemImage id="peridotite_dust" />

Peridotite는 첨단 기술에 중요한 재료입니다. Peridotite를 [Grinding](../machines/processing/grinder.md)하여 가루로 만든 뒤 [HydroSieve](../machines/processing/hydrosieve.md)에서 대량 가공하면 원재료 [Olivine](../resources/gems.md#olivine)을 얻을 수 있습니다.
