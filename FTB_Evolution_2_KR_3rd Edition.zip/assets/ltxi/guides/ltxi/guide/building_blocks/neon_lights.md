---
navigation:
    title: "Neon Lights"
    icon: ltx_lime_neon_light
    parent: building_blocks/index.md
---
# Neon Lights

<ItemGrid>
<ItemIcon id="white_neon_light" />
<ItemIcon id="orange_neon_light" />
<ItemIcon id="magenta_neon_light" />
<ItemIcon id="light_blue_neon_light" />
<ItemIcon id="yellow_neon_light" />
<ItemIcon id="lime_neon_light" />
<ItemIcon id="pink_neon_light" />
<ItemIcon id="gray_neon_light" />
<ItemIcon id="light_gray_neon_light" />
<ItemIcon id="cyan_neon_light" />
<ItemIcon id="purple_neon_light" />
<ItemIcon id="blue_neon_light" />
<ItemIcon id="brown_neon_light" />
<ItemIcon id="green_neon_light" />
<ItemIcon id="red_neon_light" />
<ItemIcon id="black_neon_light" />

<ItemIcon id="ltx_lime_neon_light" />
<ItemIcon id="energy_blue_neon_light" />
<ItemIcon id="electric_chartreuse_neon_light" />
<ItemIcon id="corrosive_green_neon_light" />
<ItemIcon id="gloom_blue_neon_light" />
</ItemGrid>

<GameScene zoom={2}>
<Block id="smooth_titanium_panel" x="0" y="1" />
<Block id="ltx_lime_neon_light" x="0" y="0" />
<Block id="titanium_panel" x="0" y="-1" />
<Block id="smooth_titanium_panel" x="1" y="1" />
<Block id="ltx_lime_neon_light" x="1" y="0" />
<Block id="titanium_panel" x="1" y="-1" />
<Block id="smooth_titanium_panel" x="2" y="1" />
<Block id="ltx_lime_neon_light" x="2" y="0" />
<Block id="titanium_panel" x="2" y="-1" />
</GameScene>

이름과 달리 Neon Lights에는 실제 Neon이 들어 있지 않습니다. 대신 염료와 융합한 [Phosphorus](../resources/elements_base.md#phosphorus)가 들어 있어 장식용 발광 블록으로 사용할 수 있습니다. Neon Lights는 [Arc Furnace](../machines/processing/arc_furnace.md)에서 만들 수 있으며, 투입 재료 대비 완제품 생산량이 높습니다. 기본 염료 16색에 더해 저희의 전용 안료로 추가 색상 5종을 만들 수 있습니다.
