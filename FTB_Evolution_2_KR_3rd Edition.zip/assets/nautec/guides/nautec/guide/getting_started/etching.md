---
navigation:
  title: 상자와 에칭
  icon: nautec:rusty_crate
  position: 6
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:etching_acid_bucket
  - nautec:crate
  - nautec:rusty_crate
---

# <Color id="light_purple">상자와 에칭</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="rusty_crate" scale="2"/>
  Crate는 상자처럼 열 수 있으며, 녹슨 상자는 먼저 Etching Acid로 세척해야 합니다.
</Column>

***

<Row>
  <ItemImage id="crate"/>
  ### <Color id="aqua">Crate</Color>
</Row>

지오드와 바닐라 난파선 및 유적 전리품에서 발견되는 27칸짜리 보관함입니다. 우클릭하면 상자처럼 열 수 있으며, 호퍼로 아이템을 넣고 꺼낼 수도 있습니다.

Crate를 부수면 개봉 여부와 관계없이 내용물이 들어 있는 상태로 아이템화됩니다. 따라서 집으로 가져간 뒤 열어볼 수 있습니다.

***

<Row>
  <ItemImage id="rusty_crate"/>
  ### <Color id="aqua">Rusty Crate</Color>
</Row>

유적에서 발견되는 녹슬어 잠긴 상자입니다. Etching Acid로 처리하기 전에는 열 수 없으며 호퍼로도 내용물을 꺼낼 수 없습니다. Etching Acid에 떨어뜨리면 전리품을 유지한 채 일반 Crate로 바뀝니다. 툴팁과 열려고 할 때 나오는 메시지에도 이 내용이 표시되며, JEI의 Item Etching 항목에서 변환법을 확인할 수 있습니다.

Rusty Crate에는 일반 Crate보다 좋은 회수품이 들어 있습니다. 부수어 옮겨도 일반 Crate와 마찬가지로 내용물이 유지됩니다.

***

## <Color id="gold">에칭</Color>

아이템을 Etching Acid에 떨어뜨리면 제작법에 따라 8~10초 후 세척됩니다. 바닥에 떨어진 아이템 묶음 전체가 한 번에 변환됩니다.

| 투입물 | 결과물 | 소요 시간 |
|---|---|---|
| Rusty Crate | Crate (전리품 유지) | 10초 |
| <ItemLink id="rusty_gear"/> | <ItemLink id="gear"/> | 8초 |
| <ItemLink id="ancient_valve"/> | <ItemLink id="valve"/> | 10초 |

JEI의 Item Etching 항목에서 이 제작법들을 확인할 수 있습니다.

에칭을 할 때마다 1/3 확률로 아이템이 들어 있는 Etching Acid 근원 블록이 소모됩니다. 흐르는 산성 액체와 웅덩이 아래 블록은 소모되지 않습니다. 깊이 1블록의 구덩이에 근원 블록 하나만 있어도 충분하지만, 보충용 양동이를 준비해 두세요.

***

<Row>
  <ItemImage id="etching_acid_bucket"/>
  ### <Color id="aqua">Etching Acid</Color>
</Row>

<RecipeFor id="etching_acid_bucket"/>

[Mixer](nautec:laser_chemistry/mixer.md)를 만들면 Salt Water로 Etching Acid를 생산할 수 있습니다. Etching Acid는 점성이 높아 들어가면 가라앉고 이동 속도가 느려지며, 몹은 이를 피해 이동합니다. [Abyssal Pressure Forge](nautec:deep_engineering/pressure_forge.md)도 이 액체를 사용합니다.
