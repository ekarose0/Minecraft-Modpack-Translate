---
navigation:
  title: 시작하기
  icon: nautec:prismarine_crystal
  position: 1
---

# <Color id="gold">시작하기</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="prismarine_crystal" scale="2"/>
  시작할 때 알아야 할 바다 생물군계와 생물, 구조물과 인양품, 잠수 장비, 낚시, 첫 레이저 빔을 소개합니다.
</Column>

***

<SubPages icons={true}/>
