---
navigation:
  title: Stronger Beams
  icon: nautec:focusing_lens
  position: 2
  parent: getting_started/getting_started-index.md
---
# <Color id="light_purple">강한 광선의 효과</Color>

레이저 광선을 사용하는 모든 NauTec 기계에는 작동을 시작하기 위해 매 틱 받아야 하는 최소 AP가 있습니다. 그보다 강한 광선을 공급해도 낭비되지 않습니다. 대부분의 기계는 더 빨리 작업하고 Deep Sea Drain은 더 많은 물을 퍼 올립니다.

***

## <Color id="gold">기본 공식</Color>

**속도 배율 = √(공급 광선 출력 ÷ 기계의 필요 출력)**

출력을 네 배로 늘리면 속도는 두 배, 아홉 배로 늘리면 세 배가 됩니다. 상한은 없지만 속도를 더 올릴 때마다 추가 에너지 비용이 커집니다.

| 기계 필요 출력 대비 공급 배율 | 속도 |
|---|---|
| 1배 미만 | 작동하지 않음 |
| 1× | ×1 (기본) |
| 2× | ×1.41 |
| 4× | ×2 |
| 9× | ×3 |
| 16× | ×4 |
| 25× | ×5 |
| 100× | ×10 |

10 AP가 필요한 기계에 40 AP를 넣으면 속도는 2배, 90 AP를 넣으면 3배가 됩니다.

순도를 높여도 속도는 빨라지지 않습니다. 최소 순도가 필요한 기계(Advanced Bacterial Analyzer, Colony Replicator, Grafting Station)는 출력이 아무리 강해도 순도 기준에 못 미치면 멈춥니다.

***

## <Color id="gold">적용 기계</Color>

| 기계 | 필요 출력(기본값) | 강한 광선의 효과 |
|---|---|---|
| [Mixer](nautec:laser_chemistry/mixer.md) | 10 AP | 주기당 제작 횟수 증가. 10 AP당 한 개씩 최대 64개, 640 AP 초과부터는 주기 자체가 빨라짐 |
| [Mutator](nautec:aquatic_biology/mutator.md) | 10 AP | 변이 시도 주기 단축으로 분당 시도 횟수 증가 |
| [Incubator](nautec:aquatic_biology/incubator.md) | 20 AP | 성장 주기 단축 및 주기별 영양분 소비 간격 단축 |
| [Bacterial Analyzer](nautec:aquatic_biology/bacterial_analyzer.md) | 5 AP | 분석 시간 단축 |
| [Advanced Bacterial Analyzer](nautec:aquatic_biology/bacterial_analyzer.md) | 순도 2.1에서 40 AP | 접시 아홉 개의 분석 시간 단축 |
| [Pressure Forge](nautec:deep_engineering/pressure_forge.md) | 40 AP | 단조 속도 증가 |
| [Colony Replicator](nautec:aquatic_biology/colony_replicator.md) | 순도 2.0에서 80 AP | 복제 시간 단축 |
| [Grafting Station](nautec:aquatic_biology/bacteria_grafting.md) | 순도 2.8에서 100 AP, Advanced Grafting Anchor 사용 시 500 AP | 채취 주기 단축 |
| [Bio Reactor](nautec:aquatic_biology/bio_reactor.md) | 기본 5 AP + 군체당 15 AP, 업그레이드 배율 적용 | 생산 속도 증가 |
| [Industrial Bio Reactor](nautec:aquatic_biology/industrial_bio_reactor.md) | 기본 100 AP + 군체당 50 AP, 업그레이드 배율 적용 | 생산 속도 증가 |
| [Augmentation Station](nautec:laser_augmentation/augmentation_station.md) | 사용 중인 확장부마다 25 AP | 증강 장치 설치 시간 단축. 가장 느린 확장부 속도 기준 |
| [Submarine Dock](nautec:submarine/submarine_dock.md) | 20 AP | 정박한 잠수함 충전 속도 증가 |
| [Deep Sea Drain](nautec:laser_chemistry/drain.md) | 20 AP 초과 | 매초 퍼 올리는 Salt Water 증가. 광선 출력에 정비례 |
| [Osmosis Filter](nautec:laser_chemistry/osmosis_filter.md) | 없음 | 40 AP를 추가할 때마다 물 생산량 두 배 |

**배율 중첩:** Bio Reactor는 먼저 군체 수와 업그레이드로 필요 출력을 계산한 다음, 그보다 강한 광선의 속도 배율을 Speed Upgrade 효과에 추가로 곱합니다. 업그레이드로 1.5배 빨라진 반응로에 필요 출력의 네 배를 공급하면 최종 속도는 3배입니다. 강한 광선은 군체의 영양분 소비 속도를 높이지 않으므로 추가 생산량만 얻습니다. Advanced Grafting Anchor도 같은 방식입니다. 기계의 필요 출력을 500 AP로 높이면서 채취 속도를 올리고, 500 AP보다 강한 광선은 속도를 또 올립니다.

**속도가 증가하지 않는 기계:** [Laser Purification Smelter](nautec:deep_engineering/laser_purification_smelter.md)는 광선이 아무리 강해도 도관 업그레이드에 따른 속도로 작동합니다. 대신 순도가 높은 광선은 요구 AP를 줄입니다.

**원래 출력에 비례하는 기계:** [Resonance Chamber](nautec:deep_engineering/resonance_chamber.md)는 받은 에너지만큼 충전하며 [Crystal Cradle](nautec:deep_engineering/crystal_cultivation.md)은 누적 공급 에너지에 따라 성장합니다. 따라서 두 기계는 원래부터 광선 출력에 정비례하여 빨라집니다.

***

## <Color id="gold">확인 방법</Color>

Jade에서는 이러한 기계의 실제 속도와 현재 광선 출력, 요구 출력이 표시됩니다. 예를 들어 "40 AP 광선에서 속도 ×2.00(필요 10)"처럼 나타납니다. 광선이 너무 약하면 빨간색으로 표시됩니다. <ItemLink id="prism_monocle"/>로 레이저 블록에 도착하는 출력과 순도를 볼 수도 있습니다.

더 강한 광선을 얻으려면 [Laser Junction](nautec:laser_chemistry/laser_manipulation.md)에서 여러 광원을 합치거나 [Energy Converter](nautec:laser_chemistry/energy_converter.md) 같은 더 강한 발전기를 연결하세요.

***

## <Color id="gold">모드팩 제작자용</Color>

`config/nautec-common.toml`의 `beamOverclock`를 비활성화하면 필요 출력 이상에서도 모든 기계가 기본 속도로 작동합니다. `beamOverclockMaxSpeed`는 최대 속도 배율을 제한하며 0은 제한 없음을 뜻합니다. Deep Sea Drain의 펌프 속도는 해당 페이지에 설명된 별도 설정을 사용합니다.
