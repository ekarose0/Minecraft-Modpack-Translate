---
navigation:
  title: Building Blocks
  icon: nautec:chiseled_dark_prismarine
  position: 14
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:polished_prismarine
  - nautec:chiseled_dark_prismarine
  - nautec:dark_prismarine_pillar
  - nautec:decorative_prismarine_crystal
  - nautec:brown_polymer_block
---

# <Color id="light_purple">Building Blocks</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="chiseled_dark_prismarine" scale="2"/>
  Prismarine 계열 건축 블록이며, 일부는 NauTec 기계 제작에도 사용됩니다.
</Column>

***

<Row>
  <ItemImage id="polished_prismarine"/>
  ### <Color id="aqua">Polished Prismarine</Color>
</Row>

NauTec의 기본 건축 블록입니다. 건축 외에도 Aquatic Catalyst, 중계기, 대부분의 초반 기계, Augmentation Station 및 Bio Reactor 멀티블록 구조물에 사용됩니다.

<Recipe id="nautec:polished_prismarine"/>

***

<Row>
  <ItemImage id="chiseled_dark_prismarine"/>
  ### <Color id="aqua">Chiseled Dark Prismarine</Color>
</Row>

장식용 Dark Prismarine 블록으로, Ocean Ruins의 아치 구조물을 이루는 블록 중 하나입니다.

<Recipe id="nautec:chiseled_dark_prismarine"/>

***

<Row>
  <ItemImage id="dark_prismarine_pillar"/>
  ### <Color id="aqua">Dark Prismarine Pillar</Color>
</Row>

원목처럼 설치 방향에 따라 축이 정해지는 기둥입니다. [Bio Reactor](nautec:aquatic_biology/bio_reactor.md)의 프레임에 사용됩니다.

<Recipe id="nautec:dark_prismarine_pillar"/>

***

<Row>
  <ItemImage id="decorative_prismarine_crystal"/>
  ### <Color id="aqua">Decorative Prismarine Crystal</Color>
</Row>

Sea Lantern만큼 밝게 빛나는 높이 6블록의 수정입니다. 순수한 장식용입니다.

설치한 블록부터 위로 다섯 블록을 더 차지하므로 총 여섯 블록이 비어 있어야 설치할 수 있습니다. 어느 부분이든 부수면 전체 수정이 사라지면서 아이템 하나로 떨어집니다.

<Recipe id="nautec:decorative_prismarine_crystal"/>

***

<Row>
  <ItemImage id="brown_polymer_block"/>
  ### <Color id="aqua">Brown Polymer Block</Color>
</Row>

<ItemLink id="brown_polymer"/>로 만든 양털처럼 부드러운 블록입니다. 다시 제작하면 Polymer 4개로 되돌릴 수 있습니다.

<Recipe id="nautec:brown_polymer_block"/>

<Recipe id="nautec:brown_polymer_from_block"/>
