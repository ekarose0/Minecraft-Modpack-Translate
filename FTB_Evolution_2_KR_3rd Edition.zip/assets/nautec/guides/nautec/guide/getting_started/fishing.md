---
navigation:
  title: Fishing
  icon: nautec:nautec_fishing_rod
  position: 13
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:nautec_fishing_rod
---

# <Color id="light_purple">Fishing</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nautec_fishing_rod" scale="2"/>
  행운 낚시 구역과 Prismatic Fishing Rod를 이용하면 추가 전리품을 얻을 수 있습니다.
</Column>

두 시스템은 서로 독립적이며 효과가 중첩됩니다. 행운 낚시 구역은 낚싯대 종류와 관계없이 낚시 위치에 따라 보너스를 줍니다. Prismatic Fishing Rod는 매번 추가 전리품 추첨을 하고 입질 시 미니게임을 시작합니다. 두 시스템 모두 일반 전리품을 대체하지 않고 추가합니다.

***

## <Color id="gold">행운 낚시 구역</Color>

바다나 강에 있을 때 주변 수면에 생성되는 열린 물 구역입니다. 위로 빛나는 포자가 떠다니고 거품이 올라오므로 멀리서도 발견할 수 있습니다.

* 구역은 플레이어로부터 약 32블록 이내에 최대 약 45초마다 하나씩 생성되며, 다른 구역의 48블록 이내에는 생성되지 않습니다.
* 반경은 2~6블록이며 반경 전체가 열린 물인 곳에서만 생성되므로 해안에서 떨어진 곳을 찾으세요.
* 5분간 유지되며 첫 낚시 성공 시 소모됩니다.

찌를 구역 안에 던지면 찌가 그 자리에 머무르고 입질 속도가 2배가 됩니다. 일반 전리품 외에 구역 전리품을 추가로 추첨합니다. 다른 모드의 낚싯대를 포함해 모든 낚싯대가 작동합니다.

<ItemLink id="eye_of_the_sea"/>를 던지면 이후 5분간 주변 구역 생성 빈도가 2배가 됩니다. [Eye of the Sea](eye_of_the_sea.md)를 참고하세요.

이 수치들은 `config/nautec-common.toml`에서 변경할 수 있으며, `luckyZonesEnabled`로 구역 생성을 끌 수도 있습니다.

***

## <Color id="gold">구역 전리품</Color>

추가 추첨은 대부분 일반 어획물이지만 약 1/7 확률로 보물을 얻습니다. 두 전리품 모두 낚시하는 물의 종류에 따라 달라집니다.

| 수역 | 일반 어획물 | 보물 |
|---|---|---|
| Anywhere | cod, salmon, Silt Skippers, Salt, Prismarine Crystal Shards | Rusty Gears, Ancient Valves, Broken Whisks, Prismarine Lenses, Crates filled with loot |
| Rivers | clay, lily pads | |
| Any ocean | tropical fish, kelp | Nautilus Shells, Atlantic Gold Nuggets |
| Abyssal Trench | Abyssal Coral, Damaged Aquatic Chips, ink sacs | Abyssal Organs, Budding Prismarine, live squid |
| Bioluminescent Grove | Luminous Membrane, Luminescent Algae, Deep Kelp, live Silt Skippers | Glow Polyps, Aquatic Chips, live Lantern Jellies |
| Hydrothermal Vents | Chitin Plates, Vent Tubeworms, magma blocks | Laser Channeling Coils, blaze powder |
| Prismarine Reef | Prismarine Fronds, prismarine shards, pufferfish, live tropical fish | Prismarine Crystal Shards, Heart of the Sea |

살아 있는 어획물은 아이템이 아닌 생물입니다. 추첨에서 생물이 나오면 낚싯줄을 감을 때 찌 위치에 생물이 나타납니다. 살아 있는 Cod는 모든 수역에서 낚일 수 있습니다.

***

<Row>
  <ItemImage id="nautec_fishing_rod"/>
  ### <Color id="aqua">Prismatic Fishing Rod</Color>
</Row>

일반 낚싯대처럼 사용하지만 어느 곳에서 낚시하든 매번 위의 행운 낚시 구역 전리품을 추가 추첨합니다. 행운 구역 안에서는 구역 자체의 추가 추첨과 중첩됩니다.

입질이 오면 화면 아래에 3초간 낚시 막대가 표시됩니다. Space, Enter 또는 마우스 좌클릭으로 낚아채세요. 막대가 나타난 직후의 입력은 무시됩니다. 다른 화면이 열려 있지 않을 때만 막대가 나타납니다.

<Recipe id="nautec:nautec_fishing_rod"/>

***

## <Color id="gold">세 종류의 막대</Color>

막대 유형은 무작위이며 상단에 이름이 표시됩니다.

* Something is biting: 초록색 구간 1개. 표시가 구간 안에 있을 때 한 번 누르세요.
* It is fighting you: 짧은 구간 3개. 순서대로 각 구간에서 한 번씩 누르세요.
* It is running with the line: 긴 구간 1개. 표시가 초록색에 들어올 때 누르고 유지하다가 벗어나기 전에 놓으세요.

표시가 성공 구간 안에 있으면 패널이 초록색으로 바뀝니다. "Hooked it"은 성공, "It slipped the hook"은 실패를 뜻하며 실패 시 막대가 끝날 때까지 빨간색으로 유지됩니다.

성공 여부와 관계없이 막대가 표시되는 동안과 종료 후 2초간 물고기가 낚싯줄에 걸려 있습니다. 막대가 사라진 뒤 우클릭해 낚싯줄을 감으세요.

***

## <Color id="gold">보상</Color>

* 실패하거나 무시한 경우: 일반 어획물 + 낚싯대 보너스 추첨 1회.
* 성공한 경우: 일반 어획물 + 일반 보너스 추첨 1회 + 보물 보너스 추첨 1회 + 경험치.
* 행운의 보물 입질(약 1/7 확률)에서 성공한 경우: 보물 추첨 2회 + 일반 어획물 추첨 1회.

실패하더라도 일반 낚싯대를 사용했을 때보다 손해를 보지는 않습니다.
