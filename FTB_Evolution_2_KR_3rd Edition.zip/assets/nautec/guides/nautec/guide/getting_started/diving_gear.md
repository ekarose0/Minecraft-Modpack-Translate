---
navigation:
  title: Diving Suit and Oxygen
  icon: nautec:diving_helmet
  position: 10
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:brown_polymer
  - nautec:diving_chestplate
  - nautec:diving_helmet
  - nautec:diving_leggings
  - nautec:diving_boots
  - nautec:air_bottle
---

# <Color id="light_purple">Diving Suit and Oxygen</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="diving_helmet" scale="2"/>
  최대 10분 분량의 공기를 저장하는 4부위 잠수복입니다.
</Column>

네 부위를 모두 착용하면 Chestplate의 공기 탱크가 물속에서 산소 게이지를 가득 유지합니다. 잠수 중 매초 공기 1초분을 소모해 산소 게이지를 채우며, 탱크가 비면 평소처럼 산소가 줄어듭니다.

네 부위를 모두 착용하면 수영하거나 떠 있는 상태에서도 육지와 같은 속도로 수중 채굴할 수 있습니다. 잠수복이 수중 채굴 속도 감소와 발이 땅에 닿지 않을 때의 속도 감소를 모두 없애 줍니다.

방어력은 Iron Armor 전체 세트와 비슷하며 Anvil에서 Copper Ingot으로 수리할 수 있습니다.

***

## <Color id="gold">잠수복 부위</Color>

<Row>
  <ItemImage id="diving_helmet"/>
  ### <Color id="aqua">Diving Helmet</Color>
</Row>

수중 안개를 제거해 더 먼 곳을 볼 수 있습니다. 나머지 잠수복 없이 Helmet만 착용해도 효과가 적용됩니다.

<Recipe id="nautec:diving_helmet"/>

<Row>
  <ItemImage id="diving_chestplate"/>
  ### <Color id="aqua">Diving Chestplate</Color>
</Row>

최대 10분 분량의 공기를 저장하는 탱크가 있습니다. 새 Chestplate는 탱크가 가득 찬 상태로 지급됩니다. 툴팁에 남은 공기가 표시되고, 물속에서는 단축바 위에 거품 줄로 나타납니다. 공기가 소진되면 빈 거품으로 바뀌어 충전이 필요함을 알려줍니다.

<Recipe id="nautec:diving_chestplate"/>

<Row>
  <ItemImage id="diving_leggings"/>
  ### <Color id="aqua">Diving Leggings and Boots</Color>
</Row>

잠수복 세트를 완성하는 데 필요합니다. 공기 탱크는 네 부위를 모두 착용해야 작동합니다.

<Recipe id="nautec:diving_leggings"/>

<Recipe id="nautec:diving_boots"/>

***

## <Color id="gold">탱크 충전</Color>

<Row>
  <ItemImage id="air_bottle"/>
  ### <Color id="aqua">Pressurized Air Bottle</Color>
</Row>

빈 Glass Bottle을 들고 거품 기둥을 우클릭하면 압축 공기를 채울 수 있습니다. Soul Sand와 Magma에서 생긴 거품 기둥 모두 사용할 수 있습니다. Geode의 Barrel에서도 일부 발견됩니다.

Chestplate 주변에 Bottle 8개를 배치해 조합하면 탱크가 10분 분량으로 완전히 충전되고 빈 Bottle은 반환됩니다. 이때 Chestplate가 새 아이템으로 만들어져 기존 마법 부여가 사라집니다. 마법 부여를 유지하려면 Bottle을 직접 마셔 충전하세요.

<Recipe id="nautec:diving_chestplate_oxygen"/>

Chestplate를 착용한 상태에서 Bottle을 마셔도 충전됩니다. 탱크가 가득 차 있지 않다면 Bottle 1개당 공기 2분분을 추가하며 최대 10분까지 채울 수 있습니다. 빈 탱크는 5개로 충전됩니다. 마시면 10초 동안 위로 떠오르는 효과도 얻습니다.

### <Color id="aqua">Oxygen Fluid</Color>

Chestplate는 Stellaris의 Oxygen처럼 다른 모드의 산소 유체로도 충전할 수 있습니다. 아이템에 유체를 채우는 기계나 탱크 슬롯에 넣으세요. 산소 1 mB당 공기 1초분이 추가되므로 600 mB로 빈 탱크를 가득 채웁니다.

***

<Row>
  <ItemImage id="brown_polymer"/>
  ### <Color id="aqua">Brown Polymer</Color>
</Row>

잠수복 제작 재료입니다. Dried Kelp와 Brown Dye로 제작하거나 Crate와 Geode Barrel에서 찾을 수 있습니다. 남는 Polymer는 Book, Bed, Banner, Item Frame 제작에도 사용됩니다.

<Recipe id="nautec:brown_polymer"/>

***

## <Color id="gold">Stellaris 연동</Color>

Stellaris가 설치되어 있다면 Diving Suit 전체 세트로 공기가 없는 행성에서도 생존할 수 있습니다. 숨 쉴 수 없는 영역에서는 매초 탱크의 공기 1초분을 소모하며 단축바 위에 거품 줄이 표시됩니다. Oxygen Distributor 영역 안에서는 탱크의 공기를 소모하지 않습니다.

Oxygen Module이 달린 Stellaris Space Suit Helmet을 착용하고 Air Bottle을 마시면 Helmet에 산소 120 mB가 추가됩니다. 이는 잠수복 탱크의 공기 2분분과 같습니다.

***

## <Color id="gold">다른 수중 호흡 방법</Color>

* [Sea Scout](nautec:submarine/submarine.md)는 동력이 있는 동안 탑승자 모두에게 호흡을 제공합니다.
* [Wave Jet](nautec:submarine/wave_jet.md)에서 추진을 유지하면 산소 게이지가 줄어들지 않습니다.
* Stellaris Space Suit 전체 세트를 착용하면 Helmet에 산소가 있는 동안 물속에서 호흡할 수 있습니다.
* Drowned Lungs Augment는 물속에서 산소 게이지를 항상 가득 유지합니다. [Mob Augments](nautec:laser_augmentation/mob_augments.md)를 참고하세요.
