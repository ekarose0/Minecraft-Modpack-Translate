---
navigation:
  title: Item Transformation
  icon: nautec:aquarine_steel_ingot
  position: 2
  parent: getting_started/getting_started-index.md
---

# <Color id="light_purple">Item Transformation</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquarine_steel_ingot" scale="2"/>
  작동 중인 레이저 빔에 떨어뜨린 아이템을 다른 아이템으로 변환합니다.
</Column>

송신 블록과 수신기 사이의 작동 중인 빔 안에 아이템을 떨어뜨리세요. 아이템에 해당하는 변환 제작법이 있고 빔 순도가 충분하면 정해진 시간이 지난 뒤 변환됩니다. 별도의 클릭은 필요 없으며 떨어진 스택 전체가 한 번에 변환됩니다. 각 입력 아이템에 제작법의 전체 결과량이 적용되므로 Prismarine Crystal 3개는 Prismarine Crystal Shard 6개가 됩니다.

아이템은 필요한 시간 내내 빔 안에 있어야 합니다. 밖으로 밀려나거나 빔 동력이 잠깐이라도 끊기면 진행 시간이 초기화됩니다.

***

## <Color id="gold">제작법</Color>

| 입력 | 출력 | 필요 순도 | 시간 |
|---|---|---|---|
| Aquarine Steel Compound | Aquarine Steel Ingot | 무관 | 5초 |
| Aquarine Steel Compound | 2 Aquarine Steel Ingots | 2.0 | 4초 |
| <ItemLink id="burnt_coil"/> | Laser Channeling Coil | 1.5 | 10초 |
| Prismarine Crystals | 2 <ItemLink id="prismarine_crystal_shard"/>s | 2.0 | 8초 |
| <ItemLink id="cast_iron_block"/> | 4 <ItemLink id="gear"/>s | 2.5 | 8초 |

여러 제작법이 적용될 수 있으면 현재 빔이 충족하는 것 중 가장 높은 순도를 요구하는 제작법을 사용합니다. 따라서 순도 2.0 이상의 빔은 Compound 1개를 Ingot 2개로 변환합니다.

다른 모드나 데이터팩에서 추가한 제작법까지 포함해 모든 변환은 JEI의 Item Transformation 항목에서 확인할 수 있습니다.

자동화하려면 [Laser Crafting Matrix](laser_crafting_matrix.md)를 사용하세요. 파이프로 재료를 공급하면 이 페이지의 모든 변환을 기계 내부에서 수행할 수 있습니다.

***

## <Color id="gold">Aquarine Steel</Color>

가장 먼저 제작할 것은 Aquarine Steel입니다. Compound는 순도 조건이 없으므로 작동 중인 <ItemLink id="aquatic_catalyst"/> 빔이면 충분합니다. Catalyst를 <ItemLink id="prismarine_laser_relay"/> 같은 수신기 쪽으로 향하게 한 뒤 빔 아래 바닥에 Compound를 떨어뜨리세요.

<Recipe id="nautec:aquarine_steel_compound"/>

이후에는 [Mixer](nautec:laser_chemistry/mixer.md)로 Compound를 대량 생산할 수 있습니다.

***

## <Color id="gold">높은 순도</Color>

Laser Channeling Coil과 Prismarine Crystal Shard는 Catalyst의 기본 순도 1.2보다 높은 순도가 필요합니다. 다음 방법 중 하나를 사용하세요.

* <ItemLink id="prismarine_crystal"/>: 순도 3.0. 아래 설치 방법을 참고하세요.
* <ItemLink id="bacterial_fuel_cell"/>: 군체에 따라 최대 순도 2.5.
* 빔 경로에 놓인 <ItemLink id="focusing_lens"/>: 직진하는 빔의 순도를 0.5 높이며 최대 2.0까지 증가시킵니다(`lensPurityBonus`).
* Catalyst에 닿아 있는 <ItemLink id="budding_prismarine"/>: 블록당 순도 0.1 증가, 최대 2.0. [Laser Power](laser_power.md)를 참고하세요.

아이템 변환은 아이템이 놓인 위치의 빔 순도를 기준으로 판정합니다. 렌즈를 통과한 빔은 증가한 순도를 적용합니다. Prismarine Crystal Shard를 사용하는 Catalyst의 빔이 렌즈 1개를 통과하면 출력 빔 순도가 1.7이 되어 Coil을 수리할 수 있습니다.

***

## <Color id="gold">Prismarine Crystal 아래에서</Color>

모든 Crystal Geode([Structures](structures.md) 참조)에는 빈 공간 위에 Prismarine Crystal이 있습니다. Stone Geode는 1블록, Deepslate Geode는 2블록 높이의 틈이 있어 이 방식에 사용할 수 있습니다.

* Aquatic Catalyst를 Crystal의 아무 블록과 같은 높이에 설치하고 측면에서 Crystal을 향하게 하세요. 16블록 이내에 두고 사이에 불투명한 장애물이 없어야 합니다.
* Catalyst에 연료를 넣습니다. 이제 Crystal의 맨 아래 블록에서 순도 3.0의 빔이 바닥으로 발사됩니다.
* Crystal 아래 틈에 아이템을 떨어뜨려 빔이 닿는 바닥에 놓이게 하세요.

Catalyst에 연료를 계속 공급하세요. 연료가 떨어져 빔이 멈추면 빔 안의 모든 아이템의 변환 진행 시간이 초기화됩니다.

<Color id="gold">팁</Color>: 빔 안에 서 있으면 화상 피해를 입습니다. Crystal 아래로 직접 들어가지 말고 측면에서 아이템을 던지세요.
