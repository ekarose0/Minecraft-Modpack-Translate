---
navigation:
  title: Biome Tanks
  icon: nautec:biome_tank
  position: 20
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:biome_tank
---

# <Color id="light_purple">Biome Tanks</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="biome_tank" scale="2"/>
  바이옴의 작은 생태계를 담아 두는 밀폐형 유리 탱크입니다.
</Column>

Biome Tank는 동력·물·빛 없이도 식물 한 종류를 자동으로 재배합니다. 현재 위치와 다른 바이옴의 식물도 재배할 수 있습니다.

***

## <Color id="gold">탱크에 식물 심기</Color>

식물을 들고 탱크를 우클릭하면 식물 1개를 소비해 심습니다. 이후 해당 식물을 계속 재배합니다. 다른 식물로 우클릭하면 재배 대상을 바꾸며, 기존에 생산한 식물은 먼저 돌려받습니다.

탱크를 부숴도 심은 식물 정보가 유지되므로 다른 곳에 옮겨 설치해도 다시 심을 필요가 없습니다.

<RecipeFor id="biome_tank"/>

***

## <Color id="gold">재배</Color>

식물이 심어진 탱크는 30초마다 1개씩 생산하며(`config/nautec-common.toml`의 `biomeTankTicks`), 최대 한 스택까지 저장합니다. 빈손으로 우클릭해 수확하거나 어느 면에서든 호퍼·파이프로 꺼낼 수 있습니다. 외부에서 아이템을 넣을 수는 없습니다. 저장 공간이 가득 차면 비울 때까지 생산을 멈춥니다.

***

## <Color id="gold">재배 가능한 식물</Color>

| 식물 | 서식 바이옴 |
|---|---|
| <ItemImage id="nautec:glow_polyp" scale="0.5"/> Glow Polyp | Bioluminescent Grove |
| <ItemImage id="nautec:luminescent_algae" scale="0.5"/> Luminescent Algae | Bioluminescent Grove |
| <ItemImage id="nautec:deep_kelp" scale="0.5"/> Deep Kelp | Bioluminescent Grove |
| <ItemImage id="nautec:prismarine_frond" scale="0.5"/> Prismarine Frond | Prismarine Reef |
| <ItemImage id="nautec:abyssal_coral" scale="0.5"/> Abyssal Coral | Abyssal Trench |
| <ItemImage id="nautec:vent_tubeworm" scale="0.5"/> Vent Tubeworm | Hydrothermal Vents |
| <ItemImage id="minecraft:kelp" scale="0.5"/> Kelp | Ocean |
| <ItemImage id="minecraft:seagrass" scale="0.5"/> Seagrass | Ocean |
| <ItemImage id="minecraft:sea_pickle" scale="0.5"/> Sea Pickle | Warm Ocean |
| <ItemImage id="minecraft:tube_coral" scale="0.5"/> Tube Coral | Warm Ocean |
| <ItemImage id="minecraft:brain_coral" scale="0.5"/> Brain Coral | Warm Ocean |
| <ItemImage id="minecraft:bubble_coral" scale="0.5"/> Bubble Coral | Warm Ocean |
| <ItemImage id="minecraft:fire_coral" scale="0.5"/> Fire Coral | Warm Ocean |
| <ItemImage id="minecraft:horn_coral" scale="0.5"/> Horn Coral | Warm Ocean |
| <ItemImage id="minecraft:cactus" scale="0.5"/> Cactus | Desert |
| <ItemImage id="minecraft:sugar_cane" scale="0.5"/> Sugar Cane | Riverbanks |
| <ItemImage id="minecraft:bamboo" scale="0.5"/> Bamboo | Jungle |
| <ItemImage id="minecraft:sweet_berries" scale="0.5"/> Sweet Berries | Taiga |
| <ItemImage id="minecraft:glow_berries" scale="0.5"/> Glow Berries | Lush Caves |
| <ItemImage id="minecraft:red_mushroom" scale="0.5"/> Red Mushroom | Mushroom Fields |
| <ItemImage id="minecraft:brown_mushroom" scale="0.5"/> Brown Mushroom | Mushroom Fields |
| <ItemImage id="minecraft:crimson_fungus" scale="0.5"/> Crimson Fungus | Crimson Forest |
| <ItemImage id="minecraft:warped_fungus" scale="0.5"/> Warped Fungus | Warped Forest |
| <ItemImage id="minecraft:chorus_fruit" scale="0.5"/> Chorus Fruit | The End |
| <ItemImage id="minecraft:cocoa_beans" scale="0.5"/> Cocoa Beans | Jungle |

***

## <Color id="gold">모드팩 제작자용</Color>

탱크가 재배할 수 있는 식물은 `nautec:biome_tank_plants` 아이템 태그로 결정됩니다. 데이터팩이나 KubeJS로 다른 모드의 아이템을 태그에 추가하면 탱크에서도 재배할 수 있습니다. 탱크 내부에는 해당 아이템의 모델이 표시되므로 별도 텍스처가 필요하지 않습니다. 태그에서 아이템을 제거하면 이미 해당 식물을 재배 중인 탱크도 작동을 멈춥니다.
