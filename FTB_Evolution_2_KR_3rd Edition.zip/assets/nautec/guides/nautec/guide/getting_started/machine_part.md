---
navigation:
  title: Ancient Machine Parts
  icon: nautec:ancient_valve
  position: 5
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:burnt_coil
  - nautec:rusty_gear
  - nautec:gear
  - nautec:ancient_valve
  - nautec:valve
  - nautec:damaged_aquatic_chip
  - nautec:aquatic_chip
---

# <Color id="light_purple">Ancient Machine Parts</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="ancient_valve" scale="2"/>
  해저에서 발견한 파손된 부품입니다. 제작법에 사용하려면 먼저 수리해야 합니다.
</Column>

Gear, Valve, Coil, Chip, Whisk는 해저에서 손상된 상태로 발견되며 종류마다 수리 방법이 다릅니다. 획득 장소는 [Salvage](salvage.md)를 참고하세요. Crystal Geode에 도달한 뒤에는 모든 부품을 직접 제작할 수도 있으므로 운에 의존할 필요가 없습니다. 페이지 아래의 직접 제작 방법을 확인하세요.

| 발견한 부품 | 수리 결과 | 방법 |
|---|---|---|
| <ItemLink id="rusty_gear"/> | <ItemLink id="gear"/> | [Etching](etching.md) |
| <ItemLink id="ancient_valve"/> | <ItemLink id="valve"/> | [Etching](etching.md) |
| <ItemLink id="burnt_coil"/> | Laser Channeling Coil | [Item Transformation](item_transformation.md) at purity 1.5 |
| <ItemLink id="damaged_aquatic_chip"/> | <ItemLink id="aquatic_chip"/> | 조합 |
| Broken Whisk | Whisk | 조합 |

***

<Row>
  <ItemImage id="gear"/>
  ### <Color id="aqua">Gear</Color>
</Row>

Rusty Gear를 Etching Acid에 던져 수리합니다. Gear는 Aquarine Steel Pickaxe·Axe·Shovel, Mixer, Fishing Station, Deep Sea Drain, Augment 2종에 사용됩니다.

***

<Row>
  <ItemImage id="valve"/>
  ### <Color id="aqua">Valve</Color>
</Row>

Ancient Valve를 Etching Acid에 던져 수리합니다. Valve는 Aquarine Steel Chestplate·Leggings, Deep Sea Drain, Thermal Vent Tap, Oxygen Diffuser, Pressure Hatch, Cargo Hold Module, Fusion Port에 사용됩니다.

***

<Row>
  <ItemImage id="burnt_coil"/>
  ### <Color id="aqua">Laser Channeling Coil</Color>
</Row>

Burnt Coil을 순도 1.5의 빔에 10초 동안 노출해 수리합니다. [Item Transformation](item_transformation.md)에 설명된 대로 Prismarine Crystal, Bacterial Fuel Cell 또는 Focusing Lens로 해당 순도에 도달할 수 있습니다. 수리한 Coil은 Aquarine Steel 도구, Charger, Prismatic Battery 등 여러 기계에 사용됩니다.

***

<Row>
  <ItemImage id="aquatic_chip"/>
  ### <Color id="aqua">Aquatic Chip</Color>
</Row>

Damaged Aquatic Chip을 Prismarine Shard와 조합해 수리합니다. Aquatic Chip은 Incubator, Bio Reactor, Bacterial Fuel Cell, Pressure Forge, Resonance Chamber, 대부분의 Sea Scout Module 및 제작형 Augment에 사용됩니다. Bioluminescent Grove의 행운 낚시 구역에서는 완제품을 얻을 때도 있습니다.

<Recipe id="nautec:aquatic_chip"/>

***

## <Color id="gold">Whisk</Color>

Broken Whisk를 Cast Iron Nugget과 조합해 수리합니다. Whisk는 [Mixer](nautec:laser_chemistry/mixer.md)에 필요합니다. Broken Whisk는 Drowned, 바다 유적 상자, 행운 낚시 구역의 보물에서 얻을 수 있습니다.

<Recipe id="nautec:whisk"/>

***

## <Color id="gold">부품 직접 제작하기</Color>

진행 단계에 따라 모든 부품을 확정적으로 제작할 수 있는 경로가 열립니다. 다음 순서대로 진행하세요.

1. **Gear:** Cast Iron Block을 순도 2.5 이상의 빔에 8초간 노출하면 Gear 4개가 됩니다. 순도 2.5는 <ItemLink id="prismarine_crystal"/> 또는 <ItemLink id="bacterial_fuel_cell"/>로만 달성할 수 있습니다. [Item Transformation](item_transformation.md)을 참고하세요.
2. **Valve와 Whisk:** Cast Iron, Gear 또는 Aquarine Steel, Prismarine Crystal Shard를 사용해 제작합니다.
3. Valve와 Whisk가 있으면 [Deep Sea Drain](nautec:laser_chemistry/drain.md)과 [Mixer](nautec:laser_chemistry/mixer.md)를 제작할 수 있습니다.
4. **Burnt Coil:** Mixer에서 Copper Ingot 4개, Redstone 2개, Aquarine Steel Ingot 1개, Prismarine Crystal Shard 1개와 Salt Water 1,000 mB를 혼합합니다. 앞서 설명한 순도 1.5의 빔으로 수리하세요.
5. **Aquatic Chip:** Mixer에서 Gold Ingot 2개, Redstone 4개, Prismarine Crystal Shard 2개, Laser Channeling Coil 1개와 Salt Water 1,000 mB를 혼합하면 완성된 Aquatic Chip 2개를 얻습니다.

Mixer와 빔 제작법은 JEI에서 확인할 수 있습니다.

<Recipe id="nautec:valve_from_cast_iron"/>

<Recipe id="nautec:whisk_from_cast_iron"/>
