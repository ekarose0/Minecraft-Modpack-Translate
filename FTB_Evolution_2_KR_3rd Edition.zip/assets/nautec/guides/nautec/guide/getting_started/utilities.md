---
navigation:
  title: Tools and Utilities
  icon: nautec:aquarine_steel_wrench
  position: 7
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:aquarine_steel_wrench
  - nautec:configuration_card
---

# <Color id="light_purple">Tools and Utilities</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquarine_steel_wrench" scale="2"/>
  Wrench로 NauTec 블록을 설정하거나 회전하고, 호퍼와 파이프가 기계의 어느 면을 사용할지 지정할 수 있습니다.
</Column>

***

<Row>
  <ItemImage id="aquarine_steel_wrench"/>
  ### <Color id="aqua">Aquarine Steel Wrench</Color>
</Row>

Wrench에는 네 가지 모드가 있습니다. 공중을 향해 웅크려 우클릭하면 전환되며, 툴팁과 단축바 위 메시지에 현재 모드가 표시됩니다.

* Rotate: <ItemLink id="aquatic_catalyst"/>, Relay, 기계처럼 방향이 있는 블록을 우클릭하면 다음 방향으로 회전합니다. 계속 클릭하면 한 바퀴를 돌릴 수 있습니다.
* Item Sides / Fluid Sides: 기계의 한 면을 우클릭하여 호퍼와 파이프의 입출력 방식을 바꾸고, 웅크려 우클릭하면 이전 방식으로 돌아갑니다. Item Sides 모드에서는 완성된 Bio Reactor 또는 Industrial Bio Reactor의 아무 블록이나 클릭해 구조물 전체의 해당 면을 설정합니다. 아래의 면별 설정을 참고하세요.
* Link: 레이저 블록 두 개를 두 번의 클릭으로 서로 조준합니다. <ItemLink id="prismarine_laser_relay"/>, <ItemLink id="laser_junction"/>, <ItemLink id="aquatic_catalyst"/>처럼 빔을 보내는 블록을 우클릭하여 시작점으로 저장한 다음, 다른 Relay나 기계처럼 빔을 받을 블록을 우클릭하세요. 시작 블록은 두 번째 블록을 향하도록, 두 번째 블록은 시작점에서 빔을 받도록 회전합니다. Junction은 대신 알맞은 출력 또는 입력 면을 엽니다. 두 블록은 직선상에 있고 빔의 사거리 안에 있어야 하며, 장애물이 있으면 단축바 위 메시지로 알려 줍니다. 연결 후에는 시작점 저장이 해제됩니다. 공중이나 빔을 송수신하지 않는 블록을 우클릭해도 해제됩니다. 저장된 동안에는 툴팁에서 시작점 위치를 볼 수 있습니다. 이 모드에서는 기계 화면을 열지 않고도 Wrench를 사용할 수 있습니다. Relay는 뒷면에서 빔을 받고 앞면으로 내보내므로, 모퉁이를 돌아 다음 블록으로 연결하면 기존 빔을 받던 방향에서 벗어날 수 있습니다. 이 경우 경고가 표시되며, 방향 전환에는 <ItemLink id="laser_junction"/>을 사용하세요.

다음 기능은 모든 모드에서 사용할 수 있습니다.

* 완성되지 않은 Augmentation Station, Bio Reactor, Industrial Bio Reactor, Deep Sea Drain의 컨트롤러를 웅크리지 않고 클릭하면 다중 블록 구조물이 완성됩니다.
* <ItemLink id="gateway"/>를 클릭하면 고리가 형성되고, 완성된 고리를 웅크려 우클릭하면 고리 전체를 아이템 하나로 회수합니다. [Gateway](nautec:deep_engineering/gateway.md)를 참고하세요.
* 직접 재배한 Prismarine Crystal을 웅크려 우클릭하면 결정 전체를 회수합니다. 자연산 결정은 이동할 수 없습니다. [Crystal Cultivation](nautec:deep_engineering/crystal_cultivation.md)을 참고하세요.
* Sea Scout를 우클릭하면 모듈 화면이 열립니다. [Sea Scout](nautec:submarine/submarine.md)를 참고하세요.
* <ItemLink id="laser_junction"/>의 면을 우클릭하면 입력, 웅크려 우클릭하면 출력으로 설정됩니다. 같은 방식으로 다시 클릭하면 꺼집니다.
* 완성된 [Bio Reactor](nautec:aquatic_biology/bio_reactor.md)의 상단 가장자리 블록, [Industrial Bio Reactor](nautec:aquatic_biology/industrial_bio_reactor.md)의 지붕 블록, 또는 [Deep Sea Drain](nautec:laser_chemistry/drain.md)의 중간 벽 바깥쪽 면을 클릭하면 레이저 포트가 열려 빔을 공급할 수 있습니다. Drain에서는 클릭한 면에 정확히 포트가 생기므로 위아래가 아니라 옆면을 클릭하세요. 반응로 포트는 다시 클릭하면 닫힙니다. Item Sides 모드에서는 반응로 면 설정 기능이 우선하므로 포트를 열 수 없습니다.

<Recipe id="nautec:aquarine_wrench"/>

***

## <Color id="gold">면별 입출력 설정</Color>

아이템이나 유체를 저장하는 모든 NauTec 기계는 자동화 장치가 접근할 수 있는 면을 각각 설정할 수 있습니다. 아이템과 유체는 별도로 설정하며 각 면에는 네 가지 모드가 있습니다.

* Insert and Extract(초록색): 호퍼와 파이프가 입력 슬롯에 넣고 출력 슬롯에서 꺼낼 수 있습니다. 모든 면의 기본값입니다.
* Insert(파란색): 넣기만 가능하며 꺼낼 수 없습니다.
* Extract(주황색): 꺼내기만 가능하며 넣을 수 없습니다.
* Off(회색): 해당 면으로는 호퍼와 파이프가 접근할 수 없습니다.

면별 모드와 관계없이 기계는 입력 슬롯에만 재료를 받고 출력 슬롯에서만 결과물을 내보냅니다. 따라서 파이프가 입력 재료를 다시 빼내지는 못합니다.

Wrench의 Item Sides 또는 Fluid Sides 모드로 면을 변경하거나 기계 화면 오른쪽 가장자리의 작은 탭을 클릭하세요. 탭을 열면 앞·뒤·왼쪽·오른쪽·위·아래 여섯 면이 십자 모양으로 표시됩니다. 방향 이름은 기계의 앞면을 기준으로 합니다. 좌클릭은 다음 모드, 우클릭은 이전 모드로 전환합니다. 아이템과 유체를 모두 저장하는 기계에는 위쪽에 Items와 Fluids 버튼이 있습니다. 방향이 없거나 위아래를 향하는 기계는 북쪽을 앞면으로 취급합니다.

Bio Reactor와 Industrial Bio Reactor는 구조물 전체의 각 면에 하나의 아이템 설정을 적용합니다. 화면의 여섯 면은 다중 블록 구조물의 바깥쪽 여섯 면에 대응하며 북쪽이 앞면입니다. Deep Sea Drain과 Fusion Plant 같은 다른 다중 블록은 각 가이드에 설명된 별도 규칙을 사용합니다.

***

<Row>
  <ItemImage id="configuration_card"/>
  ### <Color id="aqua">Configuration Card</Color>
</Row>

한 블록의 설정을 다른 블록으로 복사합니다. 기계를 웅크려 우클릭하면 설정이 카드에 복사되고, 다른 블록을 우클릭하면 붙여넣습니다. 공중을 웅크려 우클릭하면 카드가 초기화됩니다. 툴팁에는 설정을 복사한 블록과 복사 범위가 표시됩니다. 카드를 들고 우클릭하면 원래 화면이 열리는 블록에서도 항상 설정을 붙여넣습니다.

* 면별 입출력 설정은 같은 기능이 있는 모든 기계에 붙여넣을 수 있습니다. 따라서 카드 하나로 서로 다른 기계 여러 대의 입출력 방향을 똑같이 설정할 수 있습니다.
* 블록 고유 설정은 같은 종류의 블록에만 붙여넣을 수 있습니다.
  * <ItemLink id="confined_spawner"/>의 필터와 Whitelist 모드
  * <ItemLink id="resonance_node"/>의 네트워크, 입출력 모드, 우선순위, 제한값, 청크 로딩
  * <ItemLink id="uplink_array"/>의 네트워크와 청크 로딩
  * <ItemLink id="laser_junction"/>의 입력·출력 면
  * Conduit Tap의 면별 설정
  * <ItemLink id="laser_purification_smelter"/>의 자동 분배 설정
* 업그레이드와 필터도 같은 종류의 블록끼리 복사할 수 있습니다. Conduit Tap의 업그레이드와 필터, <ItemLink id="energy_converter"/>의 업그레이드, Bio Reactor의 업그레이드, Laser Purification Smelter의 Conduit 업그레이드가 해당합니다. 붙여넣을 때 플레이어 인벤토리에서 필요한 아이템을 가져오고 대상 슬롯의 기존 아이템을 돌려줍니다. 필요한 아이템이 부족하면 아무것도 적용하지 않으며 카드에 부족한 항목이 표시됩니다.

Resonance Network를 붙여넣을 때는 화면에서 직접 선택할 때와 동일하게 사용 권한을 검사합니다.

<Recipe id="nautec:configuration_card"/>
