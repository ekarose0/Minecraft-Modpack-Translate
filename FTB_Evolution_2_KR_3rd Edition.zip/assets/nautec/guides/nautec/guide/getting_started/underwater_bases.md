---
navigation:
  title: Underwater Bases
  icon: nautec:pressure_hatch
  position: 18
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:pressure_hatch
  - nautec:oxygen_diffuser
---

# <Color id="light_purple">Underwater Bases</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="pressure_hatch" scale="2"/>
  해저에 물이 없는 영구 기지를 만들기 위한 블록들입니다.
</Column>

먼저 [Bubble Anchor](bubble_anchor.md)로 공간의 물을 제거하고 벽으로 둘러싼 뒤, 작동이 끝나도 공기가 남도록 Anchor를 설정하세요. 이후에는 이 블록들이 실내를 건조하게 유지해 줍니다.

***

## <Color id="gold">Pressure Hatch</Color>

작은 창이 달린 높이 2블록짜리 강철 문입니다. 직접 열고 닫거나 레드스톤으로 조작할 수 있습니다.

* 문이 열려 있든 닫혀 있든 바닷물이 통과하지 않습니다. 따라서 열린 해치를 통해 헤엄쳐 들어와도 뒤쪽 방은 물이 없는 상태로 유지됩니다.
* 문이 닫힐 때마다 양쪽의 작은 물웅덩이를 배수합니다. 몸에 묻어 들어온 물, 물에 잠긴 출입구, 누수로 생긴 물 등을 한 번에 연결된 물 블록 최대 64개까지 제거합니다.
* 바다와 연결된 물이나 64블록보다 큰 침수 공간은 배수하지 않으므로 해치를 닫아도 바깥 바다가 사라지지 않습니다.

물속에 해치를 설치하면 해치가 차지하는 두 블록의 물이 제거되므로 침수된 출입구에도 바로 설치할 수 있습니다.

<RecipeFor id="pressure_hatch"/>

***

## <Color id="gold">Oxygen Diffuser</Color>

<ItemImage id="oxygen_diffuser" scale="2"/>

12블록 이내의 모든 플레이어에게 Water Breathing 효과를 주고 공기 게이지를 가득 유지합니다. 따라서 헬멧 없이도 기지 주변의 물속에서 작업할 수 있습니다.

* 어느 면으로든 최소 10 AP의 레이저 빔을 공급해야 합니다. 순도는 상관없어 초반의 약한 빔으로도 작동합니다.
* 빔이 유지되는 동안 매초 효과를 갱신합니다. 범위를 벗어나면 몇 초 후 효과가 사라집니다.
* 물속에도 설치할 수 있으며, 작동 중에는 윗부분에서 기포가 올라옵니다.
* 빔이 잠시 끊겨도 2초 동안 계속 작동한 뒤 멈춥니다.

효과 범위와 전력 관련 설정은 `config/nautec-common.toml`에서 변경할 수 있습니다.

<RecipeFor id="oxygen_diffuser"/>
