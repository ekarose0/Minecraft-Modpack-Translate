---
navigation:
  title: Eye of the Sea
  icon: nautec:eye_of_the_sea
  position: 15
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:eye_of_the_sea
---

# <Color id="light_purple">Eye of the Sea</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="eye_of_the_sea" scale="2"/>
  소모되지 않는 바다용 Eye of Ender입니다. 던지면 설정한 목표에 해당하는 가장 가까운 구조물로 날아갑니다.
</Column>

***

## <Color id="gold">사용 방법</Color>

우클릭하면 Eye를 던집니다. 잠시 소리를 내며 목표를 탐색하고(단축바 위에 메시지가 표시되며 탐색이 끝날 때까지 다시 던질 수 없습니다), 이후 Eye of Ender처럼 떠올라 가장 가까운 목표 구조물 쪽으로 날아갑니다. 약 4초 후 거품으로 사라지지만 아이템이 떨어지거나 소모되지는 않습니다. 던질 때마다 2초의 대기시간만 지나면 반복해서 사용할 수 있습니다.

약 1,600블록 이내(바이옴은 3,200블록 이내)에 목표가 없으면 Eye가 손에 남아 있으며 관련 메시지가 표시됩니다.

Crystal Geode는 해저 지면 아래에 묻혀 있습니다. Eye가 원을 그리거나 내려가기 시작하면 바로 아래에 지오드 중심부가 있다는 뜻이므로 그 지점에서 아래로 파 내려가세요.

***

## <Color id="gold">탐색 목표 변경</Color>

웅크린 채 우클릭하면 탐색 목표를 바꿀 수 있습니다. 현재 목표는 툴팁과 단축바 위 메시지에 표시됩니다. 목표 순서는 다음과 같습니다.

| 목표 | 탐색 대상 |
|---|---|
| Crystal Geodes | <ItemLink id="prismarine_crystal"/>이 들어 있는 돌·심층암 지오드 |
| NauTec Ruins | <ItemLink id="aquatic_catalyst"/>가 있는 어두운 프리즈머린 아치 |
| Research Outposts | 침몰한 연구 기지([Structures](structures.md) 참조) |
| Gateways | 수중 Gateway 플랫폼([Gateway](nautec:deep_engineering/gateway.md) 참조) |
| Ocean Ruins | 바닐라의 차가운 바다·따뜻한 바다 유적 |
| Ocean Monuments | 바닐라 해저 유적(해저 신전) |
| Prismarine Reefs | <ItemLink id="budding_prismarine"/>을 찾기 좋은 가장 가까운 Prismarine Reef 바이옴 |
| Abyssal Trenches | 가장 가까운 Abyssal Trench 바이옴 |
| Bioluminescent Groves | 가장 가까운 Bioluminescent Grove 바이옴 |
| Hydrothermal Vents | 가장 가까운 Hydrothermal Vents 바이옴 |

새 Eye의 기본 목표는 Crystal Geodes이며, 각 Eye는 개별적으로 설정한 목표를 기억합니다. 플레이어가 직접 건설한 Gateway는 탐색 대상이 아닙니다. 바이옴을 목표로 설정하면 가장 가까운 해당 바이옴의 가장자리로 날아갑니다. 각 구조물의 내용물은 [Structures](structures.md)를 참고하세요.

***

## <Color id="gold">바다에서의 행운</Color>

목표를 찾는 데 성공한 투척은 주변 물에도 영향을 줍니다. 이후 5분 동안 주변에 [행운 낚시 구역](fishing.md)이 생성될 확률이 2배가 됩니다. 다시 던지면 5분 지속시간이 갱신됩니다.

***

## <Color id="gold">제작법</Color>

Ender Pearl 1개와 Prismarine Shard 1개를 배치와 관계없이 조합하면 됩니다.

<Recipe id="nautec:eye_of_the_sea"/>

탐색 범위, 투척 대기시간, 낚시 보너스의 지속시간과 효과는 `config/nautec-common.toml`에서 설정할 수 있습니다.
