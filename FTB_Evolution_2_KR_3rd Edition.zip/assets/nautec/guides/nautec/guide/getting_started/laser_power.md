---
navigation:
  title: Laser Power
  icon: nautec:aquatic_catalyst
  position: 1
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:aquatic_catalyst
  - nautec:advanced_aquatic_catalyst
  - nautec:prismarine_crystal
---

# <Color id="light_purple">Laser Power</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquatic_catalyst" scale="2"/>
  Aquatic Catalyst는 Prismarine을 연료로 태워 레이저 빔을 발사합니다.
</Column>

NauTec 기계는 틱당 AP(AP/t)로 측정하는 레이저 전력으로 작동합니다. 빔에는 전력과 순도라는 두 수치가 있습니다. 기계는 전력을 사용해 작동하며 제작법은 시작 전에 순도를 검사합니다.

빔은 두 레이저 블록 사이에서만 형성됩니다. 발사 블록의 해당 방향에 빔을 받는 기계·Relay·Junction·렌즈 등이 있어야 하고, 거리는 최대 16블록(`config/nautec-common.toml`의 `laserDistance`) 또는 Relay에서 최대 64블록이며 사이에 단단한 블록이 없어야 합니다. 빔은 물과 유리를 통과하므로 유리로 둘러쌀 수 있습니다.

***

<Row>
  <ItemImage id="aquatic_catalyst"/>
  ### <Color id="aqua">Aquatic Catalyst</Color>
</Row>

첫 전력 공급원입니다. Prismarine 아이템을 하나씩 태워 한 면으로 빔을 발사합니다.

<Recipe id="nautec:aquatic_catalyst"/>

Catalyst를 연료 묶음으로 우클릭하거나 호퍼로 공급하세요. 빈손으로 우클릭하면 아직 태우기 시작하지 않은 연료를 회수할 수 있습니다.

| 연료 | 순도 | 전력 | 연소 시간 |
|---|---|---|---|
| Prismarine Shard | 0.4 | 12 AP/t | 30 s |
| Prismarine Crystals | 0.8 | 6 AP/t | 30 s |
| <ItemLink id="prismarine_crystal_shard"/> | 1.2 | 20 AP/t | 75 s |

설치할 때 바라보는 면이 연한 색의 입력부이며 연료를 넣으면 채워지는 소켓 8개가 있습니다. 반대편의 어두운 청록색 렌즈에서 빔이 발사됩니다. 아래를 보며 설치하면 아래로, 위를 보며 설치하면 위로 발사합니다. 설치 후에는 <ItemLink id="aquarine_steel_wrench"/>로 회전시킬 수 있습니다.

Catalyst는 발사 방향에 수신기가 있을 때만 연료를 태웁니다. 대상이 없으면 연료를 보존하며 대기하므로 낭비되지 않습니다. 연료 하나를 다 태우면 다음 연료로 바로 넘어가 묶음이 남아 있는 동안 빔이 계속 나옵니다. Shard 64개는 32분 동안 작동합니다.

레드스톤 신호를 주면 일시 정지합니다. 정지 중에는 빔을 발사하지 않으며 연료와 현재 연소 진행도를 유지합니다. 신호가 끊기면 이어서 작동합니다.

렌즈 면을 제외한 면에 <ItemLink id="budding_prismarine"/>을 붙이면 Catalyst가 강화됩니다. 블록 하나당 전력이 25%, 순도가 0.1 증가하며 순도 상한은 2.0입니다(`catalystBuddingOutputBonus`, `catalystBuddingPurityBonus`, `catalystBuddingMaxPurity`). 강화에 사용한 Budding Prismarine에서는 아무것도 자라지 않습니다. Catalyst가 1초마다 Prismarine Cluster를 파괴하며 아이템도 떨어지지 않습니다.

렌즈 근처 양옆의 작은 표시등 2개는 수신기 발견 여부를 보여 줍니다. 초록색은 사거리 내 레이저 블록이 빔을 받는다는 뜻입니다. 빨간색은 렌즈 앞에 대상이 없거나 단단한 블록이 막고 있거나, 앞쪽 블록이 해당 면에서 빔을 받지 못한다는 뜻입니다(주로 Relay 방향 오류). 빈손으로 Shift+우클릭하면 연료, 발사 방향, 빔이 닿는 대상, 해결 방법이 채팅에 표시됩니다.

<Color id="gold">팁</Color>: 작동 중인 빔은 플레이어를 포함해 닿는 대상에게 화상 피해를 줍니다. 빔이 강할수록 피해가 커집니다([레이저 전력 전달](nautec:laser_chemistry/laser_manipulation.md) 참고). 빔을 피해 이동하거나 유리 안으로 통과시키세요.

***

<Row>
  <ItemImage id="advanced_aquatic_catalyst"/>
  ### <Color id="aqua">Advanced Aquatic Catalyst</Color>
</Row>

금색 테두리의 강화형 Aquatic Catalyst로, 연료 8개를 한 번에 태웁니다. 연소 시간은 일반 Catalyst에서 연료 하나를 태우는 시간과 같지만 빔 전력은 8배입니다. 따라서 Prismarine Crystal Shard 묶음은 20 대신 160 AP/t를 생산하며 8배 빨리 소모됩니다. 연료 하나당 총 에너지는 같지만 더 빨리 얻는 것입니다.

<Recipe id="nautec:advanced_aquatic_catalyst"/>

| 연료 | 순도 | 전력 | 연소 시간 |
|---|---|---|---|
| Prismarine Shard | 0.44 | 96 AP/t | 30 s |
| Prismarine Crystals | 0.88 | 48 AP/t | 30 s |
| <ItemLink id="prismarine_crystal_shard"/> | 1.32 | 160 AP/t | 75 s |

같은 연료를 사용하는 일반 Aquatic Catalyst보다 Budding Prismarine 보너스 적용 전에 빔 순도가 10% 높습니다. 연료가 8개 미만이면 있는 수량만 태우고 전력도 그 수량에 비례합니다. 설치, 표시등, 레드스톤 정지, Budding Prismarine, Shift+우클릭 정보 확인 등 나머지는 일반 Catalyst와 같습니다. `advancedCatalystFuelMultiplier`와 `advancedCatalystPurityMultiplier`에서 8배와 10%를 설정합니다.

***

## <Color id="gold">순도</Color>

순도는 빔이 시작되는 곳에서 정해집니다. Catalyst 빔은 연료에 따라 순도 0.4~1.2에 Budding Prismarine 보너스가 더해집니다. 여러 빔이 같은 블록에 공급되면 전력은 합산되고 순도는 가장 높은 빔에 가까워집니다. 최종 순도는 최고 순도에서 최고 순도와 전체 평균 순도의 차이 중 1/4을 뺀 값입니다(`beamMergePurityDrop`). 따라서 순도 3.0과 0의 빔을 합치면 약 2.6이 됩니다.

더 높은 순도는 <ItemLink id="prismarine_crystal"/>(자연산 3.0, 재배 직후 3.00~6.00, 강화 시 최대 12), <ItemLink id="bacterial_fuel_cell"/>(최대 2.5), 또는 기존 빔에 추가하는 <ItemLink id="focusing_lens"/>에서 얻을 수 있습니다. 빔의 방향 전환, 분할, 집중은 [Beam Optics](nautec:deep_engineering/beam_optics.md)를 참고하세요.

***

<Row>
  <ItemImage id="prismarine_crystal"/>
  ### <Color id="aqua">Prismarine Crystal</Color>
</Row>

해저의 Crystal Geode 안에서 발견되는 높이 6블록의 결정입니다([구조물](structures.md) 참고). 모든 빔을 순도 3.0으로 바꿉니다. 자연산 결정은 제자리에 고정되지만 재배한 결정은 이동할 수 있고 성장 완료 시 순도 3.00~6.00이 정해집니다([결정 재배](nautec:deep_engineering/crystal_cultivation.md) 참고). 이후 [Bacterial Enrichment Catalyst](nautec:deep_engineering/bacterial_enrichment_catalyst.md)로 최대 12까지 높일 수 있습니다.

결정의 옆면에 빔을 조사하세요. 높이 6블록 중 어느 부분이든 네 옆면으로 빔을 받으며 여러 공급원의 전력이 합산됩니다. 맨 위 블록은 위로, 맨 아래 블록은 아래로 결정의 순도에 맞는 빔을 발사합니다. 자연산은 순도 3.0이고 재배 결정은 성장 완료 시 정해진 순도를 사용합니다. 한쪽 빔만 수신기에 닿으면 입력 전력을 모두 전달하며, 양쪽이 모두 닿으면 전력을 절반씩 나눕니다. 따라서 출력 AP의 합은 입력보다 커지지 않습니다. 두 빔은 수신기나 단단한 블록을 만날 때까지 진행하므로 빈 바닥이나 천장 방향으로도 사용할 수 있습니다.

자연산 결정은 생성된 곳에 고정되어 있으므로 주변에 시설을 건설하세요. 능력을 활성화한 Aquarine Steel Pickaxe로 채굴하면 [Prismarine Crystal Shards](nautec:laser_chemistry/crystal_shards.md)를 떼어낼 수 있지만, 타격할 때마다 결정 전체가 산산조각 날 확률이 있습니다.

***

## <Color id="gold">전력 전달</Color>

* [Laser Manipulation](nautec:laser_chemistry/laser_manipulation.md): Prismarine Laser Relay는 빔을 전달하고 Laser Junction은 빔을 합치거나 나눕니다.
* [Beam Optics](nautec:deep_engineering/beam_optics.md): Focusing Lens로 순도를 높입니다.
* [Charger](nautec:laser_chemistry/charger.md)와 [Prismatic Battery](nautec:laser_chemistry/prismatic_battery.md): 아이템에 전력을 저장합니다.

<ItemLink id="prism_monocle"/>를 착용하면 모든 레이저 블록에 공급되는 전력과 순도를 확인할 수 있습니다.

***

## <Color id="gold">강한 빔</Color>

기계에 표시된 AP는 소비량이 아니라 최소 작동 기준입니다. 그보다 강한 빔은 낭비되지 않습니다. 대부분의 기계는 √(빔 전력 ÷ 필요 전력)에 비례해 빨라지므로 전력이 4배면 속도가 2배입니다. 자세한 공식과 기계 목록은 [강한 빔](nautec:getting_started/stronger_beams.md)을 참고하세요.
