---
navigation:
  title: 해양 발전기
  icon: nautec:tidal_rotor
  position: 16
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:tidal_rotor
  - nautec:thermal_vent_tap
---

# <Color id="light_purple">해양 발전기</Color>

<Column alignItems="center" fullWidth={true}>
  <Row>
    <ItemImage id="tidal_rotor" scale="2"/>
    <ItemImage id="thermal_vent_tap" scale="2"/>
  </Row>
  바다의 에너지를 다른 모드의 기계가 사용하는 Forge Energy(FE)로 변환하는 발전기입니다.
</Column>

NauTec에는 FE 발전기 4종이 있습니다. Tidal Rotor는 바다 자체를 이용하고, Thermal Vent Tap은 해저의 열로 Salt Water를 끓입니다. [Combustion Dynamo](nautec:getting_started/combustion_dynamo.md)는 박테리아로 생산한 Oil을 연소하며, [Fusion Plant](nautec:deep_engineering/fusion_plant.md)는 후반부에 사용하는 원자로입니다. 모든 발전기는 맞닿은 케이블이나 기계에 FE를 공급합니다.

***

<Row>
  <ItemImage id="tidal_rotor"/>
  ### <Color id="aqua">Tidal Rotor</Color>
</Row>

초반에 사용하는 주철 터빈으로, 연료 없이 40~80 FE/t를 생산합니다.

바다 바이옴의 물속에 설치하세요. 최소 조건에서는 40 FE/t를 생산하고 주변 물이 넓고 깊을수록 발전량이 늘어납니다. 모든 방향이 물이고 위쪽으로 물이 24블록 쌓여 있으면 80 FE/t에 도달합니다. 해저에 파묻거나 다른 Rotor와 밀착하면 출력이 떨어지므로 겹쳐 쌓기보다 해저에 간격을 두고 배치하세요.

***

<Row>
  <ItemImage id="thermal_vent_tap"/>
  ### <Color id="aqua">Thermal Vent Tap</Color>
</Row>

마그마나 용암의 열로 Salt Water를 끓여 350~1,250 FE/t를 생산하는 중반부 발전기입니다.

* **열원:** 바로 아래 3×3 범위의 9개 블록에서 Magma Block이나 용암을 검사합니다. 열원 1개면 350 FE/t, 9개면 1,250 FE/t를 생산합니다. 열수 분출 지대의 <ItemLink id="hydrothermal_vent"/> 하나는 열원 3개로 계산됩니다. Hydrothermal Vents 바이옴에서는 열원이 하나 이상 있을 때 해저 지형이 열원 3개를 추가로 제공한 것으로 계산됩니다.
* **연료:** 어느 면으로든 Salt Water를 파이프로 공급하세요. 작동 중에는 틱당 10 mB를 끓이므로 [Deep Sea Drain](nautec:laser_chemistry/drain.md) 하나로 발전기 두 대를 가동하고도 조금 남습니다.
* **소금:** Salt Water를 1,000 mB 끓일 때마다 <ItemLink id="salt"/> 1개가 생성됩니다. 맞닿은 상자나 인벤토리로 자동 배출되며, 어느 면에서든 파이프나 호퍼로 추출할 수 있습니다. 보관 슬롯이 가득 차면 소금 생산만 멈추고 발전은 계속됩니다.

Jade에서 각 발전기의 출력과 부족한 작동 조건을 확인할 수 있습니다.

<RecipeFor id="tidal_rotor"/>

<RecipeFor id="thermal_vent_tap"/>
