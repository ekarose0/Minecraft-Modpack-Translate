---
navigation:
  title: 소개
  icon: nautec:prismarine_sand
  position: 0
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:prismarine_sand
---

# <Color id="light_purple">소개</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="prismarine_sand" scale="2"/>
  NauTec 2는 레이저 빔으로 기계를 작동시키는 해양 기술 모드입니다.
</Column>

NauTec 기계는 한 블록에서 다른 블록으로 발사되는 레이저 동력(AP)으로 작동합니다. 빔에는 순도 수치도 있으며, 고급 제작법일수록 높은 순도가 필요합니다. 모든 과정은 프리즈머린에서 시작됩니다. 초반 재료 대부분은 해저의 유적, 묻힌 지오드, Crate 및 그 안의 부품에서 얻습니다.

***

## <Color id="gold">시작하기</Color>

* 프리즈머린을 모으세요. 해변과 해저의 <ItemLink id="prismarine_sand"/>를 파서 Prismarine Shard와 Prismarine Crystal을 얻을 수 있습니다.
* <ItemLink id="aquatic_catalyst"/>를 만들고 첫 빔을 발사하세요: [Laser Power](laser_power.md).
* 빔에 Aquarine Steel Compound를 떨어뜨려 많은 제작법에 사용되는 Aquarine Steel을 만드세요: [Item Transformation](item_transformation.md).
* 해저를 탐험하며 [Structures](structures.md)와 [Salvage](salvage.md)를 찾고, 충분히 오래 잠수해 전리품을 회수할 수 있도록 [Diving Suit](diving_gear.md)를 제작하세요.
* 녹슬어 잠긴 Crate를 세척할 Etching Acid를 만드세요: [상자와 에칭](etching.md).

이후 가이드는 액체·도구·추가 빔 블록을 다루는 [Laser Chemistry](nautec:laser_chemistry/laser_chemistry-index.md), 박테리아를 다루는 [Aquatic Biology](nautec:aquatic_biology/aquatic_biology-index.md), 고순도 작업을 다루는 [Deep Engineering](nautec:deep_engineering/deep_engineering-index.md), 신체 증강을 다루는 [Laser Augmentation](nautec:laser_augmentation/laser_augmentation-index.md), Sea Scout와 Wave Jet를 다루는 [Naval](nautec:submarine/submarine-index.md)로 나뉩니다.

***

<Row>
  <ItemImage id="prismarine_sand"/>
  ### <Color id="aqua">Prismarine Sand</Color>
</Row>

모든 바다의 해변과 해저에 흩어져 있는 모래처럼 낙하하는 블록입니다. 파내면 Prismarine Shard 2~4개, Prismarine Crystal 2~4개와 약간의 경험치를 얻습니다. Fortune을 적용하면 Shard가 추가로 나오고, Silk Touch를 사용하면 블록 자체를 얻습니다.

초반에 Prismarine Shard와 Prismarine Crystal을 가장 쉽게 구할 수 있는 곳이며, 두 재료 모두 Aquatic Catalyst의 연료로 사용됩니다.

***

## <Color id="gold">이 가이드북</Color>

월드에 처음 접속하면 NauTec 2 Guide를 받습니다(`config/nautec-common.toml`의 `spawnBookInInventory`로 비활성화 가능). NauTec 아이템에 마우스를 올린 상태에서 GuideMe 가이드 키를 누르면 해당 페이지가 열립니다.
