---
navigation:
  title: Prism Monocle
  icon: nautec:prism_monocle
  position: 9
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:prism_monocle
---

# <Color id="light_purple">Prism Monocle</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="prism_monocle" scale="2"/>
  바라보고 있는 NauTec 블록의 상태 정보를 표시합니다.
</Column>

Monocle을 투구 슬롯 또는 Curios의 전용 Monocle 슬롯에 장착하세요. 장착한 상태에서 NauTec 기계나 레이저 블록을 바라보면 화면 중앙에 상태 정보가 표시됩니다. Diving Helmet과 마찬가지로 수중 안개도 제거합니다.

<Recipe id="nautec:prism_monocle"/>

***

## <Color id="gold">표시 정보</Color>

| 블록 | 표시 정보 |
|---|---|
| 모든 기계, Relay, Optic 및 기타 레이저 블록 | 공급되는 동력(틱당 AP)과 순도 |
| <ItemLink id="aquatic_catalyst"/> | Duration: 현재 연료가 연소한 틱 수 |
| <ItemLink id="bacterial_fuel_cell"/> | 출력(틱당 AP), 순도, 연료 또는 군체 없음 |
| <ItemLink id="pressure_forge"/> | 장착된 Synthesizer, 압력 상태, Acid(mB), 순도 또는 부족한 수심·물 조건 |
| <ItemLink id="resonance_chamber"/> | 충전량, 상한, 순도 또는 냉각 중 Cracked 상태 |
| <ItemLink id="gateway"/>와 고리 | 주소, 개방·준비·대기·동력 부족·레드스톤 차단·막힘 상태, 자연 생성 고리 여부, 저장 동력 |
| <ItemLink id="submarine_dock"/> | Sea Scout 정박 여부 |
| Deep Sea Drain 벽면 | 동력과 저장 액체 |
| <ItemLink id="bubble_anchor"/> | 작동 상태, 효과 범위, 남은 연료 또는 종료 조건 |
| <ItemLink id="oxygen_diffuser"/> | 작동 범위 또는 필요한 AP |
| <ItemLink id="energy_converter"/> | 송신 AP, 공유하는 빔 수, 소모 FE/t 또는 대기 이유 |
| <ItemLink id="grafting_station"/>와 <ItemLink id="advanced_bacterial_analyzer"/> | 상태, 동력, 순도 |
| <ItemLink id="colony_replicator"/> | 상태, Replicate/Splice 모드, Biomass |
| <ItemLink id="uplink_array"/> | 작동 상태 |

제작법에 문제가 있다고 판단하기 전에 빔이 제대로 도착하는지, 순도가 충분한지 확인하세요. 순도가 낮은 빔과 높은 빔이 같은 블록에 공급되면 순도가 조금 떨어집니다.

Charm 슬롯에 장착하는 <ItemLink id="resonance_charm"/>도 같은 기능을 제공하므로 둘 다 필요하지는 않습니다. [Resonance Network](nautec:deep_engineering/resonance_network.md)를 참고하세요.

***

## <Color id="gold">Jade와 함께 사용</Color>

Jade가 설치되어 있으면 일부 블록에 추가 툴팁이 표시됩니다. Aquatic Catalyst의 상태, 대기 중인 연료, 남은 틱, 틱당 AP, 빔의 도달 대상뿐 아니라 Mixer, Laser Junction, Deep Sea Drain, Confined Spawner, Crystal Cradle, Prismarine Crystal, Fusion Plant Controller, Tidal Rotor, Thermal Vent Tap, Energy Converter의 정보도 확인할 수 있습니다.
