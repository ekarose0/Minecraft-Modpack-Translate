---
navigation:
  title: Bubble Anchor
  icon: nautec:bubble_anchor
  position: 17
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:bubble_anchor
  - nautec:bubble_capsule
---

# <Color id="light_purple">Bubble Anchor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="bubble_anchor" scale="2"/>
  15 x 15 x 15 크기의 정육면체 영역에서 바닷물을 밀어내 물 없이 건축할 수 있게 합니다.
</Column>

Anchor를 설치하고 연료를 넣으면 주변 정육면체 영역의 물을 밀어냅니다. 내부에서는 바다가 없는 것처럼 걷고, 채굴하고, 건축할 수 있습니다. 영역 밖의 물은 들어오지 않으며, 희미한 거품 고리가 경계를 표시합니다.

영역 안의 Kelp, Seagrass, 거품 기둥이 제거되고 물에 잠긴 블록의 물도 빠집니다. 영역 안에 블록을 설치하면 밀려난 물이 있던 공간을 차지합니다.

***

## <Color id="gold">연료</Color>

연료 슬롯에 연료를 넣습니다. 호퍼나 파이프로도 공급할 수 있습니다.

| 연료 | 지속시간 |
|---|---|
| Dried Kelp Block | 2분 |
| Sea Pickle | 30초 |
| Dried Kelp | 12초 |
| Kelp | 6초 |

연료가 완전히 소진되기 10초 전에 경고가 표시됩니다. 슬롯 옆 막대에서 남은 연료를 확인할 수 있습니다.

***

## <Color id="gold">영역이 해제될 때</Color>

연료가 떨어지거나 장치를 끄거나 Anchor를 파괴하면 영역이 해제됩니다. 연료 소진 또는 전원 차단 시 물이 가장자리부터 안쪽으로 돌아옵니다. Anchor를 부수면 모든 물이 한꺼번에 돌아옵니다.

**Ends as** 버튼으로 영역 해제 후 빈 공간을 어떻게 처리할지 선택합니다.

* Water: 건축하지 않은 공간에 바닷물이 다시 차오릅니다. 설치한 블록은 그대로 유지됩니다.
* Air: 빈 공간을 공기로 유지합니다. 방을 벽으로 완전히 막은 뒤 사용하면 계속 건조한 상태를 유지할 수 있습니다. 외부로 열려 있다면 바닷물이 자연스럽게 다시 흘러듭니다.

**Cube** 버튼은 영역의 위치를 정합니다. Centred는 Anchor를 중심에 배치하고, On top은 Anchor 위쪽에 영역을 형성하므로 해저 바닥에 설치했을 때 위쪽 물을 제거할 수 있습니다.

***

## <Color id="gold">레이저 동력</Color>

어느 면으로든 20 AP 이상의 레이저 빔을 공급하면 연료 없이 작동합니다. 빔이 끊긴 뒤에도 2초간 유지됩니다. 빔 순도가 높을수록 영역이 넓어집니다.

| 순도 | 영역 크기 |
|---|---|
| 1.5 미만 | 15 x 15 x 15 |
| 1.5 | 17 x 17 x 17 |
| 2.0 | 21 x 21 x 21 |
| 2.5 | 25 x 25 x 25 |

이를 활용하면 대규모 수중 건축을 위한 영구적인 건식 작업장을 만들 수 있습니다. [Prismarine Crystal](laser_power.md) 빔으로 최대 크기에 도달할 수 있습니다.

영역 크기, 빔 출력, 연료 지속시간, 작동 속도는 `config/nautec-common.toml`에서 설정할 수 있습니다.

<RecipeFor id="bubble_anchor"/>

***

## <Color id="gold">Bubble Capsule</Color>

<Row>
  <ItemImage id="bubble_capsule"/>
  ### <Color id="aqua">산소가 부족할 때</Color>
</Row>

비상시에 사용하는 일회용 공기 주머니입니다. 머리가 물속에 있을 때 사용하면 머리 주변 5 x 5 x 5 영역의 물을 30초간 밀어내고 산소 게이지를 즉시 채웁니다.

작은 Anchor 영역처럼 외부의 물이 들어오지 않으며, 영역이 끝나도 설치한 블록은 남습니다. 종료 5초 전에 경고가 표시되고, 종료되면 비워 둔 공간에 물이 다시 차오릅니다. 사용 당시 머리가 있던 위치에 블록을 설치하면 영역이 조기에 종료됩니다.

영역 크기와 지속시간은 `config/nautec-common.toml`에서 설정할 수 있습니다.

<RecipeFor id="bubble_capsule"/>
