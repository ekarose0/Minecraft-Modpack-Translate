---
navigation:
  title: The Deep Oceans
  icon: nautec:luminescent_algae
  position: 11
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:hydrothermal_vent
---

# <Color id="light_purple">The Deep Oceans</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="luminescent_algae" scale="2"/>
  NauTec는 고유한 식물과 생물이 서식하는 바다 바이옴 4종을 추가합니다.
</Column>

새 바이옴은 기존 바닐라 바다를 대체하지 않고 추가됩니다. 아직 생성되지 않은 청크에만 나타나므로 기존 월드에서는 탐험한 지역의 바깥에서 찾을 수 있습니다.

네 바이옴 모두 바다로 취급됩니다. [Deep Sea Drain](nautec:laser_chemistry/drain.md), 행운 낚시 구역, NauTec 구조물, 바닐라 Ocean Ruin 및 Shipwreck이 정상 작동합니다. 모드팩에서 `config/nautec-common.toml`의 `collectSaltWater`를 활성화하면 양동이로 Salt Water를 채집할 수도 있습니다.

NauTec는 바다를 바닐라보다 깊게 만들기도 합니다. Tectonic이 설치되어 있으면 수심은 Tectonic의 설정을 따릅니다.

| 바이옴 | 생성 환경 | 시야 거리 |
|---|---|---|
| Abyssal Trench | 육지에서 먼 한랭 지역 | 약 20블록 |
| Bioluminescent Grove | 온대 기후의 깊은 바다 | 약 130블록 |
| Hydrothermal Vents | 온난 기후의 깊은 바다 | 약 50블록 |
| Prismarine Reef | 온대~고온 기후 해안의 얕은 바다 | 약 145블록 |

***

## <Color id="gold">Abyssal Trench</Color>

네 바이옴 중 가장 깊고 어두운 곳으로, 거의 검은 물속에 작은 입자들이 떠다닙니다.

* 다른 바다보다 Drowned가 훨씬 자주 생성되며 y 40 아래의 어둠에서는 Abyssal Maw가 사냥합니다.
* 바닥에 Abyssal Coral이 자라고 Silt Skipper, Cod, Squid, Glow Squid가 서식합니다.
* 해저 지면의 윗부분에 <ItemLink id="budding_prismarine"/>이 생성됩니다. 희미한 빛을 찾아보세요.
* 충분한 수심과 위쪽의 물기둥이 필요한 [Abyssal Pressure Forge](nautec:deep_engineering/pressure_forge.md)를 설치하기에 가장 좋은 장소입니다.

***

## <Color id="gold">Bioluminescent Grove</Color>

맑은 청록색 물속에 빛나는 포자가 떠다닙니다.

* 바닥에 Deep Kelp, Luminescent Algae, Seagrass, Sea Pickle이 자라고 바닥·벽·천장의 돌에는 Glow Polyp이 퍼집니다.
* Lantern Jelly, Silt Skipper, 평소보다 많은 Glow Squid가 서식합니다.
* Trench와 마찬가지로 해저 지면의 윗부분에 Budding Prismarine이 생성됩니다.

### Glow Grotto

Grove 해저 아래에 형성된 침수 동굴로, 해저에서 아래로 이어지는 좁은 통로를 통해 들어갑니다. 벽에는 Glow Polyp이 덮여 있고 바닥의 Luminescent Algae와 Sea Pickle이 빛을 내므로 입구 통로에서도 발견할 수 있습니다.

* 동굴 바닥마다 <ItemLink id="budding_prismarine"/> 1개가 있으며 이미 Prismarine Cluster가 자라 있는 경우가 많습니다.
* 약 1/3 확률로 바닥에 부품이 든 <ItemLink id="rusty_crate"/>가 있습니다.
* 건조한 동굴과 연결되지 않으므로 항상 물로 가득 차 있습니다.

***

## <Color id="gold">Hydrothermal Vents</Color>

Basalt와 Magma가 군데군데 깔린 바닥 위로 탁한 갈색 물이 흐르고 거품이 끊임없이 올라옵니다.

* 바닥에 Vent Tubeworm이 자랍니다.
* 바닥을 돌아다니는 Vent Crawler가 Chitin Plate를 떨어뜨립니다.
* 노출된 Magma가 거품 기둥을 만들어 [Diving Suit](diving_gear.md)에 사용할 압축 공기를 Glass Bottle에 채울 수 있습니다.

### Vent Field

바닥에서 솟아오른 Basalt·Blackstone 굴뚝 2~5개가 모여 있으며 가장 높은 것은 8블록까지 자랍니다. 굴뚝 꼭대기에는 연기와 거품을 내뿜는 <ItemLink id="hydrothermal_vent"/>가 있고 안팎에 Magma가 있으며 밑동에는 Vent Tubeworm이 모여 있습니다.

* 굴뚝 벽에는 Copper, Iron, Gold Ore가 박혀 있습니다.
* Hydrothermal Vent는 Magma처럼 위에 선 대상에게 화상 피해를 줍니다. 웅크리면 안전하게 지나갈 수 있습니다.
* Pickaxe로 채굴해 가져갈 수 있습니다. 위에 설치한 [Thermal Vent Tap](nautec:getting_started/ocean_generators.md)은 이를 Magma Block 3개에 해당하는 열원 3개로 계산합니다.

***

## <Color id="gold">Prismarine Reef</Color>

밝고 투명한 얕은 바다입니다.

* 해저에 Coral, Sea Pickle, Prismarine 지대가 있으며 그 사이에 Prismarine Frond가 자랍니다.
* 해저 지면 윗부분과 Prismarine 지대에 <ItemLink id="budding_prismarine"/>이 생성됩니다. 이를 찾기 가장 쉬운 바이옴입니다.
* Tropical Fish, Silt Skipper, Squid, Dolphin이 서식합니다.

***

## <Color id="gold">모드팩 제작자용</Color>

`config/nautec-worldgen.toml`의 `enableBiomeInjection`으로 바이옴 생성을 끌 수 있습니다. 사용자 지정 Overworld Preset을 사용하는 모드팩은 이를 `injectableWorldPresets`에 추가해야 합니다. Lithostitched가 설치된 경우에는 `data/nautec/lithostitched/biome_injector`의 바이옴 주입 파일을 따르며 Terralith와 Tectonic도 지원합니다.

`nautec:has_budding_prismarine` 바이옴 태그에는 해저에 Budding Prismarine이 드물게 생성되는 비NauTec 바이옴이 들어 있으며 기본값은 Warm Ocean과 Deep Lukewarm Ocean입니다. 다른 모드의 따뜻한 바다를 추가하면 같은 효과를 적용할 수 있습니다. `nautec:budding_prismarine_grafting`에는 Budding Prismarine에서 Lithophiles를 접목할 수 있는 장소가 지정되며 첫 번째 태그가 이미 포함되어 있습니다.

식물과 생물에 대한 설명은 [Life in the Deep](deep_life.md)을 참고하세요.
