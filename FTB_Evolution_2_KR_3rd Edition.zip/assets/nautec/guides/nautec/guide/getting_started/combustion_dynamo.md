---
navigation:
  title: Combustion Dynamo
  icon: nautec:combustion_dynamo
  position: 16
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:combustion_dynamo
  - nautec:kelp_slurry
  - nautec:algal_lipid
  - nautec:fiery_crystal
  - nautec:crystalline_combustion_booster
  - nautec:stellar_combustion_booster
---

# <Color id="light_purple">Combustion Dynamo</Color>

<Column alignItems="center" fullWidth={true}>
  <Row>
    <ItemImage id="combustion_dynamo" scale="2"/>
  </Row>
  기름과 물을 사용해 Forge Energy(FE)를 생산하는 엔진입니다.
</Column>

Combustion Dynamo는 기름과 물이 공급되는 동안 320 FE/t를 생산하고 접촉한 케이블이나 기계에 에너지를 전달합니다. 기름은 Kelp를 지질로 바꾸는 박테리아 균주에서 얻을 수 있으므로, Kelp 농장과 Bio Reactor를 연결하면 계속 가동할 수 있습니다.

***

## <Color id="gold">작동 방법</Color>

* **기름:** `c:oil` 태그에 포함된 기름이라면 NauTec 및 다른 모드의 기름 모두 사용할 수 있습니다. 10틱마다 1 mB를 소모하므로 한 양동이로 8분 이상 작동합니다.
* **물:** 매 틱 1 mB, 즉 초당 20 mB를 소모합니다.
* **탱크:** 기름과 물을 각각 8,000 mB씩 저장합니다. 어느 면으로든 두 유체를 공급할 수 있으며, 자동으로 해당 탱크에 들어가므로 하나의 파이프로 함께 공급할 수 있습니다.
* **첨가제:** 아이템 슬롯에 Booster를 넣으면 출력을 높일 수 있습니다. Booster 지속시간은 엔진이 작동할 때만 줄어들며, 기름·물 부족 또는 에너지 출력 공간 부족 시 일시 정지합니다.

| Booster | FE/t | 기름·물 소모량 | 지속시간 |
|---|---|---|---|
| Redstone Dust | 480 | 기본의 1.1배 | 1분 |
| Blaze Powder | 640 | 기본의 1.5배 | 2분 |
| Fiery Crystal | 960 | 기본의 2배 | 5분 |
| Crystalline Combustion Booster | 1,600 | 기본의 3배 | 10분 |
| Stellar Combustion Booster | 3,200 | 기본의 5배 | 1시간 |

Prismarine Crystal Shard 1개와 Blaze Powder 4개로 Fiery Crystal을 제작합니다. Fiery Crystal 2개, Resonant Shard 2개, Flawless Prismarine Crystal 1개를 조합하면 Crystalline 등급을 만들 수 있습니다. Stellar 등급에는 Crystalline Booster 4개, Deep Steel Plating 4개, Nether Star 1개가 필요합니다. 각 Booster의 효과와 제작법은 JEI에서 확인할 수 있습니다.

<RecipeFor id="fiery_crystal"/>
<RecipeFor id="crystalline_combustion_booster"/>
<RecipeFor id="stellar_combustion_booster"/>

화면에는 출력량, 부족한 자원, 남은 Booster 지속시간이 표시됩니다. 외부에서는 Jade로 같은 정보를 볼 수 있습니다.

***

## <Color id="gold">기름 생산하기</Color>

<Row>
  <ItemImage id="kelp_slurry"/>
  ### <Color id="aqua">Kelp Slurry</Color>
</Row>

[Mixer](nautec:laser_chemistry/mixer.md)에서 Kelp 4개와 Salt Water 1,000 mB를 혼합하면 Kelp Slurry 2개를 얻습니다.

<Row>
  <ItemImage id="algal_lipid"/>
  ### <Color id="aqua">Lipophiles와 Algal Lipid</Color>
</Row>

Lipophiles는 Algal Lipid를 생산하는 박테리아 균주입니다. [Mutator](nautec:aquatic_biology/mutator.md)에서 Halotrophs에 Kelp Slurry를 촉매로 사용하면 시도당 10% 확률로 변이합니다. 다른 균주처럼 Kelp Slurry를 먹이로 성장시키면 [Bio Reactor](nautec:aquatic_biology/bio_reactor.md)에서 Algal Lipid를 지속적으로 생산할 수 있습니다.

### <Color id="aqua">Oil</Color>

Mixer에서 Algal Lipid 1개와 Salt Water 250 mB를 혼합하면 기름 1,000 mB를 얻습니다.

<RecipeFor id="combustion_dynamo"/>
