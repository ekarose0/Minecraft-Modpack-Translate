---
navigation:
  title: Conduit Beacon
  icon: nautec:conduit_beacon
  position: 19
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:conduit_beacon
---

# <Color id="light_purple">Conduit Beacon</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="conduit_beacon" scale="2"/>
  레이저 전력으로 작동하며 기지 주변의 몹 생성도 막아 주는 Conduit입니다.
</Column>

바닐라 Conduit와 같은 방식으로 설치합니다. 비컨을 물속에 두고 주변 3×3×3 공간을 모두 물로 채운 다음 Prismarine, Prismarine Bricks, Dark Prismarine 또는 Sea Lantern으로 틀을 만드세요. 작동하려면 틀 블록이 최소 16개 필요하며, 완전한 틀은 42개입니다.

작동 중에는 다음 두 가지 효과가 적용됩니다.

* 같은 크기의 일반 Conduit와 마찬가지로 물속이나 비를 맞는 플레이어에게 Conduit Power를 부여합니다. 틀 16개에서는 반경 32블록, 완전한 틀에서는 96블록까지 적용됩니다.
* 비컨에서 수평으로 128블록 이내에서는 높이와 관계없이 적대적·비적대적·주변 환경 몹이 자연 생성되지 않습니다. 스포너, 생성 알, 번식, 습격 및 물고기나 오징어 같은 수중 생물은 영향을 받지 않습니다.

***

## <Color id="gold">전력</Color>

비컨을 향해 레이저 빔을 조사하세요. 빔이 지나가는 틀 위치도 틀의 일부로 인정되므로 빔 통로를 한 칸 비워 두어도 됩니다. 빔이 통과하는 자리는 채워진 것으로 계산되어 완전한 틀의 효과 범위 96블록을 유지할 수 있습니다.

비컨은 최대 5,000 AP를 저장합니다. 공급되는 전력이 저장소를 채우고, 틱당 50 AP를 소모해 작동하므로 빔이 끊겨도 약 5초간 계속 작동합니다. 빔 순도는 상관없습니다.

비컨이나 틀 블록에 레드스톤 신호를 주면 꺼집니다. 비컨은 항상 물에 둘러싸여 있으므로 틀 블록에 레버나 레드스톤 선을 설치하세요.

<ItemLink id="prism_monocle"/>로 비컨을 바라보면 작동 상태, 틀 크기, 효과 범위 및 저장 전력을 확인할 수 있습니다.

전력 소모량, 저장 용량 및 생성 차단 반경은 `config/nautec-common.toml`의 `conduitBeaconPowerUsage`, `conduitBeaconBuffer`, `conduitBeaconSpawnRadius`에서 설정할 수 있습니다.

<RecipeFor id="conduit_beacon"/>
