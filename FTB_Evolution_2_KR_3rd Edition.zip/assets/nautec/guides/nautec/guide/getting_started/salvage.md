---
navigation:
  title: Salvage
  icon: nautec:atlantic_gold_nugget
  position: 4
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:atlantic_gold_nugget
  - nautec:atlantic_gold_ingot
  - nautec:prismarine_lens
---

# <Color id="light_purple">Salvage</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="atlantic_gold_nugget" scale="2"/>
  NauTec의 재료와 기계 부품을 발견할 수 있는 장소를 안내합니다.
</Column>

NauTec 제작법에는 직접 제작하기보다 발견해서 수리해야 하는 부품이 많이 사용됩니다. 이 페이지에서는 획득 장소를 안내합니다. 수리 방법은 [Ancient Machine Parts](machine_part.md)를 참고하세요.

***

## <Color id="gold">구조물</Color>

| 장소 | 발견 가능한 아이템 |
|---|---|
| Ocean Ruins (NauTec) | Aquatic Catalyst, Rusty Crate, Suspicious Gravel |
| Crystal Geodes | 부품과 재료가 담긴 Barrel, Crate, Rusty Crate |
| Shipwreck 보물 상자 | 2/3 확률로 Crate |
| 바닐라 Ocean Ruin 상자 | 2/3 확률로 Crate, 1/4 확률로 Prismarine Crystal Shard, Atlantic Gold Nugget, Rusty Gear, Burnt Coil, Ancient Valve, Damaged Aquatic Chip, Broken Whisk, Deep Kelp 등의 부품과 간혹 Prismarine Lens. 큰 유적에서는 Aquarine Steel Ingot, Resonant Shard, Diving Helmet도 획득 가능 |
| 따뜻한 바다 유적의 Suspicious Sand | 가끔 Crate |
| Buried Treasure | 절반보다 약간 낮은 확률로 Damaged Aquatic Chip |

바닐라 상자에서 얻은 Crate에는 Burnt Coil, <ItemLink id="brown_polymer"/>, Cast Iron Ingot, Aquarine Steel Compound, Atlantic Gold Nugget, Prismarine, Iron, Gold 등이 들어 있습니다. NauTec 구조물은 [Structures](structures.md), 상자 여는 방법은 [Crates and Etching](etching.md)을 참고하세요.

***

## <Color id="gold">몹 전리품</Color>

| 몹 | 추가 전리품 |
|---|---|
| Guardian | 1/5 확률로 Ancient Valve, Burnt Coil 또는 Guardian Eye |
| Elder Guardian | 항상 Ancient Valve, Rusty Gear, Burnt Coil, Eldritch Heart 중 3회 추첨 |
| Drowned | 1/5 확률로 Broken Whisk 또는 Drowned Lungs |
| Dolphin | 1/5 확률로 Dolphin Fin |

Guardian Eye, Eldritch Heart, Drowned Lungs, Dolphin Fin은 Augment 부품입니다. [Mob Augments](nautec:laser_augmentation/mob_augments.md)를 참고하세요. 심해 생물의 전리품은 [Life in the Deep](deep_life.md)에서 설명합니다.

***

## <Color id="gold">Fishing</Color>

행운 낚시 구역과 Prismatic Fishing Rod로 Rusty Gear, Ancient Valve, Broken Whisk, Prismarine Lens, Atlantic Gold Nugget 등의 추가 전리품을 얻을 수 있습니다. 바이옴에 따라 희귀한 아이템도 나옵니다. [Fishing](fishing.md)을 참고하세요.

***

<Row>
  <ItemImage id="atlantic_gold_nugget"/>
  ### <Color id="aqua">Atlantic Gold</Color>
</Row>

<ItemLink id="atlantic_gold_nugget"/>는 모든 바다의 Crate, Rusty Crate, 행운 낚시 보물에서 얻을 수 있습니다. Nugget 9개로 <ItemLink id="atlantic_gold_ingot"/> 1개를 만들고, Ingot 1개를 다시 Nugget 9개로 분해할 수 있습니다. 나중에는 Y -20 이하의 [Abyssal Pressure Forge](nautec:deep_engineering/pressure_forge.md)에서 순도 2.0의 빔을 공급해 Block of Gold 1개를 15초 만에 Atlantic Gold Ingot 2개로 가공할 수 있습니다.

<Recipe id="nautec:atlantic_gold_ingot_from_nuggets"/>

<Recipe id="nautec:atlantic_gold_nuggets_from_ingot"/>

이 Ingot은 Sea Scout, Solar·Sonar Module, Auxiliary Ventricle Augment, Resonance Charm과 후반부의 Fusion Plant 부품, Crystal Cradle, Prism Satellite, Resonance Network 블록 제작에 사용됩니다.

***

<Row>
  <ItemImage id="prismarine_lens"/>
  ### <Color id="aqua">Prismarine Lens</Color>
</Row>

Bacterial Analyzer, Grafting Station, Laser Injector, Prismatic Emitter, Impulse Laser Module, Solar·Sonar Module 및 후반부 기계에 사용되는 렌즈입니다. Aquarine Steel로 제작하거나 행운 낚시 구역의 보물에서 얻을 수 있습니다.

<RecipeFor id="prismarine_lens"/>
