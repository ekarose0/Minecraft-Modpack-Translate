---
navigation:
  title: Structures
  icon: nautec:prismarine_crystal
  position: 3
  parent: getting_started/getting_started-index.md
---

# <Color id="light_purple">Structures</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="prismarine_crystal" scale="2"/>
  바다에 생성되는 NauTec 구조물 4종입니다. 모두 초반에 탐험할 가치가 있습니다.
</Column>

4종 모두 NauTec의 바다를 포함한 모든 바다 바이옴에서 해저 지형이 해수면 아래인 곳에 생성됩니다. Ocean Monument 근처에는 생성되지 않습니다.

<ItemLink id="eye_of_the_sea"/>로 각 구조물과 바닐라 Ocean Ruin, Ocean Monument의 가장 가까운 위치를 찾을 수 있습니다. [Eye of the Sea](eye_of_the_sea.md)를 참고하세요.

***

## <Color id="gold">Ocean Ruins</Color>

해저에 세워진 작은 Dark Prismarine 아치입니다. Chiseled Dark Prismarine, Dark Prismarine Pillar, Dark Prismarine Slab으로 이루어져 있습니다.

획득할 수 있는 것:

* 아치에 설치된 <ItemLink id="aquatic_catalyst"/>. 채굴하면 아이템으로 떨어져 직접 제작하기 전부터 Catalyst를 얻을 수 있습니다.
* 아치 아래 자갈에 묻힌 <ItemLink id="rusty_crate"/>. 부수면 내용물과 함께 가져갈 수 있으며 [Etching Acid](etching.md)로 세척할 수 있습니다.
* 자갈 사이의 Suspicious Gravel. Brush로 털면 Gold Nugget, Prismarine, Prismarine Laser Relay, <ItemLink id="burnt_coil"/>, <ItemLink id="atlantic_gold_nugget"/> 등을 얻습니다.

***

## <Color id="gold">Crystal Geodes</Color>

해저 지면 아래에 묻힌 빈 공간입니다. Stone Geode는 바닥이 y -10~30, Deepslate Geode는 y -59~-25에 생성됩니다. 둘 다 위쪽에 최소 4블록의 암석이 있으므로 해저가 깊을수록 더 아래에 있습니다. 수면에서는 흔적을 볼 수 없습니다. `/locate` 또는 [Eye of the Sea](eye_of_the_sea.md)로 공간 중심을 찾을 수 있습니다.

중앙에는 Scaffolding으로 둘러싸인 <ItemLink id="prismarine_crystal"/>이 있습니다. 자연적으로 생성되는 유일한 순도 3.0 빔 광원이며 생성 위치에서 움직이지 않으므로, 다른 수단을 마련하기 전에는 이곳에서 [고순도 Item Transformation](item_transformation.md)을 수행합니다. Crystal 아래에는 작업에 필요한 빈 공간이 이미 있으며 Stone Geode는 1블록, Deepslate Geode는 2블록입니다.

주변에서 찾을 수 있는 것:

* Rusty Gear, Aquarine Steel Compound, <ItemLink id="brown_polymer"/>, <ItemLink id="air_bottle"/>, Prismarine, Gold Nugget 등이 든 Barrel.
* Burnt Coil, Brown Polymer, Cast Iron Ingot, Prismarine Crystal, Iron, Aquarine Steel Compound 등이 든 Crate.
* 전체 Crate의 약 절반을 차지하는 Rusty Crate. Ancient Valve, Rusty Gear, Burnt Coil, Atlantic Gold Nugget, Aquarine Steel Ingot, 간혹 Heart of the Sea 같은 고급 부품이 들어 있습니다.
* Crafting Table, Lectern, Decorated Pot, 작은 Salt Water 웅덩이.

Crate는 상자처럼 열 수 있지만 Rusty Crate는 먼저 에칭해야 합니다. [Crates and Etching](etching.md)을 참고하세요.

<Color id="gold">팁</Color>: 능력을 활성화한 Aquarine Steel Pickaxe로 Crystal에서 [Prismarine Crystal Shard](nautec:laser_chemistry/crystal_shards.md)를 채굴할 수 있지만, 타격할 때마다 1/4 확률로 Crystal이 영구 파괴됩니다. Shard를 채굴하기 전에 변환 작업부터 준비하세요.

***

## <Color id="gold">Underwater Gateways</Color>

네 모서리에 Dark Prismarine Pillar가 있고 중앙에 <ItemLink id="gateway"/>가 놓인 작은 Polished Prismarine 플랫폼입니다. 청크가 처음 로드될 때 Gateway의 전체 고리가 형성됩니다. Ruin이나 Geode보다 훨씬 희귀합니다.

각 Gateway는 고유 주소를 가진 한 쌍의 절반입니다. 처음 통과하면 약 1,500블록 떨어진 다른 바다에 나머지 절반이 생성됩니다. 이동 방식은 [Gateway](nautec:deep_engineering/gateway.md)를 참고하세요.

***

## <Color id="gold">Sunken Research Outposts</Color>

최소 수심 12블록인 해저에 있는 버려진 연구 기지입니다. 천창이 있는 Copper·Cast Iron 돔형 중앙 구역과 짧은 복도로 연결된 연구실·창고·동력실로 이루어져 있습니다. 기지 전체가 침수되어 벽에 구멍이 뚫리고 바닥에 Seagrass가 자랍니다. 내부에는 Drowned가 생성됩니다.

획득할 수 있는 것:

* 중앙 구역의 Lectern에 놓인 Research Log. Vent, 빛나는 동굴, Trench, Gateway에 대한 승무원의 기록 4종이 있습니다.
* Petri Dish, Glass Vial, Air Bottle, Aquarine Steel Compound, 부품 등이 든 Chest와 Barrel. 간혹 Submarine Module, <ItemLink id="diving_helmet"/>, Heart of the Sea도 있습니다.
* 중앙 구역과 창고에 있는 Rusty Crate.
* 중앙 구역 출입구의 <ItemLink id="pressure_hatch"/>. Pickaxe로 채굴해 가져갈 수 있습니다. [Underwater Bases](underwater_bases.md)를 참고하세요.

Ruin보다 희귀하며 해저 바닥이 비교적 평탄한 곳에만 생성됩니다.

***

## <Color id="gold">바닐라 구조물</Color>

Shipwreck, Ocean Ruin, 따뜻한 바다 유적의 모래, Buried Treasure에서도 NauTec 전리품을 얻을 수 있습니다. 위치별 전리품은 [Salvage](salvage.md)를 참고하세요.
