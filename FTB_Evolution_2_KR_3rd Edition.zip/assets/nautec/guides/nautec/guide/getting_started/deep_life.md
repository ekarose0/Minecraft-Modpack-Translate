---
navigation:
  title: Life in the Deep
  icon: nautec:luminous_membrane
  position: 12
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:deep_kelp
  - nautec:luminescent_algae
  - nautec:glow_polyp
  - nautec:prismarine_frond
  - nautec:vent_tubeworm
  - nautec:abyssal_coral
  - nautec:silt_skipper
  - nautec:silt_skipper_bucket
  - nautec:silt_skipper_spawn_egg
  - nautec:lantern_jelly_spawn_egg
  - nautec:vent_crawler_spawn_egg
  - nautec:abyssal_maw_spawn_egg
---

# <Color id="light_purple">Life in the Deep</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="luminous_membrane" scale="2"/>
  NauTec의 바다에 서식하는 식물 6종과 생물 4종을 소개합니다.
</Column>

## <Color id="gold">식물</Color>

6종 모두 Shears로 채집해야 합니다. 다른 도구로 부수면 아무것도 얻지 못합니다. 모든 식물은 <ItemLink id="grafting_tool"/>로 박테리아를 접목하는 데 사용할 수 있으며, 종류별 정보는 [Bacteria Grafting](nautec:aquatic_biology/bacteria_grafting.md)을 참고하세요.

| 식물 | 바이옴 | 밝기 |
|---|---|---|
| <ItemLink id="deep_kelp"/> | Bioluminescent Grove | 없음 |
| <ItemLink id="luminescent_algae"/> | Bioluminescent Grove | 9 |
| <ItemLink id="glow_polyp"/> | Bioluminescent Grove | 7 |
| <ItemLink id="prismarine_frond"/> | Prismarine Reef | 없음 |
| <ItemLink id="vent_tubeworm"/> | Hydrothermal Vents | 3 |
| <ItemLink id="abyssal_coral"/> | Abyssal Trench | 없음 |

Deep Kelp는 일반 Kelp처럼 물속에서 위로 자라며 최대 40블록까지 성장합니다(`config/nautec-common.toml`의 `kelpHeight`). 줄기의 맨 위 블록만 아이템으로 떨어지므로 끝부분을 Shears로 채집하세요. Glow Polyp은 Glow Lichen처럼 블록의 어느 면에나 붙으며 Bone Meal로 퍼뜨릴 수 있습니다. 나머지 4종은 단일 수중 식물입니다.

각 바이옴의 행운 낚시 구역에서도 해당 바이옴의 식물을 얻을 수 있습니다. [Fishing](fishing.md)을 참고하세요.

***

## <Color id="gold">Silt Skipper</Color>

<GameScene zoom="3.2" background="#333333" interactive={true}>
  <Entity id="nautec:silt_skipper"/>
</GameScene>

Abyssal Trench, Bioluminescent Grove, Prismarine Reef에서 최대 8마리씩 무리 지어 헤엄치는 작은 비공격성 물고기입니다.

* 처치하면 먹을 수 있는 <ItemLink id="silt_skipper"/>를 얻습니다.
* Water Bucket을 들고 우클릭하면 <ItemLink id="silt_skipper_bucket"/>에 담을 수 있으며, 양동이를 비우면 다시 풀어줄 수 있습니다.

***

## <Color id="gold">Lantern Jelly</Color>

<GameScene zoom="2.4" background="#333333" interactive={true}>
  <Entity id="nautec:lantern_jelly"/>
</GameScene>

Bioluminescent Grove에서 천천히 떠다니는 빛나는 해파리입니다. 비공격적이며 체력이 낮습니다.

<ItemLink id="luminous_membrane"/> 1~2개를 떨어뜨립니다(Looting 효과로 증가). Photophore Skin Augment 제작에 사용합니다.

***

## <Color id="gold">Vent Crawler</Color>

<GameScene zoom="2.4" background="#333333" interactive={true}>
  <Entity id="nautec:vent_crawler"/>
</GameScene>

Hydrothermal Vents 해저를 걸어 다니는 갑각 생물입니다. 공격받으면 반격하지 않고 도망가며, 밀쳐내기 효과를 절반만 받고 화염 피해를 입지 않습니다.

<ItemLink id="chitin_plate"/> 1~3개를 떨어뜨립니다(Looting 효과로 증가). 4개를 사용해 Vent Carapace Augment를 제작합니다.

***

## <Color id="gold">Abyssal Maw</Color>

<GameScene zoom="1.8" background="#333333" interactive={true}>
  <Entity id="nautec:abyssal_maw"/>
</GameScene>

Abyssal Trench에 서식하는 적대적인 포식자입니다. y 40 아래의 어두운 물에서만 생성되며 최대 24블록 거리에서 플레이어를 발견하면 물속으로 추격합니다. 체력은 24, 물기 공격력은 6입니다.

<ItemLink id="abyssal_organ"/> 1개를 떨어뜨립니다(Looting 효과로 증가). Abyssal Eyes Augment 제작에 사용합니다.

***

## <Color id="gold">Augment</Color>

생물 3종의 전리품으로 각각 Augment를 제작할 수 있습니다. [Deep Fauna Augments](nautec:laser_augmentation/deep_fauna_augments.md)를 참고하세요. 네 생물의 Spawn Egg는 크리에이티브 메뉴에 있습니다.
