---
navigation:
  title: Laser Crafting Matrix
  icon: nautec:laser_crafting_matrix
  position: 2
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:laser_crafting_matrix
---

# <Color id="light_purple">Laser Crafting Matrix</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="laser_crafting_matrix" scale="2"/>
  기계 내부에서 레이저 변환을 수행하여 자동화할 수 있습니다.
</Column>

모든 [Item Transformation](item_transformation.md)은 Matrix에서도 한 번에 제작법 하나씩 처리할 수 있습니다. 바닥에 아이템을 떨어뜨리는 대신 파이프로 아이템과 액체를 투입하고 배출합니다.

## <Color id="gold">설치 및 설정</Color>

Matrix는 **위쪽**에서 들어오는 레이저만 받습니다. Relay 또는 Catalyst를 아래로 향하게 설치하세요. 옆면이나 아래쪽에서 들어오는 빔은 무시됩니다.

각 제작법에는 최소 AP와 순도 조건이 있습니다. 둘 중 하나라도 부족하면 Matrix는 진행 상태를 유지한 채 대기합니다. 다른 기계와 마찬가지로 필요한 출력보다 강한 빔을 공급하면 더 빨리 작동합니다([Stronger Beams](stronger_beams.md) 참조).

빈손으로 우클릭하면 기계 화면이 열립니다.

* 화살표 왼쪽에 투입 슬롯 3개, 오른쪽에 출력 슬롯 3개가 있습니다.
* 맨 왼쪽에 투입 탱크 2개, 맨 오른쪽에 출력 탱크 2개가 있으며 각각 16,000 mB를 저장합니다(설정 가능).
* 각 투입 슬롯은 서로 다른 아이템을, 각 투입 탱크는 서로 다른 액체를 보관하므로 파이프가 동일한 아이템을 모든 슬롯에 분산하지 않습니다.
* 액체가 담긴 양동이로 우클릭하면 투입 탱크를 채우고, 빈 양동이로 우클릭하면 출력 탱크부터 액체를 꺼냅니다.
* 호퍼와 파이프로 투입 슬롯에 넣거나 출력 슬롯에서 꺼낼 수 있습니다. [Side Configuration](utilities.md)에서 면마다 아이템과 액체 입출력을 따로 설정합니다.

화면에는 현재 제작법에 필요한 AP와 순도가 표시됩니다. 빔이 조건을 충족하면 녹색, 부족하면 빨간색으로 나타납니다. 화살표에 마우스를 올리면 정확한 수치를 볼 수 있습니다. Jade에서는 생산물과 기계가 대기 중인 이유도 확인할 수 있습니다.

작동 중에는 가운데 띠가 회전하고 렌즈가 주기적으로 빛납니다.

***

## <Color id="gold">제작법</Color>

JEI의 Laser Crafting 항목에서 모든 제작법을 확인할 수 있습니다.

| 투입물 | 결과물 | AP | 순도 | 시간 |
|---|---|---|---|---|
| Aquarine Steel Compound | Aquarine Steel Ingot | 10 | any | 1 s |
| Aquarine Steel Compound | 2 Aquarine Steel Ingots | 20 | 2.0 | 1 s |
| <ItemLink id="burnt_coil"/> | Laser Channeling Coil | 20 | 1.5 | 5 s |
| Prismarine Crystals | 2 <ItemLink id="prismarine_crystal_shard"/>s | 20 | 2.0 | 2 s |
| <ItemLink id="cast_iron_block"/> | 4 <ItemLink id="gear"/>s | 40 | 2.5 | 4 s |

여러 제작법이 일치하면 현재 빔의 순도로 충족할 수 있는 제작법 중 순도 요구량이 가장 높은 것을 사용합니다.

모드팩과 데이터팩에서는 아이템 투입 3개, 액체 투입 2개, 아이템 출력 3개, 액체 출력 2개까지 사용하는 `nautec:laser_crafting` 제작법을 추가할 수 있습니다.

<RecipeFor id="laser_crafting_matrix"/>
