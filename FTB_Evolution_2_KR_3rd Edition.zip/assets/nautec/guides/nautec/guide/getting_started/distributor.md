---
navigation:
  title: Nautechnical Distributor
  icon: nautec:nautechnical_distributor
  position: 8
  parent: getting_started/getting_started-index.md
item_ids:
  - nautec:nautechnical_distributor
---

# <Color id="light_purple">Nautechnical Distributor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nautechnical_distributor" scale="2"/>
  파이프 없이 기지 곳곳의 기계에서 생산물을 수집하고 필요한 재료를 공급합니다.
</Column>

Distributor는 같은 차원에서 최대 256블록 떨어진 블록에 연결할 수 있습니다. 몇 틱마다 생산물을 수집해 옆의 상자와 탱크에 넣고, 기계가 요청한 입력 재료를 보충합니다. 전송 속도 제한 없이 한 번에 들어갈 수 있는 만큼 옮깁니다. 모든 모드의 기계에서 아이템과 유체를 처리할 수 있습니다.

***

## <Color id="gold">연결하기</Color>

1. 빈손으로 웅크린 채 Distributor를 우클릭합니다.
2. 연결할 블록을 빈손으로 웅크린 채 우클릭합니다. 클릭한 면이 파이프를 연결할 때처럼 Distributor가 사용할 면으로 지정됩니다.
3. 연결을 마치면 Distributor를 다시 웅크린 채 우클릭합니다.

연결된 블록을 다시 웅크린 채 우클릭하면 연결이 해제됩니다. 1분 동안 새 연결이 없으면 연결 모드가 자동 종료됩니다. Distributor 화면에서도 연결을 해제할 수 있습니다. Distributor 하나당 최대 64개를 연결합니다.

다른 모드의 기계는 면 선택이 중요합니다. Furnace의 바닥처럼 생산물이 나오는 면을 선택하세요. NauTec 기계는 [Side Configuration](utilities.md)을 따르므로 출력 슬롯에서만 수집됩니다.

***

## <Color id="gold">생산물 수집</Color>

Distributor는 각 연결 면에서 꺼낼 수 있는 아이템과 유체를 수집해 자신의 6면에 접한 인벤토리와 탱크로 옮깁니다. 보관할 수 있는 양만 수집하므로 상자가 가득 차면 아이템을 잃지 않고 대기합니다. 연결된 블록은 Distributor의 인접 저장소로 취급되지 않습니다.

***

## <Color id="gold">입력 재료 공급</Color>

입력 재료를 요청하는 방법은 두 가지입니다.

NauTec 기계의 화면을 열고 아이템을 든 채 웅크리면서 빈 입력 슬롯을 클릭하거나 JEI에서 아이템을 끌어 놓으세요. 슬롯에 희미한 아이템 표시가 생기는데, 이를 Ghost Input이라고 합니다. Distributor는 해당 슬롯을 가능한 한 가득 채우며 지정한 아이템만 받게 됩니다. Ghost Input과 요청은 마법 부여 등 데이터까지 일치하는 아이템을 대상으로 합니다. Petri Dish는 내용물로 구분합니다. 빈 접시를 지정하면 빈 접시만, 군체가 담긴 접시를 지정하면 크기·능력치와 관계없이 같은 균주의 군체를 받습니다. 단, Bacterial Analyzer에서는 빈 접시 Ghost가 분석이 필요한 모든 군체를 받습니다. 빈손으로 웅크린 채 클릭하면 지울 수 있으며, 슬롯에 마우스를 올리면 안내가 표시됩니다.

모드 종류와 관계없이 Distributor 화면에서 연결된 블록을 선택하고 오른쪽에 요청을 설정할 수 있습니다. 아이템 최대 9종과 유체 최대 3종을 지정하고 블록에 유지할 수량을 설정합니다. 아이템이나 유체가 든 Bucket으로 요청 슬롯을 클릭하거나 JEI에서 끌어 놓으세요. 요청 위에서 휠을 돌려 수량을 변경합니다(Shift를 누르면 아이템은 16개씩, 유체는 10,000 mB씩 변경). 우클릭하면 요청을 지웁니다. Abyssal Pressure Forge에 Etching Acid를 공급하는 것처럼 화면이 없는 NauTec 기계에도 사용할 수 있습니다.

입력 재료는 먼저 다른 연결 기계의 출력에서, 다음으로 Distributor 옆의 상자·탱크에서, 마지막으로 인접한 저장 네트워크에서 가져옵니다(아래 참조). 따라서 한 기계의 생산물을 다음 기계에 직접 공급하고 남는 것만 외부로 보낼 수 있습니다. 연결된 기계가 요청한 재료는 다시 수집하지 않습니다.

***

## <Color id="gold">저장 네트워크</Color>

Applied Energistics 2의 ME Interface 또는 Refined Storage Interface를 Distributor에 붙이면 연결 기계의 Ghost Input 및 요청에 필요한 아이템과 유체를 전체 저장 네트워크에서 직접 가져옵니다. 케이블에 설치한 ME Interface Part도 Distributor를 향하면 작동합니다. Interface에는 평소처럼 채널과 동력이 필요합니다.

기계에 공간이 있고 실제로 아이템을 받을 수 있는지 확인한 뒤 필요한 양만 가져오므로 공간이 가득 차더라도 아이템이 사라지거나 복제되지 않습니다. 필요한 아이템이 없는 기계는 최대 5초 간격으로 확인해 네트워크 부하를 줄입니다.

Distributor가 수집한 생산물도 다른 인접 저장소와 마찬가지로 Interface에 들어가 네트워크에 저장됩니다. `config/nautec-common.toml`의 `distributorStorageNetworks`로 네트워크에서 가져오는 기능을 끌 수 있습니다.

***

## <Color id="gold">설정</Color>

범위, 최대 연결 수, 전송 주기(기본 4틱)는 `config/nautec-common.toml`에서 설정할 수 있습니다.

<RecipeFor id="nautechnical_distributor"/>
