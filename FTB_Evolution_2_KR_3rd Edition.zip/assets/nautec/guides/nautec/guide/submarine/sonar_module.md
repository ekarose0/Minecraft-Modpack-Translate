---
navigation:
  title: Sonar Module
  icon: nautec:sonar_module
  position: 11
  parent: submarine/submarine-index.md
item_ids:
  - nautec:sonar_module
---

# <Color id="light_purple">Sonar Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="sonar_module" scale="2"/>
  암석 너머의 광석과 적대적 생물을 탐지합니다.
</Column>

Sonar Module을 한 번 사용하면 고체 암석을 통과하여 48블록 이내의 광맥과 32블록 이내의 적대적 생물을 표시하고 승무원에게 야간 투시 효과를 부여합니다.

***

## <Color id="gold">사용 방법</Color>

| | 기본값 |
|---|---|
| 탐지당 동력 | 30,000 |
| 광석 탐지 범위 | 48블록 |
| 적대적 생물 탐지 범위 | 32블록 |
| 재사용 대기시간 | 45초 |

사용하면 선체에서 원형 탐지파가 지형을 통과해 퍼집니다. 탐지파가 광맥에 닿으면 광석 종류에 따른 색상으로 윤곽선이 표시되며, 암석 너머에서도 45초 동안 보이다가 사라집니다. 공통 광석 태그에 포함된 광석이라면 다른 모드의 광석도 탐지됩니다.

탐지 위치에서 32블록 이내의 적대적 생물은 45초 동안 빨간 윤곽선으로 표시되며, 이동해도 표시가 따라갑니다. 또한 15초 동안 발광 효과가 적용됩니다.

모든 탑승자는 45초 동안 야간 투시 효과를 받으므로 빛이 거의 닿지 않는 심해에서 특히 유용합니다.

두 탐지 범위는 탐지 당시 선체 위치를 기준으로 합니다. 다른 지역을 조사하려면 이동한 뒤 다시 사용하세요. 동력 소모량, 적대적 생물 탐지 범위, 재사용 대기시간은 설정에서 변경할 수 있습니다.

***

### <Color id="aqua">Sonar Module 제작법</Color>

<Recipe id="nautec:sonar_module"/>
