---
navigation:
  title: Stealth Module
  icon: nautec:stealth_module
  position: 10
  parent: submarine/submarine-index.md
item_ids:
  - nautec:stealth_module
---

# <Color id="light_purple">Stealth Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="stealth_module" scale="2"/>
  2분 동안 적의 시야에서 벗어납니다.
</Column>

Stealth Module을 사용하면 이동 속도가 조금 감소하는 대신 2분 동안 생물이 선체와 승무원을 감지하지 못합니다.

***

## <Color id="gold">사용 방법</Color>

| | 기본값 |
|---|---|
| 사용당 동력 | 50,000 |
| 지속 시간 | 2분 |
| 작동 중 속도 | 추진력 15% 감소 |
| 재사용 대기시간 | 발동 시점부터 130초 |

사용하는 즉시 반경 32블록 안에서 선체나 승무원을 추적하던 모든 생물이 추적을 포기합니다. 이후 2분 동안 아무리 가까이 접근해도 선체나 승무원을 공격 대상으로 지정할 수 없습니다. 은신 중에는 모듈 슬롯에 밝은 표시가 나타납니다.

은신 중에는 추진력이 15% 감소합니다. 빠르게 벗어나야 한다면 [Booster Module](booster_module.md)을 함께 사용하세요.

은신이 종료된 뒤 10초가 더 지나야 다시 사용할 수 있습니다. 은신이 끝나면 생물들이 평소처럼 플레이어를 감지합니다.

모든 수치는 설정에서 변경할 수 있습니다.

***

### <Color id="aqua">Stealth Module 제작법</Color>

<Recipe id="nautec:stealth_module"/>
