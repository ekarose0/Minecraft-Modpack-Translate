---
navigation:
  title: 모듈
  icon: nautec:aquatic_chip
  position: 6
  parent: submarine/submarine-index.md
---

# <Color id="light_purple">모듈</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquatic_chip" scale="2"/>
  9칸의 업그레이드 슬롯입니다.
</Column>

모듈은 Sea Scout의 모듈 슬롯에 장착하여 새로운 능력을 부여하는 아이템입니다. 조종 중에는 단축바 대신 모듈 바가 표시되며 여기서 능력을 사용할 수 있습니다.

***

## <Color id="gold">모듈 슬롯</Color>

선체 밖에서 웅크리지 않은 상태로 <ItemLink id="aquarine_steel_wrench"/>를 들고 우클릭하면 모듈 슬롯이 열립니다(다른 렌치도 사용 가능). 슬롯은 9개이며 각 슬롯에 모듈 하나씩만 장착할 수 있습니다. 웅크린 채 우클릭하면 모듈 화면 대신 선체를 회수합니다.

선체를 회수해도 모듈은 장착된 상태로 유지되며 아이템 툴팁에 목록이 표시됩니다.

***

## <Color id="gold">모듈 사용</Color>

조종 중에는 화면 아래에 단축바 대신 9개의 모듈 슬롯이 표시되고, 선택한 모듈의 이름이 그 위에 나타납니다. 숫자 키나 마우스 휠로 슬롯을 선택한 뒤 좌클릭하거나 F키를 눌러 사용하세요.

* 지속 효과 모듈은 슬롯 아래에 옅은 띠가 표시되며, 선택하거나 사용하지 않아도 어느 슬롯에서든 작동합니다.
* 작동 중인 Booster 또는 Stealth Module은 슬롯 아래에 밝은 띠가 표시됩니다.
* 재사용 대기 중인 모듈은 슬롯에 어두운 표시가 나타나며, 다시 사용할 수 있을 때까지 점차 줄어듭니다.

모듈을 사용할 수 없으면 바 위에 "That module is still cycling", "Not enough power for that module" 또는 순간이동 관련 메시지가 표시됩니다. 사용에 실패한 모듈은 동력을 소비하지 않습니다.

재사용 대기시간은 모듈 종류별로 공유되며 사용 시 시작됩니다. 같은 모듈을 여러 개 장착해도 하나를 사용하면 같은 종류의 모든 모듈에 대기시간이 적용되므로 Booster를 두 개 장착해도 연속 사용은 불가능합니다. 대기시간 도중 선체를 회수하면 남은 시간이 보존되고 다시 진수하면 이어서 진행됩니다. 지속 효과도 중첩되지 않으므로 Solar, Armour, Flight Module을 두 개씩 장착해도 효과가 추가되지 않습니다.

***

## <Color id="gold">전체 모듈</Color>

| 모듈 | 유형 | 동력 | 대기시간 |
|---|---|---|---|
| [Solar](solar_module.md) | 지속 효과 | 5초마다 2,000 생산 | 없음 |
| [Armour](armor_module.md) | 지속 효과 | 없음 | 없음 |
| [Booster](booster_module.md) | 10초간 가속 | 20,000 | 13초 |
| [Stealth](stealth_module.md) | 2분간 은신 | 50,000 | 130초 |
| [Sonar](sonar_module.md) | 소나 탐지 1회 | 30,000 | 45초 |
| [Shield](shield_module.md) | 지속 피해 흡수 및 방출 | 흡수한 하트당 10,000, 방출당 25,000 | 5초 |
| [Impulse Laser](impulse_laser_module.md) | 누르는 동안 발사 | 틱당 400에서 1,400까지 증가 | 없음 |
| [Teleport](teleport_module.md) | Anchor로 순간이동 | 200,000 | 30초 |
| [Flight](flight_module.md) | 지속 효과 | 비행 중 틱당 4 | 없음 |
| [Cargo Hold](cargo_module.md) | 화물칸 열기 | 없음 | 없음 |

Booster와 Stealth Module의 재사용 대기시간에는 효과 지속시간도 포함됩니다. 각 모듈의 툴팁에는 사용당 동력 소모량과 대기시간이 표시되며 모든 수치는 설정에서 변경할 수 있습니다.
