---
navigation:
  title: Impulse Laser
  icon: nautec:impulse_laser_module
  position: 13
  parent: submarine/submarine-index.md
item_ids:
  - nautec:impulse_laser_module
---

# <Color id="light_purple">Impulse Laser</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="impulse_laser_module" scale="2"/>
  전방으로 발사되는 쌍발 레이저 빔입니다.
</Column>

Impulse Laser Module은 발사 키를 누르는 동안 선체 앞쪽에서 두 개의 레이저 빔을 발사합니다. 두 빔은 한 쌍의 Atlantean Rifle처럼 조준점에서 합쳐집니다.

***

## <Color id="gold">사용 방법</Color>

| | 기본값 |
|---|---|
| 충전 시간 | 빔 발사 전 0.5초 |
| 출력 상승 | 연속 발사 5초 후 최대 출력 |
| 동력 소모 | 틱당 400에서 1,400까지 증가 |
| 사거리 | 64블록 |
| 빔 하나의 피해량 | 2에서 6까지 증가하며, 대상 최대 체력의 0.4%에서 1.25%까지 추가 피해를 초당 4회 적용 |

능력 바에서 모듈을 선택하고 공격 키 또는 능력 키를 누르고 계세요. 0.5초 동안 충전한 뒤 두 빔이 발사됩니다. 연속 발사 시간이 길수록 빔이 굵고 밝아지며 피해량도 증가하여 5초 후 최대 출력에 도달합니다. 키를 놓으면 즉시 멈추고, 다시 발사하면 충전부터 시작합니다.

선체의 방향으로 조준합니다. 조종 중 두 빔은 조준점에 있는 생물이나 고체 블록에서 만나며, 아무것도 없으면 최대 사거리까지 나아갑니다. 빔은 시선이 아닌 기수 방향을 따라가므로 자유 시점에서도 선체가 향하는 곳을 공격합니다. 각 빔은 처음 맞힌 생물이나 고체 블록에서 멈추며, 두 빔을 모두 맞은 대상은 각각의 피해를 받습니다. 피해는 방어력을 무시하고 선체에 탑승한 승무원은 맞히지 않습니다.

***

## <Color id="gold">동력</Color>

최대 출력의 레이저는 초당 28,000의 동력을 소모하므로 계속 발사하는 것보다 짧게 끊어 쏘는 편이 효율적입니다. 동력이 부족하거나 조종자가 내리거나 모듈을 제거하면 발사가 중단됩니다.

모든 수치는 설정에서 변경할 수 있습니다.

***

### <Color id="aqua">Impulse Laser Module 제작법</Color>

<Recipe id="nautec:impulse_laser_module"/>
