---
navigation:
  title: Booster Module
  icon: nautec:booster_module
  position: 9
  parent: submarine/submarine-index.md
item_ids:
  - nautec:booster_module
---

# <Color id="light_purple">Booster Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="booster_module" scale="2"/>
  10초 동안 추가 추진력을 제공합니다.
</Column>

Booster Module을 사용하면 10초 동안 추진력이 45% 증가합니다.

***

## <Color id="gold">사용 방법</Color>

| | 기본값 |
|---|---|
| 사용당 동력 | 20,000 |
| 가속 효과 | 추진력 45% 증가 |
| 지속 시간 | 10초 |
| 재사용 대기시간 | 발동 시점부터 13초 |

추진 중에 모듈을 선택하고 사용하세요. 가속 효과는 기존 추진력에 추가되므로 달리기 키를 누른 효과와 중첩됩니다. 작동 중에는 선미에 밝은 궤적이 남으며, 효과가 끝날 때까지 모듈 슬롯에 밝은 표시가 나타납니다.

가속은 10초 후 종료되고, 3초가 더 지나면 다시 사용할 수 있습니다. 한 번에 20,000의 동력만 사용하므로 장거리 이동이나 위험에서 벗어날 때 부담 없이 활용할 수 있습니다.

[Stealth Module](stealth_module.md)과 함께 사용하면 두 효과가 곱연산으로 적용되어, 속도가 감소하는 대신 평소보다 약 23% 빨라집니다.

모든 수치는 설정에서 변경할 수 있습니다.

***

### <Color id="aqua">Booster Module 제작법</Color>

<Recipe id="nautec:booster_module"/>
