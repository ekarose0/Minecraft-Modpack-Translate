---
navigation:
  title: Solar Module
  icon: nautec:solar_module
  position: 7
  parent: submarine/submarine-index.md
item_ids:
  - nautec:solar_module
---

# <Color id="light_purple">Solar Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="solar_module" scale="2"/>
  햇빛으로 동력을 자동 충전합니다.
</Column>

Solar Module은 낮 동안 선체에서 하늘이 보이면 5초마다 2,000의 동력(배터리의 0.2%, 틱당 약 20)을 충전합니다.

***

## <Color id="gold">충전 방식</Color>

어느 슬롯에 장착해도 자동으로 작동합니다. 물을 통과해 하늘을 감지하므로 잠수한 상태에서도 충전되지만, 선체와 하늘 사이에 고체 블록이 있으면 작동하지 않습니다. 낮에만 충전되며 Nether나 End처럼 낮밤 주기가 없는 차원에서는 작동하지 않습니다.

탑승자가 없어도 충전은 계속됩니다. 탁 트인 물 위에 정박한 선체는 햇빛을 약 42분 받으면 완전히 충전됩니다. [Sea Scout Dock](submarine_dock.md)은 이보다 두 배 빠릅니다.

여러 개를 장착해도 효과가 중첩되지 않으므로 하나면 충분합니다. 충전 속도는 설정값(`submarineSolarPercentPer5s`)으로 변경할 수 있습니다.

***

### <Color id="aqua">Solar Module 제작법</Color>

<Recipe id="nautec:solar_module"/>
