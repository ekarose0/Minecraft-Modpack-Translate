---
navigation:
  title: Teleport Module
  icon: nautec:teleport_module
  position: 14
  parent: submarine/submarine-index.md
item_ids:
  - nautec:teleport_module
---

# <Color id="light_purple">Teleport Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="teleport_module" scale="2"/>
  선체를 저장된 위치로 순간이동시킵니다.
</Column>

Teleport Module은 어느 차원에 있든 모듈에 저장한 앵커 지점으로 선체와 승무원을 함께 순간이동시킵니다.

***

## <Color id="gold">앵커 지정</Color>

모듈을 손에 들고 물속에 서서 웅크린 채 우클릭하세요. 현재 블록 위치, 차원, 바라보는 방향이 저장되고 좌표와 함께 앵커 지정 메시지가 표시됩니다. 선체는 저장된 방향을 향한 상태로 도착합니다. 다시 지정하면 기존 앵커가 덮어써집니다.

툴팁에는 앵커와 차원이 표시되고, 조종석의 단축 바에서 모듈을 선택하면 이름 위에 좌표가 나타납니다. 각 Teleport Module은 독립적인 앵커를 저장하므로 두 슬롯에 장착하면 목적지를 두 곳 지정할 수 있습니다. 다만 재사용 대기시간은 공유되어 순간이동 후 모든 Teleport Module이 30초 동안 대기합니다.

앵커는 주변 공간이 충분한 탁 트인 물속에 지정하세요. 선체가 크기 때문에 앵커 블록에 물이 있어야 하고 선체 전체가 들어갈 공간도 필요합니다.

***

## <Color id="gold">순간이동</Color>

| | 기본값 |
|---|---|
| 순간이동당 동력 | 200,000 |
| 시작에 필요한 저장 동력 | 200,000 (배터리 용량의 1/5) |
| 충전 시간 | 2.5초 |
| 재사용 대기시간 | 30초 |

조종석에서 모듈을 사용하세요. 기수 앞에 포털이 열리고 선체가 앞으로 빨려 들어갑니다. 2.5초 뒤 승무원이 탑승한 상태로 앵커에 나타나 약간 앞으로 이동합니다. 충전 중에는 조종과 다른 모듈 사용이 잠깁니다.

앵커가 지정되지 않았거나, 저장 동력이 200,000 미만이거나, 앵커가 물 밖에 있거나 선체가 들어갈 공간이 부족하면 안내 메시지와 함께 비용 없이 순간이동이 거부됩니다. 충전이 끝날 때도 앵커를 다시 검사합니다. 그 사이 공간이 막혔다면 순간이동이 취소되고 동력이 반환되며 재사용 대기시간도 시작되지 않으므로 즉시 다시 시도할 수 있습니다.

순간이동은 선체 기능 중 동력 소모가 가장 큽니다. 귀환 수단으로 사용할 계획이라면 미리 충전해 두세요. 모든 수치는 설정에서 변경할 수 있습니다.

***

### <Color id="aqua">Teleport Module 제작법</Color>

<Recipe id="nautec:teleport_module"/>
