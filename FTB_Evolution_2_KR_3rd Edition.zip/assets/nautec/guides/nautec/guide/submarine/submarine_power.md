---
navigation:
  title: 동력과 산소
  icon: nautec:prismatic_battery
  position: 2
  parent: submarine/submarine-index.md
---

# <Color id="light_purple">동력과 산소</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="prismatic_battery" scale="2"/>
  배터리 동력이 사용되는 곳입니다.
</Column>

Sea Scout는 1,000,000의 동력을 저장하는 배터리 하나로 추진, 승무원의 산소 공급, 모든 모듈을 작동시킵니다.

***

## <Color id="gold">운행 동력 소모</Color>

선체는 탑승자가 있을 때만 동력을 소비합니다. 아무도 타지 않은 선체는 정박 중이든 표류 중이든 충전량이 유지됩니다.

| 탑승 중 상태 | 틱당 동력 소모 |
|---|---|
| 정지 상태 | 1 |
| 이동 중 | 추가 6 |
| 승무원 산소 공급 | 추가 2 |
| [Flight Module](flight_module.md)로 비행 중 | 추가 4 |

승무원이 탑승하여 이동 중인 선체는 틱당 9의 동력을 사용하므로 완충 상태에서는 약 1시간 30분 동안 이동할 수 있습니다. 모듈도 같은 배터리를 사용하며 작동할 때 훨씬 많은 동력을 소비하므로, 모듈을 자주 사용하는 잠수에서는 더 빨리 방전됩니다([Modules](submarine_modules.md) 참조).

이 수치는 모두 설정에서 변경할 수 있습니다. 크리에이티브 모드의 조종사는 동력을 소비하지 않습니다.

***

## <Color id="gold">산소 공급</Color>

배터리에 동력이 조금이라도 남아 있으면 선체가 밀폐되어 수심과 관계없이 모든 탑승자의 산소 막대가 가득 찬 상태로 유지됩니다.

배터리가 완전히 방전되면 밀폐 기능도 사라집니다. 표시창에 CHG가 나타나고 추진기가 멈추며, 일반 수영과 마찬가지로 산소가 줄어듭니다. 그전에 수면으로 올라가거나 [Sea Scout Dock](submarine_dock.md)에 도착하세요. 비상용으로 [Diving Suit](nautec:getting_started/diving_gear.md)를 착용하는 것도 좋습니다.

선체 자체는 익사 피해를 받지 않습니다.

***

## <Color id="gold">충전</Color>

| 충전 수단 | 충전 속도 | 완충 소요 시간 |
|---|---|---|
| [Sea Scout Dock](submarine_dock.md) | 틱당 40 | 약 21분 |
| <ItemLink id="charger"/> (선체를 아이템으로 보관) | 빔 출력에 따라 틱당 최대 128 | 128 AP일 때 약 6분 30초, 출력이 낮으면 더 오래 걸림 |
| [Solar Module](solar_module.md) | 낮에 5초마다 2,000 (틱당 약 20) | 약 42분 |

선체를 충전하기에는 Dock에 정박해 두었다가 돌아오는 방법이 편리합니다. Charger를 사용하려면 먼저 선체를 아이템으로 회수해야 하며, 충전 속도는 공급되는 빔에 따라 달라집니다. 40 AP 빔은 Dock과 속도가 같고 더 강한 빔은 더 빠릅니다. Solar Module은 탑승 여부와 무관하게 작동하므로 낮에 탁 트인 수면에 정박하면 자동으로 충전됩니다.
