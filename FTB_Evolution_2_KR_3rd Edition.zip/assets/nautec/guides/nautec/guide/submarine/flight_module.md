---
navigation:
  title: Flight Module
  icon: nautec:flight_module
  position: 15
  parent: submarine/submarine-index.md
item_ids:
  - nautec:flight_module
---

# <Color id="light_purple">Flight Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="flight_module" scale="2"/>
  Sea Scout가 물 밖으로 나와 비행할 수 있게 합니다.
</Column>

Flight Module을 장착하면 선체가 물 밖으로 나와도 추락하지 않습니다. 공중에 떠서 수중과 같은 방식으로 조종할 수 있으며, 비행 속도는 더 빠릅니다.

***

## <Color id="gold">비행 방법</Color>

어느 슬롯에 장착해도 자동으로 작동합니다. 물 밖으로 이동하거나 지상에서 Space를 눌러 이륙하면 계속 비행할 수 있습니다.

* 수중과 동일하게 조종합니다. 시선을 따라 기수가 위아래로 움직이며, Space로 상승하고 C로 하강합니다.
* 공중에서는 수중보다 이동 속도와 최고 속도가 각각 약 50% 높습니다.
* 지면이나 수면으로 하강하여 착륙할 수 있습니다.

조종자가 없으면 선체가 추락하지 않고 천천히 지면으로 내려옵니다. 따라서 공중에서 내리더라도 파괴되지 않으며, 선체는 낙하 피해를 받지 않습니다.

***

## <Color id="gold">동력</Color>

탑승자가 있는 상태로 공중에 떠 있으면 일반 운행 비용 외에 틱당 4의 동력이 추가로 소모됩니다. 비행 중 전력이 고갈되면 선체도 추락하므로, 장거리 비행에서는 잔량 표시를 확인하세요.

속도 보너스와 유지 동력은 설정값(`submarineFlightSpeedMultiplier`, `submarineFlightPowerUsage`)으로 변경할 수 있습니다. 여러 개를 장착해도 효과가 중첩되지 않으므로 하나면 충분합니다.

***

### <Color id="aqua">Flight Module 제작법</Color>

<Recipe id="nautec:flight_module"/>
