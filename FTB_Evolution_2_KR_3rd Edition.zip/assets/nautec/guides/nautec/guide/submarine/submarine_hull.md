---
navigation:
  title: 선체와 수리
  icon: nautec:submarine
  position: 3
  parent: submarine/submarine-index.md
---

# <Color id="light_purple">선체와 수리</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="submarine" scale="2"/>
  선체 손상과 파손, 수리 방법을 설명합니다.
</Column>

선체에는 자체 체력과 방어력이 있으며, 탑승 중에는 플레이어 대신 선체가 공격받습니다.

***

## <Color id="gold">선체 내구도</Color>

| 항목 | 기본값 |
|---|---|
| 선체 내구도 | 80 (하트 40칸) |
| 방어력 | 20 (다이아몬드 방어구 전체 착용과 동일) |
| 방어 강도 | 8 (다이아몬드 방어구 전체 착용과 동일) |

세 수치 모두 설정에서 변경할 수 있습니다. [Armour Module](armor_module.md)은 방어 강도를 높이고 밀치기를 방지하며, [Shield Module](shield_module.md)은 동력을 소비해 피해를 흡수합니다.

탑승하면 32블록 이내에서 플레이어를 추적하던 생물의 목표가 선체로 바뀝니다. 탑승 중 플레이어를 노리는 생물도 선체를 공격합니다. 추적을 피하려면 [Stealth Module](stealth_module.md)을 사용하세요.

선체는 익사, 동결, 블록 질식, 밀집 피해, 낙하 피해를 받지 않으며 탑승자도 선체에 피해를 줄 수 없습니다. 포션과 회복 효과는 선체에 적용되지 않습니다.

***

## <Color id="gold">자동 수리</Color>

선체는 탑승 여부와 관계없이 10초마다 내구도 1%를 회복합니다. 따라서 손상된 선체도 잠시 두면 완전히 회복됩니다. 회복 간격과 양은 설정할 수 있으며 모드팩에서 자동 수리를 비활성화할 수도 있습니다.

화면의 HULL 표시에서 현재 선체 상태를 확인할 수 있습니다([조종](submarine_controls.md) 참조).

***

## <Color id="gold">선체 파손</Color>

선체 내구도가 0이 되면 탑승자는 피해 없이 밖으로 튕겨 나오고, 선체는 모듈과 충전량을 유지한 채 아이템으로 떨어집니다. 이 아이템은 파손된 상태이므로 사용하면 "The hull is breached. Repair it on an anvil before launching"이라는 메시지가 표시되며 툴팁에도 같은 내용이 나타납니다.

<Color id="gold">팁</Color>: 탑승자는 선체가 파손된 위치에서 내리게 되며, 깊은 물속일 수 있습니다. 손상된 선체로 이동할 때는 [Diving Suit](nautec:getting_started/diving_gear.md)를 착용하세요.

***

## <Color id="gold">모루에서 수리하기</Color>

<ItemImage id="deep_steel_plating" scale="1"/>

모루의 왼쪽 슬롯에 선체를, 오른쪽 슬롯에 <ItemLink id="deep_steel_plating"/>을 넣으세요. 판 하나당 내구도 20%를 회복하며 경험치 레벨 2를 소모합니다. 모루는 수리에 필요한 수량만 사용하므로 판 5개로 완전히 파손된 선체를 모두 수리할 수 있습니다.

이 방법은 완전히 파손된 선체뿐 아니라 손상된 모든 선체 아이템에 적용됩니다. Deep Steel Plating은 [Abyssal Pressure Forge](nautec:deep_engineering/pressure_forge.md)에서 제작합니다. 수리 재료와 개당 회복량은 설정할 수 있으며, 모드팩에 따라 수리 재료가 다이아몬드로 변경되었을 수도 있습니다.
