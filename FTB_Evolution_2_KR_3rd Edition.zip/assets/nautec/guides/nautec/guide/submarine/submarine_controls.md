---
navigation:
  title: Piloting
  icon: nautec:submarine
  position: 1
  parent: submarine/submarine-index.md
---

# <Color id="light_purple">Piloting</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="submarine" scale="2"/>
  조작 키, 조향 방법, 상태 표시창을 설명합니다.
</Column>

조종사는 일반 이동 키로 Sea Scout를 움직이고 시선으로 방향을 조종합니다. 탑승 중에는 단축바 대신 동력·선체 상태와 Module 막대가 표시됩니다.

***

## <Color id="gold">조작 키</Color>

| 키(기본값) | 동작 |
|---|---|
| W | 전진 |
| S | 절반 추진력으로 후진 |
| 달리기(Ctrl) + W 또는 S | 추진력 60% 증가 |
| 마우스 | 시선 방향으로 선수가 회전 |
| Space | 상승 |
| C | 잠수 |
| 우클릭 길게 누르기(사용) | 자유 시점: 방향을 바꾸지 않고 주변을 둘러보며 1인칭에서 선체를 투과해 볼 수 있음 |
| 1~9 또는 마우스 휠 | Module 슬롯 선택 |
| 좌클릭 또는 F | 선택한 Module 발사 |
| Ctrl + H | 상태 표시창 위치 조정 |
| 웅크리기(Shift) | 하차 |

C, F, Ctrl + H는 조작 설정에서 각각 Sea Scout Descend, Fire Sea Scout Module, Reposition Sea Scout HUD로 표시되는 NauTec 키입니다. 해당 메뉴에서 변경할 수 있습니다. 조종 중 F는 Module 발사에만 사용되므로 손의 아이템을 바꾸거나 Wave Jet 조명을 전환하지 않습니다.

***

## <Color id="gold">조향</Color>

별도의 회전 키는 없습니다. 선체가 시선 방향을 따라 회전하며, 물속에서는 위아래로 최대 75도까지 기울어집니다. 자유 시점 상태에서 우클릭을 놓으면 시야가 다시 선수 방향으로 돌아옵니다.

1인칭에서 자유 시점을 유지하면 선체가 반투명해져 바닥 아래를 내려다볼 수 있습니다. 투명도는 클라이언트 설정 `submarineFreeLookHullOpacity`로 조정합니다.

선체는 회전할 공간이 있을 때만 방향을 바꿉니다. 바위를 향해 시선을 돌려도 블록을 통과하지 않고 기존 방향을 유지하므로, 좁은 동굴에서는 뒤로 물러나거나 상승한 뒤 회전하세요. 충돌 판정은 회전하는 선체의 실제 모양을 따릅니다. 블록과만 충돌하며, 경로에 있는 물고기 등 생물은 옆으로 밀려납니다.

수면에서는 선체가 수평을 유지하며 추진력이 약 1/3로 줄어듭니다. 상승과 잠수도 약해지므로 빠르게 이동하려면 물속으로 들어가세요.

[Flight Module](flight_module.md)을 설치하면 공중 비행이 가능합니다. 물 밖에서도 수중과 똑같이 방향과 기울기를 조절할 수 있고, Space와 C로 최대 출력으로 상승·하강하며 이동 속도도 1.5배가 됩니다.

추진에는 동력이 필요합니다. Cell이 비면 선체는 관성으로 떠다닙니다.

탑승 중 3인칭 카메라는 선체에서 10블록 뒤에 위치해 선체 전체를 볼 수 있습니다. 거리는 `submarineCameraDistance`로 설정할 수 있습니다.

***

## <Color id="gold">상태 표시창</Color>

조종석에 앉으면 화면에 Cell의 동력을 나타내는 PWR과 선체 상태를 나타내는 HULL이 각각 백분율로 표시됩니다. 아래에는 조작 방법이 안내됩니다.

* PWR은 20% 미만에서 깜박이며 Cell이 비면 CHG로 표시됩니다.
* HULL은 35% 미만에서 빨간색으로 바뀌고 15% 미만에서 깜박입니다.

조종 중에는 이 패널이 바닐라 탈것 체력 표시, 단축바, 경험치 레벨을 대체합니다. 화면 하단에는 단축바 대신 9개의 Module 슬롯이 표시됩니다([Modules](submarine_modules.md) 참조).

언제든 Ctrl + H를 눌러 위치 조정 화면을 열고 패널을 원하는 위치로 끌어 놓으세요. Esc 또는 Ctrl + H를 다시 누르면 저장됩니다. 위치는 클라이언트 설정에 유지됩니다.

뒷좌석 승객에게는 이 패널이 표시되지 않으며 일반 단축바가 유지됩니다.
