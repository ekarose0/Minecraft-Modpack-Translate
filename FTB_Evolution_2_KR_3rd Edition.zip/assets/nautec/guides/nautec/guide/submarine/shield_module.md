---
navigation:
  title: Shield Module
  icon: nautec:shield_module
  position: 12
  parent: submarine/submarine-index.md
item_ids:
  - nautec:shield_module
---

# <Color id="light_purple">Shield Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shield_module" scale="2"/>
  선체 내구도 대신 동력을 소모합니다.
</Column>

Shield Module은 저장된 동력으로 선체가 받는 피해를 흡수하며, 직접 사용하면 선체 주변의 대상을 밀쳐낼 수도 있습니다.

***

## <Color id="gold">자동 보호막</Color>

어느 슬롯에든 장착하면 선체가 피해를 받을 때 배터리 동력이 먼저 소모됩니다. 보호막이 하트 1칸의 피해를 흡수할 때마다 10,000의 동력이 필요합니다. 먼저 선체 방어력이 피해를 줄이고, 그 뒤에 남은 피해만 보호막이 흡수합니다. 동력이 부족하면 나머지 피해는 선체에 적용됩니다.

배터리가 가득 차 있으면 최대 하트 100칸의 피해를 흡수할 수 있습니다. 하지만 같은 배터리가 추진기와 승무원 산소 공급에도 사용됩니다. 전투가 길어지면 동력이 고갈되어 산소 공급까지 끊길 수 있으므로 PWR 표시를 확인하세요.

보호막은 방어력으로 줄일 수 있는 공격만 흡수합니다. 마법, 화염, Warden의 음파 공격처럼 방어력을 무시하는 피해는 선체에 직접 적용됩니다.

***

## <Color id="gold">방전 공격</Color>

| | 기본값 |
|---|---|
| 방전당 동력 | 25,000 |
| 범위 | 선체 주변 5블록 |
| 피해량 | 10 (하트 5칸) |
| 기절 | 3초 |
| 재사용 대기시간 | 5초 |

모듈을 사용하면 선체에서 원형 충격파가 퍼집니다. 탑승자를 제외한 반경 5블록 안의 모든 생물은 10의 피해를 받고 밀려나며 3초 동안 기절합니다. 기절한 생물은 움직이거나 공격할 수 없고 기존 추적 대상도 잊습니다.

방전 공격은 적대적 생물뿐 아니라 다른 플레이어, 반려동물, 비공격적 생물에게도 적용됩니다. 사용하기 전에 주변을 확인하세요.

모든 수치는 설정에서 변경할 수 있습니다.

***

### <Color id="aqua">Shield Module 제작법</Color>

<Recipe id="nautec:shield_module"/>
