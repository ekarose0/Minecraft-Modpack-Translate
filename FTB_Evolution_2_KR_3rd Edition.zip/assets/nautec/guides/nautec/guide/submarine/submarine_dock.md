---
navigation:
  title: Sea Scout Dock
  icon: nautec:submarine_dock
  position: 4
  parent: submarine/submarine-index.md
item_ids:
  - nautec:submarine_dock
---

# <Color id="light_purple">Sea Scout Dock</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="submarine_dock" scale="2"/>
  정박한 선체를 충전하는 패드입니다.
</Column>

Sea Scout Dock는 위에 정박한 Sea Scout를 충전하고, 승무원이 없는 선체를 제자리에 고정하며, 탑승자의 호흡을 유지해 줍니다.

***

## <Color id="gold">설치 방법</Color>

Dock는 물속에도 설치할 수 있는 낮은 패드입니다. 어느 면으로든 최소 20 AP의 레이저 빔을 공급하세요([Laser Power](nautec:getting_started/laser_power.md) 참고). Dock는 빔 자체를 소모하지 않으며, 기본적으로 빔이 공급되면 충전합니다. 강한 빔에 따른 속도 증가는 아래 항목을 참고하세요.

선체를 패드 위에 정박시키세요. 패드 바로 위의 가로 3×3, 높이 3블록 영역과 선체가 겹치면 정박한 것으로 판정됩니다. 고정될 때 소리가 나며, 선체가 떠나거나 빔이 20 AP 미만으로 떨어지면 고정이 해제됩니다. <ItemLink id="prism_monocle"/>로 패드를 바라보면 Sea Scout의 정박 여부를 확인할 수 있습니다.

***

## <Color id="gold">기능</Color>

* 20 AP 빔에서는 틱당 전력 40을 충전합니다. 선체를 회수하지 않아도 방전 상태에서 완충까지 약 21분이 걸립니다. 강한 빔은 충전 속도를 높이며(아래 참고), 속도는 설정할 수 있습니다.
* 탑승자가 없는 선체를 고정하므로 나중에 돌아와도 제자리에 남아 있습니다. 조종사가 탑승하면 고정을 무시하고 바로 출발할 수 있습니다.
* 선체의 전력 셀이 비어 있어도 Dock의 전력으로 탑승자 모두가 호흡할 수 있게 합니다.

***

### <Color id="aqua">Sea Scout Dock 제작법</Color>

<Recipe id="nautec:submarine_dock"/>

***

## <Color id="gold">더 강한 레이저 빔</Color>

Submarine Dock는 최소 20 AP가 필요합니다. 빔이 강할수록 정박한 잠수함을 더 빨리 충전하며, 속도 배율은 √(빔 AP ÷ 20)입니다.

| 레이저 빔 | 속도 |
|---|---|
| 20 AP | ×1 (기본) |
| 80 AP | ×2 |
| 180 AP | ×3 |
| 320 AP | ×4 |

20 AP 빔에서는 틱당 전력 40, 80 AP 빔에서는 틱당 전력 80을 충전하며, 이후에도 같은 규칙이 적용됩니다.

계산 규칙과 적용 장치 목록은 [Stronger Beams](nautec:getting_started/stronger_beams.md)를 참고하세요.
