---
navigation:
  title: Cargo Hold Module
  icon: nautec:cargo_module
  position: 16
  parent: submarine/submarine-index.md
item_ids:
  - nautec:cargo_module
---

# <Color id="light_purple">Cargo Hold Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="cargo_module" scale="2"/>
  Sea Scout에 획득한 아이템을 보관할 화물칸을 추가합니다.
</Column>

Cargo Hold Module 하나를 장착하면 일반 상자와 같은 27칸의 화물칸이 생깁니다. 두 개를 장착하면 큰 상자와 같은 54칸이 되지만, 세 번째 모듈은 효과가 없습니다.

***

## <Color id="gold">화물칸 열기</Color>

* 조종 중에는 단축 바에서 모듈을 선택한 뒤 사용(왼쪽 클릭 또는 F)하세요. 동력을 소모하지 않고 재사용 대기시간도 없습니다.
* 밖에서는 선체 뒤쪽에 서서 우클릭하세요. 앞이나 옆에서 우클릭하면 평소처럼 탑승합니다.

Sea Scout는 자신의 화물칸은 물론 다른 Sea Scout의 화물칸에도 보관할 수 없습니다.

***

## <Color id="gold">화물 보존</Color>

화물은 선체에 저장됩니다. 선체를 회수하거나 파괴되어 아이템으로 떨어져도 내용물이 유지되므로, 다시 설치하면 모든 화물을 되찾을 수 있습니다.

Cargo Hold Module을 제거해도 내용물은 보존되지만, 다시 장착하기 전까지 접근할 수 없습니다. 모듈 두 개 중 하나를 제거하면 화물칸의 뒤쪽 절반이 숨겨지며, 재장착하면 다시 표시됩니다.

<Recipe id="nautec:cargo_module"/>
