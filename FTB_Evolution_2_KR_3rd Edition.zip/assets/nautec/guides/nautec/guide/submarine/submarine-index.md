---
navigation:
  title: 해양 장비
  icon: nautec:submarine
  position: 6
---

# <Color id="gold">해양 장비</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="submarine" scale="2"/>
  잠수정 Sea Scout와 전용 모듈, 도크, Wave Jet를 소개합니다.
</Column>

***

<SubPages icons={true}/>
