---
navigation:
  title: Sea Scout
  icon: nautec:submarine
  position: 0
  parent: submarine/submarine-index.md
item_ids:
  - nautec:submarine
---

# <Color id="light_purple">Sea Scout</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="submarine" scale="2"/>
  두 명이 탑승할 수 있는 동력식 잠수정입니다.
</Column>

Sea Scout는 자체 배터리로 플레이어와 동승자 한 명을 깊은 물속으로 운송합니다. 충전되어 있는 동안 산소를 공급하고 탑승자 대신 피해를 받습니다.

동력 1,000,000을 저장하고 선체 내구도 80을 가지며, 속도·무기·소나·보호막·순간이동 기능을 추가하는 모듈 슬롯 9개가 있습니다.

***

## <Color id="gold">진수하기</Color>

아이템을 들고 6블록 이내의 물을 바라보며 사용하세요. 수면 위에서는 바라보는 지점의 물에 진수되고, 머리가 물속에 있으면 몇 블록 앞에 진수됩니다.

진수 지점은 큰 선체 전체가 들어갈 만큼 공간이 확보된 물이어야 합니다. 공간이 부족하면 "The Sea Scout needs open water to launch into"라는 메시지가 표시되고 아이템은 소모되지 않습니다. 파손된 선체는 수리하기 전까지 진수할 수 없습니다([Hull and Repair](submarine_hull.md) 참조).

***

## <Color id="gold">탑승 좌석</Color>

선체를 우클릭하여 탑승하세요. 먼저 탄 사람이 앞좌석에서 조종하고, 두 번째 사람은 뒷좌석에 앉아 좌우 약 85도 범위를 자유롭게 둘러볼 수 있습니다. 방향 조종과 모듈 발사는 조종사만 할 수 있으며 최대 탑승 인원은 2명입니다.

웅크리기 키를 누르면 내립니다.

***

## <Color id="gold">회수하기</Color>

아무도 탑승하지 않은 선체를 웅크린 상태에서 우클릭하면 인벤토리로 회수합니다. 저장된 동력, 선체 손상, 장착된 모듈, 모듈 재사용 대기시간, 지정한 이름이 모두 유지됩니다. 툴팁에는 충전량, 선체 내구도(%)와 장착 모듈이 표시됩니다. 회수하려면 먼저 모든 탑승자가 내려야 합니다.

크리에이티브 모드에서는 선체를 공격하면 즉시 회수합니다.

***

## <Color id="gold">Sea Scout 추가 정보</Color>

* [조종](submarine_controls.md): 조작 키, 방향 조종, 화면 상태 표시
* [동력과 산소](submarine_power.md): 동력 소모량, 사용 가능 시간, 충전 방법
* [선체와 수리](submarine_hull.md): 피해, 선체 파손, Deep Steel Plating
* [모듈](submarine_modules.md): 모듈 슬롯과 각 모듈의 기능
* [Sea Scout Dock](submarine_dock.md): 선체를 정박시키고 충전하는 설비
* [Gateway](nautec:deep_engineering/gateway.md): 탑승자와 함께 통과할 수 있는 대형 고리로, 접근하면 열립니다.

***

### <Color id="aqua">Sea Scout 제작법</Color>

<Recipe id="nautec:submarine"/>
