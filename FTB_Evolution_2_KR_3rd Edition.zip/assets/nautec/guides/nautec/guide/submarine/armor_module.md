---
navigation:
  title: Armour Module
  icon: nautec:armor_module
  position: 8
  parent: submarine/submarine-index.md
item_ids:
  - nautec:armor_module
---

# <Color id="light_purple">Armour Module</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="armor_module" scale="2"/>
  선체에 더 견고한 장갑을 추가합니다.
</Column>

Armour Module은 선체의 방어 강도를 높이고 공격을 받았을 때 밀려나는 현상을 방지합니다.

***

## <Color id="gold">변경되는 능력치</Color>

| | 미장착 | 장착 |
|---|---|---|
| 방어력 | 20 | 20 |
| 방어 강도 | 8 (다이아몬드) | 12 (네더라이트) |
| 넉백 | 일반 | 없음 |

방어 강도는 강력한 공격이 방어력을 관통하는 정도를 줄여 주므로, 특히 피해량이 큰 적을 상대할 때 유용합니다. 넉백도 없어져 공격을 받아도 진행 방향에서 밀려나지 않습니다.

어느 슬롯에 장착해도 자동으로 적용되며 동력을 소모하지 않습니다. 제거하면 선체 능력치가 즉시 기본값으로 돌아갑니다. 여러 개를 장착해도 효과가 중첩되지 않으므로 하나면 충분합니다. 방어 강도는 설정값(`submarineArmorModuleToughness`)으로 조절할 수 있습니다.

장갑을 통과한 피해는 [Shield Module](shield_module.md)로 흡수할 수 있습니다. 다른 선체 방어 기능은 [선체와 수리](submarine_hull.md)를 참고하세요.

***

### <Color id="aqua">Armour Module 제작법</Color>

<Recipe id="nautec:armor_module"/>
