---
navigation:
  title: 레이저 증강
  icon: nautec:claw_robot_arm
  position: 5
---

# <Color id="gold">레이저 증강</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="claw_robot_arm" scale="2"/>
  Augmentation Station을 이용한 신체 증강 장치 장착, Aquarine Steel 방어구, 장거리 레이저 빔을 설명합니다.
</Column>

***

<SubPages icons={true}/>
