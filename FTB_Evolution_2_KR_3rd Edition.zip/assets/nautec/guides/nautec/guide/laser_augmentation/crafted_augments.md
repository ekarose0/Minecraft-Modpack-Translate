---
navigation:
  title: Crafted Augments
  icon: nautec:magnetic_coil_arm
  position: 4
  parent: laser_augmentation/laser_augmentation-index.md
item_ids:
  - nautec:hydraulic_leg
  - nautec:servo_knee
  - nautec:shock_absorber
  - nautec:tendon_weave
  - nautec:magnetic_coil_arm
  - nautec:ender_coil_arm
  - nautec:hydro_drill_arm
  - nautec:syringe_robot_arm
  - nautec:trident_launcher_arm
  - nautec:volley_trident_arm
  - nautec:buoyancy_tank
  - nautec:auxiliary_ventricle
---

# <Color id="light_purple">Crafted Augments</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="magnetic_coil_arm" scale="2"/>
  열두 가지 Augment 부품은 몹에게서 얻는 대신 제작대에서 제작할 수 있습니다.
</Column>

모든 부품은 다른 부품과 마찬가지로 [Augmentation Station](augmentation_station.md)에서 장착합니다.

***

## <Color id="gold">다리</Color>

네 가지 부품이 Left Leg와 Right Leg 슬롯을 사용합니다.

<Row>
  <ItemImage id="hydraulic_leg"/>
  ### <Color id="aqua">Hydraulic Leg</Color>
</Row>

Augment: Leap. 지상에 서서 Left Alt를 누르면 바라보는 방향으로 도약합니다. 수직으로 뛰려면 바로 위를 바라보세요. 재사용 대기시간은 1초보다 조금 깁니다.

<Recipe id="nautec:hydraulic_leg"/>

<Row>
  <ItemImage id="servo_knee"/>
  ### <Color id="aqua">Servo Knee</Color>
</Row>

Augment: Step Up. 점프하지 않고 한 블록 높이의 턱을 걸어 올라갑니다.

<Recipe id="nautec:servo_knee"/>

<Row>
  <ItemImage id="shock_absorber"/>
  ### <Color id="aqua">Shock Absorber</Color>
</Row>

Augment: Prevent Fall Damage. 높이에 관계없이 낙하 피해를 받지 않습니다. Hydraulic Leg와 함께 사용하기 좋습니다.

<Recipe id="nautec:shock_absorber"/>

<Row>
  <ItemImage id="tendon_weave"/>
  ### <Color id="aqua">Tendon Weave</Color>
</Row>

Augment: Walking Speed. 기본 걷기 속도를 일반적인 속도의 2.5배로 높입니다.

<Recipe id="nautec:tendon_weave"/>

***

## <Color id="gold">보조 팔</Color>

여섯 가지 부품이 Left Arm과 Right Arm 슬롯을 사용하며, 다음 세 가지는 단독으로 작동합니다.

<Row>
  <ItemImage id="magnetic_coil_arm"/>
  ### <Color id="aqua">Magnetic Coil Arm</Color>
</Row>

Augment: Magnet. 5블록 이내에 떨어진 아이템을 끌어옵니다. 아이템을 버릴 때처럼 잠시 중지하려면 웅크리세요. 다시 켤 때까지 끄려면 조작 설정에서 Toggle Magnet Augments 키를 지정하세요.

<Recipe id="nautec:magnetic_coil_arm"/>

<Row>
  <ItemImage id="ender_coil_arm"/>
  ### <Color id="aqua">Ender Coil Arm</Color>
</Row>

Augment: Ender Magnet. 5블록 이내의 떨어진 아이템을 인벤토리로 바로 순간이동시킵니다. 공간이 없으면 아이템은 바닥에 남습니다. 웅크려 일시 중지하거나 Toggle Magnet Augments 키로 끌 수 있습니다.

<Recipe id="nautec:ender_coil_arm"/>

<Row>
  <ItemImage id="hydro_drill_arm"/>
  ### <Color id="aqua">Hydro Drill Arm</Color>
</Row>

Augment: Underwater Mining Speed. 머리가 물속에 있을 때의 채굴 속도 감소를 없애 줍니다. 헬멧 없이 Aqua Affinity 효과를 얻는 것과 같습니다. 다만 물에 떠 있는 상태의 채굴 속도 감소는 그대로이므로 바닥에 서서 채굴하세요.

<Recipe id="nautec:hydro_drill_arm"/>

***

## <Color id="gold">투척형 팔</Color>

다음 세 가지는 키를 누르면 발사되며 재사용 대기시간은 각각 1초입니다. 탄약을 소모하지 않으며 발사체는 회수할 수 없습니다.

<Row>
  <ItemImage id="trident_launcher_arm"/>
  ### <Color id="aqua">Trident Launcher Arm</Color>
</Row>

Augment: Bouncing Trident, 기본 Y키. 삼지창을 던지면 처음 맞힌 블록에서 한 번 튕겨 계속 날아갑니다. 몹에 맞으면 튕기지 않고 끝납니다.

<Recipe id="nautec:trident_launcher_arm"/>

<Row>
  <ItemImage id="volley_trident_arm"/>
  ### <Color id="aqua">Volley Trident Arm</Color>
</Row>

Augment: Spreading Trident, 기본 U키. 던진 삼지창이 블록에 닿으면 충돌 지점에서 세 갈래로 퍼집니다. 몹 무리 근처의 바닥이나 벽을 조준하세요.

<Recipe id="nautec:volley_trident_arm"/>

<Row>
  <ItemImage id="syringe_robot_arm"/>
  ### <Color id="aqua">Syringe Robot Arm</Color>
</Row>

Augment: Random Potion Throwing, 기본 G키. Healing, Harming, Regeneration, Swiftness, Slowness 중 무작위 물약을 투척합니다. 다섯 가지 중 두 가지는 맞은 대상에게 피해를 주거나 둔화시키므로 자기 발밑에 던지지 마세요.

<Recipe id="nautec:syringe_robot_arm"/>

***

## <Color id="gold">몸통과 심장</Color>

<Row>
  <ItemImage id="buoyancy_tank"/>
  ### <Color id="aqua">Buoyancy Tank</Color>
</Row>

Augment: Creative Flight, Body 슬롯. 크리에이티브 모드처럼 비행할 수 있습니다. 물속이나 물 밖에서 점프를 두 번 눌러 이륙하세요. Body 슬롯을 사용하므로 Dolphin Fin 또는 Photophore Skin을 대체합니다.

<Recipe id="nautec:buoyancy_tank"/>

<Row>
  <ItemImage id="auxiliary_ventricle"/>
  ### <Color id="aqua">Auxiliary Ventricle</Color>
</Row>

Augment: Bonus Hearts, Heart 슬롯. 최대 체력이 하트 10개에서 20개로 두 배가 됩니다. <ItemLink id="eldritch_heart"/> Augment와 Heart 슬롯을 공유하므로 최대 체력 증가와 물속 회복 중 하나를 선택해야 합니다.

<Recipe id="nautec:auxiliary_ventricle"/>
