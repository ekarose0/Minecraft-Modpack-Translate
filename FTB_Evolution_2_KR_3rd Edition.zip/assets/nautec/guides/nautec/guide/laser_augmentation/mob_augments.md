---
navigation:
  title: Mob Augments
  icon: nautec:dolphin_fin
  position: 3
  parent: laser_augmentation/laser_augmentation-index.md
item_ids:
  - nautec:guardian_eye
  - nautec:dolphin_fin
  - nautec:drowned_lungs
  - nautec:eldritch_heart
---

# <Color id="light_purple">Mob Augments</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="dolphin_fin" scale="2"/>
  바닐라 바다 몹이 떨어뜨리는 장기에서 네 종류의 Augment를 얻을 수 있습니다.
</Column>

각 장기는 별도 제작 없이 획득한 그대로 [Augmentation Station](augmentation_station.md)에서 장착합니다.

***

<Row>
  <ItemImage id="guardian_eye"/>
  ### <Color id="aqua">Guardian Eye</Color>
</Row>

슬롯: Eyes. Guardian 약 40마리당 1마리꼴로 떨어뜨립니다.

L키를 누르고 있으면 시선 방향으로 최대 15블록 떨어진 첫 번째 생명체에 Guardian 빔을 발사합니다. 단단한 블록에 닿으면 막히므로 목표까지 시야가 확보되어야 합니다. 물은 빔을 막지 않습니다. 명중할 때마다 마법 피해 3을 입히며(설정값 `guardianAugmentDamage`), 재사용 대기시간이나 전력 소모 없이 키를 누르는 동안 계속 발사합니다.

Abyssal Eyes와 Eyes 슬롯을 공유합니다.

***

<Row>
  <ItemImage id="dolphin_fin"/>
  ### <Color id="aqua">Dolphin Fin</Color>
</Row>

슬롯: Body. Dolphin 약 5마리당 1마리꼴로 떨어뜨립니다.

머리가 물속에 있으면 Dolphin's Grace II 효과를 받아 훨씬 빠르게 수영합니다. 비행 능력 및 Photophore Skin과 같은 Body 슬롯을 사용합니다.

***

<Row>
  <ItemImage id="drowned_lungs"/>
  ### <Color id="aqua">Drowned Lungs</Color>
</Row>

슬롯: Lungs. Drowned 약 20마리당 1마리꼴로 떨어뜨립니다.

물속에서 공기 게이지를 항상 가득 유지해 익사하지 않게 합니다. Lungs 슬롯을 사용하는 유일한 Augment이므로 다른 부품과 경쟁하지 않습니다.

***

<Row>
  <ItemImage id="eldritch_heart"/>
  ### <Color id="aqua">Eldritch Heart</Color>
</Row>

슬롯: Heart. Elder Guardian 한 마리당 약 60% 확률로 최소 1개를 떨어뜨립니다.

물속에 있는 동안 매초 하트 반 칸을 회복합니다.

Augmentation Station 제작에도 하나가 필요하므로 첫 번째 획득품은 제작용으로 보관하세요. 최대 체력을 두 배로 늘려 주는 [Crafted Augments](crafted_augments.md)의 Auxiliary Ventricle과 Heart 슬롯을 공유합니다.
