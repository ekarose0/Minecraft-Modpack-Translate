---
navigation:
  title: Augmentation Station
  icon: nautec:augmentation_station
  position: 1
  parent: laser_augmentation/laser_augmentation-index.md
item_ids:
  - nautec:augmentation_station
  - nautec:augmentation_station_extension
  - nautec:claw_robot_arm
---

# <Color id="light_purple">Augmentation Station</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="augmentation_station" scale="2"/>
  Augmentation Station은 신체에 Augment를 장착하는 다중 블록 구조물입니다.
</Column>

중앙 블록에 플레이어가 서고, 주변의 네 Extension에 부품을 넣으면 로봇 팔이 장착 작업을 진행합니다.

***

## <Color id="gold">건설 방법</Color>

구조물은 모서리 네 칸이 비어 있는 5×5 크기의 단층입니다.

* 중앙에 Augmentation Station을 놓습니다.
* 중앙의 동서남북 바로 옆에 Polished Prismarine을 놓습니다.
* 네 대각선에 Aquarine Steel Block을 놓습니다.
* 중앙에서 각 방향으로 두 칸 떨어진 곳에 Augmentation Station Extension을 놓습니다.

<GameScene zoom="4" background="#333333" interactive={true}>
  <Block id="nautec:augmentation_station_extension" x="2" y="0" z="0"/>
  <Block id="nautec:aquarine_steel_block" x="1" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="1"/>
  <Block id="nautec:aquarine_steel_block" x="3" y="0" z="1"/>
  <Block id="nautec:augmentation_station_extension" x="0" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="2"/>
  <Block id="nautec:augmentation_station" x="2" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="2"/>
  <Block id="nautec:augmentation_station_extension" x="4" y="0" z="2"/>
  <Block id="nautec:aquarine_steel_block" x="1" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="3"/>
  <Block id="nautec:aquarine_steel_block" x="3" y="0" z="3"/>
  <Block id="nautec:augmentation_station_extension" x="2" y="0" z="4"/>
  <IsometricCamera yaw="225" pitch="30"/>
</GameScene>

웅크리지 않은 상태에서 <ItemLink id="aquarine_steel_wrench"/>로 중앙 Augmentation Station을 우클릭하면 구조물이 완성됩니다. Extension 하나만 사용할 예정이어도 네 개 모두 설치해야 합니다. 완성된 구조물의 블록을 하나라도 부수면 전체가 해체되므로 블록을 복구하고 Wrench로 다시 완성하세요.

***

## <Color id="gold">Extension에 부품 넣기</Color>

완성된 Extension을 우클릭하면 슬롯 두 개가 있는 화면이 열립니다. 각 슬롯에는 아이템 하나씩 들어갑니다.

* 위쪽 슬롯에는 <ItemLink id="claw_robot_arm"/>을 넣습니다. 없으면 해당 Extension은 무시됩니다.
* 아래쪽 슬롯에는 장착하려는 부품을 넣습니다.

Augment가 요구하는 부품 수만큼 Extension을 채우세요. 대부분 부품 하나만 필요하므로 Extension 하나만 채우고 나머지는 비워 둡니다. 예외인 Vent Carapace는 네 Extension 각각에 Chitin Plate를 하나씩 넣어야 합니다. 장착된 Extension 구성이 제작법과 정확히 일치해야 인식되므로 불필요한 Extension에 부품을 넣으면 장착할 수 없습니다.

***

## <Color id="gold">전력 공급</Color>

부품이 들어 있는 Extension마다 아래 블록에서 위로 들어오는 최소 25 AP의 레이저 빔이 필요합니다. 전력은 소비되지 않고 충족 여부만 확인하지만, 장착 작업 내내 25 AP 이상을 유지해야 합니다. 비어 있는 Extension에는 빔이 필요하지 않습니다.

빔이 아래에서 들어와야 하므로 바닥 아래에 Catalyst나 Relay를 설치하고 수직 위로 발사하세요. 빔 생성 방법은 [Laser Power](nautec:getting_started/laser_power.md)를 참고하세요.

25 AP 기준은 `augmentationPowerRequirement`에서 설정할 수 있습니다.

***

## <Color id="gold">사용법</Color>

중앙 블록에 서면 0.5초 후 화면이 열립니다. 서 있는 동안 화면이 실시간 갱신되므로 열린 상태에서 부품을 넣거나 빔을 조정할 수 있습니다.

* 위쪽 상태 표시줄에 준비 여부와 문제가 있다면 그 이유가 표시됩니다. 커서를 올리면 자세한 설명이 나옵니다.
* Augment 상자에는 장착된 부품으로 만들 Augment의 이름과 효과가 표시됩니다.
* 네 Extension 열에는 각 부품과 공급받는 빔이 표시됩니다. Claw Robot Arm이 없으면 빨간 테두리가 나타나고, 전력 수치는 25 AP 이상이면 초록색, 미만이면 빨간색입니다. 커서를 올리면 세부 정보를 볼 수 있습니다.
* 왼쪽의 플레이어 그림에 커서를 올리면 이미 장착한 Augment를 확인할 수 있습니다.

아래에서 신체 슬롯을 고르고 Apply를 누르세요. 이미 Augment가 있으면 Apply 버튼이 빨갛게 변하고 툴팁에 교체할 대상이 표시됩니다. 화면을 닫았다면 중앙에서 내려왔다가 다시 올라가 열 수 있습니다. 완성되지 않은 Station에 서면 단축바 위에 안내가 나옵니다.

다음 4초 동안 로봇 팔이 작업하는 동안 움직일 수 없고 진행 표시줄이 나타납니다. 중앙에서 벗어나거나 빔이 25 AP 미만으로 떨어지거나 부품이 제거되면 취소되며 재료는 소비되지 않습니다. 완료되면 부품은 소비되고 Claw Robot Arm은 남으며 선택한 신체 슬롯에 Augment가 장착됩니다.

Augment를 제거하려면 먼저 Extension에서 모든 부품을 꺼내세요. 아무것도 들어 있지 않으면 아래 버튼에 Augment가 장착된 슬롯이 표시되고 Apply가 Remove로 바뀝니다. 슬롯을 골라 누르면 4초간 움직일 수 없으며, 완료되면 Augment가 제거되고 부품이 인벤토리로 돌아옵니다. 제거할 때는 빔이 필요하지 않습니다.

각 슬롯에 장착할 수 있는 종류와 교체·제거 방법은 [Player Augmentation](augmentation.md)을 참고하세요.

***

## <Color id="gold">제작법</Color>

<Recipe id="nautec:augmentation_station"/>

<Recipe id="nautec:augmentation_station_extension"/>

<Recipe id="nautec:claw_robot_arm"/>

***

## <Color id="gold">강한 빔</Color>

사용 중인 Extension마다 25 AP가 필요합니다. 강한 빔은 장착 시간을 줄이며 속도는 √(빔 전력 ÷ 25)입니다. 장착 작업은 가장 약한 Extension의 속도를 따르므로 전력을 고르게 공급하세요.

| 빔 | 속도 |
|---|---|
| 25 AP | ×1 (기본) |
| 100 AP | ×2 |
| 225 AP | ×3 |
| 400 AP | ×4 |

기본 장착 시간 4초는 모든 Extension에 25 AP가 공급될 때의 수치입니다.

공식과 적용 기계 목록은 [Stronger Beams](nautec:getting_started/stronger_beams.md)를 참고하세요.
