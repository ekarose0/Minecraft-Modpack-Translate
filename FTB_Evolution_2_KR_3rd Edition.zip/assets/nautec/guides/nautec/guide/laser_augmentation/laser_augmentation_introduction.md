---
navigation:
  title: Introduction to Laser Augmentation
  icon: nautec:eldritch_heart
  position: 0
  parent: laser_augmentation/laser_augmentation-index.md
---

# <Color id="light_purple">Introduction to Laser Augmentation</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="eldritch_heart" scale="2"/>
  Augment는 Augmentation Station에서 신체에 장착하는 영구적인 강화 장치입니다.
</Column>

Augment는 신체 슬롯 하나에 장착되며, 이후 자동으로 작동하거나 능동형인 경우 지정 키를 눌러 사용합니다. 장착한 뒤에는 전력이 필요하지 않고, 사망해도 유지됩니다.

***

## <Color id="gold">준비물</Color>

* [Augmentation Station](augmentation_station.md): 본체 블록, Polished Prismarine 4개, Aquarine Steel Block 4개, <ItemLink id="augmentation_station_extension"/> 4개를 설치하고 <ItemLink id="aquarine_steel_wrench"/>로 구조물을 완성합니다. 본체 제작에는 <ItemLink id="eldritch_heart"/>가 필요하므로 먼저 Elder Guardian을 처치해야 합니다.
* 부품을 넣는 확장 장치에 <ItemLink id="claw_robot_arm"/>를 설치합니다.
* 해당 확장 장치의 아래쪽으로 최소 25 AP의 레이저 빔을 공급합니다.
* 장착할 부품을 준비합니다.

***

## <Color id="gold">부품 획득처</Color>

* [Mob Augments](mob_augments.md): Guardian, Dolphin, Drowned, Elder Guardian이 떨어뜨리는 장기입니다.
* [Crafted Augments](crafted_augments.md): 제작대에서 만드는 다리, 팔, 비행 탱크, 보조 심장 장치입니다.
* [Deep Fauna Augments](deep_fauna_augments.md): NauTec의 네 가지 바다 바이옴 생물에게서 얻는 부품입니다.

JEI의 Augmentation Effects 항목에서 모든 부품의 장착 슬롯과 효과를 확인할 수 있습니다.

***

## <Color id="gold">장착 및 사용</Color>

[Player Augmentation](augmentation.md)에서는 신체 슬롯, 장착 방법, 능동형 Augment의 단축키 및 교체 방법을 설명합니다.

같은 챕터에서 저장된 전력으로 작동하는 [Aquarine Steel Armor](aquarine_steel_armor.md)도 다룹니다.
