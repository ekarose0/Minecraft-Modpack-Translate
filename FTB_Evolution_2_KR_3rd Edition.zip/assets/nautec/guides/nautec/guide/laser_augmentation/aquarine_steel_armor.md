---
navigation:
  title: Aquarine Steel Armor
  icon: nautec:aquarine_steel_chestplate
  position: 6
  parent: laser_augmentation/laser_augmentation-index.md
item_ids:
  - nautec:aquarine_steel_helmet
  - nautec:aquarine_steel_chestplate
  - nautec:aquarine_steel_leggings
  - nautec:aquarine_steel_boots
---

# <Color id="light_purple">Aquarine Steel Armor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquarine_steel_chestplate" scale="2"/>
  Aquarine Steel Armor는 저장된 전력으로 작동하며, 충전된 상태에서 훨씬 뛰어난 방어력을 제공합니다.
</Column>

각 부위는 최대 512 AP를 저장합니다. 아이템의 전력 막대는 충전 상태를, 툴팁은 정확한 충전량을 표시합니다.

***

## <Color id="gold">방어 성능</Color>

충전되지 않은 상태에서는 투구 방어력 3, 흉갑 8, 레깅스 6, 부츠 3을 제공하며, 각 부위마다 방어 강도 3과 밀치기 저항 10%가 추가됩니다.

전력이 남아 있는 부위는 각각 방어력 10과 방어 강도 5를 추가로 제공합니다. 바닐라의 상한(방어력 30, 방어 강도 20)은 그대로 적용되므로, 모든 부위가 충전되면 두 수치 모두 상한에 도달합니다. 한 부위의 전력이 소진되어도 그 부위의 추가 효과만 사라지고, 다른 충전 부위의 효과는 유지됩니다.

***

## <Color id="gold">내구도 대신 전력 소모</Color>

방어구는 내구도가 줄어들지 않습니다. 원래 내구도를 소모할 피해를 받으면 대신 전력이 소모되므로, 격렬한 전투에서는 더 빨리 방전됩니다. 내구성 마법부여는 레벨당 전력 소모를 10% 줄여 줍니다.

<ItemLink id="charger"/>에서 충전하세요. 수리는 필요하지 않습니다.

***

## <Color id="gold">제작법</Color>

<Recipe id="nautec:aquarine_helmet"/>

<Recipe id="nautec:aquarine_chestplate"/>

<Recipe id="nautec:aquarine_leggings"/>

<Recipe id="nautec:aquarine_boots"/>

***

## <Color id="gold">관련 도구</Color>

Aquarine Steel 검, 곡괭이, 도끼, 삽, 괭이도 저장된 전력으로 작동합니다. 자세한 내용은 [Aquarine Steel Tools](nautec:laser_chemistry/tools.md)에서 확인하세요.
