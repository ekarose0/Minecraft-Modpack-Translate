---
navigation:
  title: Player Augmentation
  icon: nautec:claw_robot_arm
  position: 2
  parent: laser_augmentation/laser_augmentation-index.md
---

# <Color id="light_purple">Player Augmentation</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="claw_robot_arm" scale="2"/>
  신체에는 9개의 Augment 슬롯이 있으며, 슬롯마다 Augment 1개를 장착할 수 있습니다.
</Column>

Augment마다 장착 가능한 슬롯이 정해져 있습니다. Station 위에 올라서면 해당 부품을 장착할 수 있는 슬롯이 화면에 표시됩니다.

***

## <Color id="gold">신체 슬롯</Color>

| 슬롯 | 장착 가능한 Augment |
|---|---|
| Head | Vent Carapace, Resonance (Resonance Charm) |
| Eyes | Guardian Eye, Abyssal Eyes |
| Body | Dolphin Fin, Creative Flight (Buoyancy Tank), Photophore Skin, Vent Carapace |
| Lungs | Drowned Lung |
| Heart | Eldritch Heart, Bonus Hearts (Auxiliary Ventricle) |
| Left Arm, Right Arm | Magnet, Ender Magnet, Underwater Mining Speed, Bouncing Trident, Spreading Trident, Random Potion Throwing |
| Left Leg, Right Leg | Leap, Step Up, Prevent Fall Damage, Walking Speed |

Flight, Dolphin Fin, Photophore Skin은 모두 Body 슬롯을 사용하므로 셋 중 하나만 선택할 수 있습니다. Vent Carapace를 Head 슬롯에 장착하면 Body 슬롯을 비워 둘 수 있지만 Resonance Augment와 슬롯이 겹칩니다.

Resonance Augment는 [Resonance Charm](nautec:deep_engineering/resonance_network.md)을 부품으로 장착한 것으로, Charm 슬롯을 사용하지 않고 아이템을 충전할 수 있습니다.

같은 다리 부품을 양쪽에 장착해도 효과가 중첩되지 않으므로 서로 다른 부품을 장착하세요. Head와 Body에 Vent Carapace를 동시에 장착해도 마찬가지입니다.

***

## <Color id="gold">장착</Color>

완성된 [Augmentation Station](augmentation_station.md)의 확장 장치 하나에 부품과 Claw Robot Arm을 넣고 아래에서 25 AP 빔을 공급합니다. 가운데 블록 위에 올라서서 슬롯을 선택한 뒤 Apply를 누르세요. 장착에는 4초가 걸리며 그동안 움직일 수 없습니다.

***

## <Color id="gold">교체 및 제거</Color>

이미 Augment가 장착된 슬롯에 새 부품을 설치하면 기존 Augment가 교체됩니다. 기존 부품은 반환되지 않고 파괴됩니다.

슬롯을 비우려면 Station 확장 장치에서 모든 부품을 꺼낸 뒤 가운데 블록에 올라서세요. 화면 아래 버튼에 장착된 Augment 목록이 표시됩니다. 하나를 선택하고 Remove를 누르세요. 장착할 때와 마찬가지로 4초간 움직일 수 없으며, 중간에 내려오면 취소됩니다. 부품은 장착 당시의 데이터를 유지한 채 반환되므로 Resonance Charm의 연결 정보도 보존됩니다. 인벤토리가 가득 차면 발밑에 떨어집니다. 제거에는 빔이나 추가 부품이 필요하지 않습니다.

관리자는 `/nautec augments remove <slot>`(예: `nautec:left_arm`) 또는 `/nautec augments clear` 명령어를 사용할 수 있습니다. 명령어는 실행한 플레이어에게 적용됩니다.

사망해도 장착한 Augment는 유지됩니다.

***

## <Color id="gold">단축키</Color>

대부분의 Augment는 자동으로 작동하지만 일부는 단축키가 필요합니다. 조작 설정의 Nautec 항목에서 확인할 수 있습니다.

| 키(기본값) | 단축키 이름 | Augment |
|---|---|---|
| B | Open the Augmentation Screen | 장착한 Augment와 슬롯 표시 |
| L (hold) | Activate Guardian Eye Augment Laser | Guardian Eye |
| Left Alt | Leap | Leap (Hydraulic Leg) |
| Y | Throw Trident | Bouncing Trident (Trident Launcher Arm) |
| U | Throw Spreading Trident | Spreading Trident (Volley Trident Arm) |
| G | Throw Potion | Random Potion Throwing (Syringe Robot Arm) |
| 미지정 | Toggle Magnet Augments | Magnet 및 Ender Magnet 켜기/끄기 |

활성형 Augment는 동력이나 아이템을 소비하지 않습니다. Leap와 세 종류의 투척 팔에는 짧은 재사용 대기시간이 있으며, Guardian Eye는 키를 누르고 있는 동안 계속 발사됩니다.
