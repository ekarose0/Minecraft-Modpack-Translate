---
navigation:
  title: Deep Fauna Augments
  icon: nautec:abyssal_organ
  position: 5
  parent: laser_augmentation/laser_augmentation-index.md
item_ids:
  - nautec:abyssal_organ
  - nautec:luminous_membrane
  - nautec:chitin_plate
---

# <Color id="light_purple">Deep Fauna Augments</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="abyssal_organ" scale="2"/>
  NauTec 바다 바이옴의 생물에게서 세 종류의 Augment를 얻을 수 있습니다.
</Column>

이 생물들은 해당 부품을 반드시 떨어뜨리며, 약탈 마법부여로 하나를 더 얻을 수 있습니다. 각 생물의 생성 위치는 [Life in the Deep](nautec:getting_started/deep_life.md)을 참고하세요. 세 부품 모두 행운의 낚시 구역에서도 얻을 수 있습니다([Fishing](nautec:getting_started/fishing.md) 참고).

***

<Row>
  <ItemImage id="abyssal_organ"/>
  ### <Color id="aqua">Abyssal Eyes</Color>
</Row>

부품: Abyssal Organ. Abyssal Maw 한 마리당 하나를 얻습니다. 이 생물은 Y 40 아래의 Abyssal Trench에서 사냥합니다.

슬롯: Eyes. Y 45 이하에서 야간 투시 효과를 제공합니다(설정값 `abyssalEyesDepth`). 그보다 위에서는 작동하지 않으며, 경계 위로 올라가면 약 10초 이내에 효과가 사라집니다.

<ItemLink id="guardian_eye"/>와 Eyes 슬롯을 공유합니다.

***

<Row>
  <ItemImage id="luminous_membrane"/>
  ### <Color id="aqua">Photophore Skin</Color>
</Row>

부품: Luminous Membrane. Bioluminescent Grove의 Lantern Jelly 한 마리당 1~2개를 얻습니다.

슬롯: Body. 물속에 있는 동안 12블록 이내의 모든 생명체에 발광 효과가 적용되어 블록 너머로 윤곽을 볼 수 있습니다(설정값 `photophoreSkinRadius`). 물 밖에서는 효과가 없습니다.

비행 능력 및 Dolphin Fin과 같은 Body 슬롯을 사용합니다.

***

<Row>
  <ItemImage id="chitin_plate"/>
  ### <Color id="aqua">Vent Carapace</Color>
</Row>

부품: Chitin Plate 4개. 확장 장치 네 곳에 하나씩 배치합니다. Hydrothermal Vents의 Vent Crawler 한 마리당 1~3개를 얻습니다. 각 확장 장치에는 Claw Robot Arm과 별도의 25 AP 빔이 필요합니다([Augmentation Station](augmentation_station.md) 참고).

슬롯: Head 또는 Body. 방어력 4와 밀치기 저항 50%를 추가하고, 불에 타는 시간을 절반으로 줄입니다. Body 슬롯을 다른 용도로 사용하려면 Head 슬롯에 장착하세요. 다른 슬롯에 두 번째 갑각을 장착해도 효과가 중첩되지 않습니다.
