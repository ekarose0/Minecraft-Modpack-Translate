---
navigation:
  title: NauTec 2
  icon: nautec:nautec_guide
  position: 0
item_ids:
  - nautec:nautec_guide
---

# <Color id="gold">NauTec 2</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquatic_catalyst" scale="2"/>
  레이저 빔으로 작동하는 해양 기술 모드입니다.
</Column>

NauTec의 기계는 한 블록에서 다른 블록으로 발사하는 레이저 동력(AP)으로 작동합니다. 이 가이드에서는 레이저 빔의 생성과 전달, 빔을 사용하는 기계, 자원 생산을 위한 박테리아 배양, 신체 증강 장치 장착, 잠수정 Sea Scout를 설명합니다.

처음 시작하신다면 [소개](getting_started/introduction.md)를 읽고 [레이저 동력](getting_started/laser_power.md)을 참고하여 첫 번째 빔을 발사해 보세요.

***

## <Color id="gold">목차</Color>

* <ItemImage id="prismarine_crystal" scale="0.75"/> [시작하기](getting_started/getting_started-index.md)
* <ItemImage id="eas_vial" scale="0.75"/> [레이저 화학](laser_chemistry/laser_chemistry-index.md)
* <ItemImage id="petri_dish" scale="0.75"/> [수생 생물학](aquatic_biology/aquatic_biology-index.md)
* <ItemImage id="resonant_shard" scale="0.75"/> [심해 공학](deep_engineering/deep_engineering-index.md)
* <ItemImage id="claw_robot_arm" scale="0.75"/> [레이저 증강](laser_augmentation/laser_augmentation-index.md)
* <ItemImage id="submarine" scale="0.75"/> [해양 장비](submarine/submarine-index.md)

***

## <Color id="gold">이 가이드북</Color>

<RecipeFor id="nautec_guide"/>

NauTec 아이템에 마우스를 올리고 GuideMe 가이드 키를 누르면 해당 설명 페이지로 바로 이동합니다.
