---
navigation:
  title: Fusion Plant
  icon: nautec:fusion_controller
  position: 8
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:fusion_controller
  - nautec:fusion_casing
  - nautec:aquamarine_structural_glass
  - nautec:laser_injector
  - nautec:fusion_collector
  - nautec:containment_coil
  - nautec:fusion_port
---

# <Color id="light_purple">Fusion Plant</Color>

<Column alignItems="center" fullWidth={true}>
  <Row>
    <ItemImage id="fusion_controller" scale="2"/>
    <ItemImage id="laser_injector" scale="2"/>
    <ItemImage id="containment_coil" scale="2"/>
  </Row>
  Cultivated Prismarine Crystal을 중심으로 건설하는 레이저 핵융합 반응로입니다. Salt Water를 연료로 다른 모드 기계에 공급할 Forge Energy(FE)를 생산합니다.
</Column>

Laser Injector가 중심 결정에 빔을 발사하면 결정이 플라스마 빔으로 바꾸어 두 Fusion Collector에 전달합니다. 플라스마는 Salt Water를 융합해 FE를 생산합니다. 작은 반응실은 약 20,000 FE/t, Containment Coil을 충분히 설치한 대형 반응실은 300,000 FE/t를 생산하며, 모서리에 위성 결정을 추가하면 최대 700,000 FE/t까지 높일 수 있습니다.

***

## <Color id="gold">필요한 재료</Color>

* [결정 재배](crystal_cultivation.md)에서 설명한 방법으로 키운 Cultivated Prismarine Crystal. 중심 결정은 반드시 재배한 것이어야 합니다.
* 순도 2.0 이상의 레이저 빔. 순도 3.0에서 기본 효율인 AP당 50 FE를 얻으므로 고출력 설비는 다른 결정을 거쳐 공급합니다. 최대 성능의 [Bacterial Fuel Cell](nautec:aquatic_biology/bacterial_fuel_cell.md)(순도 2.5)은 그 효율의 5/6입니다. 순도 3.0보다 높은 빔은 더 많은 전력을 생산합니다(아래 가동 방법 참고).
* [Deep Sea Drain](nautec:laser_chemistry/drain.md)으로 안정적으로 공급하는 Salt Water.
* 아래 구성품. JEI에서 제작법을 확인할 수 있으며 Deep Steel Plating, Atlantic Gold, Ender Pearl, Flawless Prismarine Crystal, 그리고 Controller에는 Nether Star가 필요합니다.

***

## <Color id="gold">반응실 건설</Color>

결정은 속이 빈 정사각형 상자 중앙에 세웁니다. 내부 높이는 결정과 같은 정확히 6블록이며, 내부 가로·세로는 3, 5, 7, 9블록 중 하나입니다. 벽·바닥·천장은 내부 공간을 둘러싸는 두께 1블록으로 만듭니다.

<GameScene zoom="2.5" background="#333333" interactive={true}>
  <Block id="nautec:fusion_casing" x="0" y="0" z="0"/>
  <Block id="nautec:fusion_casing" x="1" y="0" z="0"/>
  <Block id="nautec:fusion_casing" x="2" y="0" z="0"/>
  <Block id="nautec:fusion_casing" x="3" y="0" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="0" z="0"/>
  <Block id="nautec:fusion_casing" x="0" y="0" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="0" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="2" y="0" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="0" z="1"/>
  <Block id="nautec:fusion_casing" x="4" y="0" z="1"/>
  <Block id="nautec:fusion_casing" x="0" y="0" z="2"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="0" z="2"/>
  <Block id="nautec:fusion_collector" x="2" y="0" z="2"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="0" z="2"/>
  <Block id="nautec:fusion_casing" x="4" y="0" z="2"/>
  <Block id="nautec:fusion_casing" x="0" y="0" z="3"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="0" z="3"/>
  <Block id="nautec:aquamarine_structural_glass" x="2" y="0" z="3"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="0" z="3"/>
  <Block id="nautec:fusion_casing" x="4" y="0" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="0" z="4"/>
  <Block id="nautec:fusion_casing" x="1" y="0" z="4"/>
  <Block id="nautec:fusion_casing" x="2" y="0" z="4"/>
  <Block id="nautec:fusion_casing" x="3" y="0" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="0" z="4"/>
  <Block id="nautec:fusion_casing" x="0" y="1" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="1" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="2" y="1" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="1" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="1" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="1" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="1" z="2"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="1" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="1" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="1" z="4"/>
  <Block id="nautec:fusion_casing" x="0" y="2" z="0"/>
  <Block id="nautec:containment_coil" x="1" y="2" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="2" y="2" z="0"/>
  <Block id="nautec:containment_coil" x="3" y="2" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="2" z="0"/>
  <Block id="nautec:fusion_port" x="0" y="2" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="2" z="2"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="2" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="2" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="2" z="4"/>
  <Block id="nautec:fusion_casing" x="0" y="3" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="3" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="2" y="3" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="3" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="3" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="3" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="3" z="2"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="3" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="3" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="3" z="4"/>
  <Block id="nautec:fusion_casing" x="0" y="4" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="4" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="2" y="4" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="4" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="4" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="4" z="1"/>
  <Block id="nautec:laser_injector" x="0" y="4" z="2" p:facing="east"/>
  <Block id="nautec:laser_injector" x="4" y="4" z="2" p:facing="west"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="4" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="4" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="4" z="4"/>
  <Block id="nautec:fusion_casing" x="0" y="5" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="5" z="0"/>
  <Block id="nautec:fusion_controller" x="2" y="5" z="0" p:facing="north"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="5" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="5" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="5" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="5" z="2"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="5" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="5" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="5" z="4"/>
  <Block id="nautec:fusion_casing" x="0" y="6" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="1" y="6" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="2" y="6" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="3" y="6" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="6" z="0"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="6" z="1"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="6" z="2"/>
  <Block id="nautec:aquamarine_structural_glass" x="0" y="6" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="6" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="6" z="4"/>
  <Block id="nautec:fusion_casing" x="0" y="7" z="0"/>
  <Block id="nautec:fusion_casing" x="1" y="7" z="0"/>
  <Block id="nautec:fusion_casing" x="2" y="7" z="0"/>
  <Block id="nautec:fusion_casing" x="3" y="7" z="0"/>
  <Block id="nautec:fusion_casing" x="4" y="7" z="0"/>
  <Block id="nautec:fusion_casing" x="0" y="7" z="1"/>
  <Block id="nautec:fusion_casing" x="4" y="7" z="1"/>
  <Block id="nautec:fusion_casing" x="0" y="7" z="2"/>
  <Block id="nautec:fusion_collector" x="2" y="7" z="2"/>
  <Block id="nautec:fusion_casing" x="4" y="7" z="2"/>
  <Block id="nautec:fusion_casing" x="0" y="7" z="3"/>
  <Block id="nautec:fusion_casing" x="4" y="7" z="3"/>
  <Block id="nautec:fusion_casing" x="0" y="7" z="4"/>
  <Block id="nautec:fusion_casing" x="1" y="7" z="4"/>
  <Block id="nautec:fusion_casing" x="2" y="7" z="4"/>
  <Block id="nautec:fusion_casing" x="3" y="7" z="4"/>
  <Block id="nautec:fusion_casing" x="4" y="7" z="4"/>
  <BoxAnnotation min="2 1 2" max="3 7 3" color="#52e8ff" thickness="0.6">
Cultivated Prismarine Crystal을 이 위치에 세워 바닥부터 천장까지 채웁니다.
  </BoxAnnotation>
  <BlockAnnotation x="2" y="5" z="0" color="#ffd86b">
Fusion Controller입니다. 가장자리를 제외한 옆벽에 바깥쪽을 향하게 설치합니다.
  </BlockAnnotation>
  <BlockAnnotation x="0" y="4" z="2" color="#52e8ff">
Laser Injector입니다. 결정 중심부 높이의 옆벽 중앙에 놓고 결정을 향하게 합니다.
  </BlockAnnotation>
  <BlockAnnotation x="2" y="0" z="2" color="#b8a6ff">
Fusion Collector입니다. 바닥 중앙에 놓고 천장 중앙에도 하나 더 놓습니다.
  </BlockAnnotation>
  <BlockAnnotation x="1" y="2" z="0" color="#ffd86b">
Containment Coil입니다. 벽·바닥·천장의 어느 곳에나 배치할 수 있습니다.
  </BlockAnnotation>
  <BlockAnnotation x="0" y="2" z="1" color="#8cc4f2">
Fusion Port입니다. 벽·바닥·천장의 어느 곳에나 배치할 수 있습니다.
  </BlockAnnotation>
  <IsometricCamera yaw="135" pitch="25"/>
</GameScene>

내부를 볼 수 있도록 그림에서는 벽 2개와 천장을 생략했습니다.

* 상자의 모든 모서리에는 <ItemLink id="fusion_casing"/>을 배치합니다.
* 나머지 벽·바닥·천장은 <ItemLink id="aquamarine_structural_glass"/>, Fusion Casing, Containment Coil, Fusion Port로 채울 수 있습니다. 유리를 사용하면 플라스마를 관찰할 수 있습니다.
* <ItemLink id="fusion_collector"/>는 천장 중앙과 바닥 중앙에 하나씩, 결정과 같은 선상에 설치합니다.
* <ItemLink id="laser_injector"/>는 결정 중심부 높이(결정 바닥에서 네 번째 블록)의 옆벽 중앙에 설치합니다. 반응실 안쪽을 바라보며 설치해 결정 쪽으로 향하게 하세요. 벽마다 하나씩 최대 4개를 설치할 수 있습니다.
* <ItemLink id="fusion_controller"/>는 모서리를 제외한 옆벽에 바깥쪽을 향하게 놓습니다. Controller는 뒤쪽 2~5블록 거리에서 결정을 찾습니다.
* 결정과 모서리의 위성 결정(아래 참고)을 제외한 내부 공간은 비워 두세요. 공기와 물 모두 허용되므로 수중에도 건설할 수 있습니다.

Controller나 Fusion Port를 우클릭하면 화면이 열립니다. 반응실이 미완성일 때는 화면 맨 아래에 첫 번째 문제 원인이 표시됩니다.

***

## <Color id="gold">가동 방법</Color>

1. **연료:** Controller 또는 <ItemLink id="fusion_port"/>에 파이프로 Salt Water를 공급합니다. 다른 유체는 받지 않습니다.
2. **점화:** 외부에서 Injector의 뒷면으로 빔을 조사하세요. 차가운 반응로는 발전을 시작하기 전에 처음 5,000,000 AP를 열로 흡수합니다. 6,000 AP/t에서는 약 40초, 소규모 공급에서는 몇 분이 걸립니다. 화면 왼쪽 막대에 열이 표시됩니다.
3. **발전:** 열 막대가 가득 차면 순도 3.0에서 입력 AP당 50 FE를 생산합니다. 순도가 낮으면 효율도 비례해 낮아져 순도 2.4에서는 AP당 40 FE입니다. 순도 3.0을 넘으면 증가 폭이 점차 완만해지는 곡선에 따라 효율이 올라갑니다. 순도 6에서는 약 1.35배, 9에서는 1.55배, 12에서는 1.69배입니다. 더 순도 높은 빔은 [Bacterial Enrichment Catalyst](bacterial_enrichment_catalyst.md)로 강화한 결정에서 얻을 수 있습니다.
4. **연소:** Salt Water 1 mB당 2,000 FE를 생산하므로 300,000 FE/t를 만드는 반응로는 틱마다 150 mB를 소모합니다. 이는 Deep Sea Drain 6개의 공급량입니다.
5. **출력:** Controller와 모든 Fusion Port는 맞닿은 케이블이나 기계로 FE를 출력합니다.

연료나 빔 공급이 끊기면 플라스마가 식기 시작하며 20초에 걸쳐 다시 차가워집니다. 짧게 끊긴 경우에는 잃은 열만큼만 다시 공급하면 되므로 빠르게 재가동할 수 있습니다.

***

## <Color id="gold">출력 상한</Color>

반응실에는 담을 수 있는 플라스마의 상한이 있습니다. 상한을 초과하는 빔 전력은 낭비되며 화면에 **상한 도달**이라고 표시됩니다.

| 내부 크기 | 출력 상한 |
|---|---|
| 3 x 3 | 20,000 FE/t |
| 5 x 5 | 50,000 FE/t |
| 7 x 7 | 100,000 FE/t |
| 9 x 9 | 200,000 FE/t |

외벽의 <ItemLink id="containment_coil"/> 하나당 상한이 4,000 FE/t 증가하며 총 상한은 300,000 FE/t입니다. 내부 9 × 9 반응실에 Coil 25개를 설치하고 순도 3.0의 6,000 AP/t 빔을 공급하면 상한에 도달합니다.

***

## <Color id="gold">중심 결정 순도</Color>

중심 결정 자체의 순도가 3.0을 초과하면 초과 순도 1당 반응로의 출력 상한과 최대 출력이 10% 증가합니다. 순도 6에서는 +30%, 순도 12에서는 +90%입니다. 높은 순도로 생성된 재배 결정이 유리하고, 강화한 결정은 더 좋습니다.

완성된 반응로 안에서는 결정을 강화할 수 없습니다. 밖에서 [Bacterial Enrichment Catalyst](bacterial_enrichment_catalyst.md)로 강화하고 렌치로 회수한 뒤 중심부에 설치하세요.

***

## <Color id="gold">위성 결정</Color>

내부 7 × 7 또는 9 × 9 반응실에는 추가 결정을 놓을 공간이 있습니다. 안쪽 네 모서리마다 Cultivated Prismarine Crystal을 하나씩 바닥부터 천장까지 세우세요. 위성 결정 하나당 다음 효과가 있습니다.

* 출력 상한에 100,000 FE/t를 더하고 300,000 FE/t 최대 한도도 같은 양만큼 높입니다.
* 주입된 AP당 생산 FE를 10 늘립니다. 위성 1개면 50에서 60으로, 4개면 90으로 증가합니다.

<GameScene zoom="2.5" background="#333333" interactive={true}>
  <ImportStructure src="fusion_plant_satellites.nbt" />
  <IsometricCamera yaw="225" pitch="30" />
  <BoxAnnotation min="3.97 0.97 3.97" max="5.03 7.03 5.03" color="#52e8ff" thickness="0.06" alwaysOnTop={true}>
**중심 결정.** 반응로의 핵심인 Cultivated Prismarine Crystal이 바닥부터 천장까지 서 있습니다.
  </BoxAnnotation>
  <BoxAnnotation min="0.97 0.97 0.97" max="2.03 7.03 2.03" color="#ff6ec7" thickness="0.06" alwaysOnTop={true}>
**위성 결정.** Cultivated Prismarine Crystal을 바닥부터 천장까지 세웁니다.
  </BoxAnnotation>
  <BoxAnnotation min="6.97 0.97 0.97" max="8.03 7.03 2.03" color="#ff6ec7" thickness="0.06" alwaysOnTop={true}>
**위성 결정.** Cultivated Prismarine Crystal을 바닥부터 천장까지 세웁니다.
  </BoxAnnotation>
  <BoxAnnotation min="0.97 0.97 6.97" max="2.03 7.03 8.03" color="#ff6ec7" thickness="0.06" alwaysOnTop={true}>
**위성 결정.** Cultivated Prismarine Crystal을 바닥부터 천장까지 세웁니다.
  </BoxAnnotation>
  <BoxAnnotation min="6.97 0.97 6.97" max="8.03 7.03 8.03" color="#ff6ec7" thickness="0.06" alwaysOnTop={true}>
**위성 결정.** Cultivated Prismarine Crystal을 바닥부터 천장까지 세웁니다.
  </BoxAnnotation>
  <BoxAnnotation min="3.97 4.97 -0.03" max="5.03 6.03 1.03" color="#ffd86b" thickness="0.06" alwaysOnTop={true}>
**Fusion Controller.** 가장자리를 제외한 옆벽에 바깥쪽을 향하게 설치합니다.
  </BoxAnnotation>
  <BoxAnnotation min="3.97 3.97 -0.03" max="5.03 5.03 1.03" color="#52e8ff" thickness="0.06" alwaysOnTop={true}>
**Laser Injector.** 옆벽 중앙의 결정 중심부 높이에 놓고 결정을 향하게 합니다. 이 반응로는 각 벽에 하나씩 설치했습니다.
  </BoxAnnotation>
  <BoxAnnotation min="3.97 -0.03 3.97" max="5.03 1.03 5.03" color="#b8a6ff" thickness="0.06" alwaysOnTop={true}>
**Fusion Collector.** 바닥 중앙에 하나, 천장 중앙에 하나를 설치합니다.
  </BoxAnnotation>
  <BoxAnnotation min="7.97 1.97 0.97" max="9.03 3.03 2.03" color="#ffb74d" thickness="0.06" alwaysOnTop={true}>
**Containment Coil.** 동쪽 벽에 2줄로 설치되어 있습니다. 하나당 출력 상한이 4,000 FE/t 증가합니다.
  </BoxAnnotation>
  <BoxAnnotation min="-0.03 1.97 3.97" max="1.03 3.03 5.03" color="#8cc4f2" thickness="0.06" alwaysOnTop={true}>
**Fusion Port.** Controller처럼 Salt Water를 공급받고 FE를 출력합니다.
  </BoxAnnotation>
</GameScene>

위성 결정 4개를 설치한 내부 7 × 7 반응로의 예시입니다. 모서리 Fusion Casing 88개, Aquarine Structural Glass 244개, Containment Coil 14개, Laser Injector 4개, Fusion Collector 2개, Fusion Port 1개, Controller 1개로 총 354개 블록과 결정 5개가 필요합니다. 결정은 자체 렌더러로 표시되므로 그림에는 결정 대신 위치를 표시했습니다. 장면을 드래그하면 회전합니다.

| 위성 결정 수 | 최대 출력 | AP당 FE | 순도 3.0에서 최대 출력에 필요한 AP/t |
|---|---|---|---|
| 0 | 300,000 FE/t | 50 | 6,000 |
| 1 | 400,000 FE/t | 60 | 6,667 |
| 2 | 500,000 FE/t | 70 | 7,143 |
| 3 | 600,000 FE/t | 80 | 7,500 |
| 4 | 700,000 FE/t | 90 | 7,778 |

모든 위성 결정은 [결정 재배](crystal_cultivation.md)로 얻어야 하므로 결정 하나당 성장에 10,000,000 AP가 추가로 필요합니다. Salt Water 1 mB는 여전히 2,000 FE를 생산하므로 700,000 FE/t 반응로는 틱마다 350 mB를 소모하며, 이는 Deep Sea Drain 14개의 공급량입니다. 화면의 Satellites 항목에 위성 결정 수가 표시됩니다. 다른 위치에 결정을 놓으면 구조물이 완성되지 않습니다.

관련 설정은 `config/nautec-common.toml`의 `fusionSatelliteContainment`, `fusionSatelliteFePerAp`입니다.

<Color id="gold">팁</Color>: [Energy Converter](nautec:laser_chemistry/energy_converter.md)로 반응로가 생산한 FE의 일부를 다시 AP로 변환해 공급할 수 있습니다. Converter 빔의 순도는 0이므로 먼저 다른 Prismarine Crystal을 통과시켜 해당 결정의 순도로 높여야 합니다.
