---
navigation:
  title: Resonance Network
  icon: nautec:resonance_node
  position: 9
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:prismatic_emitter
  - nautec:tuning_fork
  - nautec:resonance_charm
---

# <Color id="light_purple">Resonance Network</Color>

<Column alignItems="center" fullWidth={true}>
  <Row>
    <ItemImage id="uplink_array" scale="2"/>
    <ItemImage id="resonance_node" scale="2"/>
  </Row>
  케이블 없이 기지 사이에서 레이저 전력(AP)과 Forge Energy(FE)를 전송하는 이름 있는 네트워크입니다.
</Column>

Resonance Network는 거리와 차원에 관계없이 <ItemLink id="uplink_array"/>, [Resonance Node](resonance_node.md), Resonance Charm을 연결합니다. 위성을 발사한 Uplink Array가 네트워크의 중심입니다. 입력 Node와 케이블이 전력을 공급하면 출력 Node와 Charm으로 AP와 FE를 전송합니다. 중심 장치에 관해서는 [Prism Satellite](prism_satellite.md), 전력 입출력은 [Resonance Node](resonance_node.md)를 참고하세요.

***

## <Color id="gold">설정 방법</Color>

1. <ItemLink id="resonance_node"/> 또는 <ItemLink id="uplink_array"/>를 설치하고 빈손으로 우클릭하세요.
2. 입력칸에 이름을 적고 **Create**를 누르면 자신이 소유한 네트워크가 생성되고 해당 블록이 연결됩니다.
3. 위치에 관계없이 다음 Node 또는 Array를 열고 화살표로 같은 네트워크를 선택하세요.

Node와 Array는 해당 청크가 로드된 동안에만 작동합니다. 화면에서 **Load**를 켜면 자신의 청크를 계속 로드하므로 멀리 떨어져 있어도 연결이 유지됩니다. 단 서버에서 `resonanceChunkLoading`을 비활성화한 경우에는 작동하지 않습니다.

***

## <Color id="gold">사용 권한</Color>

소유자와 신뢰 목록에 등록된 플레이어만 블록을 네트워크에 연결하거나 이미 연결된 블록의 화면을 열 수 있습니다. 다른 플레이어에게는 네트워크 이름과 소유자를 알리는 메시지가 표시됩니다.

소유자는 네트워크의 Node 또는 Array에서 접근 권한을 관리합니다.

* **Trust**: 접속 중인 플레이어의 이름을 입력하고 Trust를 누르면 해당 플레이어도 블록을 연결할 수 있습니다. 이름 옆의 빨간 X로 제거합니다.
* **Team**: FTB Teams가 설치되어 있다면 이를 켜서 소유자 팀의 모든 구성원이 개별 등록 없이 네트워크를 사용하게 할 수 있습니다.
* **Delete**: 네트워크를 삭제하고 연결된 모든 블록을 해제합니다. 두 번 클릭해야 합니다.

플레이어 한 명은 네트워크를 최대 16개 소유할 수 있습니다.

***

<Row>
  <ItemImage id="prismatic_emitter"/>
  ### <Color id="aqua">Prismatic Emitter</Color>
</Row>

케이블 없이 근처 기계에 전력을 공급합니다. 케이블이나 접촉한 출력 Resonance Node로 FE를 공급한 다음, 전력을 받을 기계를 연결하세요. 각 기계에 수정 연결선이 생기며 최대 10,000 FE/t를 손실 없이 나누어 보냅니다.

1. <ItemLink id="tuning_fork"/>를 들고 Emitter를 우클릭하여 Tuning Fork를 조율하세요.
2. 각 기계를 우클릭하여 연결합니다. 연결된 기계를 다시 우클릭하면 해제됩니다.

조율된 Fork로 다른 Emitter도 같은 방식으로 연결할 수 있으므로 전력을 Emitter 사이에 중계해 더 멀리 전달할 수 있습니다. 연결 고리가 시작 Emitter로 되돌아오는 순환 구조는 허용되지 않습니다. 다른 Emitter로 조율하려면 먼저 공중을 향해 웅크려 우클릭하세요. 연결된 기계나 Emitter를 부수면 연결선이 제거됩니다.

Emitter의 연결 범위는 최대 64블록(`emitterRange`)이며 최대 16개 기계에 전력을 공급합니다. 설치한 플레이어만 해당 Emitter에 Fork를 조율할 수 있습니다. Fork로 Emitter를 웅크려 우클릭하면 모든 연결이 해제되고, 공중을 웅크려 우클릭하면 Fork의 조율 정보가 지워집니다.

***

<Row>
  <ItemImage id="resonance_charm"/>
  ### <Color id="aqua">Resonance Charm</Color>
</Row>

어디에 있든 네트워크의 전력으로 소지한 아이템을 충전합니다.

Charm을 들고 Resonance Node 또는 Uplink Array를 우클릭하여 네트워크에 귀속시키세요. 해당 네트워크의 사용 권한이 필요합니다. 이후 Charm 슬롯에 착용하면 0.5초마다 차원에 관계없이 네트워크의 [Uplink Array](prism_satellite.md)에서 FE를 가져와 인벤토리, 방어구, Curio 슬롯의 FE 아이템과 <ItemLink id="atlantean_rifle"/>, <ItemLink id="prismatic_battery"/>처럼 레이저 전력으로 작동하는 NauTec 아이템을 충전합니다. 최대 2,000 FE/t를 전송하며 출력 Node와 마찬가지로 10% 손실이 발생합니다.

Charm의 수정에는 <ItemLink id="prism_monocle"/> 기능도 있습니다. 착용하면 별도의 Monocle 없이 레이저 블록의 전력과 순도를 확인하고 수중 시야도 선명하게 볼 수 있습니다.

소유자가 신뢰 목록에서 제거하면 다시 권한을 받을 때까지 Charm이 작동하지 않습니다. Charm을 들고 공중을 우클릭하면 귀속 네트워크, 소유자, Uplink 및 출력 Node 수, Uplink의 FE 저장량을 확인할 수 있습니다. 우선순위도 설정할 수 있으며, 우선순위가 높은 Charm은 낮은 출력 Node와 Charm보다 먼저 충전됩니다. 공중을 웅크려 우클릭하면 귀속이 해제됩니다.

### <Color id="aqua">Resonance Augment</Color>

Charm 슬롯을 비우고 싶다면 Charm을 Augment로 장착할 수도 있습니다. 다른 부품처럼 [Augmentation Station](nautec:laser_augmentation/augmentation_station.md)에 넣고 Head 슬롯에 장착하세요. 네트워크와 우선순위가 유지되고, 착용한 Charm과 동일하게 아이템을 충전하고 Monocle 정보를 표시합니다. 사망해도 유지됩니다.

다른 네트워크로 조율하려면 빈손으로 Resonance Node 또는 Uplink Array를 웅크려 우클릭하세요. 네트워크 정보나 우선순위를 변경하려면 Augmentation Screen(기본 B키)을 열고 Head 행을 클릭합니다. 귀속된 Charm을 별도로 착용 중이면 Charm이 우선 작동하고 Augment는 대기합니다.
