---
navigation:
  title: Resonance Node
  icon: nautec:resonance_node
  position: 11
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:resonance_node
---

# <Color id="aqua">Resonance Node</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="resonance_node" scale="2"/>
  접시형 안테나나 열린 하늘 없이도 레이저 회선 또는 FE 케이블을 위성 네트워크에 연결합니다.
</Column>

Resonance Node는 [Uplink Array](prism_satellite.md)와 같은 [Resonance Network](resonance_network.md)에 연결됩니다. 위성이 발사된 Uplink마다 전체 네트워크의 동력 풀에 에너지를 모읍니다. Node는 설치 위치와 관계없이 이 풀에 에너지를 공급하거나 꺼내 사용할 수 있습니다.

***

## <Color id="gold">설치 방법</Color>

1. 블록의 한 면에 Node를 설치합니다. Crystal은 클릭한 면의 반대 방향을 향합니다.
2. 빈손으로 우클릭해 네트워크를 선택하거나 생성합니다. 새 네트워크는 이름을 입력하고 **Create**를 누르며, 기존 네트워크는 화살표로 선택합니다.
3. 화면의 버튼으로 **Input** 또는 **Output** 모드를 지정합니다.

네트워크에는 어느 차원이든 발사된 위성과 하늘이 열린 <ItemLink id="uplink_array"/>가 최소 하나 필요합니다. 없으면 Node에 **No core**가 표시되고 에너지를 전송하지 않습니다.

***

## <Color id="gold">입력과 출력</Color>

* **Input:** 어느 면으로든 들어오는 레이저 빔과 케이블의 FE를 받아 네트워크의 Uplink로 전송합니다. 같은 차원의 Uplink를 우선 사용하며, 다른 차원으로 보내는 AP는 순도가 5% 감소합니다.
* **Output:** 네트워크에서 AP와 FE를 받아 Crystal 끝에서 AP 빔을 발사하고 접촉한 장치에 FE를 공급합니다.

Output Node는 Resonance Charm과 우선순위에 따라 네트워크 동력을 나눠 씁니다. 전송 중 10%가 손실되며 해당 차원에 Uplink가 없으면 수신 AP의 순도가 추가로 5% 낮아집니다.

***

## <Color id="gold">버퍼·우선순위·전송 한도</Color>

Node는 최대 200,000 AP와 1,000,000 FE를 저장합니다(`resonanceNodeApBuffer`, `resonanceNodeFeBuffer`). Input Node는 Uplink에 여유가 생길 때까지 입력 에너지를 보관합니다. Output Node는 네트워크에서 받은 에너지를 저장했다가 설정한 한도만큼 빠르게 내보냅니다.

화면 상단에서 우선순위(-100~100)와 틱당 AP·FE 전송 한도를 각각 설정합니다. 우선순위가 높은 대상부터 공급됩니다. 숫자를 클릭하면 초기화됩니다.

***

## <Color id="gold">업그레이드</Color>

기본 Node는 틱당 최대 100,000 AP와 100,000 FE를 전송합니다(`satelliteTransferLimit`). Conduit Upgrade를 장착하면 전송 한도와 버퍼 용량이 증가합니다.

| 업그레이드 | 틱당 전송량 | FE 버퍼 | AP 버퍼 |
|---|---|---|---|
| 없음 | 100,000 | 1,000,000 | 200,000 |
| <ItemLink id="eddy_upgrade"/> | 500,000 | 5,000,000 | 1,000,000 |
| <ItemLink id="surge_upgrade"/> | 2,500,000 | 25,000,000 | 5,000,000 |
| <ItemLink id="riptide_upgrade"/> | 10,000,000 | 100,000,000 | 20,000,000 |
| <ItemLink id="maelstrom_upgrade"/> | 무제한 | 1,000,000,000 | 1,000,000,000 |

Upgrade를 들고 Node를 우클릭하면 장착됩니다. 다른 Upgrade로 교체하면 기존 것은 반환됩니다. 빈손으로 웅크린 채 우클릭하면 제거할 수 있습니다. 장착한 Upgrade는 화면의 모드 버튼 아래에 표시됩니다. 틱당 한도는 `resonanceNodeUpgradeLimits`에서 설정합니다.

<ItemLink id="uplink_array"/> 하나는 5,000,000 FE를 저장하므로 틱당 그 이상을 전송하려면 Uplink가 여러 개 필요합니다.

**Load**를 활성화하면 Node가 있는 청크를 계속 로드해 주변에 플레이어가 없어도 작동합니다.

 <ItemLink id="configuration_card"/>로 Node의 네트워크, 모드, 우선순위, 한도, 청크 로딩, Upgrade 설정을 다른 Node에 복사할 수 있습니다.

***

## <Color id="gold">제작법</Color>

<RecipeFor id="resonance_node"/>
