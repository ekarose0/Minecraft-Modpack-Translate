---
navigation:
  title: 빔 광학
  icon: nautec:focusing_lens
  position: 0
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:focusing_lens
---

# <Color id="light_purple">빔 광학</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="focusing_lens" scale="2"/>
  순도와 순도를 높이는 렌즈를 설명합니다.
</Column>

<ItemLink id="prismarine_laser_relay"/>는 빔을 직선으로 전달하고, <ItemLink id="laser_junction"/>은 빔의 방향을 바꾸거나 합치고 분배합니다. 둘 다 순도를 직접 변경하지 않습니다([Moving Laser Power](nautec:laser_chemistry/laser_manipulation.md) 참조). 제작법은 작동 전에 순도를 확인하므로 최종 기계가 요구하는 순도에 맞춰 동력원을 계획하세요.

***

## <Color id="gold">순도</Color>

순도는 동력원에서 결정됩니다. 빔을 합치면 조금 낮아지고 Focusing Lens를 통과하면 높아집니다.

| 동력원 | 순도 |
|---|---|
| Prismarine Shard를 사용하는 <ItemLink id="aquatic_catalyst"/> | 0.4 |
| Prismarine Crystal을 사용하는 Aquatic Catalyst | 0.8 |
| Prismarine Crystal Shard를 사용하는 Aquatic Catalyst | 1.2 |
| <ItemLink id="bacterial_fuel_cell"/> | 최대 2.5 |
| <ItemLink id="prismarine_crystal"/> (옆면에 빔 조사) | 3.0 또는 배양된 수정 자체의 순도(최대 12) |

배양한 수정은 [Bacterial Enrichment Catalyst](bacterial_enrichment_catalyst.md)로 순도를 6.0보다 높일 수 있습니다.

Aquatic Catalyst에 맞닿은 Budding Prismarine 블록 하나당 빔의 순도가 0.1 증가하며 최대 2.0까지 적용됩니다. [Laser Power](nautec:getting_started/laser_power.md)를 참고하세요.

이 항목의 기계들이 요구하는 순도는 다음과 같습니다.

| 생산물 | 기계 | 순도 |
|---|---|---|
| Flawless Prismarine Crystal | [Abyssal Pressure Forge](pressure_forge.md) | 2.0 |
| Atlantic Gold Ingot | Abyssal Pressure Forge | 2.0 |
| Deep Steel Plating | Abyssal Pressure Forge | 2.5 |
| Resonant Shard | [Resonance Chamber](resonance_chamber.md) | 3.0 |
| Prismarine Crystal Seed | Resonance Chamber | 3.0 |

두 개 이상의 빔이 같은 블록에 공급되면 동력은 합산되고 순도는 가장 높은 순도에 가깝게 유지됩니다. 최종 순도는 최고 순도에서 최고 순도와 전체 평균 순도의 차이의 1/4을 뺀 값입니다(`beamMergePurityDrop`). 따라서 순도 3.0 빔과 0 빔을 합치면 약 2.6이 됩니다.

***

<Row>
  <ItemImage id="focusing_lens"/>
  ### <Color id="aqua">Focusing Lens</Color>
</Row>

직선으로 통과하는 빔의 순도를 0.5(`lensPurityBonus`) 높이며 최대 순도는 2.0입니다. 빔이 진행할 방향을 바라보며 설치하세요. 플레이어 쪽 면으로 빔을 받아 반대편으로 최대 16블록(`laserDistance`)까지 전달합니다. 동력량은 변하지 않으며 물속에도 설치할 수 있습니다.

렌즈는 순도가 0보다 높은 빔에만 작용하므로 정상 작동 중인 동력원 뒤에 배치하세요. 순도 1.8 빔은 2.0으로 올라가지만 이미 2.0 이상인 빔은 변하지 않습니다. 렌즈를 여러 개 이어도 최대 2.0까지만 높일 수 있습니다. Prismarine Crystal Shard를 사용하는 Catalyst(순도 1.2) 뒤에 렌즈 두 개를 연속으로 놓으면 Flawless Prismarine Crystal 제작에 필요한 Pressure Forge 순도 2.0을 충족합니다. 순도 2.5 또는 3.0이 필요하면 Bacterial Fuel Cell이나 Prismarine Crystal을 동력원으로 사용하세요.

<Recipe id="nautec:focusing_lens"/>
