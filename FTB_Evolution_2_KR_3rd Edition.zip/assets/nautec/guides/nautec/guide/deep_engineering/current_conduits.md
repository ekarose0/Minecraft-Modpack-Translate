---
navigation:
  title: Current Conduits
  icon: nautec:current_conduit
  position: 12
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:current_conduit
  - nautec:aquarine_copper_ingot
  - nautec:aquarine_copper_compound
  - nautec:clay_gasket
  - nautec:eddy_upgrade
  - nautec:surge_upgrade
  - nautec:riptide_upgrade
  - nautec:maelstrom_upgrade
  - nautec:filter
  - nautec:intricate_filter
---

# <Color id="aqua">Current Conduits</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="current_conduit" scale="2"/>
  아이템·유체·FE를 모두 전송하는 파이프입니다. 일반 Conduit 자체는 전송하지 않으며 Conduit Tap이 자원을 이동시킵니다.
</Column>

<ItemLink id="current_conduit"/> 회선은 연결된 모든 Conduit Tap을 하나의 네트워크로 묶습니다. 자원은 Tap 사이에서 직접 이동하므로 파이프 내부를 따라 움직이지 않고 Tap 사이 Conduit의 청크를 계속 로드할 필요도 없습니다. 다만 회선 일부가 로드되지 않은 청크에 있으면 다시 로드될 때까지 그 지점에서 네트워크가 끊깁니다.

Conduit는 물속에서도 작동하며 Waterlogged 상태로 설치할 수 있습니다.

***

## <Color id="gold">Conduit Tap 만들기</Color>

1. 연결할 블록 옆에 Conduit를 설치합니다.
2. 해당 블록에 닿은 Conduit를 <ItemLink id="aquarine_steel_wrench"/>로 웅크린 채 우클릭하면 Conduit Tap으로 바뀝니다.
3. Tap 하나로 닿아 있는 모든 블록에 연결할 수 있으며 최대 기계 5개와 Conduit 회선을 연결합니다.

Tap을 Wrench로 웅크린 채 우클릭하면 일반 Conduit로 돌아갑니다. Upgrade와 Filter도 반환됩니다. Tap을 부수면 Conduit와 내부 아이템이 모두 떨어집니다.

웅크리지 않고 Wrench를 사용하면 한 면의 연결을 켜거나 끕니다. 일반 Conduit에서는 인접 블록과 연결되지 않게 하므로 두 회선을 합치지 않고 나란히 설치할 수 있습니다. Tap에서는 해당 면을 비활성화합니다.

***

## <Color id="gold">면 설정</Color>

빈손으로 Tap을 우클릭해 화면을 엽니다. 왼쪽에서 면을 선택한 뒤 Setup 페이지에서 자원별 동작을 지정합니다.

* **Insert:** 네트워크가 해당 자원을 블록에 넣습니다.
* **Extract:** 네트워크가 해당 자원을 블록에서 꺼냅니다. 발전기나 호퍼가 Extract 면으로 자원을 밀어 넣을 수도 있습니다.
* **Extract & Insert:** 자원을 넣고 꺼내지만, 꺼낸 자원을 원래 블록으로 되돌리지는 않습니다.
* **Off:** 이 면에서 해당 자원을 처리하지 않습니다.

새 Tap은 모든 면이 Insert로 설정되어 있으므로 공급원 쪽 면은 Extract로 바꾸세요.

Tap이 닿은 블록의 연결부 색상은 면 설정을 나타냅니다. Insert만 허용하면 주황색, Extract만 허용하면 파란색, 둘 다 허용하면 보라색, 둘 다 끄면 일반 구리색입니다. 블록이 저장할 수 있는 자원만 적용되므로 Chest 연결부는 에너지 설정을 무시합니다.

**Priority**는 -99~99이며 우선순위가 높은 목적지부터 채웁니다. **Distribution**은 우선순위가 같은 목적지의 분배 방식을 정합니다. Round Robin은 차례대로, Nearest First는 가까운 곳부터, Random은 전송할 때마다 다른 시작점을 선택합니다. **Redstone**으로 Tap에 신호가 있을 때만 또는 없을 때만 면을 작동하게 할 수 있습니다.

<ItemLink id="configuration_card"/>로 Tap의 모든 면 설정과 Upgrade·Filter를 다른 Tap에 복사할 수 있습니다. 적용할 때 필요한 Upgrade와 Filter는 인벤토리에서 가져오고 대상 Tap에 있던 기존 부품은 반환됩니다.

***

## <Color id="gold">전송 속도</Color>

각 면은 독립적으로 전송합니다. Tap에 Upgrade 하나를 장착하면 모든 면의 전송 속도가 증가합니다.

| 업그레이드 | 아이템 | 유체 | FE |
| --- | --- | --- | --- |
| 없음 | 20틱마다 8개 | 1,000 mB/t | 5,000/t |
| <ItemLink id="eddy_upgrade"/> | 10틱마다 16개 | 5,000 mB/t | 25,000/t |
| <ItemLink id="surge_upgrade"/> | 5틱마다 32개 | 30,000 mB/t | 150,000/t |
| <ItemLink id="riptide_upgrade"/> | 2틱마다 64개 | 200,000 mB/t | 1,000,000/t |
| <ItemLink id="maelstrom_upgrade"/> | 매 틱 256개 | 1,000,000 mB/t | 5,000,000/t |

***

## <Color id="gold">필터</Color>

Tap에 <ItemLink id="filter"/>를 장착하면 Filter 페이지에서 면마다 아이템 슬롯 9개와 유체 슬롯 9개를 사용할 수 있습니다. <ItemLink id="intricate_filter"/>를 장착하면 아이템 슬롯 27개가 모두 열립니다.

* 아이템·Bucket·Tank로 슬롯을 클릭하거나 JEI에서 끌어 놓습니다. 우클릭하면 지웁니다.
* 아이템 슬롯을 Shift+클릭하면 Enchanted Book이나 내용물이 든 Dish처럼 구성 요소 데이터까지 정확히 일치시킵니다. 해당 슬롯에는 금색 모서리 표시가 생깁니다.
* 군체가 든 Petri Dish는 기본적으로 크기에 관계없이 같은 균주와 일치합니다. Shift+클릭하면 모든 Dish를 허용하도록 바뀝니다. 정확히 일치하도록 설정한 빈 Dish는 빈 Dish만 받습니다.
* **Whitelist**는 지정한 항목만 통과시키고 **Blacklist**는 지정한 항목을 차단합니다. 필터를 설정하지 않은 면은 모든 자원을 통과시킵니다.

필터는 양방향으로 적용되어 Extract 면에서 꺼내는 자원과 Insert 면에서 받는 자원을 모두 제한합니다.

***

## <Color id="gold">재료</Color>

떨어뜨린 <ItemLink id="aquarine_copper_compound"/>에 순도 2.1 이상의 레이저 빔을 통과시키면 개당 <ItemLink id="aquarine_copper_ingot"/> 4개로 변환됩니다. Compound는 Copper, Prismarine Crystal, Dried Kelp로 조합하거나 <ItemLink id="mixer"/>에서 Copper Ingot 3개, <ItemLink id="kelp_slurry"/> 1개, Salt Water 500 mB를 혼합해 한 번에 6개씩 만들 수 있습니다.

<RecipeFor id="aquarine_copper_compound"/>
<RecipeFor id="clay_gasket"/>
<RecipeFor id="current_conduit"/>
<RecipeFor id="eddy_upgrade"/>
<RecipeFor id="filter"/>
