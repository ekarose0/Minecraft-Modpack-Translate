---
navigation:
  title: Bacterial Enrichment Catalyst
  icon: nautec:bacterial_enrichment_catalyst
  position: 17
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:bacterial_enrichment_catalyst
---

# <Color id="light_purple">Bacterial Enrichment Catalyst</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="bacterial_enrichment_catalyst" scale="2"/>
  Cultivated Prismarine Crystal의 순도를 생성 시 최대치인 6.00보다 높여 최대 12까지 올립니다.
</Column>

결정은 [Crystal Cradle](crystal_cultivation.md)에서 성장할 때 순도 3.00~6.00이 정해집니다. Catalyst는 이를 조금씩 더 높입니다. 주기마다 다른 결정에서 빔 전력을 받고 Prismatophiles 군체의 일부를 소모합니다.

***

## <Color id="gold">배치 방법</Color>

결정 2개가 필요합니다. **대상 결정**은 순도를 높일 결정이고 **공급원 결정**은 대상 순도를 어디까지 올릴 수 있는지 결정합니다.

<GameScene zoom="4" background="#333333" interactive={true}>
  <ImportStructure src="bacterial_enrichment_catalyst.nbt" />
  <IsometricCamera yaw="225" pitch="30" />
  <BoxAnnotation min="0.97 0.97 0.97" max="2.03 7.03 2.03" color="#ff6ec7" thickness="0.06" alwaysOnTop={true}>
**대상 결정.** 순도 4.0 이상인 Cultivated Prismarine Crystal이며 높이는 6블록입니다.
  </BoxAnnotation>
  <BoxAnnotation min="1.97 1.97 0.97" max="3.03 8.03 2.03" color="#52e8ff" thickness="0.06" alwaysOnTop={true}>
**공급원 결정.** Catalyst와 같은 세로줄의 바로 위에 있습니다. 결정의 아래쪽 끝에서 Catalyst로 빔을 발사합니다.
  </BoxAnnotation>
  <BoxAnnotation min="1.97 0.97 0.97" max="3.03 2.03 2.03" color="#ffd86b" thickness="0.06" alwaysOnTop={true}>
**Bacterial Enrichment Catalyst.** 대상 결정의 옆에 등을 맞대어 배치하며 공급원 결정 바로 아래에 놓습니다.
  </BoxAnnotation>
  <BoxAnnotation min="0.97 -0.03 0.97" max="2.03 1.03 2.03" color="#9aa5b1" thickness="0.06" alwaysOnTop={true}>
**Crystal Cradle.** 이 결정이 원래 위치에서 성장했기 때문에 표시됩니다. 렌치로 옮긴 결정에는 필요하지 않습니다.
  </BoxAnnotation>
  <BoxAnnotation min="2.97 3.97 0.97" max="4.03 5.03 2.03" color="#52e8ff" thickness="0.06" alwaysOnTop={true}>
**레이저.** 공급원 결정의 옆면을 향합니다.
  </BoxAnnotation>
  <BoxAnnotation min="1.97 3.97 1.97" max="3.03 5.03 3.03" color="#52e8ff" thickness="0.06" alwaysOnTop={true}>
**레이저.** 공급원 결정의 옆면을 향합니다.
  </BoxAnnotation>
</GameScene>

색상 상자는 두 결정의 위치를 표시합니다. 상자에 커서를 올리면 설명을 볼 수 있고, 장면을 드래그하면 회전합니다.

1. 순도 4.0 이상의 Cultivated Prismarine Crystal을 세우세요. 이것이 대상 결정입니다.
2. <ItemLink id="bacterial_enrichment_catalyst"/>를 대상 결정 기둥의 어느 옆면에든 등을 맞대어 설치하세요.
3. Catalyst와 같은 세로줄의 바로 위나 아래에 공급원 결정을 세워 결정 끝에서 Catalyst의 윗면이나 아랫면으로 빔이 직접 들어오게 하세요. Catalyst는 레이저, Relay, 렌즈, Node 또는 대상 결정의 빔을 직접 받지 않습니다.
4. 레이저를 공급원 결정의 옆면에 조사하세요. 결정은 입력된 전력을 자체 순도로 모두 전달하므로 공급원 결정의 순도가 중요하며, 연결된 레이저들의 총 AP가 속도를 결정합니다.
5. Prismatophiles가 담긴 <ItemLink id="petri_dish"/>를 넣으세요. 군체가 담긴 접시는 군체를 투입하고 빈 접시는 군체를 회수합니다.
6. Catalyst 화면에서 목표 순도를 설정하세요. 레드스톤 신호를 주면 일시 정지합니다.

결정 하나에는 Catalyst 하나만 작동할 수 있습니다. 공급원 결정에서 최소 **500 AP**를 받아야 합니다.

***

## <Color id="gold">주기와 비용</Color>

Catalyst는 주기 단위로 작동합니다. 순도 6인 결정의 주기당 비용은 1,000,000 AP이며 순도가 정수 1만큼 올라갈 때마다 비용이 2배가 됩니다. 매 틱 빔의 모든 전력이 누적되므로 전력을 2배로 늘리면 시간은 절반이 됩니다.

| 결정 순도 | 주기당 AP | 주기당 군체 소모 | 1,000 AP/t에서 시간 |
|---|---|---|---|
| 4 | 250,000 | 약 50 | 12.5초 |
| 6 | 1,000,000 | 100 | 50초 |
| 8 | 4,000,000 | 약 200 | 3분 20초 |
| 10 | 16,000,000 | 약 400 | 13분 |
| 12 | 64,000,000 | 약 800 | 53분 |

주기가 끝나면 결정 순도가 **0.10 증가**하거나 **0.20 감소**합니다. 감소해도 4.0 아래로 내려가지 않습니다. 강화 중에도 결정은 계속 빔을 발사하며 렌치로 옮겨도 순도가 유지됩니다.

***

## <Color id="gold">위험과 단계적 강화</Color>

순도 감소 확률은 대상 결정이 공급원 결정보다 얼마나 높은지에 따라 달라집니다.

| 대상과 공급원 비교 | 순도 감소 확률 |
|---|---|
| 공급원이 1.0 이상 높음 | 2% |
| 동일 | 10% |
| 대상이 공급원보다 1.5 높음 | 30% |

대상이 공급원보다 1.5 이상 높으면 Catalyst가 멈춥니다. 따라서 순도 6.0 공급원으로 대상을 7.5까지 높일 수 있습니다. 이후 강화된 결정을 다음 공급원으로 사용하면 9.0까지 높일 수 있고 이런 식으로 반복합니다. 두 결정을 번갈아 강화해도 됩니다.

공급원의 순도가 높을수록 안전하고 군체 소모량도 줄어듭니다(아래 군체 항목 참고). 결정의 순도는 아이템 툴팁이나 <ItemLink id="prism_monocle"/>로 확인할 수 있습니다.

***

## <Color id="gold">목표 순도와 일시 정지</Color>

Catalyst 화면에서 목표 순도를 설정하세요. 결정이 해당 수치에 도달하면 목표를 올릴 때까지 멈춥니다. 순도는 12를 넘을 수 없습니다. 레드스톤 신호를 주면 일시 정지하며 신호가 사라지면 기존 진행도부터 재개합니다.

완성된 [Fusion Plant](fusion_plant.md) 내부의 결정은 강화할 수 없습니다. 외부에서 강화한 뒤 렌치로 회수해 핵심부에 설치하세요.

***

## <Color id="gold">군체</Color>

Catalyst는 **Prismatophiles**를 사용합니다. [Mutator](nautec:aquatic_biology/mutator.md)에서 에메랄드 균주인 Smaragdophiles에 <ItemLink id="atlantic_gold_ingot"/>를 촉매로 사용하면 5% 확률로 얻습니다. Bio Reactor에서는 아무것도 생산하지 않습니다. [Incubator](nautec:aquatic_biology/incubator.md)에서 <ItemLink id="prismarine_crystal_shard"/>를 먹여 키우고 Mutator에서 Prismarine Crystal Shard를 촉매로 능력치를 정제하세요(기본 성공 확률 25%). [균주 계통도](nautec:aquatic_biology/strain_tree.md)를 참고하세요.

주기마다 군체가 소모됩니다. 순도 6에서 100을 소모하고 순도가 1 올라갈 때마다 약 1.41배가 되어 순도 12 부근에서는 약 800을 소모합니다. 대상 순도가 공급원보다 높으면 차이가 1 늘 때마다 기본 비용만큼 추가되어 1.0 높을 때는 2배가 됩니다. Mutation Resistance 상한에 도달한 군체는 절반만 소모합니다. 군체 크기가 주기당 비용보다 작으면 Catalyst가 대기합니다.

***

## <Color id="gold">작동이 멈출 때</Color>

화면 맨 위 줄에는 Catalyst가 감지한 첫 문제가 아래 우선순위대로 표시됩니다.

| 상태 | 해결 방법 |
|---|---|
| 결정 없음 | Catalyst 뒤에 결정이 없습니다. 등 뒤에 재배한 결정을 놓으세요. |
| 자연산 결정 | 자연산 결정은 강화할 수 없습니다. Crystal Cradle에서 재배하세요. |
| 결정 사용 중 | 다른 Catalyst가 이 결정을 사용 중입니다. 하나를 제거하세요. |
| 결정 순도 부족 | 순도가 4.0 미만입니다. 4.0 이상인 결정을 사용하세요. |
| 최대 순도 | 순도 12에 도달해 더 올릴 수 없습니다. |
| 목표 도달 | 화면에서 목표 순도를 높이세요. |
| 일시 정지 | 레드스톤 신호를 끄세요. |
| 공급원 빔 없음 | Catalyst와 같은 세로줄에 결정을 놓고 옆면에 레이저를 조사하세요. |
| 빔 전력 부족 | 최소 500 AP가 필요합니다. 공급원 결정에 조사하는 레이저 전력을 늘리세요. |
| 공급원 순도 부족 | 대상 순도가 공급원보다 1.5 이상 높습니다. 더 순도 높은 공급원 결정을 사용하세요. |
| 군체 없음 | Prismatophiles가 담긴 Petri Dish를 넣으세요. |
| 군체 크기 부족 | 군체가 한 주기 비용보다 작습니다. 다시 키우거나 더 순도 높은 공급원으로 비용을 줄이세요. |
| 강화 중 | 정상 작동 중입니다. 표시된 수치는 현재 주기의 진행도입니다. |

***

## <Color id="gold">순도를 높이면 얻는 효과</Color>

* [Crystal Cultivator](nautec:laser_chemistry/crystal_cultivator.md): 순도 6까지는 순도 1당 Fortune 1레벨, 순도 9에서 Fortune VIII, 12에서 Fortune IX가 됩니다.
* [Laser Purification Smelter](laser_purification_smelter.md): 제련 비용이 줄어듭니다.
* [Resonance Chamber](resonance_chamber.md): 상한이 높아집니다.
* [Fusion Plant](fusion_plant.md): 순도 3.0을 초과하는 Injector 빔의 AP당 FE 생산량과 핵심 결정의 순도에 따른 출력 상한이 높아집니다.

***

## <Color id="gold">제작법</Color>

<RecipeFor id="bacterial_enrichment_catalyst"/>

AP, 순도, 위험도, 군체 소모량은 `config/nautec-common.toml`의 `enrichment` 설정으로 변경할 수 있습니다.
