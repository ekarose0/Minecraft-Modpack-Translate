---
navigation:
  title: Prism Satellite
  icon: nautec:prism_satellite
  position: 10
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:prism_satellite
  - nautec:uplink_array
---

# <Color id="aqua">Prism Satellite</Color>

<Column alignItems="center" fullWidth={true}>
  <Row>
    <ItemImage id="uplink_array" scale="2"/>
    <ItemImage id="prism_satellite" scale="2"/>
  </Row>
  Relay를 연속으로 연결하지 않고도 네트워크 어디로든 레이저 동력(AP)과 FE를 전달합니다.
</Column>

<ItemLink id="uplink_array"/>는 레이저에서 AP를, 케이블에서 FE를 받아 상공의 궤도 위성으로 전송합니다. 위성은 거리와 관계없이 같은 네트워크에 있는 모든 출력 [Resonance Node](resonance_node.md)와 Resonance Charm으로 에너지를 다시 전송합니다.

***

## <Color id="gold">설치 방법</Color>

1. 높이가 2블록인 <ItemLink id="uplink_array"/>를 설치합니다.
2. 빈손으로 우클릭하여 <ItemLink id="resonance_node"/>에서와 같은 방식으로 네트워크를 선택하거나 생성합니다. Array와 Node는 네트워크 및 신뢰할 수 있는 플레이어 목록을 공유합니다.
3. <ItemLink id="prism_satellite"/>를 들고 Uplink를 우클릭하여 발사합니다. 위성은 궤도로 올라가며 Uplink를 부술 때까지 유지되고, 부수면 다시 떨어집니다.
4. Uplink의 옆면이나 아래쪽으로 레이저를 조사하고, 어느 면으로든 파이프로 FE를 공급합니다.
5. 에너지가 필요한 위치에 <ItemLink id="resonance_node"/>를 설치하고 같은 네트워크에 연결한 뒤 **Output**으로 설정합니다.

***

## <Color id="gold">작동 규칙</Color>

* **하늘:** Uplink 접시 위쪽은 하늘이 열려 있어야 합니다. 고체 블록만 방해하며 물, 유리, 나뭇잎은 통과할 수 있으므로 해저나 유리 지붕 아래에서도 작동합니다. Resonance Node에는 하늘이 필요하지 않습니다.
* **차원:** 위성을 발사한 모든 Uplink는 차원을 넘어 네트워크 전체가 공유하는 에너지 저장소에 공급합니다. 자체 Uplink가 없는 차원의 출력 Node도 에너지를 받을 수 있지만 AP 순도가 5% 감소합니다(`satelliteCrossDimensionPurityLoss`). 손실을 막으려면 해당 차원에도 Uplink를 설치하세요.
* **분배:** 우선순위가 높은 출력 Node와 Charm이 먼저 충전되고, 우선순위가 같으면 균등하게 분배됩니다. 전송 과정에서 10%가 손실됩니다. Uplink가 설치된 차원 안에서는 순도가 변하지 않습니다.
* **여러 Uplink:** 같은 네트워크의 모든 Uplink는 차원과 관계없이 같은 저장소에 공급합니다. 빔이 합쳐지므로 저장소의 순도는 가장 높은 순도의 Uplink에 가깝게 유지됩니다.
* **청크 로딩:** Uplink는 해당 청크가 로딩되어 있을 때만 작동합니다. 화면에서 **Load**를 켜면 서버에서 비활성화하지 않은 경우(`resonanceChunkLoading`) 자체 청크를 계속 로딩합니다.

화면에는 Uplink의 온라인 여부, 작동하지 않을 경우 대기 이유, 저장된 AP와 FE가 표시됩니다.

***

## <Color id="gold">저장 버퍼</Color>

각 Uplink는 최대 5,000,000 AP와 5,000,000 FE를 저장합니다(`satelliteApBuffer`, `satelliteFeBuffer`). 레이저로 공급된 AP와 순도, 케이블로 공급된 FE를 출력 Node나 Charm이 요구할 때까지 보관하므로 출력 장치를 설치하기 전에도 미리 충전할 수 있습니다.

우선순위와 틱당 전송 한도는 각 출력 Node에서 설정합니다. [Resonance Node](resonance_node.md)를 참고하세요.
