---
navigation:
  title: Resonance Chamber
  icon: nautec:resonance_chamber
  position: 1
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:resonance_chamber
---

# <Color id="light_purple">Resonance Chamber</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="resonance_chamber" scale="2"/>
  레이저 빔의 에너지를 충전량으로 축적하고 임계 수준에 도달하면 제작을 수행합니다.
</Column>

Resonance Chamber는 <ItemLink id="prismarine_crystal_shard"/>를 Resonant Shard로 변환하고 Dormant Crystal Seed를 [Crystal Cultivation](crystal_cultivation.md)에 필요한 Prismarine Crystal Seed로 각성시킵니다. 순도 3.0 이상의 빔이 필요하며 측면 4곳과 윗면에서 빔을 받습니다.

***

## <Color id="gold">충전량과 상한</Color>

입력 빔이 틱당 최소 20 AP(`resonancePowerUsage`)를 공급하면 Chamber가 매 틱 빔의 전체 출력을 충전량에 더합니다. 이보다 낮으면 충전량이 감소합니다.

상한은 Chamber가 안전하게 저장할 수 있는 충전량입니다. 공식은 2,000 × (1 + 순도)이므로 순도 3.0에서는 상한이 8,000입니다. 기본값 2,000은 `config/nautec-common.toml`의 `resonanceBaseCeiling`입니다.

| 충전량 | 동작 |
|---|---|
| 상한의 90% 미만 | 계속 충전 |
| 90~110%(임계) | 가능하면 아이템 1개 제작 후 충전량 0으로 초기화 |
| 110% 초과 | 에너지 방출 |

순도 3.0에서는 충전량 7,200~8,800이 임계 범위입니다. 40 AP 빔은 180틱(9초) 만에 도달합니다.

***

## <Color id="gold">제작</Color>

충전량이 임계에 도달하기 전에 Prismarine Crystal Shard를 넣으세요. 임계에 도달할 때마다 Shard 1개를 소비하고 Resonant Shard를 출력한 뒤 충전량 0부터 다시 시작하므로 한 스택을 자동으로 처리할 수 있습니다.

Shard를 들고 우클릭하면 투입합니다. 수동·자동화 모두 제작 가능한 아이템만 받습니다. 빈손으로 우클릭하면 출력물을 가져오며 출력이 비어 있으면 입력물을 회수합니다. 아래에 호퍼를 설치하는 등 호퍼·파이프로 Shard를 넣고 Resonant Shard를 꺼낼 수 있습니다. 기본적으로 모든 면에서 입출력이 가능하며 [Side Configuration](nautec:getting_started/utilities.md)으로 변경할 수 있습니다.

<ItemLink id="prism_monocle"/>로 바라보면 상한 대비 충전 비율, 충전 상한, 빔 순도가 표시됩니다. 임계 범위에서는 충전 표시가 금색으로 바뀝니다.

***

## <Color id="gold">에너지 방출</Color>

충전량이 상한의 110%를 넘으면 Chamber가 에너지를 방출합니다. 반경 4블록의 모든 생물이 피해 8을 입고 Chamber는 10초간 금이 간 상태가 되어 충전·제작을 중단합니다. 블록 자체는 파괴되지 않습니다.

임계에 도달했지만 제작할 수 없는 경우에도 방출합니다. 원인은 다음과 같습니다.

* 입력 슬롯이 비어 있음
* 빔 순도가 3.0 미만임
* 출력 슬롯이 가득 참

출력 슬롯을 비우거나 아래에 호퍼를 설치하고 Shard가 떨어지면 빔을 끄세요. 빔 출력 자체는 안전합니다. 90% 미만에서 임계 범위로 진입하는 틱에는 빔이 아무리 강해도 충전량이 상한의 100%에서 멈춥니다.

방출 피해, 반경, 재사용 대기시간은 `config/nautec-common.toml`의 `resonanceVentDamage`, `resonanceVentRadius`, `resonanceVentCooldown`에서 설정할 수 있습니다.

***

## <Color id="gold">순도 3.0 확보하기</Color>

측면에서 빔을 받은 <ItemLink id="prismarine_crystal"/>은 순도 3.0의 빔을 발사합니다. Chamber를 직접 향하게 하거나 순도를 유지하는 Prismarine Laser Relay와 Laser Junction을 통해 전달하세요. [Focusing Lens](beam_optics.md)는 순도를 최대 2.0까지만 높이므로 여기서는 도움이 되지 않습니다.

***

### <Color id="aqua">Resonance Chamber 제작법</Color>

<Recipe id="nautec:resonance_chamber"/>

***

## <Color id="gold">강한 빔</Color>

Resonance Chamber는 매 틱 빔의 전체 출력을 충전하므로 출력이 2배면 충전 속도도 2배입니다. 다른 기계에서 사용하는 제곱근 규칙은 적용되지 않습니다.

규칙과 적용 기계 목록은 [Stronger Beams](nautec:getting_started/stronger_beams.md)를 참고하세요.
