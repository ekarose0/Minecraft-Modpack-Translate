---
navigation:
  title: Gateway
  icon: nautec:gateway
  position: 2
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:gateway
  - nautec:gateway_ring
---

# <Color id="light_purple">Gateway</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="gateway" scale="2"/>
  지름 13블록의 수직 고리입니다. 사건의 지평선을 통과한 대상은 같은 주소를 가진 다른 고리에서 나옵니다.
</Column>

통로 너비가 9블록이므로 <ItemLink id="submarine"/>도 양옆에 약 3블록의 여유를 두고 통과할 수 있습니다.

고리 아래쪽 두께가 2블록이어서 통로는 설치된 지면보다 2블록 위에서 시작합니다. 수중에서는 바로 헤엄치거나 조종해서 들어갈 수 있지만 육지에서는 계단이나 경사로를 만드세요.

***

## <Color id="gold">자연 생성 Gateway</Color>

Gateway는 해저의 작은 Prismarine 플랫폼 위에 생성됩니다. 각 Gateway는 고유한 주소를 가진 한 쌍의 절반이며 전력이 필요하지 않습니다.

자연 생성 Gateway를 처음 통과하면 약 1,500블록 떨어진 다른 바다에 짝이 되는 Gateway가 생성되고 그곳으로 이동합니다. 이후 두 고리는 고정된 이동 경로가 됩니다. 미리 탐험하거나 청크를 불러올 필요가 없습니다.

이 변경 이전에 생성되어 모두 Cyan으로 시작하던 자연 Gateway도 고리가 완성될 때 각각의 짝 주소를 받습니다.

자연 Gateway도 다른 Gateway처럼 주소를 바꿀 수 있습니다. 직접 만든 고리의 주소를 지정하면 원래 짝 대신 그곳으로 연결됩니다. 다른 고리가 사용하지 않는 새 주소를 지정하면 다음 이동 시 그 주소의 새로운 짝이 생성됩니다.

***

## <Color id="gold">Gateway 제작과 이동</Color>

제작한 Gateway는 고리 전체가 하나의 아이템으로 포장되어 있습니다. 설치하면 바라보는 방향을 가로지르는 고리 전체가 한 번에 생성되며 전면은 플레이어를 향합니다.

웅크린 채 렌치(<ItemLink id="aquarine_steel_wrench"/> 또는 다른 모드의 렌치)로 완성된 고리의 아무 부분이나 우클릭하면 다시 포장됩니다. 주소를 유지한 Gateway 아이템 하나가 돌아오므로 자연 Gateway를 집으로 옮겨도 기존 경로를 유지할 수 있습니다.

고리는 Gateway 블록 위에 서며 너비 13블록, 높이 13블록의 공간이 필요합니다. 공기, 물, kelp, seagrass, coral 등 다른 블록으로 덮어 설치할 수 있는 공간에는 생성됩니다. 단단한 블록이 가로막으면 Gateway 블록만 남고 방해 위치를 알려 줍니다. <ItemLink id="prism_monocle"/>를 착용하고 Gateway를 바라보면 방해 블록이 모두 빨간색으로 표시됩니다. 이를 제거하면 몇 초 안에 자동으로 고리가 완성되며, 렌치로 Gateway를 우클릭해 즉시 재시도할 수도 있습니다.

완성된 고리는 채굴해서 재료를 얻을 수 없습니다. 일부를 부수려면 맨손으로 Obsidian을 부수는 만큼 시간이 걸리며 아무것도 떨어지지 않고 나머지 고리는 일반 <ItemLink id="gateway_ring"/>으로 돌아갑니다. 대신 렌치를 사용하세요.

부서진 고리를 수리하려면 아래 원형 배치대로 조각을 다시 놓고 렌치로 Gateway를 우클릭하세요.

<GameScene zoom="2" background="#333333" interactive={true}>
  <Block id="nautec:gateway_ring" x="4" y="0" z="0"/>
  <Block id="nautec:gateway_ring" x="5" y="0" z="0"/>
  <Block id="nautec:gateway" x="6" y="0" z="0"/>
  <Block id="nautec:gateway_ring" x="7" y="0" z="0"/>
  <Block id="nautec:gateway_ring" x="8" y="0" z="0"/>
  <Block id="nautec:gateway_ring" x="2" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="3" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="4" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="5" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="6" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="7" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="8" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="9" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="10" y="1" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="2" z="0"/>
  <Block id="nautec:gateway_ring" x="2" y="2" z="0"/>
  <Block id="nautec:gateway_ring" x="3" y="2" z="0"/>
  <Block id="nautec:gateway_ring" x="9" y="2" z="0"/>
  <Block id="nautec:gateway_ring" x="10" y="2" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="2" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="3" z="0"/>
  <Block id="nautec:gateway_ring" x="2" y="3" z="0"/>
  <Block id="nautec:gateway_ring" x="10" y="3" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="3" z="0"/>
  <Block id="nautec:gateway_ring" x="0" y="4" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="4" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="4" z="0"/>
  <Block id="nautec:gateway_ring" x="12" y="4" z="0"/>
  <Block id="nautec:gateway_ring" x="0" y="5" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="5" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="5" z="0"/>
  <Block id="nautec:gateway_ring" x="12" y="5" z="0"/>
  <Block id="nautec:gateway_ring" x="0" y="6" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="6" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="6" z="0"/>
  <Block id="nautec:gateway_ring" x="12" y="6" z="0"/>
  <Block id="nautec:gateway_ring" x="0" y="7" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="7" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="7" z="0"/>
  <Block id="nautec:gateway_ring" x="12" y="7" z="0"/>
  <Block id="nautec:gateway_ring" x="0" y="8" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="8" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="8" z="0"/>
  <Block id="nautec:gateway_ring" x="12" y="8" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="9" z="0"/>
  <Block id="nautec:gateway_ring" x="2" y="9" z="0"/>
  <Block id="nautec:gateway_ring" x="10" y="9" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="9" z="0"/>
  <Block id="nautec:gateway_ring" x="1" y="10" z="0"/>
  <Block id="nautec:gateway_ring" x="2" y="10" z="0"/>
  <Block id="nautec:gateway_ring" x="3" y="10" z="0"/>
  <Block id="nautec:gateway_ring" x="9" y="10" z="0"/>
  <Block id="nautec:gateway_ring" x="10" y="10" z="0"/>
  <Block id="nautec:gateway_ring" x="11" y="10" z="0"/>
  <Block id="nautec:gateway_ring" x="2" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="3" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="4" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="5" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="6" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="7" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="8" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="9" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="10" y="11" z="0"/>
  <Block id="nautec:gateway_ring" x="4" y="12" z="0"/>
  <Block id="nautec:gateway_ring" x="5" y="12" z="0"/>
  <Block id="nautec:gateway_ring" x="6" y="12" z="0"/>
  <Block id="nautec:gateway_ring" x="7" y="12" z="0"/>
  <Block id="nautec:gateway_ring" x="8" y="12" z="0"/>
</GameScene>

***

## <Color id="gold">전력</Color>

한 번도 이동하지 않은 자연 Gateway는 전력이 필요하지 않습니다. 제작하거나 이동한 Gateway에는 AP가 필요하므로 고리 아래의 Gateway 블록에 레이저를 조사하세요([레이저 전력](nautec:getting_started/laser_power.md) 참고). 최대 5,000 AP를 저장하며 열린 동안 매 틱 100 AP를 사용합니다. 2,000 AP가 충전되면 열리고 저장 전력이 바닥날 때까지 유지됩니다. 따라서 100 AP/t 이상을 공급하면 주변에 누군가 있는 동안 계속 열립니다. 약한 레이저로는 몇 초 동안 열렸다가 2,000 AP를 다시 충전하는 동안 닫힙니다.

***

## <Color id="gold">열리는 조건</Color>

연결된 고리는 플레이어나 Submarine이 약 12블록 이내에 접근하면 열려 바로 진입할 수 있습니다. 먼저 주소를 입력하는 동작이 시작되어 문양 고리가 회전하고 주소 표시가 지정된 색으로 빛나며 사건의 지평선이 열립니다. 모두 떠난 뒤 몇 초가 지나면 다시 닫힙니다.

Gateway 블록에 레드스톤 신호를 주면 고리가 닫힌 상태로 유지됩니다.

***

## <Color id="gold">주소</Color>

9개 표시 중 전면 기준 왼쪽 위, 오른쪽 위, 왼쪽 아래, 오른쪽 아래 4개가 주소를 저장합니다. 각 표시에는 8가지 색을 지정할 수 있으므로 총 4,096개 주소가 가능합니다.

White, Light Blue, Cyan, Blue, Purple, Magenta, Lime, Black의 8가지 색입니다.

주소 변경에는 비용이 들지 않으며 두 가지 방법이 있습니다.

* 해당 색 염료를 들고 주소 표시 근처의 고리를 우클릭하면 가장 가까운 표시가 그 색으로 바뀝니다. 염료는 소모되지 않습니다.
* 빈손으로 고리를 우클릭하면 주소 화면이 열립니다. 1~4행은 왼쪽 위, 오른쪽 위, 왼쪽 아래, 오른쪽 아래 표시입니다. 각각 색을 고르고 Set을 누르세요.

<ItemLink id="prism_monocle"/>로 고리의 아무 부분이나 바라보면 주소, 개방 여부, 저장 전력을 확인할 수 있습니다.

***

## <Color id="gold">이동</Color>

양쪽 어느 방향에서든 사건의 지평선을 통과하면 연결된 고리의 전면으로 나옵니다. 통로 안의 상대 위치와 이동 속도가 유지되며 출구 반대쪽을 바라보게 됩니다. 타고 있는 탈것과 다른 탑승자도 함께 이동하므로 Submarine의 승무원도 그대로 도착합니다. 몹과 떨어진 아이템도 이동합니다.

* 목적지 고리 전면이 막혀 있으면 후면으로 나옵니다. 양쪽 모두 막혀 있으면 이동하지 않고 닫힌 고리처럼 그냥 통과합니다.
* 이동 후 5초 동안은 Gateway를 다시 사용할 수 없습니다(`config/nautec-common.toml`의 `gatewayCooldown`, 100틱). 즉시 되돌아가는 일을 막습니다.
* 목적지 고리가 로드되지 않은 청크에 있어도 이동할 때 Gateway가 해당 청크를 불러옵니다.
* 같은 주소의 고리가 여러 개면 가장 가까운 고리에 도착합니다. 원하는 곳에 도착하도록 고리 쌍마다 다른 주소를 지정하세요.

연결된 고리가 없으면 어둡게 유지되며 모든 대상이 그대로 통과합니다.

***

### <Color id="aqua">제작법</Color>

<Recipe id="nautec:gateway"/>

<Recipe id="nautec:gateway_ring"/>
