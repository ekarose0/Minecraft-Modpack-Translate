---
navigation:
  title: 심해 공학
  icon: nautec:resonant_shard
  position: 4
---

# <Color id="gold">심해 공학</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="resonant_shard" scale="2"/>
  레이저 광학과 순도, Abyssal Pressure Forge, Laser Purification Smelter, Resonance Chamber, Gateway, 결정 배양, Fusion Plant, Resonance Network 및 이를 이용해 제작하는 후반 장비를 다룹니다.
</Column>

***

<SubPages icons={true}/>
