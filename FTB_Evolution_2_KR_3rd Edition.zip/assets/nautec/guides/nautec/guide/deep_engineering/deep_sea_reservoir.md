---
navigation:
  title: Deep Sea Reservoir
  icon: nautec:deep_sea_reservoir
  position: 15
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:deep_sea_reservoir
  - nautec:reservoir_upgrade_2
  - nautec:reservoir_upgrade_3
  - nautec:reservoir_upgrade_4
---

# <Color id="light_purple">Deep Sea Reservoir</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="deep_sea_reservoir" scale="2"/>
  한 종류의 액체를 다른 탱크와 비교할 수 없을 만큼 대량으로 저장하는 3×3×3 탱크입니다.
</Column>

## <Color id="gold">설치하기</Color>

Reservoir는 아이템 하나로 설치하는 3×3×3 구조물입니다. 블록 위에 놓으면 해당 블록을 중심으로 위쪽 3×3×3 공간에 자동으로 생성되며 계기판이 플레이어를 향합니다. 이 공간은 미리 비어 있어야 합니다(공기, 물 또는 덮어 설치할 수 있는 식물은 허용). 따라서 해저에도 설치할 수 있습니다.

마른 상태로 설치한 Reservoir에 물이 닿으면 일반 물의 흐름처럼 프레임 안으로 퍼집니다. 옆면에서는 수평으로, 위쪽에서는 아래로 흘러들지만 아래에서 위로는 흐르지 않습니다.

어느 부분을 부수든 Reservoir 전체가 아이템 하나로 회수됩니다. 단계와 내부 액체가 모두 보존되므로 가득 찬 Reservoir도 그대로 옮길 수 있습니다.

***

## <Color id="gold">액체 투입과 배출</Color>

* 3×3×3 구조물의 모든 외부 면이 같은 탱크에 연결되므로 어느 면에든 파이프를 연결할 수 있습니다.
* 양동이나 다른 액체 용기를 들고 우클릭하면 액체를 넣거나 꺼냅니다.
* 빈손으로 우클릭하면 화면이 열립니다. 커서에 액체 용기를 들고 화면의 계기판을 클릭해도 액체를 넣거나 꺼낼 수 있습니다.
* 전면의 유리 표시창에서 내부 액체와 현재 수위를 확인할 수 있습니다.
* 비교기로 탱크의 충전 비율을 읽을 수 있습니다.

한 번에 한 종류의 액체만 저장할 수 있습니다. 완전히 비우면 다른 액체를 넣을 수 있습니다.

***

## <Color id="gold">단계별 용량</Color>

| 단계 | 저장 용량 | 업그레이드 |
|---|---|---|
| I | 500,000,000양동이 | 기본 Reservoir |
| II | 2,000,000,000양동이 | <ItemLink id="reservoir_upgrade_2"/> |
| III | 10,000,000,000양동이 | <ItemLink id="reservoir_upgrade_3"/> |
| IV | 50,000,000,000양동이 | <ItemLink id="reservoir_upgrade_4"/> |

단계가 오를수록 외형이 바뀝니다. II단계에는 강철 프레임과 리벳 띠, III단계에는 구리 띠·파이프·밸브 손잡이, IV단계에는 빛나는 프리즈머린 수정 장식이 추가됩니다.

업그레이드는 순서대로 적용해야 합니다. 다음 단계의 업그레이드를 들고 Reservoir를 우클릭하거나 화면의 업그레이드 슬롯에 넣으면 즉시 적용됩니다.

화면의 **Remove Upgrade**를 누르면 최상위 업그레이드를 돌려받고 Reservoir 단계가 하나 내려갑니다. 현재 액체량이 하위 단계 용량을 초과하면 손실량을 알려주고 두 번째 클릭으로 확인을 요청합니다. 하위 단계의 최대 용량을 초과하는 액체는 사라집니다.

***

## <Color id="gold">제작법</Color>

<Recipe id="nautec:deep_sea_reservoir"/>

<Recipe id="nautec:reservoir_upgrade_2"/>

<Recipe id="nautec:reservoir_upgrade_3"/>

<Recipe id="nautec:reservoir_upgrade_4"/>

단계별 저장 용량은 `config/nautec-common.toml`에서 설정할 수 있습니다.
