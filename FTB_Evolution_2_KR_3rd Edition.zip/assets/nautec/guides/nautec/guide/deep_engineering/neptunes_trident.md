---
navigation:
  title: Neptune's Trident
  icon: nautec:neptunes_trident
  position: 6
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:neptunes_trident
---

# <Color id="light_purple">Neptune's Trident</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="neptunes_trident" scale="2"/>
  부서지지 않고 손으로 돌아오며 명중 지점에 조류 충격파를 일으키는 삼지창입니다.
</Column>

Neptune's Trident는 바닐라 삼지창과 비슷하지만 피해량이 더 높습니다. 절대 부서지지 않으며 Loyalty III의 속도로 항상 돌아옵니다. 사용 키를 누르고 있다가 놓으면 던지고, 공격하면 근접 무기로 사용합니다.

***

## <Color id="gold">피해량</Color>

| 공격 방식 | 피해량 |
|---|---|
| 투척 | 18 |
| 근접 공격 | 19 (공격 속도 1.2) |
| Riptide 회전 | 18 |

근접 공격은 검처럼 휩쓸기 공격을 하여 목표 옆의 생물도 타격합니다.

***

## <Color id="gold">조류 충격파</Color>

던진 삼지창이 처음 맞힌 생물이나 블록의 위치에서 조류 충격파가 발생합니다. 번개 효과로 충격파 발생 지점이 표시되지만 이 번개는 시각 효과일 뿐 불을 붙이지 않습니다.

* 반경 5블록 이내의 모든 대상에 피해를 주며, 중심에서는 14, 가장자리에서는 7의 피해를 주고 중심에서 바깥쪽으로 밀쳐냅니다.
* Sharpness 레벨당 피해량이 3 증가하고, Knockback 레벨당 밀치기 효과가 강화됩니다.
* 사용자 자신, 길들인 동물, 같은 팀 플레이어, 크리에이티브 또는 관전자 모드 플레이어는 피해를 받지 않습니다.
* 충격파가 발생한 뒤 다음 충격파까지 3초의 대기시간이 있습니다. 그동안 삼지창을 계속 던질 수 있지만 충격파 없이 일반 피해만 줍니다. 인벤토리의 삼지창 슬롯에 남은 시간이 표시됩니다.

범위, 피해량, 레벨당 보너스와 재사용 대기시간은 `config/nautec-common.toml`에서 설정할 수 있습니다(`tridentShockwaveRadius`, `tridentShockwaveDamage`, `tridentShockwaveDamagePerSharpness`, `tridentShockwaveKnockback`, `tridentShockwaveKnockbackPerLevel`, `tridentShockwaveCooldown`).

***

## <Color id="gold">마법부여</Color>

삼지창과 검의 마법부여를 모두 적용할 수 있습니다.

* Impaling, Riptide and Channeling
* Sharpness, Smite, Bane of Arthropods, Knockback, Fire Aspect, Looting and Sweeping Edge
* Curse of Vanishing

Loyalty 효과는 기본으로 내장되어 있으며 Unbreaking이나 Mending은 필요하지 않습니다. 일반 삼지창처럼 Sharpness, Smite, Bane of Arthropods, Impaling 중 하나만 적용할 수 있습니다. 이 중 충격파 피해량도 올리는 것은 Sharpness입니다. Riptide와 Channeling은 동시에 적용할 수 없습니다.

Riptide를 적용하면 물속이나 비가 올 때 던지는 대신 사용자가 돌진하므로 충격파가 발생하지 않습니다. Channeling은 바닐라 삼지창과 마찬가지로 뇌우 중 하늘이 열린 곳의 목표에 실제 번개를 떨어뜨립니다.

마법부여 적합도가 매우 낮으므로 마법부여대보다 모루에서 마법이 부여된 책을 사용하는 것이 좋습니다.

***

## <Color id="gold">제작하기</Color>

제작법에 [Resonance Chamber](resonance_chamber.md)와 [Abyssal Pressure Forge](pressure_forge.md)에서 생산하는 재료가 필요하므로 두 기계를 먼저 가동하세요. [심해 재료](materials.md)를 참고하세요.

<Recipe id="nautec:neptunes_trident"/>
