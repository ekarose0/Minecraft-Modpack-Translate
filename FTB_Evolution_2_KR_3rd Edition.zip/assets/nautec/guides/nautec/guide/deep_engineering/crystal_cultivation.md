---
navigation:
  title: Crystal Cultivation
  icon: nautec:prismarine_crystal_seed
  position: 7
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:dormant_crystal_seed
  - nautec:prismarine_crystal_seed
  - nautec:crystal_cradle
---

# <Color id="light_purple">Crystal Cultivation</Color>

<Column alignItems="center" fullWidth={true}>
  <Row>
    <ItemImage id="prismarine_crystal_seed" scale="2"/>
    <ItemImage id="crystal_cradle" scale="2"/>
  </Row>
  직접 옮겨 설치할 수 있는 Prismarine Crystal을 재배합니다.
</Column>

<ItemLink id="prismarine_crystal"/>은 모든 레이저 빔의 순도를 3.0으로 바꾸지만, Crystal Geode에서 자연적으로 생성된 결정은 자란 곳에 고정되어 있습니다. **Cultivated Prismarine Crystal**은 성장이 끝날 때 **3.00~6.00**의 순도가 무작위로 정해지므로 더 순도 높은 빔을 얻을 기회가 있습니다. 렌치로 회수하여 원하는 곳에 다시 설치할 수도 있습니다. 재배에는 씨앗, 받침대, 높은 순도의 레이저 에너지 1,000만 AP가 필요합니다.

***

## <Color id="gold">1. 자연산 결정 찾기</Color>

씨앗을 활성화하려면 순도 3.0의 빔이 필요하며, 이 빔은 Prismarine Crystal에서만 나옵니다. 해저의 Crystal Geode에서 결정을 찾고([구조물](nautec:getting_started/structures.md) 참고), [Laser Power](nautec:getting_started/laser_power.md)에 설명된 대로 레이저를 조사하세요. 이 과정은 처음 한 번만 필요합니다. 첫 재배 결정을 얻고 나면 이후 모든 씨앗을 그 결정으로 활성화할 수 있습니다.

***

## <Color id="gold">2. Dormant Crystal Seed 제작</Color>

Flawless Prismarine Crystal 주위에 Resonant Shards와 Prismarine Crystal Shards를 배치하면 <ItemLink id="dormant_crystal_seed"/>를 만들 수 있습니다. 아직은 작동하지 않습니다.

<RecipeFor id="dormant_crystal_seed"/>

***

## <Color id="gold">3. 씨앗 활성화</Color>

<Row>
  <ItemImage id="dormant_crystal_seed" scale="2"/>
  <ItemImage id="prismarine_crystal_seed" scale="2"/>
</Row>

순도 3.0의 빔이 공급되는 [Resonance Chamber](resonance_chamber.md)에 Dormant Crystal Seed를 넣으세요. 공명실이 임계 상태에 도달하면 씨앗이 빛나는 <ItemLink id="prismarine_crystal_seed"/>로 바뀝니다. 비활성 씨앗 1개를 넣으면 활성 씨앗 1개가 나옵니다. 제작법은 JEI의 Resonance Chamber 분류에서 확인할 수 있습니다.

***

## <Color id="gold">4. 받침대에 씨앗 놓기</Color>

결정을 세울 위치에 <ItemLink id="crystal_cradle"/>을 놓고, **위쪽 6칸을 비워 두세요**. 공기와 물 모두 허용되므로 수중에서도 작동합니다. 활성화된 씨앗을 들고 받침대를 우클릭하면 작은 결정이 위에 나타납니다.

<RecipeFor id="crystal_cradle"/>

성장이 시작되기 전에는 빈손으로 씨앗을 다시 꺼낼 수 있습니다. 호퍼와 파이프로도 씨앗을 넣을 수 있습니다.

***

## <Color id="gold">5. 1,000만 AP 공급</Color>

받침대의 네 옆면 중 아무 곳에나 레이저 빔을 조사하세요. 매 틱 빔의 모든 AP가 씨앗의 성장에 더해지지만 **빔 순도가 2.0 이상일 때만** 작동합니다. 순도 2.0 이상의 빔을 얻는 방법은 다음과 같습니다.

* <ItemLink id="bacterial_fuel_cell"/> 사용(최대 2.5)
* 기존 빔에 [Focusing Lens](beam_optics.md) 사용(최대 2.0까지 상승)
* 다른 Prismarine Crystal 사용(3.0)

여러 빔을 받침대에 연결하면 전력은 합산되고, 순도는 가장 높은 빔에 가까워지되 전체 평균과의 차이의 1/4만큼 낮아집니다. 약한 빔도 순도를 조금 낮춥니다. 따라서 순도 2.1인 빔에 순도 0인 빔을 합치면 2.0 아래로 떨어집니다.

총 **10,000,000 AP**를 공급하면 씨앗이 완전한 결정으로 자랍니다(`config/nautec-common.toml`의 `crystalGrowthPower`, 최소 순도는 `crystalGrowthPurity`). 전력이 높을수록 빨리 자랍니다.

| 빔 전력 | 성장 시간 |
|---|---|
| 100 AP/t | 약 83분 |
| 250 AP/t | 약 33분 |
| 500 AP/t | 약 17분 |
| 1,000 AP/t | 약 8분 |

받침대 위의 결정은 성장도가 차오를수록 높아집니다. 진행도는 감소하지 않습니다. 빔이 끊겨도 다시 공급될 때까지 기다리므로 여러 번에 나누어 1,000만 AP를 채워도 됩니다.

Jade로 받침대를 바라보면 진행도, 공급되는 전력과 순도, 현재 전력 기준 남은 시간, 정지 이유(씨앗 없음, 위쪽 공간 부족, 전력 없음, 순도 부족)를 확인할 수 있습니다.

<Color id="gold">성장 중인 씨앗 이동</Color>: 아무 도구로 받침대를 부수면 씨앗과 누적 성장도가 저장된 상태로 떨어집니다. 툴팁에서 진행도를 확인할 수 있으며 다시 설치하면 성장이 이어집니다.

***

## <Color id="gold">6. 재배한 결정</Color>

총 1,000만 AP에 도달하면 씨앗이 받침대 위의 완전한 Cultivated Prismarine Crystal로 변합니다. 성장이 끝나는 순간 순도가 **3.00~6.00** 사이에서 0.01 단위로 무작위 결정됩니다(이후 더 높일 수도 있습니다). 결정의 옆면에 빔을 조사하면 위아래에서 해당 순도의 빔이 출력되며 입력 전력을 나누어 사용합니다([Laser Power](nautec:getting_started/laser_power.md) 참고). 받침대는 다시 비어 다음 씨앗을 받을 수 있습니다.

**이동하려면** 웅크린 채 렌치로 결정의 아무 부분이나 우클릭하세요. <ItemLink id="aquarine_steel_wrench"/>를 포함해 `c:tools/wrench` 태그에 속한 다른 모드의 렌치도 사용할 수 있습니다. 결정이 아이템으로 회수되며, 재설치할 때도 위쪽 6칸이 비어 있어야 합니다. 회수하거나 월드를 다시 불러와도 순도는 유지되며 새로 추첨되지 않습니다. 아이템 툴팁에서 순도를 확인하세요.

자연산 결정은 제자리에 고정되어 있습니다. Aquarine Steel Pickaxe의 분쇄 능력은 자연산 결정에만 적용되므로 재배 결정은 실수로 부서지지 않습니다. Jade에는 각 결정이 Cultivated인지 Natural인지 표시됩니다.

6.00은 초기 순도의 상한일 뿐입니다. [Bacterial Enrichment Catalyst](bacterial_enrichment_catalyst.md)를 사용하면 재배 결정의 순도를 최대 12까지 더 높일 수 있습니다.

재배 결정은 NauTec에서 가장 큰 발전기인 [Fusion Plant](fusion_plant.md)의 핵심 재료이기도 합니다.
