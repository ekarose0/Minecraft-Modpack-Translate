---
navigation:
  title: Laser Purification Smelter
  icon: nautec:laser_purification_smelter
  position: 13
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:laser_purification_smelter
---

# <Color id="light_purple">Laser Purification Smelter</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="laser_purification_smelter" scale="2"/>
  연료 대신 레이저 빔을 사용하여 최대 9개 슬롯의 아이템을 동시에 제련합니다.
</Column>

Laser Purification Smelter는 일반 화로에서 제련할 수 있는 모든 아이템을 처리하며, 입력 슬롯에는 제련 가능한 아이템만 들어갑니다. 각각 출력 슬롯과 짝을 이루는 입력 슬롯 9개와 Conduit 업그레이드 슬롯 1개가 있습니다. 업그레이드에 따라 열리는 슬롯 수와 제련 속도가 달라집니다. 순도가 높은 빔을 쓰면 전력 소비가 줄어듭니다.

***

## <Color id="gold">전력</Color>

제련기는 윗면과 앞면을 제외한 세 옆면에서 레이저 빔을 받습니다. 연료는 필요하지 않습니다.

가동 중에는 매 틱 다음만큼 AP가 필요합니다.

**작업 중인 슬롯 수 × 업그레이드의 슬롯당 AP ÷ 빔 순도**, 올림 처리

작업 중인 슬롯이란 열려 있고 제련할 아이템이 있으며 출력 공간이 남아 있는 슬롯입니다. 빈 슬롯, 잠긴 슬롯, 출력이 가득 찬 슬롯은 전력을 소비하지 않으며, 대기 중인 제련기에는 빔 자체가 필요하지 않습니다.

* 필요한 전력보다 약한 빔이 들어오면 멈춥니다. 진행도는 유지되며 충분한 빔이 다시 들어오면 재개됩니다.
* 필요한 전력보다 강한 빔을 넣어도 속도는 빨라지지 않습니다. 속도는 업그레이드만 결정합니다.
* 순도가 1.0보다 높으면 소비 전력이 그만큼 나누어집니다. 순도 2.0은 전력 소비를 절반으로 줄입니다. 최소 순도 제한은 없으며 1.0 미만의 빔은 1.0으로 취급하므로 추가 비용도 할인도 없습니다.

***

## <Color id="gold">업그레이드와 속도</Color>

업그레이드 슬롯에 <ItemLink id="eddy_upgrade"/>, <ItemLink id="surge_upgrade"/>, <ItemLink id="riptide_upgrade"/>, <ItemLink id="maelstrom_upgrade"/> 중 하나를 넣으세요. [Current Conduit](current_conduits.md)의 Tap에 사용하는 것과 동일한 업그레이드입니다.

| 업그레이드 | 열리는 슬롯 | 제련량 | 작업 슬롯당 AP |
|---|---|---|---|
| 없음 | 1 | 20틱마다 8개 | 1 |
| Eddy | 3 | 10틱마다 16개 | 2 |
| Surge | 5 | 5틱마다 32개 | 4 |
| Riptide | 7 | 2틱마다 64개 | 8 |
| Maelstrom | 9 | 매 틱 64개 | 16 |

표의 속도는 슬롯마다가 아니라 제련기 전체에 적용됩니다. 각 간격이 끝날 때 작업 중인 슬롯을 차례로 돌며 아이템을 하나씩 제련하고, 정해진 수량을 처리하거나 더 이상 제련할 것이 없을 때까지 반복합니다. 예를 들어 9개 슬롯이 모두 가동 중인 Maelstrom 제련기는 틱당 각 슬롯에서 약 7개를 제련하며, 순도 1.0에서 144 AP, 순도 2.0에서 72 AP가 필요합니다.

제련 결과는 해당 입력과 짝을 이루는 출력 슬롯으로 이동합니다. 출력 슬롯은 같은 아이템만 받을 수 있고 결과 전체가 들어갈 공간이 있어야 하므로, 가득 찬 출력 슬롯은 그 슬롯의 작업만 중단시킵니다.

***

## <Color id="gold">잠긴 슬롯</Color>

업그레이드가 열어 주는 개수를 초과하는 슬롯은 자물쇠로 표시되며 잠깁니다. 커서를 올리면 어떤 업그레이드가 필요한지 나옵니다. 잠긴 입력 슬롯에는 플레이어나 자동화 장치가 아이템을 넣을 수 없습니다.

아이템이 들어 있는 슬롯이 잠기도록 업그레이드를 제거해도 아이템은 그대로 남습니다. 슬롯이 다시 열리기 전까지 제련되지는 않지만 직접 꺼낼 수는 있습니다.

***

## <Color id="gold">자동 분배</Color>

두 격자 사이의 Auto 버튼으로 자동 분배를 켜고 끕니다. 켜면 0.5초마다 입력 아이템을 열린 입력 슬롯에 균등하게 분배해 여러 슬롯이 동시에 제련하도록 합니다.

* 한 종류의 아이템은 최대한 고르게 나뉩니다. 열린 슬롯 3개에 Cobblestone 10개가 있으면 4개, 3개, 3개로 분배됩니다.
* 여러 종류의 아이템은 각 종류의 수량 비율에 따라 슬롯을 나눕니다. 각 종류에 최소 1개 슬롯을 배정하고 해당 슬롯들에 균등하게 분배합니다.
* 아이템은 추가되거나 사라지지 않고, 슬롯의 최대 중첩 수를 넘지 않습니다. 잠긴 슬롯의 아이템은 건드리지 않습니다.

새 제련기에서는 기본적으로 꺼져 있습니다. <ItemLink id="configuration_card"/>를 사용하면 장착된 업그레이드와 함께 이 설정을 다른 제련기로 복사할 수 있습니다.

***

## <Color id="gold">사용법</Color>

빈손으로 우클릭하면 화면이 열립니다. 왼쪽은 입력 격자, 오른쪽은 출력 격자이며, 가운데 진행 화살표는 현재 처리 간격의 진행도를 보여 줍니다. 아래 패널에는 다음 정보가 나옵니다.

* 현재 공급되는 빔 전력과 필요한 전력
* 빔 순도와 순도에 따른 소비 전력 할인
* 장착된 업그레이드의 처리 간격당 제련량
* 열린 슬롯 수

Inventory 표시 옆에는 Smelting, Waiting for beam, Outputs full, Idle 등의 상태가 표시됩니다. 패널의 항목에 커서를 올리면 자세한 정보를 볼 수 있습니다. 화살표를 클릭하면 JEI의 제련 제작법을 확인할 수 있습니다.

호퍼와 파이프로 입력 슬롯에 아이템을 넣고 출력 슬롯에서 꺼낼 수 있으며, 기본적으로 모든 면을 사용할 수 있습니다. [Side Configuration](nautec:getting_started/utilities.md)에서 면별로 설정할 수 있습니다. 자동화 장치는 업그레이드 슬롯에 접근할 수 없습니다. 제련기를 부수면 업그레이드를 포함한 내부 아이템이 모두 떨어집니다.

이 제련기는 경험치를 제공하지 않습니다.

***

## <Color id="gold">모드팩 제작자용 설정</Color>

`config/nautec-common.toml`의 `smelterSlots`는 업그레이드 없음, Eddy, Surge, Riptide, Maelstrom 순서의 열린 슬롯 수(기본값 1, 3, 5, 7, 9)를, `smelterApMultipliers`는 같은 순서의 작업 슬롯당 AP(기본값 1, 2, 4, 8, 16)를 지정합니다. 속도는 Conduit Tap의 아이템 설정(`conduitItemIntervalBase`~`conduitItemIntervalMaelstrom`, `conduitItemsPerOpBase`~`conduitItemsPerOpMaelstrom`)을 따르므로 이를 변경하면 양쪽 모두에 적용됩니다.

***

### <Color id="aqua">Laser Purification Smelter 제작법</Color>

<Recipe id="nautec:laser_purification_smelter"/>
