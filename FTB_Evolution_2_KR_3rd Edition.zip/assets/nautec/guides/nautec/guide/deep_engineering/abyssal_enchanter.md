---
navigation:
  title: Abyssal Enchanter
  icon: nautec:abyssal_enchanter
  position: 16
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:abyssal_enchanter
---
# <Color id="light_purple">Abyssal Enchanter</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="abyssal_enchanter" scale="2"/>
  시약, 액체 경험치, 레이저 광선을 사용해 책과 아이템에 원하는 마법 부여를 정확히 적용합니다.
</Column>

## <Color id="gold">배치</Color>

Enchanter는 아이템 한 개로 설치하며 중심 블록 기준 3×3, 높이 2블록 공간을 차지합니다. 해당 공간은 먼저 전부 비워야 하지만 수중에도 설치할 수 있습니다. 어느 부분을 부수든 내부 내용물과 함께 기계 전체가 아이템 하나로 떨어집니다.

작동 중에는 주변의 부서진 돌 고리가 떠오르며 회전하고, 기둥 안쪽 중심부가 빛나며 받침대 위로 빛기둥이 솟아오릅니다.

***

## <Color id="gold">마법 부여 방법</Color>

1. 책 또는 해당 마법을 부여할 수 있는 아이템을 위쪽 슬롯에 넣습니다.
2. 그 아래 슬롯에 시약을 넣습니다. 시약으로 마법 종류가 정해집니다. 예를 들어 석영은 날카로움(Sharpness), 레드스톤은 효율(Efficiency), 흑요석은 내구성(Unbreaking)에 대응합니다. 전체 목록은 JEI의 **Laser Enchanting**에서 확인하세요.
3. 화면의 화살표로 레벨을 선택합니다. 기본값은 최고 레벨입니다.
4. 탱크에 액체 경험치를 채우고 기계의 어느 블록이든 바깥 면으로 광선을 쏩니다.

레벨마다 시약 한 세트가 필요하므로 Sharpness V에는 Sharpness I보다 석영이 다섯 배 필요합니다. 작업이 끝나면 책이나 아이템이 출력 슬롯으로 이동합니다. 이미 더 낮은 레벨의 해당 마법이 부여되어 있었다면 선택한 레벨로 올라갑니다.

하나의 시약에 여러 마법이 대응하면 **»** 버튼으로 변경할 수 있습니다.

***

## <Color id="gold">최대 레벨 초과 부여</Color>

정상 최대 레벨보다 다섯 단계 높은 수준까지 마법을 부여할 수 있으므로 Sharpness는 X까지 가능합니다. 화살표로 최대 레벨을 넘기면 레벨이 금색으로 표시됩니다.

정상 최대 레벨을 넘을 때마다 총 AP와 액체 경험치 소모량이 이전 레벨의 네 배가 됩니다. Sharpness VI는 4배, VII은 16배, X는 1,024배입니다. 필요한 광선 출력도 기존 공식에 따라 계속 높아지지만 시약 수량은 정상 최대 레벨 기준으로 유지됩니다.

초과 부여는 아이템에만 가능합니다. 위쪽 슬롯에 책을 넣으면 일반 최대 레벨까지만 선택할 수 있으므로 검, 곡괭이, 방어구 자체를 Enchanter에 넣으세요.

***

## <Color id="gold">액체 경험치</Color>

탱크는 `c:experience` 유체 태그를 가진 액체 경험치만 받습니다. Experience Algae와 다른 모드의 경험치 유체도 허용되지만 그 외 액체는 들어가지 않습니다. 저장량은 약 210만 양동이이며 너무 많이 넣었다면 파이프로 다시 뺄 수 있습니다. 20 mB가 경험치 1점입니다.

***

## <Color id="gold">광선 에너지</Color>

마법 부여에는 두 가지 AP 기준이 있습니다.

* **최소 광선 출력**: 작업을 시작하기 위해 필요한 출력입니다.
* **총 소모량**: 완료될 때까지 받아야 하는 누적 AP입니다. 최소 출력보다 강한 광선을 사용하면 더 빨리 끝납니다.

두 값은 마법의 레벨과 희귀도가 높을수록 급격히 증가합니다. Sharpness I에는 10 AP 광선, Sharpness V에는 250 AP 광선과 총 250,000 AP가 필요하며, Thorns III에는 720 AP 광선이 필요합니다. Mending 같은 보물 마법은 비용이 두 배입니다. 화면과 JEI에 정확한 수치가 표시됩니다.

***

## <Color id="gold">순도</Color>

광선 순도가 **3.0** 이상이면 선택한 마법과 레벨이 반드시 그대로 적용됩니다. 이보다 낮으면 순도가 떨어질수록 다음과 같은 결과 변동이 자주 발생합니다.

* 레벨이 달라질 수 있으며 보통 하나 낮아지고 간혹 하나 높아집니다.
* 아이템에 적용할 수 있는 다른 마법으로 바뀔 수 있습니다.
* 선택한 마법과 더불어 무작위 1레벨 마법이 추가될 수 있습니다.

순도 **0.5** 미만에서는 저주가 추가될 가능성도 있습니다. 책이나 아이템 자체는 파괴되지 않으며 화면에서 현재 광선의 안정성을 확인할 수 있습니다.

***

## <Color id="gold">제작</Color>

<Recipe id="nautec:abyssal_enchanter"/>

출력·경험치·순도·저주·초과 레벨 설정은 `config/nautec-common.toml`에서 조정합니다. 모드팩 제작자는 `nautec:laser_enchanting` 제작법으로 자체 시약을 추가할 수 있습니다.

특정 마법을 제외하려면 설정의 `abyssalEnchanterBlacklist`에 마법 ID를 추가하거나(`modid:*`는 해당 모드 전체 차단), `nautec:abyssal_enchanter_blacklist` 마법 태그에 등록하세요. 차단한 마법은 만들 수 없고 저순도 결과에도 나오지 않으며 JEI에서도 숨겨집니다. Ars Elemental의 Soulbound는 기본적으로 차단됩니다.
