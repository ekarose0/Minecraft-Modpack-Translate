---
navigation:
  title: Atlantean Rifle
  icon: nautec:atlantean_rifle
  position: 5
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:atlantean_rifle
---
# <Color id="light_purple">Atlantean Rifle</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="atlantean_rifle" scale="2"/>
  사용 버튼을 누르고 있으면 연속 입자 광선을 발사하는 충전식 무기입니다.
</Column>

사용 버튼을 0.5초 동안 누르면 준비 동작을 마치고 조준한 곳으로 광선을 발사합니다. 누르고 있는 동안 2틱마다 피해를 주며 연속 발사할수록 위력이 강해집니다. 저장된 AP를 사용하므로 충전량이 없으면 작동하지 않습니다.

***

## <Color id="gold">피해량과 에너지</Color>

연속 발사하는 첫 10초 동안 피해량과 에너지 소비량이 초기값에서 최대값까지 함께 증가합니다. 버튼에서 손을 떼면 모두 초기화됩니다.

| 항목 | 처음 | 10초 뒤 |
|---|---|---|
| 명중당 피해 | 4 | 20 |
| 초당 피해 | 40 | 200 |
| 명중당 AP | 125 | 625 |
| 초당 AP | 1,250 | 6,250 |

* 각 공격은 대상의 피해 무적 시간을 무시하므로 모든 명중이 피해를 줍니다.
* 광선의 사거리는 128블록입니다. 물을 통과하지만 처음 만나는 고체 블록에서 막히며, 경로상 첫 번째 생명체를 맞힙니다.
* 완충 시 연속 발사 시간은 약 164초(2분 45초)입니다. 짧게 끊어 쏘면 소비량이 낮은 초기 구간을 주로 이용하므로 더 오래 사용할 수 있습니다.
* 첫 발에 필요한 AP도 없으면 "The Atlantean Rifle has no charge"가 표시되고 발사되지 않습니다. 발사 중 에너지가 바닥나도 멈춥니다.

표의 수치와 준비 시간·사거리는 `config/nautec-common.toml`의 `rifleBaseDamage`, `rifleMaxDamage`, `rifleBaseDrain`, `rifleMaxDrain`, `rifleRampTicks`, `rifleChargeTicks`, `rifleRange`에서 설정할 수 있습니다.

***

## <Color id="gold">충전</Color>

최대 저장량은 1,000,000 AP(`riflePowerCapacity`)이며 제작 직후에는 비어 있습니다. 아이템 아래 막대에 잔량이, 툴팁에 정확한 값이 표시됩니다.

* <ItemLink id="charger"/>는 광선으로 공급받는 에너지를 매 틱 충전하며 최대 입력은 틱당 20,000 AP(`rifleMaxInput`)입니다. Charger에 강한 광선을 넣으면 더 빨리 충전합니다.
* Curios 슬롯에 착용한 <ItemLink id="prismatic_battery"/>의 기능이 켜져 있으면 배터리 저장량에서 틱당 최대 100 AP를 공급합니다.

***

## <Color id="gold">마법 부여</Color>

이 무기에는 무한(Infinity)과 저주만 부여할 수 있습니다. 무한은 에너지 소비량을 절반으로 줄이므로 완충 시 연속 발사 시간이 약 324초(5분 30초)가 됩니다. 마법 부여 적합도가 매우 낮아 부여대보다 모루와 책을 사용하는 편이 낫습니다.

Apotheosis가 설치되어 있으면 이 무기는 접사와 보석에서 활로 취급되며, 활 능력치가 광선에도 적용됩니다.

* 장전 속도(Draw speed)는 발사 준비 시간을 단축합니다. +50%라면 준비 시간이 원래의 2/3가 됩니다.
* 화살 속도와 화살 피해는 광선 피해량에 곱해집니다. 화살 속도 +50%는 피해량 1.5배를 뜻합니다.
* 보호 관통과 보호 분쇄는 대상의 보호 효과를 일부 무시하고, 방어력 관통과 분쇄는 대상 방어력을 일부 무시합니다. 효과는 보석에 따라 달라집니다.
* 치명타 확률과 피해량도 일반 공격과 동일하게 적용됩니다.

***

## <Color id="gold">획득 방법</Color>

제작법에 [Abyssal Pressure Forge](pressure_forge.md)의 재료가 필요하므로 먼저 해당 기계를 준비하세요. [심해 재료](materials.md)도 참고하세요.

<Recipe id="nautec:atlantean_rifle"/>
