---
navigation:
  title: Abyssal Pressure Forge
  icon: nautec:pressure_forge
  position: 3
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:pressure_forge
  - nautec:pressure_synthesizer
  - nautec:atlantean_pressure_synthesizer
---

# <Color id="light_purple">Abyssal Pressure Forge</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="pressure_forge" scale="2"/>
  레이저 빔과 Etching Acid를 이용해 깊은 물속의 압력으로 재료를 압착합니다.
</Column>

Abyssal Pressure Forge는 Flawless Prismarine Crystal, Atlantic Gold Ingot, Deep Steel Plating을 만듭니다. 깊은 지하와 물기둥 아래에서만 작동하므로 해저에 설치하거나 깊은 수직 통로를 물로 채워야 합니다.

***

## <Color id="gold">작동 조건</Color>

아래 조건을 모두 동시에 충족해야 합니다. 하나라도 충족하지 못하면 현재 압착 작업의 진행도가 0으로 초기화됩니다.

* 깊이: Forge는 Y 0 이하에 있어야 합니다(`pressureForgeDepth`). 제작법별 최대 Y 높이도 아래 표에 나옵니다.
* 물: Forge 바로 위 8칸이 모두 물 근원 블록이어야 합니다(`pressureForgeWaterColumn`). 깊이만 충족해서는 안 되며 마른 수직 통로는 인정되지 않습니다. Pressure Synthesizer로 대체할 수 있습니다.
* 전력: 매 틱 최소 40 AP의 빔이 필요합니다(`pressureForgePowerUsage`). 네 옆면과 윗면에서 빔을 받습니다.
* 순도: 제작법이 요구하는 빔 순도를 충족해야 합니다.
* Etching Acid: 탱크에 최소 250 mB가 있어야 합니다. 압착 작업을 한 번 완료할 때마다 250 mB를 소비합니다(`pressureForgeAcidUsage`). 탱크 용량은 4,000 mB입니다(`pressureForgeCapacity`).

이 값들은 모두 `config/nautec-common.toml`에서 설정할 수 있습니다.

***

## <Color id="gold">제작법</Color>

| 입력 | 출력 | 순도 | 최대 Y | 시간 |
|---|---|---|---|---|
| Resonant Shard | Flawless Prismarine Crystal | 2.0 | -20 | 10초 |
| Block of Gold | 2 Atlantic Gold Ingots | 2.0 | -20 | 15초 |
| Aquarine Steel Ingot | Deep Steel Plating | 2.5 | -40 | 15초 |

제작법은 JEI에서도 확인할 수 있습니다. 결과물의 용도는 [Deep Materials](materials.md)를 참고하세요.

***

## <Color id="gold">사용법</Color>

빈손으로 우클릭하면 Forge 화면이 열립니다. 입력, 출력, 산 탱크, 합성기 슬롯이 있고 입력과 출력 사이에는 진행 화살표가 있습니다. 아래 체크리스트에는 깊이, 위쪽 물, 빔 전력, 제작법에 필요한 빔 순도, Etching Acid의 현재 값이 초록색 또는 빨간색으로 표시됩니다. 항목에 커서를 올리면 요구 조건을 볼 수 있습니다. 화살표를 클릭하면 JEI의 제작법이 열립니다.

압착할 아이템을 들고 우클릭해 넣거나 <ItemLink id="etching_acid_bucket"/>으로 탱크를 채울 수도 있습니다.

호퍼와 파이프로 아이템과 Etching Acid를 넣고 완성된 아이템을 꺼낼 수 있으며 기본적으로 모든 면이 허용됩니다. [Side Configuration](nautec:getting_started/utilities.md)에서 아이템과 유체의 면별 입출력을 따로 설정합니다. 윗면은 물에 잠겨 있어야 하므로 옆면을 사용하세요. Forge는 한 번에 아이템 하나를 압착하며 출력 슬롯에 공간이 있어야 작업을 완료합니다.

<ItemLink id="prism_monocle"/>로 바라보면 상태를 확인할 수 있습니다. 올바르게 설치된 경우 "Under pressure"와 산 용량 및 빔 순도가 표시되고, 그렇지 않으면 부족한 깊이나 물 조건이 표시됩니다.

## <Color id="gold">Pressure Synthesizer</Color>

Forge에 합성기를 장착하면 깊은 물속의 압력을 대신 구현하므로 원하는 장소에 설치할 수 있습니다. 합성기를 들고 Forge를 우클릭하거나 화면의 합성기 슬롯에 넣어 장착하세요. 슬롯에서 꺼내거나 빈손으로 웅크려 우클릭하면 제거됩니다. 다른 합성기를 장착하면 기존 합성기가 반환되며, Forge를 부수면 장착된 합성기가 떨어집니다. <ItemLink id="prism_monocle"/>로 장착 상태를 확인할 수 있습니다.

<Row>
  <ItemImage id="pressure_synthesizer"/>
  <ItemImage id="atlantean_pressure_synthesizer"/>
</Row>

* <ItemLink id="pressure_synthesizer"/>: Forge 위의 물기둥을 대신합니다. Forge는 여전히 Y 0 이하에 있어야 하며 제작법별 최대 Y도 적용됩니다. [Mixer](nautec:laser_chemistry/mixer.md)에서 Flawless Prismarine Crystal 1개와 Salt Water 8,000 mB로 만듭니다.
* <ItemLink id="atlantean_pressure_synthesizer"/>: 위쪽에 물이 없어도 어느 높이에서든 Forge를 작동시키며 제작법별 최대 Y 제한도 무시합니다. Mixer에서 Pressure Synthesizer 1개, Heart of the Sea 1개, Nether Star 1개, Ender Pearl 4개와 Salt Water 8,000 mB로 만듭니다.

Flawless Prismarine Crystal은 실제 물속에서 작동하는 Forge로 먼저 만들어야 하므로 최초에는 정상적인 수중 Forge가 필요합니다.

<Color id="gold">팁</Color>: 레이저 빔은 물을 통과합니다. 최대 순도 2.5의 <ItemLink id="bacterial_fuel_cell"/>나 순도 3.0의 <ItemLink id="prismarine_crystal"/>을 사용하면 세 제작법 모두 처리할 수 있습니다. Relay나 [Laser Junction](nautec:laser_chemistry/laser_manipulation.md)으로 빔의 방향을 바꿀 수 있습니다.

***

### <Color id="aqua">Abyssal Pressure Forge 제작법</Color>

<Recipe id="nautec:pressure_forge"/>

***

## <Color id="gold">강한 빔</Color>

Pressure Forge에는 40 AP가 필요합니다. 더 강한 빔을 사용하면 압착 속도가 빨라지며 속도는 √(빔 전력 ÷ 40)입니다.

| 빔 | 속도 |
|---|---|
| 40 AP | ×1 (기본) |
| 160 AP | ×2 |
| 360 AP | ×3 |
| 640 AP | ×4 |

제작법 표의 시간은 40 AP 빔 기준입니다. 제작법별 Etching Acid 소비량은 바뀌지 않습니다.

적용 공식과 해당 기계 목록은 [Stronger Beams](nautec:getting_started/stronger_beams.md)를 참고하세요.
