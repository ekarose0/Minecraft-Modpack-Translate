---
navigation:
  title: Extradimensional Energy Storage
  icon: nautec:extradimensional_energy_storage
  position: 14
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:extradimensional_energy_storage
  - nautec:rift_containment_frame
  - nautec:void_containment_frame
  - nautec:abyssal_containment_frame
  - nautec:event_horizon_containment_frame
---
# <Color id="light_purple">Extradimensional Energy Storage</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="extradimensional_energy_storage" scale="2"/>
  특이점을 격리 장치로 붙잡아 그 너머 공간에 FE를 저장합니다. 1블록에서 최대 9×9 바닥 구조물까지 확장됩니다.
</Column>

FE만 저장합니다. 저장 블록 하나를 놓으면 즉시 1티어로 작동합니다. 주변에 프레임 고리를 추가할수록 티어·저장 용량·FE 전송 속도가 증가하며 위쪽의 특이점도 커집니다.

***

## <Color id="gold">티어</Color>

| 티어 | 크기 | 추가할 프레임 고리 | 용량 | 포트당 틱당 전송량 |
|---|---|---|---|---|
| 1 | 1×1 | 없음 | 10,000,000 FE | 50,000 FE |
| 2 | 3×3 | 8 <ItemLink id="rift_containment_frame"/> | 1,000,000,000 FE | 500,000 FE |
| 3 | 5×5 | 16 <ItemLink id="void_containment_frame"/> | 100,000,000,000 FE | 5,000,000 FE |
| 4 | 7×7 | 24 <ItemLink id="abyssal_containment_frame"/> | 10,000,000,000,000 FE | 50,000,000 FE |
| 5 | 9×9 | 32 <ItemLink id="event_horizon_containment_frame"/> | 1,000,000,000,000,000 FE | 2,147,483,647 FE |

각 고리는 저장 블록과 같은 높이에서 바로 이전 고리를 둘러싸야 합니다. 먼저 Rift 프레임을 저장 블록에 닿도록 설치하고, 그 바깥에 Void 프레임을 놓는 방식입니다. 고리가 완성되어 있고 올바른 프레임으로 구성되어야 티어에 반영됩니다. 마지막 프레임을 놓으면 1초 이내에 구조물이 자동으로 형성되며 각 블록의 모습도 하나의 기계에 속한 것으로 바뀝니다. 프레임 하나라도 부수면 마지막으로 완성된 티어까지 낮아집니다. 저장된 FE는 사라지지 않지만, 새 용량을 초과한 상태에서는 FE를 더 받을 수 없습니다.

저장 블록이나 형성된 프레임을 우클릭하면 화면이 열립니다.

***

## <Color id="gold">포트</Color>

네 방향에 포트가 하나씩 있습니다. 블록 하나만 설치했을 때는 옆면 네 개가 포트입니다. 고리를 만들면 바닥 구조물의 각 변 가운데 블록이 포트가 되고, 바깥쪽 면으로 FE가 드나듭니다.

화면 위의 버튼 네 개로 각 포트를 **Input(입력)**, **Output(출력)**, **Off(꺼짐)**로 지정할 수 있습니다. 입력 포트는 케이블과 기계에서 FE를 받고, 출력 포트는 맞닿은 대상에 FE를 공급하며 케이블이 FE를 가져갈 수도 있습니다. 기본값은 입력입니다.

***

## <Color id="gold">Resonance Network</Color>

[Resonance Node](resonance_node.md)처럼 화면에서 네트워크를 선택하거나 만드세요. 그러면 별도 모드 설정 없이 해당 네트워크의 배터리 역할을 합니다.

* 네트워크의 입력 노드가 보낸 FE 중 출력 노드에서 쓰지 않는 양은 업링크를 채우는 대신 저장 장치에 들어갑니다.
* 출력 노드나 Resonance Charm이 입력 노드의 공급량보다 더 많은 FE를 요구하면 저장 장치가 부족분을 보충합니다.

네트워크와는 각 방향별로 최대 포트 전송 속도만큼 매 틱 FE를 주고받습니다. 일반적인 네트워크 손실 10%는 저장할 때가 아니라 꺼내어 공급할 때 적용됩니다. 네트워크에는 위성이 발사된 <ItemLink id="uplink_array"/>가 필요하며 차원은 상관없습니다. 전까지 화면에는 **No core**라고 표시됩니다. **Load**를 사용하면 청크가 계속 로드됩니다.

***

## <Color id="gold">옮기기</Color>

저장 블록을 부수면 FE가 아이템에 보존되며 다시 배치하면 복구됩니다. 따라서 가득 찬 저장 장치를 다른 기지로 운반할 수 있습니다. 프레임은 개별 아이템으로 떨어집니다. 다이아몬드 곡괭이 이상의 도구가 필요합니다.

<ItemLink id="configuration_card"/>로 네트워크 설정, 포트 설정, 청크 로드 설정을 복사할 수 있습니다.

***

## <Color id="gold">제작법</Color>

<RecipeFor id="extradimensional_energy_storage"/>
<RecipeFor id="rift_containment_frame"/>
<RecipeFor id="void_containment_frame"/>
<RecipeFor id="abyssal_containment_frame"/>
<RecipeFor id="event_horizon_containment_frame"/>
