---
navigation:
  title: 심해 재료
  icon: nautec:flawless_prismarine_crystal
  position: 4
  parent: deep_engineering/deep_engineering-index.md
item_ids:
  - nautec:resonant_shard
  - nautec:flawless_prismarine_crystal
  - nautec:deep_steel_plating
---

# <Color id="light_purple">심해 재료</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="flawless_prismarine_crystal" scale="2"/>
  Resonance Chamber와 Abyssal Pressure Forge에서 생산하는 세 가지 제작 재료입니다.
</Column>

각 재료는 특정 기계 제작법 한 가지로만 생산됩니다. JEI에서 필요한 순도와 깊이 조건을 포함한 제작법을 확인할 수 있습니다.

***

<Row>
  <ItemImage id="resonant_shard"/>
  ### <Color id="aqua">Resonant Shard</Color>
</Row>

순도 3.0 이상의 빔을 공급한 [Resonance Chamber](resonance_chamber.md)에 <ItemLink id="prismarine_crystal_shard"/> 1개를 넣으면 Resonant Shard 1개를 얻습니다.

[Gateway](gateway.md), [Abyssal Pressure Forge](pressure_forge.md), [Neptune's Trident](neptunes_trident.md), [Fusion Plant](fusion_plant.md)의 Laser Injector, Dormant Crystal Seed, [Resonance Network](resonance_network.md) 블록 제작에 사용됩니다. 압축하여 Flawless Prismarine Crystal을 만들 수도 있습니다.

***

<Row>
  <ItemImage id="flawless_prismarine_crystal"/>
  ### <Color id="aqua">Flawless Prismarine Crystal</Color>
</Row>

[Abyssal Pressure Forge](pressure_forge.md)에서 Resonant Shard로 제작합니다. 순도 2.0, Y좌표 -20 이하에 설치된 Forge가 필요하며 수정 하나당 10초가 걸립니다.

[Atlantean Rifle](atlantean_rifle.md), [Neptune's Trident](neptunes_trident.md), [Gateway](gateway.md), Fusion Controller, Crystal Cradle, Dormant Crystal Seed, Pressure Synthesizer 제작에 사용됩니다.

***

<Row>
  <ItemImage id="deep_steel_plating"/>
  ### <Color id="aqua">Deep Steel Plating</Color>
</Row>

[Abyssal Pressure Forge](pressure_forge.md)에서 Aquarine Steel Ingot으로 제작합니다. 순도 2.5, Y좌표 -40 이하에 설치된 Forge가 필요하며 판 하나당 15초가 걸립니다.

[Atlantean Rifle](atlantean_rifle.md), [Neptune's Trident](neptunes_trident.md), [Gateway](gateway.md), 대부분의 [Fusion Plant](fusion_plant.md) 부품, Crystal Cradle 제작에 사용됩니다.

모루에서 <ItemLink id="submarine"/>을 수리할 때도 사용됩니다. 회수한 Sea Scout를 왼쪽 슬롯에, Plating을 오른쪽 슬롯에 넣으세요. 판 하나당 선체 내구도 20%를 회복하며 경험치 레벨 2가 소모됩니다. 수리 재료와 개당 회복량은 `config/nautec-common.toml`의 `submarineRepairItem`, `submarineRepairPercent`로 설정할 수 있습니다.
