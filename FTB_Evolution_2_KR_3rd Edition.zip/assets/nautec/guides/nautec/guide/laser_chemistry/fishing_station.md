---
navigation:
  title: Fishing Station
  icon: nautec:fishing_station
  position: 11
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:fishing_station
---

# <Color id="light_purple">Fishing Station</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="fishing_station" scale="2"/>
  자동으로 낚시하고 잡은 물고기와 전리품을 보관합니다.
</Column>

## <Color id="gold">설치</Color>

탁 트인 수면 위에 설치하세요. 장치 아래 가로 5×5, 깊이 2블록 범위의 모든 블록이 일반 물이어야 합니다. 해당 범위에 켈프, 해초, 물에 잠긴 블록 또는 Salt Water가 하나라도 있으면 작동하지 않으므로 주변을 정리하거나 깨끗한 장소를 선택하세요.

5초마다 물 상태를 검사하며, 작동 중에는 그물이 회전합니다.

***

## <Color id="gold">전력</Color>

장치의 위쪽이나 아래쪽으로 레이저 빔을 조사하세요. 전력량이 얼마든 작동하며(기본 소모량 틱당 1 AP, 설정 가능), 순도는 영향을 주지 않습니다.

***

## <Color id="gold">생산물</Color>

2초마다 일반 낚시 전리품을 한 번 획득하며(설정 가능), 잡은 물품을 15개 슬롯에 보관합니다. 우클릭하여 인벤토리를 열고 꺼내거나, 호퍼 또는 파이프로 어느 면에서든 추출할 수 있습니다. 슬롯이 모두 차면 추가 전리품은 장치 밖으로 아이템 형태로 떨어집니다.

***

### <Color id="aqua">Fishing Station 제작법</Color>

<RecipeFor id="fishing_station"/>
