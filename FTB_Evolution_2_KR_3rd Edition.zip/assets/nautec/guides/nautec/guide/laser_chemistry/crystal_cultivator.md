---
navigation:
  title: Crystal Cultivator
  icon: nautec:crystal_cultivator
  position: 13
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:crystal_cultivator
---

# Crystal Cultivator

<ItemImage id="crystal_cultivator" scale="2"/>

발아 블록의 아무 면에나 Crystal Cultivator를 부착한 뒤, 바깥쪽을 향한 수정 끝부분에 레이저를 조사하세요. 성장을 가속하고 나머지 면에서 완전히 자란 Cluster를 자동 수확하며, 어린 싹과 원본 블록은 그대로 둡니다.

Budding Prismarine에 사용하면 Prismarine Crystal Shard 생산을 자동화할 수 있으며, 바닐라 Budding Amethyst에도 사용할 수 있습니다. 해당 모드가 설치되어 있으면 GeoOre의 발아 블록과 AE2의 Budding Quartz도 지원합니다.

## 동력과 순도

수확에는 **20 AP**가 필요합니다. 20 AP를 공급하면 수정이 자연 성장보다 **2.5배** 빠르게 자라고, **100 AP에서는 25배** 빨라집니다. 이 사이의 성장 속도는 선형으로 증가합니다. 출력을 더 높이면 효과는 계속 증가하지만 증가폭은 줄어들어, 180 AP에서는 약 40.6배, 260 AP에서는 약 49.7배로 성장합니다.

순도는 수확 시 적용되는 Fortune 마법부여 레벨을 결정합니다. 순도 6까지는 정수 순도 1당 Fortune 레벨이 1씩 올라가므로 순도 2.0은 Fortune II, 순도 6.0은 Fortune VI입니다. 6을 넘으면 효율이 감소하여 순도 9는 Fortune VIII, 순도 12는 Fortune IX를 제공합니다. 순도 6 초과는 수정에 작용하는 [Bacterial Enrichment Catalyst](nautec:deep_engineering/bacterial_enrichment_catalyst.md)로 얻습니다. 실제 전리품과 Fortune 효과는 Cluster의 기본 전리품 테이블을 따릅니다.

## 수확물 회수

9칸짜리 출력 버퍼에서 파이프와 호퍼로 아이템을 추출할 수 있습니다. 빈손으로 우클릭하면 한 묶음을, 웅크린 채 우클릭하면 전부 회수합니다. 수확물 전체를 보관할 공간이 부족하면 공간이 생길 때까지 완전히 자란 Cluster가 그대로 남습니다. 물에 잠긴 Cluster를 수확하면 물은 남습니다.

발아 블록 하나당 Cultivator 하나만 사용하세요. 여러 개를 붙여도 성장 보너스는 중첩되지 않습니다. 동력이 없는 Cultivator는 수확하거나 성장을 가속하지 못하지만, 발아 블록 자체의 자연 성장은 계속됩니다.

## 모드 호환성

Cultivator는 원본 블록의 성장 로직을 사용하므로 해당 모드의 성장 설정과 조건이 그대로 적용됩니다. 월드의 랜덤 틱 속도도 따르며, 해당 게임 규칙이 0이면 성장 가속이 비활성화됩니다.

AE2의 Flawed, Chipped, Damaged Budding Quartz는 성장에 성공할 때마다 기존 확률대로 열화됩니다. 따라서 성장 속도가 빨라지면 더 빨리 소모됩니다. 지속 가능한 Certus Quartz 농장에는 **Flawless Budding Quartz**를 사용하세요.

모드팩 제작자는 `nautec:cultivator_sources`와 `nautec:cultivator_clusters` 블록 태그로 지원 대상을 추가하거나 제한할 수 있습니다. 여기에는 공통 태그 `c:budding_blocks`와 `c:clusters`가 포함됩니다. 후자에는 수확 가능한 완전히 자란 Cluster만 추가하고 덜 자란 싹은 제외하세요.

## 제작법

<RecipeFor id="crystal_cultivator"/>
