---
navigation:
  title: Osmosis Filter
  icon: nautec:osmosis_filter
  position: 5
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:osmosis_filter
---

# <Color id="light_purple">Osmosis Filter</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="osmosis_filter" scale="2"/>
  연료, 재료 투입, 레이저 빔 없이도 자동으로 Water를 생산합니다.
</Column>

## <Color id="gold">사용 방법</Color>

어디에든 설치하면 매초 Water 1,000 mB(양동이 1개 분량)를 탱크에 채우기 시작합니다. 탱크에 16,000 mB(양동이 16개 분량, 설정 가능)가 차면 멈추며, 여과 중에는 전면 패널이 빛납니다.

* 빈 Bucket을 들고 우클릭하면 1,000 mB를 꺼낼 수 있습니다. 다른 유체 용기도 사용할 수 있습니다.
* 파이프로 어느 면에서든 Water를 추출할 수 있습니다. 외부에서 유체를 넣을 수는 없습니다.
* 기본적으로 모든 면에서 Water를 내보냅니다. [Side Configuration](nautec:getting_started/utilities.md)에서 면별 출력 여부를 설정할 수 있습니다.

빈손으로 우클릭하면 탱크 상태, 초당 Water 생산량 및 공급 중인 AP를 볼 수 있습니다. Jade에서도 탱크와 생산 속도가 표시됩니다.

생산된 Water를 Salt와 함께 [Mixer](mixer.md)에 공급하면 Salt Water를 만들 수 있으며, [Combustion Dynamo](nautec:getting_started/combustion_dynamo.md)에도 공급할 수 있습니다.

***

## <Color id="gold">더 강한 레이저 빔</Color>

Osmosis Filter는 빔 없이도 작동하지만, 어느 면으로든 레이저 빔을 공급하면 속도가 빨라집니다. 전력이 40 AP씩 증가할 때마다 생산량이 두 배가 되며, 초당 최대 1,024,000 mB까지 생산합니다(두 값 모두 설정 가능).

| 레이저 빔 | 초당 Water 생산량 |
|---|---|
| 없음 | 1,000 mB |
| 40 AP | 2,000 mB |
| 80 AP | 4,000 mB |
| 160 AP | 16,000 mB |
| 320 AP | 256,000 mB |
| 400 AP | 1,024,000 mB |

초당 생산량이 16,000 mB를 초과하는 빔을 사용하면 탱크가 1초 생산량만큼 채워지므로 추출 사이에 생산이 멈추지 않습니다. 빔이 약해져도 탱크에 이미 저장된 Water는 유지되며, 공간이 부족하면 일부를 꺼낼 때까지 추가 생산만 중단됩니다.

강한 빔으로 속도를 높일 수 있는 장치 목록은 [Stronger Beams](nautec:getting_started/stronger_beams.md)를 참고하세요.

<RecipeFor id="osmosis_filter"/>
