---
navigation:
  title: Aquarine Steel and Cast Iron
  icon: nautec:aquarine_steel_ingot
  position: 2
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:aquarine_steel_compound
  - nautec:aquarine_steel_ingot
  - nautec:aquarine_steel_block
  - nautec:cast_iron_compound
  - nautec:cast_iron_ingot
  - nautec:cast_iron_nugget
  - nautec:cast_iron_rod
  - nautec:cast_iron_block
  - nautec:laser_channeling_coil
  - nautec:whisk
  - nautec:broken_whisk
  - nautec:oil_barrel
---

# <Color id="light_purple">Aquarine Steel and Cast Iron</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquarine_steel_ingot" scale="2"/>
  대부분의 NauTec 기계를 제작하는 데 사용되는 금속과 부품입니다.
</Column>

## <Color id="gold">Aquarine Steel</Color>

<Row>
  <ItemImage id="aquarine_steel_compound"/>
  ### <Color id="aqua">Aquarine Steel Compound</Color>
</Row>

직접 조합하거나 [Mixer](mixer.md)에서 Salt Water와 혼합해 제작합니다. Mixer를 사용하면 같은 양의 원료 Iron으로 더 많은 Compound를 얻습니다. 제작법은 JEI에서 확인하세요.

<Recipe id="nautec:aquarine_steel_compound"/>

<Row>
  <ItemImage id="aquarine_steel_ingot"/>
  ### <Color id="aqua">Aquarine Steel Ingot</Color>
</Row>

Compound를 작동 중인 레이저 빔에 떨어뜨리면 5초 후 Ingot으로 변환됩니다. 순도 조건이 없으므로 Aquatic Catalyst 하나로 충분합니다. 순도 2.0 이상의 빔에서는 4초마다 Compound 1개를 Ingot 2개로 변환합니다. 설치 방법은 [Item Transformation](nautec:getting_started/item_transformation.md)을 참고하세요.

<Row>
  <ItemImage id="aquarine_steel_block"/>
  ### <Color id="aqua">Aquarine Steel Block</Color>
</Row>

Ingot 9개를 보관하는 압축 블록입니다.

<RecipeFor id="aquarine_steel_block"/>

***

## <Color id="gold">Cast Iron</Color>

<Row>
  <ItemImage id="cast_iron_compound"/>
  ### <Color id="aqua">Cast Iron Compound</Color>
</Row>

<Recipe id="nautec:cast_iron_compound"/>

<Row>
  <ItemImage id="cast_iron_ingot"/>
  ### <Color id="aqua">Cast Iron Ingot</Color>
</Row>

Compound를 Furnace에서 제련하거나 Blast Furnace에서 2배 빠르게 제련할 수 있습니다.

<Recipe id="nautec:cast_iron_ingot_blasting"/>

해저에서 발견한 오래된 철제 물건도 Blast Furnace로 제련할 수 있습니다. Anchor는 Ingot 11개, Oil Barrel은 5개를 얻습니다.

<Recipe id="nautec:cast_iron_ingot_from_oil_barrel_blasting"/>

<Row>
  <ItemImage id="cast_iron_rod"/>
  ### <Color id="aqua">Cast Iron Rod</Color>
</Row>

Aquarine Steel 도구, Fishing Station, Deep Sea Drain Wall, Oil Barrel, Whisk 제작에 사용됩니다.

<Recipe id="nautec:cast_iron_rod"/>

<Row>
  <ItemImage id="cast_iron_nugget"/>
  ### <Color id="aqua">Cast Iron Nugget</Color>
</Row>

Nugget 9개를 Ingot 1개로 만들거나 반대로 분해할 수 있습니다. Nugget은 Broken Whisk 수리에 사용됩니다.

<Row>
  <ItemImage id="cast_iron_block"/>
  ### <Color id="aqua">Cast Iron Block</Color>
</Row>

Ingot 9개를 보관하는 압축 블록입니다.

<Recipe id="nautec:cast_iron_block_from_ingots"/>

<Row>
  <ItemImage id="oil_barrel"/>
  ### <Color id="aqua">Oil Barrel</Color>
</Row>

NauTec와 다른 모드의 기름(`c:oil` 태그)을 최대 8,000 mB 저장하는 Cast Iron 드럼입니다. 우클릭해 뚜껑을 열고 닫을 수 있으며, 파이프는 뚜껑이 열렸을 때만 기름을 입출력할 수 있습니다. Blast Furnace로 제련하면 Cast Iron Ingot을 얻습니다. Pickaxe로 채굴해 회수할 수 있습니다.

<Recipe id="nautec:oil_barrel"/>

***

## <Color id="gold">기계 부품</Color>

<Row>
  <ItemImage id="laser_channeling_coil"/>
  ### <Color id="aqua">Laser Channeling Coil</Color>
</Row>

<ItemLink id="burnt_coil"/>을 Item Transformation으로 변환해 제작합니다. 순도 1.5 이상의 빔에 10초간 노출해야 합니다. Aquatic Catalyst의 순도는 최대 1.2이므로 Catalyst 빔을 <ItemLink id="prismarine_crystal"/>에 쏘아 출력 빔을 사용하거나 Crystal Shard 빔을 <ItemLink id="focusing_lens"/>에 직진 통과시키세요.

Coil은 Charger, Prismatic Battery, 대부분의 Aquarine Steel 도구 및 후반부 기계에 사용됩니다.

<Row>
  <ItemImage id="broken_whisk"/>
  ### <Color id="aqua">Broken Whisk</Color>
</Row>

Drowned가 가끔 떨어뜨리며 행운 낚시 구역의 보물, Ocean Ruin과 Research Outpost 상자에서도 얻을 수 있습니다.

<Row>
  <ItemImage id="whisk"/>
  ### <Color id="aqua">Whisk</Color>
</Row>

[Mixer](mixer.md)의 교반 부품입니다. Broken Whisk를 Cast Iron Nugget 4개로 수리하거나 Cast Iron Rod, Prismarine Crystal Shard, Aquarine Steel Ingot으로 새로 제작할 수 있습니다.

<Recipe id="nautec:whisk"/>
<Recipe id="nautec:whisk_from_cast_iron"/>
