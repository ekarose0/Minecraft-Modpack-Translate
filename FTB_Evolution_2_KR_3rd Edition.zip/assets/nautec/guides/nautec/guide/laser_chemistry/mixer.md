---
navigation:
  title: Mixer
  icon: nautec:mixer
  position: 4
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:mixer
---

# <Color id="light_purple">Mixer</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="mixer" scale="2"/>
  아이템을 Salt Water와 혼합해 화학물질, Aquarine Steel Compound, 기계 부품을 제작합니다.
</Column>

## <Color id="gold">설치 방법</Color>

Mixer는 어느 면으로든 레이저 빔을 받아 틱당 최소 10 AP가 공급되면 작동합니다(설정 가능). Prismarine Shard 또는 Prismarine Crystal Shard를 연료로 사용하는 <ItemLink id="aquatic_catalyst"/> 하나면 충분합니다. Prismarine Crystal을 연료로 쓰는 Catalyst 하나로는 부족하므로 [Laser Junction](laser_manipulation.md)으로 두 번째 광원을 합치세요.

빈손으로 우클릭하면 화면이 열립니다. 재료 슬롯 4개, 출력 슬롯 1개, 입력 탱크와 출력 탱크가 있으며 각 탱크는 64,000 mB(64 Bucket)를 저장합니다(설정 가능).

* <ItemLink id="saltwater_bucket"/>을 들고 우클릭하면 입력 탱크를 채웁니다. Salt Water는 [Deep Sea Drain](drain.md)에서 얻거나 Mixer에 Water Bucket과 Salt를 넣어 제작할 수 있습니다.
* 빈 Bucket을 들고 우클릭하면 출력 탱크의 유체를 꺼냅니다.
* 호퍼와 파이프로 재료 투입, 입력 탱크 충전, 출력 탱크 배출을 자동화할 수 있습니다.
* 출력 슬롯의 아이템도 자동으로 추출할 수 있습니다.
* 기본적으로 모든 면에서 입출력이 가능합니다. [Side Configuration](nautec:getting_started/utilities.md)에서 면별 아이템·유체 설정을 따로 지정할 수 있습니다.

작동 중에는 Whisk가 회전합니다. <ItemLink id="prism_monocle"/>로 입력 동력을 확인할 수 있고 Jade에는 탱크, 혼합 진행률, 동시 제작 수가 표시됩니다.

***

## <Color id="gold">제작법</Color>

JEI의 Mixing 항목에서 재료를 확인할 수 있습니다.

| 결과 | 사용 유체 | 시간 |
|---|---|---|
| 1,000 mB Salt Water | 1,000 mB Water와 <ItemLink id="salt"/> 1개 | 5초 |
| 1,000 mB Electrolyte Algae Serum | 1,000 mB Salt Water | 10초 |
| 1,000 mB Etching Acid | 1,000 mB Salt Water | 7.5초 |
| 5 Aquarine Steel Compound | 1,000 mB Salt Water | 5초 |
| 1 <ItemLink id="burnt_coil"/> | 1,000 mB Salt Water | 10초 |
| 2 <ItemLink id="aquatic_chip"/>s | 1,000 mB Salt Water | 10초 |
| 1 <ItemLink id="pressure_synthesizer"/> | 8,000 mB Salt Water | 20초 |
| 1 <ItemLink id="atlantean_pressure_synthesizer"/> | 8,000 mB Salt Water | 30초 |

결과물을 출력 공간에 넣을 수 있을 때만 제작을 시작합니다. 따라서 여러 번 제작하려면 출력 탱크나 슬롯을 비우세요. 동력이 끊기면 진행률이 초기화되지 않고 일시 정지합니다.

<Color id="gold">팁</Color>: 출력 탱크에 유체가 남아 있으면 Bucket으로 우클릭할 때 출력 탱크가 우선 선택되므로 Salt Water Bucket을 투입할 수 없습니다. 먼저 출력 탱크를 비우세요.

유체별 용도는 [Chemistry Fluids](chemistry_introduction.md)를 참고하세요.

***

### <Color id="aqua">Mixer 제작법</Color>

<ItemLink id="whisk"/>는 Broken Whisk를 수리하거나 Cast Iron Rod, Prismarine Crystal Shard, Aquarine Steel Ingot으로 제작할 수 있습니다.

***

## <Color id="gold">강한 빔</Color>

Mixer는 10 AP가 필요합니다. 빔이 강해지면 먼저 동시 제작 수가 증가합니다. 10 AP마다 주기당 제작 1회가 추가되며 최대 64회까지 증가합니다(설정 가능). 주기가 끝날 때 재료·입력 탱크·출력 공간이 허용하는 만큼 제작하므로 640 AP, Salt 한 스택, Water 64,000 mB가 있으면 5초의 한 주기로 Salt Water 64,000 mB를 만들 수 있습니다.

동시 제작 수가 64회에 도달한 뒤에는 추가 AP가 제작 주기를 단축합니다. 속도는 √(빔 출력 ÷ (동시 제작 수 × 10))입니다. 640 AP 미만에서 10 AP 단위 사이의 출력은 속도를 조금만 높입니다.

| 빔 | 주기당 제작 수 | 속도 |
|---|---|---|
| 10 AP | 1 | ×1 (기본) |
| 40 AP | 4 | ×1 |
| 640 AP | 64 | ×1 |
| 2,560 AP | 64 | ×2 |
| 5,760 AP | 64 | ×3 |
| 10,240 AP | 64 | ×4 |

제작법 표의 시간은 속도 ×1에서 한 주기에 걸리는 시간입니다.

규칙과 적용 기계 목록은 [Stronger Beams](nautec:getting_started/stronger_beams.md)를 참고하세요.

<RecipeFor id="mixer"/>
