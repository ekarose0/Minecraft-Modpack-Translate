---
navigation:
  title: Deep Sea Drain
  icon: nautec:deep_sea_drain
  position: 5
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:deep_sea_drain
  - nautec:deep_sea_drain_wall
---
# <Color id="light_purple">Deep Sea Drain</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="deep_sea_drain" scale="2"/>
  바다에서 Salt Water를 퍼 올리는 3×3 다중 블록 구조물입니다.
</Column>

## <Color id="gold">건설</Color>

평평한 3×3 바닥을 만듭니다. 가운데에 Deep Sea Drain을, 주변 여덟 칸에 Deep Sea Drain Wall을 놓습니다. <ItemLink id="aquarine_steel_wrench"/>를 들고 Deep Sea Drain을 우클릭하면 완성됩니다.

<GameScene zoom="4" background="#333333" interactive={true}>
  <Block id="nautec:deep_sea_drain_wall" x="0" y="0" z="0"/>
  <Block id="nautec:deep_sea_drain_wall" x="1" y="0" z="0"/>
  <Block id="nautec:deep_sea_drain_wall" x="2" y="0" z="0"/>
  <Block id="nautec:deep_sea_drain_wall" x="0" y="0" z="1"/>
  <Block id="nautec:deep_sea_drain" x="1" y="0" z="1"/>
  <Block id="nautec:deep_sea_drain_wall" x="2" y="0" z="1"/>
  <Block id="nautec:deep_sea_drain_wall" x="0" y="0" z="2"/>
  <Block id="nautec:deep_sea_drain_wall" x="1" y="0" z="2"/>
  <Block id="nautec:deep_sea_drain_wall" x="2" y="0" z="2"/>
  <IsometricCamera yaw="225" pitch="30"/>
</GameScene>

바다와 비슷한 바이옴이어야 하며 9개 블록 바로 위가 모두 물이어야 작동합니다. 해저에 지으면 두 조건을 충족하기 쉽습니다. 다른 모드에서 추가한 바이옴을 포함하여 바다 또는 해양 태그가 붙은 바이옴이 인정됩니다. Drain 위치나 그 위쪽 수면 중 하나만 해당 바이옴이어도 되므로 월드 생성 모드가 해저를 동굴·해구 바이옴으로 바꿔도 작동할 수 있습니다.

***

## <Color id="gold">에너지 공급</Color>

매 틱 20 AP를 **초과하는** 광선이 필요합니다(설정 가능). <ItemLink id="aquatic_catalyst"/>의 연료별 출력은 다음과 같습니다.

| 연료 | 틱당 AP |
|---|---|
| Prismarine Crystal | 6 |
| Prismarine Shard | 12 |
| Prismarine Crystal Shard | 12 |

Shard를 사용하는 Catalyst 두 개의 광선을 [Laser Junction](laser_manipulation.md)에서 합치면 24 AP로 작동시킬 수 있습니다. Prismarine Crystal을 쓴다면 네 개가 필요합니다. Junction은 출력을 여러 방향으로 균등 분배하므로 Drain 쪽 출력은 한 방향만 사용하세요.

광선은 레이저 포트로 들어갑니다. 렌치를 들고 모서리가 아닌 네 변 중앙의 Wall 중 하나를 우클릭하세요. 어느 면을 클릭해도 포트가 Drain 반대쪽 바깥을 향하게 되며 확인 메시지가 나옵니다. 그 벽의 바깥 면으로 광선을 쏘세요. 포트는 동시에 하나만 존재합니다. 다른 중앙 Wall을 렌치로 누르면 포트가 이동하고 같은 Wall을 다시 누르면 그곳에 새로 설정됩니다.

***

## <Color id="gold">가동</Color>

양손을 비운 상태에서 Drain을 Shift+우클릭해 엽니다. 충분한 에너지가 들어오면 밸브가 돌고 뚜껑이 몇 초에 걸쳐 열립니다. 다시 Shift+우클릭하면 닫힙니다.

열리지 않으면 현재 공급량과 필요 출력이 메시지에 표시됩니다. 뚜껑은 열렸지만 위에 물이 없거나 바이옴이 맞지 않아 펌프가 멈추는 경우도 메시지로 이유를 알려줍니다.

열려 있고 에너지가 공급되면 Salt Water를 용량 128,000 mB의 탱크로 퍼 올립니다. 20 AP를 조금 넘으면 매초 500 mB, 더 강한 광선에서는 상한 없이 출력에 정비례하여 증가합니다. 1 AP당 매초 25 mB를 얻으므로 광선 출력을 네 배로 높이면 펌프 속도도 네 배가 됩니다.

| 광선 출력 | 초당 Salt Water |
|---|---|
| 20 AP 조금 초과 | 약 500 mB |
| 80 AP | 2,000 mB |
| 320 AP | 8,000 mB |
| 2,000 AP | 50,000 mB |
| 20,000 AP | 500,000 mB |

Jade에는 현재 펌프 속도가 표시됩니다. 기본 속도, 요구 출력, 출력에 따른 증가율(`drainPowerScaling`), 탱크 용량은 설정할 수 있습니다. 이것은 [Mixer](mixer.md)에 Salt Water를 꾸준히 공급하는 방법입니다. 일반 바닷물을 양동이로 담아도 `config/nautec-common.toml`에서 `collectSaltWater`가 활성화된 모드팩이 아니라면 그냥 물로 취급되기 때문입니다.

* 중앙 블록의 아래쪽 면에 파이프를 연결해 Salt Water를 꺼냅니다.
* 또는 양동이나 다른 유체 용기를 들고 Drain의 아무 부분을 우클릭합니다. 탱크에 최소 1,000 mB가 있으면 양동이를 채울 수 있습니다.

Wall을 <ItemLink id="prism_monocle"/>로 보면 저장된 유체 양을 알 수 있습니다. Jade로 구조물의 아무 부분을 보면 닫힘, 열리는 중, Salt Water 퍼 올리는 중, 에너지 부족, 위쪽 물 없음, 바다 아님, 탱크 가득 참 등의 상태와 공급 출력이 표시됩니다.

<Color id="gold">주의</Color>: 에너지를 받아 열려 있는 Drain은 위쪽의 모든 물체를 거품 기둥으로 아래로 끌어당깁니다. 떨어진 아이템을 포함해 안으로 들어간 모든 대상은 익사 피해를 입습니다. 위로 헤엄쳐 지나가기 전에 반드시 닫으세요.

***

### <Color id="aqua">제작법</Color>

***

## <Color id="gold">강한 광선의 효과</Color>

Deep Sea Drain은 대부분의 기계에 적용되는 제곱근 공식이 아니라 광선 출력에 정비례하여 Salt Water를 더 퍼 올립니다. 광선을 네 배로 높이면 펌프 속도도 네 배입니다. 위 표에서 수치를 확인할 수 있습니다. 모드팩에서는 `config/nautec-common.toml`의 `drainPowerScaling`을 바꿀 수 있으며 0.5로 설정하면 제곱근 공식이 적용됩니다.

일반적인 공식과 적용 기계 목록은 [강한 광선](nautec:getting_started/stronger_beams.md)을 참고하세요.

<RecipeFor id="deep_sea_drain"/>

<RecipeFor id="deep_sea_drain_wall"/>
