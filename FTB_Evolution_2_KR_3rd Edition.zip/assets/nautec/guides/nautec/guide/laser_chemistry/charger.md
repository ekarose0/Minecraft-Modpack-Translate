---
navigation:
  title: Charger
  icon: nautec:charger
  position: 6
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:charger
---

# <Color id="light_purple">Charger</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="charger" scale="2"/>
  레이저 빔의 전력으로 AP 사용 아이템을 충전합니다.
</Column>

## <Color id="gold">사용 방법</Color>

아이템을 들고 Charger를 우클릭하면 충전대에 올려놓을 수 있습니다. 빈손으로 우클릭하면 다시 회수합니다. 한 번에 아이템 하나만 올릴 수 있습니다.

어느 면으로든 레이저 빔을 조사하세요. Charger는 높이가 낮은 블록이므로 바닥을 따라 지나가는 빔도 옆면에서 받아들이며, 위쪽에서도 받을 수 있습니다. 충전 중에는 불꽃이 튀고, 완충되면 멈춥니다.

아이템은 매 틱마다 자체 입력 한도 내에서 빔이 공급하는 전력을 받습니다. 입력 한도에 도달하기 전까지는 빔이 강할수록 더 빨리 충전됩니다.

[Aquarine Steel 도구](tools.md)와 [방어구](nautec:laser_augmentation/aquarine_steel_armor.md), [Prismatic Battery](prismatic_battery.md), <ItemLink id="wave_jet"/>, <ItemLink id="atlantean_rifle"/> 등 AP를 저장하는 모든 아이템을 충전할 수 있습니다.

| 아이템 | 저장 용량 | 틱당 최대 입력량 |
|---|---|---|
| Aquarine Steel Pickaxe, Axe, Shovel or Sword | 1,200 AP | 128 AP |
| Aquarine Steel Hoe | 700 AP | 128 AP |
| Prismatic Battery | 10,000 AP | 128 AP |

***

### <Color id="aqua">Charger 제작법</Color>

<RecipeFor id="charger"/>
