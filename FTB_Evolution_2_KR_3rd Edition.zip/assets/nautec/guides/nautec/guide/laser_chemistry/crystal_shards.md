---
navigation:
  title: Prismarine Crystal Shards
  icon: nautec:prismarine_crystal_shard
  position: 9
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:prismarine_crystal_shard
---

# <Color id="light_purple">Prismarine Crystal Shards</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="prismarine_crystal_shard" scale="2"/>
  Aquatic Catalyst에 가장 좋은 연료이며 여러 고급 제작법에 사용되는 재료입니다.
</Column>

<ItemLink id="aquatic_catalyst"/>에서 이 파편은 연료 중 가장 높은 출력을 내며, 순도 1.2에서 75초 동안 틱당 20 AP를 공급합니다. Prismatic Battery 및 다른 고급 제작법에도 사용됩니다.

***

## <Color id="gold">Prismarine Crystal에서 획득</Color>

<ItemLink id="prismarine_crystal"/>은 주입된 [Aquarine Steel Pickaxe](tools.md)의 능력을 활성화한 상태에서 채굴해야 파편을 얻을 수 있습니다. 해당 곡괭이로 수정을 때리세요.

* 한 번 때릴 때마다 파편 1~2개가 인벤토리에 바로 들어옵니다.
* 타격할 때마다 25% 확률로 수정이 산산조각 납니다. 이때 곡괭이에 100 AP 이상 남아 있으면 100 AP를 소모하고 파편 3~7개가 추가로 떨어집니다.

부서진 수정은 영구적으로 사라집니다. 순도 증폭 장치에 사용 중인 수정이라면 다른 수정을 채굴하세요.

***

## <Color id="gold">Budding Prismarine에서 획득</Color>

<ItemLink id="budding_prismarine"/>은 파편으로 분해되는 군집을 자라게 하므로, 재생 가능한 공급원입니다.

***

## <Color id="gold">Prismarine Crystals를 변환해 획득</Color>

순도 2.0 이상의 레이저 빔에 <ItemLink id="minecraft:prismarine_crystals"/>를 던지면 8초 후 각각 파편 2개로 변합니다. Catalyst 자체의 빔은 순도 1.2가 최대이므로, Prismarine Crystal에 빔을 쏘고 통과해 나온 빔을 사용하거나 파편 연료를 사용하는 Catalyst의 빔을 Focusing Lens 두 개에 연속으로 통과시키세요. 자세한 내용은 [Item Transformation](nautec:getting_started/item_transformation.md)을 참고하세요.
