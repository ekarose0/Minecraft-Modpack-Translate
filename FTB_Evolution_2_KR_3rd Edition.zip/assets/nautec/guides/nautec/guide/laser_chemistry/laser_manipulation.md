---
navigation:
  title: Moving Laser Power
  icon: nautec:laser_junction
  position: 0
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:prismarine_laser_relay
  - nautec:laser_junction
---

# <Color id="light_purple">Moving Laser Power</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="laser_junction" scale="2"/>
  전원에서 기계까지 Aquatic Power(AP)를 전달하는 방법입니다.
</Column>

## <Color id="gold">레이저 빔의 작동 방식</Color>

NauTec의 모든 기계는 레이저 빔으로 전달되는 Aquatic Power를 사용합니다. 빔의 전력은 틱당 AP로 측정되는 공급 속도입니다. 중간 경로에는 전력이 저장되지 않으며 기계도 빔 자체를 소모하지 않습니다. 매 틱 필요한 AP가 도착하는 동안 기계가 작동합니다.

* 빔은 직선으로 이동합니다. 대부분의 레이저 블록은 최대 16블록, Relay는 최대 64블록까지 도달합니다(설정 가능).
* 경로에서 충돌 판정이 있는 첫 블록이 빔을 막습니다. 물, 유리, 유리판은 색유리를 포함해 빔을 막지 않으므로 유리로 빔을 둘러싸 플레이어가 접근하지 못하게 할 수 있습니다. Charger처럼 낮은 레이저 블록은 빔이 위를 지나가는 것처럼 보여도 옆에서 들어오는 빔을 받습니다.
* 빔이 맞닿는 면에서 상대 블록이 빔을 받아들일 때만 연결됩니다. 연결 여부는 0.5초마다 다시 확인합니다.
* 전력이 공급된 빔 안에 있는 몹이나 플레이어는 초당 두 번 화상 피해를 받습니다. 피해량은 빔 전력의 제곱근에 비례하며 기계 속도 증가와 같은 곡선을 따릅니다. 10 AP는 피해 3(하트 1.5개), 40 AP는 6, 160 AP는 12, 1,000 AP는 30입니다. Fire Resistance로 막을 수 있습니다. `config/nautec-common.toml`의 `laserDamage`, `laserDamageReferencePower`, `laserDamageScaling`, `laserDamageMax`로 변경할 수 있습니다.
* 전력이 공급된 빔 안에 떨어진 아이템은 [Item Transformation](nautec:getting_started/item_transformation.md)으로 변환될 수 있습니다.

빔에는 일부 제작법이 요구하는 순도도 있습니다. 경로에 따라 순도가 어떻게 바뀌는지는 [Beam Optics](nautec:deep_engineering/beam_optics.md)를 참고하세요.

<Color id="gold">팁</Color>: <ItemLink id="prism_monocle"/>를 사용하면 바라보는 레이저 블록에 공급되는 전력과 순도를 확인할 수 있습니다.

***

## <Color id="gold">기계별 필요 전력</Color>

| 기계 | 필요한 틱당 AP |
|---|---|
| [Mixer](mixer.md) | 10 이상 |
| [Deep Sea Drain](drain.md) | 20 초과 |
| [Charger](charger.md) | 제한 없음(입력 한도 내에서 빔이 전달한 만큼 아이템에 공급) |
| [Fishing Station](fishing_station.md) | 1 이상 |
| [Confined Spawner](confined_spawner.md) | 지속 작동에 50 필요(그보다 적으면 간헐적으로 작동) |

<ItemLink id="aquatic_catalyst"/>는 Prismarine Shard를 태우면 틱당 12 AP, Prismarine Crystal Shard는 20 AP, Prismarine Crystal은 6 AP를 출력합니다. 위 기계들의 필요 전력은 설정할 수 있습니다.

***

<Row>
  <ItemImage id="prismarine_laser_relay"/>
  ### <Color id="aqua">Prismarine Laser Relay</Color>
</Row>

뒷면에서 빔을 받아 앞면으로 최대 64블록(`relayLaserDistance`)까지 전달합니다. 전력과 순도가 그대로 유지되므로 Relay를 연달아 설치해 먼 거리까지 연결할 수 있습니다. 물속에도 설치할 수 있습니다.

Relay는 다른 레이저 블록에 붙여 설치하면 자동으로 방향을 맞춥니다. 전원의 출력 면(Catalyst의 렌즈나 다른 Relay의 앞면)에 설치하면 그 빔을 받아 전원 반대쪽으로 전달합니다. 빔을 받는 기계에 붙여 설치하면 해당 기계를 향합니다. 그 외에는 플레이어가 바라보는 방향이 앞면이 됩니다. 빈손으로 우클릭하면 방향 설정 화면이 열립니다. 화면에는 여섯 면이 표시되며 Front는 플레이어를 향한 면이므로 다른 블록과 맞닿은 면도 쉽게 설정할 수 있습니다. 면을 좌클릭하면 그쪽으로 빔을 출력하고 우클릭하면 그쪽에서 입력받습니다. 반대편 면에는 자동으로 반대 역할이 지정됩니다. Rotate 모드의 <ItemLink id="aquarine_steel_wrench"/>로 우클릭해 다음 방향으로 회전할 수도 있습니다.

<RecipeFor id="prismarine_laser_relay"/>

***

<Row>
  <ItemImage id="laser_junction"/>
  ### <Color id="aqua">Laser Junction</Color>
</Row>

여러 빔을 합쳐 원하는 방향으로 내보냅니다. 여섯 면 각각을 입력, 출력, 닫힘으로 설정할 수 있으며 처음에는 모두 닫혀 있습니다.

* 빈손으로 우클릭하면 여섯 면의 설정 화면이 열리며 Front는 플레이어를 향한 면입니다. 면을 클릭하면 Off, Input, Output 순서로 바뀌고 우클릭하면 역순으로 바뀝니다. 다른 블록과 맞닿은 면도 설정할 수 있습니다.
* <ItemLink id="aquarine_steel_wrench"/>로 면을 우클릭하면 입력으로 설정되고 다시 클릭하면 닫힙니다.
* 면을 웅크려 우클릭하면 출력으로 설정되고 다시 클릭하면 닫힙니다.

모든 입력 빔의 전력이 합산되어 연결된 출력으로 균등하게 분배되며 소수점 이하는 버립니다. 25 AP 입력에서 출력이 두 개면 각각 12 AP를 받습니다. 순도는 가장 높은 입력에 가깝게 유지되지만 연결된 모든 입력의 평균과의 차이의 1/4만큼 낮아집니다. 멈춘 전원은 0으로 계산되므로 비어 있는 입력도 순도를 조금 낮춥니다.

각 출력에 상한을 설정할 수도 있습니다. 면 설정 화면에서 출력 면 위로 스크롤하면 틱당 최대 AP를 정할 수 있습니다. Shift를 누르면 1씩, Ctrl을 누르면 10씩 변경되고 1 아래로 내리면 제한이 사라집니다. 제한된 출력이 가져가지 않은 전력은 다른 출력에 분배됩니다. 이 기능을 이용하면 빔 하나로 기계 여러 대를 일렬로 작동시킬 수 있습니다. 각 Junction의 기계 방향 출력은 필요한 전력으로 제한하고 나머지 출력은 다음 Junction으로 보내세요. 100 AP 빔으로 20 AP 기계 네 대를 돌리면 Junction마다 전력이 절반으로 줄어드는 대신 80, 60, 40 AP가 다음 Junction으로 전달됩니다. Configuration Card로 면 설정과 출력 상한을 함께 복사할 수 있습니다.

Junction은 두 Catalyst의 약한 빔을 합쳐 [Deep Sea Drain](drain.md)에 공급하는 데 사용할 수 있습니다. 또한 모퉁이에서 빔을 꺾거나(한 면 입력, 다른 면 출력) 빔 하나를 최대 다섯 기계에 균등하게 나누어 줄 수 있습니다. 어느 경우든 순도 손실 없이 전달됩니다.

<RecipeFor id="laser_junction"/>

***

## <Color id="gold">먼 거리와 굴절 경로</Color>

거리를 늘리려면 Relay를 연결하고, 빔을 꺾거나 분기할 때는 Laser Junction을 사용하세요. 순도를 높이는 Focusing Lens는 [Beam Optics](nautec:deep_engineering/beam_optics.md)에 설명되어 있습니다. 지도 반대편이나 다른 차원으로 전력을 보내려면 [Prism Satellite](nautec:deep_engineering/prism_satellite.md)를 참고하세요.

***

## <Color id="gold">Laser P2P Tunnel</Color>

Applied Energistics 2가 설치되어 있다면 ME 네트워크로 레이저 빔을 전송할 수도 있습니다. ME P2P Tunnel을 Prismarine Laser Relay나 Laser Junction으로 우클릭하면 Laser P2P Tunnel로 변환됩니다. 다른 P2P Tunnel과 마찬가지로 Memory Card로 서로 연결하세요.

* 사거리 내의 레이저 블록에서 입력 Tunnel의 면으로 빔을 발사하세요. 기계에 연결하는 것과 같은 방식으로 빔이 연결됩니다.
* 각 출력 Tunnel은 맞닿은 면의 레이저 블록에 빔이 도착한 것처럼 전력을 공급합니다. 상대 블록은 해당 면에서 빔을 받을 수 있어야 합니다.
* 전력은 실제로 공급받는 블록이 있는 출력 Tunnel 사이에 균등하게 나뉘며 순도는 유지됩니다. 100 AP 입력에 출력 두 개면 각각 50 AP입니다.
* 다른 P2P Tunnel처럼 ME 네트워크의 채널과 전력이 필요합니다. 없으면 입력까지 빔이 도착하더라도 출력은 나오지 않습니다.

출력 Tunnel은 이미 자신의 상류에 있는 블록으로 빔을 되돌려 보내지 않으므로 Tunnel을 순환 연결해 전력을 복제할 수 없습니다.
