---
navigation:
  title: 화학 액체
  icon: nautec:eas_bucket
  position: 3
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:eas_bucket
  - nautec:saltwater_bucket
  - nautec:oil_bucket
  - nautec:glass_vial
  - nautec:eas_vial
  - nautec:salt
---

# <Color id="light_purple">화학 액체</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="eas_bucket" scale="2"/>
  NauTec 기계에서 사용하거나 생산하는 액체입니다.
</Column>

Salt Water는 거의 모든 [Mixer](mixer.md) 제작법의 기본 재료입니다. Mixer를 사용하면 Electrolyte Algae Serum(EAS)과 Etching Acid로 변환할 수 있습니다.

***

<Row>
  <ItemImage id="saltwater_bucket"/>
  ### <Color id="aqua">Salt Water</Color>
</Row>

Salt Water는 초당 500 mB를 탱크로 퍼 올리는 [Deep Sea Drain](drain.md)에서 얻습니다. 양동이나 파이프로 꺼낼 수 있습니다.

[Mixer](mixer.md)에서도 만들 수 있습니다. 일반 Water 1,000 mB와 Salt 1개를 사용하면 5초 후 Salt Water 1,000 mB를 얻습니다.

기본 설정에서는 바닷물을 양동이로 퍼도 일반 물로 취급됩니다. 모드팩 제작자가 `config/nautec-common.toml`의 `collectSaltWater`를 true로 설정하면 바다 바이옴의 물 근원에서 양동이를 채울 때 Salt Water Bucket을 얻도록 변경할 수 있습니다.

***

<Row>
  <ItemImage id="eas_bucket"/>
  ### <Color id="aqua">Electrolyte Algae Serum (EAS)</Color>
</Row>

[Mixer](mixer.md)에서 Salt Water로 만듭니다. EAS는 [Aquarine Steel 도구](tools.md)의 특수 능력을 해제합니다.

도구에 주입하려면 EAS를 근원 블록으로 붓고 도구를 그 안에 떨어뜨리세요. 약 7.5초 후 도구가 영구적으로 주입 상태가 되며 EAS 근원 블록은 소모됩니다. 따라서 양동이 하나로 도구 하나를 처리할 수 있습니다.

***

<Row>
  <ItemImage id="etching_acid_bucket"/>
  ### <Color id="aqua">Etching Acid</Color>
</Row>

Crate와 오래된 부품의 녹을 제거합니다. [Mixer](mixer.md)나 제작대를 통해 만들 수 있습니다. [상자와 아이템 에칭](nautec:getting_started/etching.md)을 참고하세요.

***

<Row>
  <ItemImage id="oil_bucket"/>
  ### <Color id="aqua">Oil</Color>
</Row>

<ItemLink id="oil_barrel"/>에서 발견되는 점성이 높은 액체입니다.

***

## <Color id="gold">바이알과 소금</Color>

<Row>
  <ItemImage id="glass_vial"/>
  ### <Color id="aqua">Glass Vial</Color>
</Row>

<Recipe id="nautec:glass_vial"/>

<Row>
  <ItemImage id="eas_vial"/>
  ### <Color id="aqua">Electrolyte Algae Serum (EAS) Vial</Color>
</Row>

EAS Bucket 하나와 Glass Vial 3개로 EAS Vial 3개를 만들 수 있으며 빈 양동이는 돌려받습니다. Glass Vial과 EAS Vial은 <ItemLink id="syringe_robot_arm"/>에 사용됩니다.

<Recipe id="nautec:eas_vial"/>

<Row>
  <ItemImage id="salt"/>
  ### <Color id="aqua">Salt</Color>
</Row>

행운 낚시 구역에서 낚시 전리품으로 얻을 수 있습니다([낚시](nautec:getting_started/fishing.md) 참조). [Thermal Vent Tap](nautec:getting_started/ocean_generators.md)은 Salt Water 1,000 mB를 끓일 때마다 Salt 1개를 생산합니다. Mixer에서 Salt와 Water를 사용하면 Salt Water를 만들 수 있습니다.
