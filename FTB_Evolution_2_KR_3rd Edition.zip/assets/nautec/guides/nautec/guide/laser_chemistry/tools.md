---
navigation:
  title: Aquarine Steel Tools
  icon: nautec:aquarine_steel_axe
  position: 8
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:aquarine_steel_sword
  - nautec:aquarine_steel_pickaxe
  - nautec:aquarine_steel_axe
  - nautec:aquarine_steel_shovel
  - nautec:aquarine_steel_hoe
---

# <Color id="light_purple">Aquarine Steel Tools</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aquarine_steel_axe" scale="2"/>
  내구도 대신 AP를 소비하며 EAS로 특수 능력을 해제할 수 있는 도구입니다.
</Column>

## <Color id="gold">동력</Color>

이 도구들은 부서지지 않고 대신 AP를 소모합니다. 대부분의 블록을 채굴하거나 몹을 공격할 때 1 AP가 필요합니다. 아이콘 아래 막대는 충전 상태를, 툴팁은 정확한 충전량을 표시합니다.

AP가 바닥나면 채굴, 공격, 블록 상호작용을 할 수 없습니다. [Charger](charger.md)나 [Prismatic Battery](prismatic_battery.md)로 충전량을 유지하세요. Hoe는 700 AP, 나머지 도구는 1,200 AP를 저장합니다.

***

## <Color id="gold">특수 능력 해제</Color>

새 도구는 특수 능력이 잠겨 있습니다. [Electrolyte Algae Serum](chemistry_introduction.md)을 근원 블록으로 붓고 도구를 떨어뜨리세요. 약 7.5초 후 영구적으로 주입 상태가 되며 EAS는 소모됩니다.

주입한 뒤 도구를 들고 Shift+우클릭하면 특수 능력을 켜거나 끌 수 있습니다. 능력이 활성화되면 도구에 반짝임 효과가 나타납니다.

***

<Row>
  <ItemImage id="aquarine_steel_pickaxe"/>
  ### <Color id="aqua">Pickaxe</Color>
</Row>

파괴하는 면을 기준으로 돌과 기타 곡괭이 채굴 블록을 3×3 범위로 채굴하며 블록당 2 AP를 소모합니다. 상자나 기계처럼 블록 엔티티가 있는 블록은 제외됩니다.

특수 능력으로 파괴한 블록은 일반 도구로 캔 것처럼 아이템을 떨어뜨립니다. Fortune이나 Silk Touch를 적용하려면 능력을 끄세요. Axe와 Shovel에도 같은 규칙이 적용됩니다.

능력을 활성화하면 <ItemLink id="prismarine_crystal"/>도 수확할 수 있습니다. [Prismarine Crystal Shards](crystal_shards.md)를 참고하세요.

<RecipeFor id="aquarine_steel_pickaxe"/>

***

<Row>
  <ItemImage id="aquarine_steel_axe"/>
  ### <Color id="aqua">Axe</Color>
</Row>

원목 하나를 부수면 연결된 원목이 모두 쓰러집니다. 원목 하나당 2 AP를 소모하며 나무 전체가 쓰러지거나 도끼의 동력이 소진될 때까지 계속됩니다.

<RecipeFor id="aquarine_steel_axe"/>

***

<Row>
  <ItemImage id="aquarine_steel_shovel"/>
  ### <Color id="aqua">Shovel</Color>
</Row>

일반 채굴에는 블록당 1 AP를 소모합니다. 특수 능력을 켜면 파괴하는 면을 기준으로 흙, 모래, 자갈 등 삽으로 채굴하는 블록을 3×3 범위로 캡니다. 추가 블록당 2 AP가 소모되며 블록 엔티티가 있는 블록은 제외됩니다.

<RecipeFor id="aquarine_steel_shovel"/>

***

<Row>
  <ItemImage id="aquarine_steel_hoe"/>
  ### <Color id="aqua">Hoe</Color>
</Row>

한 번 사용하면 흙이나 잔디 블록의 3×3 범위를 경작지로 바꾸며 블록당 2 AP를 소모합니다.

<RecipeFor id="aquarine_steel_hoe"/>

***

<Row>
  <ItemImage id="aquarine_steel_sword"/>
  ### <Color id="aqua">Sword</Color>
</Row>

능력을 켜고 AP가 남아 있으면 피해량이 70% 증가하고 명중한 대상에 번개를 떨어뜨립니다. 이때 공격 한 번당 10 AP가 소모됩니다.

<Color id="gold">주의</Color>: 번개는 사용자 자신을 포함해 대상 주변 몇 블록 이내의 모든 것에 영향을 주며 불을 붙일 수 있습니다.

<RecipeFor id="aquarine_steel_sword"/>
