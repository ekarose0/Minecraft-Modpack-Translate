---
navigation:
  title: Energy Converter
  icon: nautec:energy_converter
  position: 1
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:energy_converter
  - nautec:creative_power_source
  - nautec:creative_energy_source
  - nautec:energy_conversion_upgrade
  - nautec:advanced_energy_conversion_upgrade
  - nautec:ultimate_energy_conversion_upgrade
---

# <Color id="light_purple">Energy Converter</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="energy_converter" scale="2"/>
  다른 모드의 Forge Energy(FE)를 레이저 빔으로 변환합니다.
</Column>

변환은 FE 입력 → AP 출력의 한 방향으로만 이루어집니다.

***

## <Color id="gold">사용 방법</Color>

다른 모드의 케이블이나 발전기로 어느 면에서든 FE를 공급할 수 있습니다. 최대 4,000,000 FE를 저장합니다(`config/nautec-common.toml`의 `energyConverterFeCapacity`).

10 FE를 1 AP로 변환합니다(`energyConverterFePerAp`). 최대 16블록 거리의 직선상에 레이저 수신기가 있는 모든 방향으로 빔을 발사합니다. AP는 연결된 수신기에 균등 분배하며 소수점 이하는 버립니다. 예를 들어 150 AP를 수신기 2개에 나누면 각각 75 AP, 4개에 나누면 각각 37 AP입니다. 수신기가 하나 이상 연결되었을 때만 FE를 소비하므로 출력 대상이 없으면 에너지를 저장합니다.

우클릭해 틱당 전송 AP를 설정합니다. 버튼은 기본 1 또는 10씩, Shift를 누르면 10 또는 100씩, Ctrl을 누르면 100 또는 1,000씩 조정합니다. 화면에 틱당 FE 소모량이 표시되므로 발전기의 공급량에 맞게 설정하면 저장량이 바닥나 빔이 끊기는 일을 방지할 수 있습니다. 전송량을 0으로 설정하면 꺼집니다.

***

## <Color id="gold">업그레이드</Color>

업그레이드가 없으면 틱당 최대 150 AP를 전송합니다. 화면에는 등급별로 3개의 업그레이드 슬롯이 있으며, 각 슬롯에는 해당 등급 업그레이드를 최대 8개 넣을 수 있습니다.

| 업그레이드 | 개당 증가량 | 8개 장착 시 증가량 |
|---|---|---|
| <ItemLink id="energy_conversion_upgrade"/> | 150 AP/t | 1,200 AP/t |
| <ItemLink id="advanced_energy_conversion_upgrade"/> | 500 AP/t | 4,000 AP/t |
| <ItemLink id="ultimate_energy_conversion_upgrade"/> | 1,500 AP/t | 12,000 AP/t |

세 슬롯을 모두 채우면 틱당 17,350 AP를 전송하며 173,500 FE/t를 소비합니다. 업그레이드를 제거하면 최대 전송량이 새 한도로 감소합니다.

<Recipe id="nautec:energy_conversion_upgrade"/>
<Recipe id="nautec:advanced_energy_conversion_upgrade"/>
<Recipe id="nautec:ultimate_energy_conversion_upgrade"/>

***

## <Color id="gold">순도</Color>

변환기의 빔 순도는 0입니다. 따라서 [Mixer](mixer.md), [Deep Sea Drain](drain.md), [Charger](charger.md), 순도 요구치가 없는 Item Transformation에 사용할 수 있습니다. Focusing Lens는 이미 순도가 있는 빔만 증폭하므로 이 빔의 순도를 높이지 못합니다.

FE로 높은 순도의 빔을 얻으려면 [Laser Junction](laser_manipulation.md) 등을 이용해 변환기 빔과 순도가 높은 빔을 같은 블록에 합쳐야 합니다. 합쳐진 빔의 순도는 가장 높은 빔에 가깝게 유지됩니다. 예를 들어 순도 3.0의 Prismarine Crystal 빔과 변환기 빔을 합치면 두 빔의 출력을 모두 가지면서 순도는 약 2.6이 됩니다. 순도가 높은 광원은 [Beam Optics](nautec:deep_engineering/beam_optics.md)를 참고하세요.

<Recipe id="nautec:energy_converter"/>

***

<Row>
  <ItemImage id="creative_power_source"/>
  ### <Color id="aqua">Creative Power Source</Color>
</Row>

건축물 테스트용 크리에이티브 전용 레이저 광원입니다. 연료 없이 순도 0의 100 AP/t를 출력하며, 직선상에 수신기가 있는 모든 방향으로 균등 분배합니다. NauTec 크리에이티브 탭에서 찾을 수 있습니다.

***

<Row>
  <ItemImage id="creative_energy_source"/>
  ### <Color id="aqua">Creative Energy Source</Color>
</Row>

Energy Converter를 테스트하기 위한 무한 FE 공급원입니다. 스스로 에너지를 밀어내지 않으므로 에너지를 추출하는 케이블에 연결해야 합니다. NauTec 크리에이티브 탭에서 찾을 수 있습니다.
