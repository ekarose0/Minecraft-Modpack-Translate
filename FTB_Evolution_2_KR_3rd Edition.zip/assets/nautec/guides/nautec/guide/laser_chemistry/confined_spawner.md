---
navigation:
  title: Confined Spawner
  icon: nautec:spawner_confinement_matrix
  position: 12
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:spawner_confinement_matrix
  - nautec:confined_spawner
  - nautec:mob_sampler
  - nautec:mob_sample
---

# <Color id="light_purple">Confined Spawner</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="spawner_confinement_matrix" scale="2"/>
  몹 생성기를 실제 몹을 소환하지 않고 전리품을 내부 저장 공간에 직접 생산하는 기계로 바꿉니다.
</Column>

## <Color id="gold">생성기 봉인하기</Color>

Spawner Confinement Matrix를 몹 생성기에 사용하세요. 우리에 빛나는 룬과 금속 테두리가 생기며 Confined Spawner로 변합니다. 원래 생성기의 몹 종류, 한 번에 소환하는 수, 소환 간격, 업그레이드가 모두 유지됩니다. Apothic Spawners로 강화한 생성기도 소환 수와 간격이 유지되므로 강화 효과에 따라 더 빨리 작동합니다.

빈손이나 Matrix를 들고 웅크려 우클릭하면 봉인이 해제됩니다. 현재 몹과 업그레이드를 유지한 일반 생성기로 돌아오고 Matrix는 인벤토리로 반환됩니다. 단, 내부 저장 공간과 경험치 탱크가 모두 비어 있어야 해제할 수 있으며, 남아 있다면 먼저 비우라는 메시지가 표시됩니다.

곡괭이로 Confined Spawner를 부수면 Silk Touch 유무와 관계없이 Confined Spawner 아이템 자체가 떨어집니다. 몹 종류, 생성기 설정, 업그레이드, 필터가 유지되므로 그대로 옮겨 다시 설치할 수 있습니다. 저장된 전리품과 경험치도 아이템에 함께 보관되어 바닥에 쏟아지지 않습니다. 일반 생성기로 되돌리려면 내부를 비운 뒤 봉인을 해제하세요.

## <Color id="gold">몹 변경</Color>

Mixer에서 Glass Vial 1개, Aquarine Copper Ingot 2개, 다이아몬드 1개, Electrolyte Algae Serum 250 mB로 <ItemLink id="mob_sampler"/>를 만드세요. 한 번에 Sampler 1개가 제작됩니다.

Sampler를 살아 있는 몹에 사용하면 <ItemLink id="mob_sample"/>을 채취합니다. 몹은 죽거나 이동하지 않으며 Sampler만 소비됩니다. Sample 툴팁에는 채취한 몹의 이름이 표시됩니다. 다른 모드의 생물도 가능합니다.

Sample을 Confined Spawner에 사용하면 생성되는 몹이 변경되고 Sample은 소비됩니다. 소환 수, 간격, 업그레이드, 필터, 저장된 전리품과 경험치는 유지되지만 다음 작업 주기의 진행도는 초기화됩니다. 생성기를 부쉈다가 다시 설치하거나 일반 생성기로 봉인을 해제해도 변경된 몹이 유지됩니다. 일반 생성기에는 Sample을 직접 사용할 수 없습니다.

플레이어, 죽은 생물, `c:capturing_not_supported` 엔티티 유형 태그에 속한 대상은 채취할 수 없습니다. Sample 적용 시에도 이 태그를 다시 확인하므로 모드팩 규칙이 변경되기 전에 채취한 Sample을 차단할 수도 있습니다.

<RecipeFor id="mob_sampler"/>

### <Color id="aqua">Guardian 재료</Color>

Guardian은 처음 채취하기 좋은 대상입니다. Guardian Confined Spawner로 [Aquatic Catalyst 연료](nautec:getting_started/laser_power.md)와 NauTec 제작에 필요한 Prismarine Shard, Prismarine Crystal을 지속적으로 얻을 수 있습니다. Aquarine Copper Compound 제작에도 사용됩니다.

또한 <ItemLink id="ancient_valve"/>, <ItemLink id="burnt_coil"/>, <ItemLink id="guardian_eye"/>도 일정 확률로 생산합니다. 따라서 Augment와 Impulse Laser Module에 쓰이는 폐품 부품과 Guardian Eye를 자동 공급할 수 있습니다. 추가 몹 전리품은 [Salvage](nautec:getting_started/salvage.md), 폐품 부품 정제는 [Crates and Etching](nautec:getting_started/etching.md)을 참고하세요.

## <Color id="gold">전력</Color>

아무 면에나 레이저 빔을 조사하세요. 생성기는 최대 500 AP를 저장하며 작동 중 매 틱 50 AP를 소비합니다. 50 AP 이상의 빔을 공급하면 계속 작동하고, 더 약한 빔은 버퍼가 충전될 때마다 간헐적으로 작동합니다. 공급 방법은 [Laser Power](nautec:getting_started/laser_power.md)를 참고하세요.

전력과 빈 저장 슬롯만 있으면 근처에 플레이어가 없어도, 조명이나 공간 조건을 충족하지 않아도 작동합니다. 작동 중에는 룬이 더 밝게 빛나고 안쪽 몹이 빠르게 회전합니다.

## <Color id="gold">전리품</Color>

한 주기의 길이는 원래 생성기의 소환 간격과 같습니다. 주기가 끝나면 소환했을 몹 수만큼 전리품을 추첨합니다. 플레이어가 처치한 것으로 취급하므로 플레이어 처치 조건의 전리품도 포함됩니다. 결과물은 대형 상자와 같은 54칸 저장 공간에 들어갑니다.

모든 슬롯이 차면 생성기가 멈추고 빈 슬롯이 생길 때까지 버퍼를 가득 유지합니다. 추첨 결과 중 공간이 없어 들어가지 못한 아이템은 사라집니다.

호퍼와 파이프로 기본적으로 모든 면에서 전리품을 꺼낼 수 있습니다([Side Configuration](nautec:getting_started/utilities.md)). 아이템을 넣는 것은 생성기 자체만 가능합니다.

## <Color id="gold">경험치</Color>

생성기는 몹이 떨어뜨릴 경험치도 16,000 mB 용량의 탱크에 액체 경험치로 저장합니다. 경험치 1포인트는 20 mB로 변환되며, 이는 대부분의 모드에서 사용하는 비율입니다. 탱크가 가득 차면 추가 경험치는 사라지지만 생성기는 계속 작동합니다.

기본 유체는 초록색으로 빛나는 Experience Algae입니다. 모드팩에 다른 모드의 액체 경험치가 있다면 `config/nautec-common.toml`의 `confinedSpawnerXpFluids`에 해당 유체 ID를 먼저 적어 생성기가 대신 생산하게 할 수 있습니다. Experience Algae는 `c:experience` 유체 태그에 속하므로 해당 태그로 액체 경험치를 받는 모드에서도 사용할 수 있습니다.

경험치는 모든 면에서 파이프로 빼내거나 빈 양동이를 들고 생성기를 우클릭해 꺼낼 수 있습니다. 유체의 [Side Configuration](nautec:getting_started/utilities.md)은 아이템과 별도로 적용됩니다. 파이프는 탱크에서 꺼내기만 할 수 있습니다. 화면 왼쪽 탭의 세 번째 막대는 탱크 용량을 보여 줍니다. 생성기를 부수면 경험치도 떨어진 아이템에 보존됩니다.

## <Color id="gold">화면</Color>

생성기를 우클릭하면 저장 공간을 열고 아이템을 꺼낼 수 있습니다. 왼쪽 탭에는 저장된 AP, 현재 주기 진행도, 액체 경험치의 막대 세 개가 있습니다. 막대에 커서를 올리면 수치가 표시됩니다. 작동하지 않을 때는 제목 옆 상태에 정지 이유가 나옵니다.

## <Color id="gold">전리품 필터</Color>

제목 옆의 깔때기 버튼을 누르면 필터 슬롯 18개가 있는 화면이 열립니다.

* 아이템을 들고 슬롯을 클릭하면 해당 아이템이 필터에 등록됩니다. JEI에서 아이템을 끌어다 넣을 수도 있습니다.
* 채워진 슬롯을 우클릭하면 아이템의 태그들을 순서대로 선택한 뒤 다시 정확한 아이템 필터로 돌아옵니다. 태그 필터는 해당 태그의 모든 아이템에 적용되며 금색 **#**이 표시됩니다.
* 빈손으로 슬롯을 클릭하면 필터가 지워집니다.

위쪽 버튼으로 다음 두 모드를 전환합니다.

* **Blacklist**: 필터에 등록된 전리품을 제외하고 모두 생산합니다.
* **Whitelist**: 필터에 등록된 전리품만 생산합니다.

필터로 제외한 전리품은 아예 생성되지 않아 저장 공간을 차지하지 않습니다. Whitelist가 비어 있으면 필터를 추가할 때까지 생성기가 멈춥니다.

## <Color id="gold">Jade</Color>

Jade로 Confined Spawner를 바라보면 몹 종류, 작동 여부, 저장된 AP와 아이템을 확인할 수 있습니다.

***

### <Color id="aqua">Spawner Confinement Matrix 제작법</Color>

<RecipeFor id="spawner_confinement_matrix"/>
