---
navigation:
  title: Budding Prismarine
  icon: nautec:budding_prismarine
  position: 10
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:budding_prismarine
  - nautec:small_prismarine_bud
  - nautec:medium_prismarine_bud
  - nautec:large_prismarine_bud
  - nautec:prismarine_cluster
---

# <Color id="light_purple">Budding Prismarine</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="budding_prismarine" scale="2"/>
  Budding Amethyst가 자수정을 키우는 것처럼 Prismarine Crystal Shard를 성장시킵니다.
</Column>

## <Color id="gold">발견 장소</Color>

가장 찾기 쉬운 곳은 Prismarine Reef로, 약 두 청크 중 한 청크의 해저 표면이나 프리즈머린 지대에서 발견됩니다. Abyssal Trench와 Bioluminescent Grove의 해저 표면, 모든 Glow Grotto 바닥에서도 생성됩니다. 바닐라 Warm Ocean과 Deep Lukewarm Ocean의 해저 표면에도 드물게 나타납니다. Abyssal Trench의 행운 낚시 구역에서는 보물로 낚을 수도 있습니다. Silk Touch로 채굴하여 원하는 재배 장소에 옮기세요.

이 블록은 희미하게 빛나며 간헐적으로 반짝입니다. 밤에 해저의 약한 빛을 찾아보세요. 해당 바이옴을 찾으려면 <ItemLink id="eye_of_the_sea"/>의 목표를 Prismarine Reefs로 설정한 뒤 던지세요.

이 바이옴들에서는 <ItemLink id="grafting_tool"/>을 사용해 블록에서 Lithophiles를 채취할 수 있습니다.

***

## <Color id="gold">성장 단계</Color>

공기 또는 물 근원 블록과 맞닿은 모든 면에서 싹이 자랍니다. 따라서 해저에 놓인 블록도 동굴에 놓인 블록처럼 성장합니다. 싹은 같은 자리에서 네 단계를 거칩니다.

<Row>
  <ItemImage id="small_prismarine_bud"/>
  <ItemImage id="medium_prismarine_bud"/>
  <ItemImage id="large_prismarine_bud"/>
  <ItemImage id="prismarine_cluster"/>
</Row>

Small Prismarine Bud → Medium Prismarine Bud → Large Prismarine Bud → Prismarine Cluster 순서로 자랍니다. 성장할수록 빛이 밝아집니다.

***

## <Color id="gold">수확</Color>

Prismarine Cluster까지 성장할 때를 기다리세요. 이를 부수면 <ItemLink id="prismarine_crystal_shard"/> 2개가 떨어지고, Fortune을 적용하면 더 많이 얻을 수 있습니다. 이후 같은 자리에 새 싹이 자랍니다.

덜 자란 싹은 Silk Touch 없이 부수면 아무것도 떨어뜨리지 않습니다. Silk Touch를 사용하면 싹이나 Cluster 자체를 얻습니다. Budding Prismarine 블록에서 자란 부분만 수확하세요.

Budding Prismarine 블록 자체를 옮기려면 Silk Touch 곡괭이로 채굴해야 합니다. 일반 곡괭이로 캐면 Prismarine Crystal Shard 4~6개로 부서지고 더는 아무것도 자라지 않습니다.
