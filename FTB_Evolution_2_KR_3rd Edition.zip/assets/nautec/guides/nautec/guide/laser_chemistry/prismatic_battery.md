---
navigation:
  title: Prismatic Battery
  icon: nautec:prismatic_battery
  position: 7
  parent: laser_chemistry/laser_chemistry-index.md
item_ids:
  - nautec:prismatic_battery
---

# <Color id="light_purple">Prismatic Battery</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="prismatic_battery" scale="2"/>
  10,000 AP를 저장하며 인벤토리에 있는 전력 사용 아이템을 충전합니다.
</Column>

## <Color id="gold">사용 방법</Color>

* [Charger](charger.md)에서 충전합니다.
* 손에 들고 Shift+우클릭하면 켜집니다. 작동 중에는 반짝이는 효과가 나타나며, 툴팁에서 작동 상태와 충전량을 확인할 수 있습니다.
* Curios 인벤토리의 Battery 슬롯에 장착합니다. 이 슬롯에 있어야만 작동합니다.

작동 중에는 배터리가 소진될 때까지 매 틱마다 단축바와 기본 인벤토리에서 충전이 덜 된 AP 저장 아이템 각각에 최대 100 AP를 공급합니다.

<Color id="gold">팁</Color>: 착용 중인 방어구는 해당 슬롯에 포함되지 않습니다. 착용 방어구는 Charger에서 충전하거나 잠시 벗어서 충전하세요.

***

### <Color id="aqua">Prismatic Battery 제작법</Color>

<RecipeFor id="prismatic_battery"/>
