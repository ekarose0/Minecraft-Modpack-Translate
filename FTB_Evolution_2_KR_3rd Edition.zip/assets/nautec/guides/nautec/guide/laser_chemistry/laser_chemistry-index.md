---
navigation:
  title: 레이저 화학
  icon: nautec:eas_vial
  position: 2
---

# <Color id="gold">레이저 화학</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="eas_vial" scale="2"/>
  블록 사이로 레이저 동력(AP)을 전달하고 아이템을 충전하는 방법과, 빔으로 작동하는 기계 및 재료를 소개합니다.
</Column>

***

<SubPages icons={true}/>
