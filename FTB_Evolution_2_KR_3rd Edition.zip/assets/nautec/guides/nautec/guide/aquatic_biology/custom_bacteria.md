---
navigation:
  title: Custom Bacteria
  icon: minecraft:command_block
  position: 14
  parent: aquatic_biology/aquatic_biology-index.md
---

# <Color id="light_purple">Custom Bacteria</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="minecraft:command_block" scale="2"/>
  관리자 명령어로 원하는 아이템을 생산하는 새로운 세균 균주를 생성할 수 있습니다.
</Column>

이 문서는 서버 관리자와 모드팩 제작자를 위한 것입니다. 명령어를 사용하려면 운영자 권한(레벨 2)이 필요합니다.

***

## <Color id="gold">균주 생성</Color>

`/nautec bacteria generate <name> <item> [rarity]`

`<item>`을 생산하는 `<name>`이라는 균주를 만듭니다. 이 아이템 자체를 영양분으로 사용하는 배양법, 같은 영양분을 사용하는 군체 먹이 공급법, 해당 아이템을 촉매로 사용하는 돌연변이 제작법도 함께 생성됩니다. 희귀도는 초기 능력치, 배양 성장량, 돌연변이 확률, [균주 생산량](production_rates.md) 및 돌연변이의 출발 균주를 결정합니다.

| 희귀도 | 돌연변이 출발 균주 | 균주 생산량 |
|---|---|---|
| common | Lithophiles | 1 |
| uncommon (default) | Metallophiles | 0.8 |
| rare | Ferrophiles | 0.6 |
| epic | Aurrophiles | 0.4 |
| legendary | Adamantophiles | 0.12 |

`/nautec bacteria generate-tag <name> <item> <tag> [rarity]`도 같은 작업을 수행하지만 영양분으로 개별 아이템 대신 아이템 태그 전체를 사용합니다.

두 명령어 끝에 `preview`를 붙이면 실제 파일을 생성하지 않고 채팅에 내용을 출력합니다. 출력된 내용을 클릭하여 복사할 수 있습니다.

***

## <Color id="gold">채취 원천 설정</Color>

`/nautec bacteria obtain <name> <block> <biometag> <chance>`

`<biometag>`에 속하는 모든 바이옴에서 `<block>`을 통해 해당 균주를 0~1 사이의 확률로 채취할 수 있도록 합니다. NauTec가 이미 균주 채취에 사용하는 블록은 피하세요.

***

## <Color id="gold">균주 관리</Color>

* `/nautec bacteria list-generated`는 생성된 모든 균주와 생산 아이템, 관련 제작법을 표시합니다.
* `/nautec bacteria delete-generated <name>`은 해당 균주의 파일과 채취 항목을 삭제합니다.

모든 생성 파일은 `config/nautec/generated_pack`에 저장되며, 같은 인스턴스의 모든 월드가 공유합니다. 새 제작법과 채취 원천을 반영하려면 `/reload`를 실행하세요. 새 균주 자체는 다음에 월드에 접속할 때 불러옵니다.
