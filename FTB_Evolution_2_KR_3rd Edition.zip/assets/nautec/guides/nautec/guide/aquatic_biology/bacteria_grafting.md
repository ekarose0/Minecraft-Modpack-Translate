---
navigation:
  title: Bacteria Grafting
  icon: nautec:grafting_tool
  position: 3
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:grafting_tool
  - nautec:grafting_station
  - nautec:grafting_anchor
  - nautec:advanced_grafting_anchor
---

# <Color id="light_purple">Bacteria Grafting</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="grafting_tool" scale="2"/>
  Grafting Tool로 블록에서 첫 박테리아 군체를 채취하여 Petri Dish에 담습니다.
</Column>

주손에 Grafting Tool을, 보조 손에 빈 <ItemLink id="petri_dish"/>를 들고 해당 생물군계의 채취 가능한 블록을 우클릭하세요. 시도할 때마다 내구도 1을 소모하며 일정 확률로 접시에 새 군체가 담깁니다. 성공할 때까지 반복하세요.

<Color id="gold">팁</Color>: 반드시 빈 접시를 사용하세요. 보조 손의 접시에 이미 군체가 있으면 "이 Petri Dish에는 이미 군체가 있습니다"라는 메시지가 나오고 아무 일도 일어나지 않으며 내구도도 소모되지 않습니다.

***

## <Color id="gold">Grafting Tool</Color>

<RecipeFor id="grafting_tool"/>

이 도구의 내구도는 80입니다.

***

## <Color id="gold">채취할 수 있는 장소</Color>

| 블록 | 생물군계 | 균주 | 확률 |
|---|---|---|---|
| Stone | 모든 바다 | Cyanobacteria | 40% |
| Sand | 모든 해변 | Halobacteria | 40% |
| Podzol | 모든 숲 | Methanogens | 40% |
| Netherrack | 네더 | Thermophiles | 40% |
| Glow Polyp | Bioluminescent Grove | Cyanobacteria | 50% |
| Deep Kelp | Bioluminescent Grove | Halotrophs | 30% |
| Luminescent Algae | Bioluminescent Grove | Algaeformers | 30% |
| Prismarine Frond | Prismarine Reef | Phototrophs | 35% |
| <ItemLink id="budding_prismarine"/> | Prismarine Reef, Bioluminescent Grove, Abyssal Trench, Warm Ocean, Deep Lukewarm Ocean | Lithophiles | 30% |
| Abyssal Coral | Abyssal Trench | Calciophiles | 30% |
| Vent Tubeworm | Hydrothermal Vents | Sulfurophiles | 25% |

모드팩에 따라 목록이 달라질 수 있습니다. JEI의 Bacteria Grafting 분류에는 항상 현재 목록이 표시되며, "Only In" 항목에서 생물군계를 확인할 수 있습니다.

***

## <Color id="gold">Grafting Station</Color>

<Row>
  <ItemImage id="grafting_station" scale="2"/>
</Row>

Grafting Station은 도구 없이, 생물군계 제한도 없이 군체를 채취합니다. 빈 <ItemLink id="petri_dish"/>, 위 표의 채취 가능한 블록 하나, Salt Water를 공급하면 주기마다 새 군체가 접시에 담깁니다. 확률 판정이 없어 시도가 실패하지 않습니다.

* 전력: 전면을 제외한 면으로 순도 2.8 이상, 최소 100 AP의 빔을 공급하세요. <ItemLink id="prismarine_crystal"/>의 빔(순도 3.0)을 직접 공급하거나 Relay와 Junction을 거쳐 공급해도 됩니다.
* Salt Water: 군체 하나당 4,000 mB가 필요합니다. 탱크 용량은 16,000 mB입니다. 파이프로 넣거나 양동이를 들고 우클릭하세요.
* 시간: 군체 하나당 1분입니다. 빔이 약하면 진행도를 잃지 않고 일시 정지합니다.
* Grafting Anchor나 Advanced Grafting Anchor를 장착하지 않으면 군체마다 접시 하나와 블록 하나를 소모합니다.

우클릭하여 화면을 여세요. 화살표에 커서를 올리면 무엇을 기다리는지 확인할 수 있고, <ItemLink id="prism_monocle"/>로 바라봐도 됩니다. 호퍼와 파이프를 이용해 접시와 블록을 넣고 군체가 담긴 접시를 꺼낼 수 있습니다. 기본적으로 모든 면을 사용하며 [면 설정](nautec:getting_started/utilities.md)에서 변경할 수 있습니다. 작동 중에는 전면 창에 불이 들어옵니다.

이 값들은 모두 `config/nautec-common.toml`에서 설정할 수 있습니다.

<RecipeFor id="grafting_station"/>

<Row>
  <ItemImage id="grafting_anchor"/>
  ### <Color id="aqua">Grafting Anchor</Color>
</Row>

Grafting Station용 업그레이드입니다. 화면 왼쪽 아래 슬롯에 넣으면 채취할 때마다 샘플 블록이 사라지지 않습니다. 접시와 Salt Water만 계속 공급하면 블록 하나로 군체를 무한히 채취할 수 있습니다. 인벤토리에서 Shift+클릭하면 해당 슬롯에 바로 들어갑니다. 파이프는 이 슬롯에 접근할 수 없어 자동화로 실수로 꺼내지지 않습니다.

<RecipeFor id="grafting_anchor"/>

<Row>
  <ItemImage id="advanced_grafting_anchor"/>
  ### <Color id="aqua">Advanced Grafting Anchor</Color>
</Row>

[Bio Reactor](bio_reactor.md)의 Reactor Speed Upgrade 4개로 강화한 Grafting Anchor입니다. 같은 슬롯에 장착하고 샘플 블록을 유지하면서 채취 속도가 200% 증가해 군체 하나에 1분 대신 20초가 걸립니다. 대신 전력 요구량이 100 AP의 5배인 500 AP로 늘어납니다. 순도는 여전히 2.8 이상이어야 합니다. 화면의 화살표에 커서를 올리면 현재 장착한 Anchor에 필요한 전력을 확인할 수 있습니다.

<RecipeFor id="advanced_grafting_anchor"/>

***

## <Color id="gold">강한 빔</Color>

Grafting Station에 필요량보다 강한 빔을 공급하면 채취가 빨라집니다. 속도 배율은 √(빔 전력 ÷ 필요 전력)입니다. 일반적으로 100 AP, Advanced Grafting Anchor 장착 시 500 AP가 필요하며 순도는 항상 2.8 이상이어야 합니다.

| 필요 전력 대비 빔 배율 | 속도 |
|---|---|
| 1× | ×1 (기본) |
| 4× | ×2 |
| 9× | ×3 |
| 16× | ×4 |

두 효과는 중첩됩니다. Advanced Grafting Anchor를 장착하면 500 AP에서 이미 3배 빠르고, 2,000 AP 빔을 공급하면 속도가 다시 2배가 되어 군체 하나에 60초 대신 10초가 걸립니다.

적용 공식과 해당 기계 목록은 [강한 빔](nautec:getting_started/stronger_beams.md)을 참고하세요.

***

## <Color id="gold">어떤 군체부터 시작할까요?</Color>

Cyanobacteria, Halobacteria, Methanogens, Thermophiles는 아무것도 생산하지 않고 배양할 수도 없습니다. 이들은 시작 균주이므로 바로 [Mutator](mutator.md)에 넣어 아이템을 생산하는 균주로 변이시키세요.

심해 균주는 채취하자마자 생산에 사용할 수 있습니다. Halotrophs는 kelp, Algaeformers는 seagrass, Phototrophs는 sugar cane, Lithophiles는 stone, Calciophiles는 bone meal, Sulfurophiles는 gunpowder를 생산합니다. Lithophiles는 여러 균주의 조상이며 Budding Prismarine에서 직접 채취하면 Thermophiles로부터의 15% 확률 변이 과정을 건너뛸 수 있습니다. 따라서 [심해](nautec:getting_started/deep_oceans.md)에 다녀오면 변이 작업을 크게 줄일 수 있습니다.

새로 채취한 군체는 아직 분석되지 않은 상태입니다. [Bacterial Analyzer](bacterial_analyzer.md)에 넣어 어떤 군체인지 확인하세요.
