---
navigation:
  title: Bacteria Stats
  icon: nautec:petri_dish
  position: 5
  parent: aquatic_biology/aquatic_biology-index.md
---
# <Color id="light_purple">박테리아 능력치</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="petri_dish" scale="2"/>
  군체의 가치는 크기, 활력(Vitality), 네 가지 능력치로 결정됩니다.
</Column>

군체를 채취하거나 변이시키면 해당 균주의 초기 범위 안에서 능력치가 무작위로 정해집니다. 이후에는 [Mutator](mutator.md)에서 변이 또는 개량할 때만 바뀌며, 새 군체에는 약간의 무작위 변동이 적용된 능력치가 이어집니다. Growth Rate와 Production Rate는 각각 현재 능력치 ÷ (10 × (1 + Mutation Resistance)) 이내에서 증가하거나 감소합니다. 예를 들어 Production Rate가 1이고 저항력이 0이면 0.9~1.1이 되고, 저항력이 높을수록 부모에 가까워집니다. Lifespan은 최대 100틱 변하며 저항력이 높으면 변화 폭이 줄어듭니다. Mutation Resistance 자체는 감소하지 않습니다. 변이 때마다 조금씩 상승하며 상한에 가까울수록 증가량이 작아집니다. 우수한 군체를 얻으려면 여러 번 변이하거나 개량해야 합니다. 성장·급식·생산 과정에서는 능력치가 변하지 않습니다.

[Bacterial Analyzer](bacterial_analyzer.md)로 접시를 분석한 뒤 마우스를 올리고 Shift를 누르면 능력치를 볼 수 있습니다.

***

## <Color id="gold">네 가지 능력치</Color>

| 능력치 | 상한 | 효과 |
|---|---|---|
| Growth Rate | 5 | [Incubator](incubator.md)의 한 주기에서 증가하는 크기에 곱해집니다. |
| Mutation Resistance | 1 | [Mutator](mutator.md)의 성공 확률을 최대 절반까지 낮추며, 실패 시 손실도 줄여 상한에 도달하면 손실이 없어집니다. [Bacterial Fuel Cell](bacterial_fuel_cell.md) 광선의 순도를 결정합니다. |
| Production Rate | 2 | [Bio Reactor](bio_reactor.md)의 아이템 생산 속도에 곱해집니다. Fuel Cell의 출력과 군체 소모 속도도 결정합니다. |
| Lifespan | 24,000 | 영양분 없이 반응로에서 작업하다 노쇠(Senescent) 상태가 될 때까지의 시간(틱)입니다. |

네 가지 상한은 모두 설정에서 바꿀 수 있습니다. 툴팁에서 빨간색인 능력치는 상한에 도달한 것입니다.

생산품이 있는 균주의 분석 툴팁에는 Strain Yield도 표시됩니다. 이는 군체가 아닌 균주에 고정된 값이므로 변이해도 달라지지 않으며 생산 속도에 영향을 줍니다. 돌은 1, 다이아몬드는 0.12입니다. 모든 균주는 [생산 속도](production_rates.md)에서 확인하세요.

모든 균주의 초기 능력치는 낮습니다. Growth Rate 0.4~1.2, Production Rate 0.08~0.7, Mutation Resistance 최대 0.2, Lifespan 900~2,600틱입니다. 영양분 없는 반응로에서는 1분 미만에서 2분 남짓밖에 활동하지 못합니다. JEI의 Bio Reactor 항목에서 균주별 초기 Production Rate 범위를 확인할 수 있습니다.

***

## <Color id="gold">크기(Size)</Color>

크기는 군체의 양입니다. 채취하거나 변이한 군체는 120~600으로 시작하며, Incubator에서 상한인 40,000까지 성장할 수 있습니다(설정 가능). Incubator에서는 큰 군체가 더 빠르게 성장합니다.

* 반응로에서는 상한 크기의 군체가 아주 작은 군체보다 두 배 빠르게 작업합니다.
* Mutator에서는 큰 군체의 성공 확률이 조금 낮아지며 상한에서는 최대 25% 낮아집니다. 새 군체의 크기는 이전 군체의 크기와 무관합니다.
* Fuel Cell에서는 크기가 군체의 연소 지속 시간만 결정합니다.

***

## <Color id="gold">활력(Vitality)</Color>

활력은 Lifespan 중 남은 비율입니다. 영양분 없이 작동 중인 반응로에 있을 때만 매 틱 나이가 1틱씩 증가합니다. 영양분을 공급받는 군체나 출력 슬롯이 가득 차 작업을 멈춘 군체는 노화하지 않습니다. 접시, Incubator, Mutator, Fuel Cell에서도 군체는 노화하지 않습니다. 반응로의 급식 방식은 [군체 영양 공급](colony_feeding.md)을 참고하세요.

툴팁에서는 비율로 표시되며 50% 이상은 초록색, 20% 이상은 노란색, 그 미만은 빨간색입니다. 0%에 도달하면 Senescent(노쇠)로 표시됩니다. 노쇠한 군체가 반응로에서 영양분 없이 작동하면 매초 크기의 2%(최소 1)가 줄어듭니다(설정 가능). 약 35초 뒤에는 크기가 절반 정도 사라집니다. 영양분을 공급하면 크기 손실은 멈추지만 노쇠 상태는 유지됩니다.

[Incubator](incubator.md)의 배양 주기가 한 번 완료될 때마다 활력은 100%로 회복됩니다. 노쇠한 군체라도 Fuel Cell에서는 최대 출력으로 연소합니다.
