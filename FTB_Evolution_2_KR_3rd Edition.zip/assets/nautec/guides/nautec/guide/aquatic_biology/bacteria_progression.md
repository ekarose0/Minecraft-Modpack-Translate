---
navigation:
  title: Bacteria Progression
  icon: nautec:bio_reactor
  position: 1
  parent: aquatic_biology/aquatic_biology-index.md
---

# <Color id="light_purple">Bacteria Progression</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="bio_reactor" scale="2"/>
  첫 군체 채취부터 여러 반응로를 운영하기까지의 과정과 단계별 필요 전력을 안내합니다.
</Column>

군체를 전력이 공급되는 [Bio Reactor](bio_reactor.md)에 넣고 영양분을 제공하면 본격적인 생산이 시작됩니다. 전력이 유지되는 동안 노화하지 않고 계속 아이템을 생산합니다. 이 안내서는 좋은 군체를 확보하고 더 많은 군체를 가동하는 과정을 설명합니다.

이 페이지에서는 제작 순서, 각 기계 제작에 필요한 선행 재료, 단계별 전력 공급 방법을 정리합니다. [균주 계통도](strain_tree.md)에서는 어떤 변이로 어떤 균주를 얻는지 볼 수 있습니다.

***

## <Color id="gold">시작하기 전에</Color>

생물학 기계를 사용하려면 이 모드의 다른 시스템에서 세 가지를 먼저 준비해야 합니다.

* **Salt Water.** [Mutator](mutator.md) 제작에는 Electrolyte Algae Serum 양동이가 필요합니다. 이는 [Mixer](nautec:laser_chemistry/mixer.md)에서 Salt Water로 만들며, [Deep Sea Drain](nautec:laser_chemistry/drain.md)을 이용하면 안정적으로 공급할 수 있습니다.
* **순도 1.5의 빔.** Incubator, Bio Reactor, Fuel Cell에 들어가는 Laser Channeling Coil은 순도 1.5의 [아이템 변환](nautec:getting_started/item_transformation.md)으로 만듭니다. <ItemLink id="aquatic_catalyst"/>에 <ItemLink id="prismarine_crystal_shard"/>를 연료로 넣으면 순도 1.2가 나오고, 맞닿은 <ItemLink id="budding_prismarine"/> 하나당 0.1씩 증가하므로 3개를 배치하면 1.5가 됩니다.
* **Aquarine Steel.** Analyzer, 보호막, 렌즈 제작에 필요합니다.

***

## <Color id="gold">필요 전력 요약</Color>

표의 수치는 모두 최소 요구량입니다. 이보다 낮으면 기계가 대기하고, 더 강한 빔을 공급하면 대부분의 기계가 빨라집니다([강한 빔](nautec:getting_started/stronger_beams.md)).

| 기계 | 요구량 | 빔 입력 면 |
|---|---|---|
| [Bacterial Analyzer](bacterial_analyzer.md) | 5 AP | 아랫면 |
| [Mutator](mutator.md) | 10 AP | 윗면 또는 아랫면 |
| [Incubator](incubator.md) | 20 AP | 윗면과 아랫면, 두 빔 합산 |
| [Bio Reactor](bio_reactor.md) | 군체 1개에 20 AP, 3개에 50 AP | 상단 층의 해치 |
| [Advanced Bacterial Analyzer](bacterial_analyzer.md) | 순도 2.1에서 40 AP | 전면을 제외한 모든 면 |
| [Colony Replicator](colony_replicator.md) | 순도 2.0에서 80 AP | 전면을 제외한 모든 면 |
| [Grafting Station](bacteria_grafting.md) | 순도 2.8에서 100 AP | 전면을 제외한 모든 면 |
| [Industrial Bio Reactor](industrial_bio_reactor.md) | 군체 1개에 150 AP, 9개에 550 AP | 지붕 해치 |

[Reactor Upgrades](reactor_upgrades.md)를 장착하면 반응로의 요구 전력이 배율에 따라 증가합니다.

Prismarine Shards를 사용하는 Aquatic Catalyst 하나는 12 AP를 생산하며 분당 조각 2개를 소모합니다. 맞닿은 Budding Prismarine 하나당 출력이 25% 증가하므로 1개를 붙이면 15 AP입니다. 이 정도면 초반 기계들을 모두 작동시킬 수 있습니다. Bio Reactor는 Catalyst 2개로 군체 1개, 3개로 군체 2개, Budding Prismarine이 각각 붙은 Catalyst 4개로 군체 3개를 가동할 수 있습니다. Catalyst를 많이 쓰면 조각 소모가 크므로 가능한 빨리 [Energy Converter](nautec:laser_chemistry/energy_converter.md)로 전환하는 편이 좋습니다.

***

## <Color id="gold">1단계: 첫 군체</Color>

**제작:** Petri Dish, Grafting Tool, Bacterial Analyzer, 그리고 그 아래에 놓을 Catalyst 하나.

빈 접시를 여러 개 준비하고 채취를 시작하세요. 첫 채취로 추천하는 균주는 다음과 같습니다.

* **Lithophiles:** Warm Ocean, Deep Lukewarm Ocean 또는 심해 생물군계의 <ItemLink id="budding_prismarine"/>에서 채취합니다(30%). 모든 금속·보석 균주의 조상이므로 변이 한 단계를 건너뛸 수 있습니다.
* **Halobacteria:** 모든 해변의 Sand에서 채취합니다(40%). Mutator에서 kelp를 사용하면 75% 확률로 Halotrophs가 됩니다. 가장 쉬운 첫 변이이며, Halotrophs는 [Combustion Dynamo](nautec:getting_started/combustion_dynamo.md)의 연료용 기름을 만드는 Lipophiles로 이어집니다.
* **심해 균주:** 채취 즉시 생산 가능한 Halotrophs(kelp), Algaeformers(seagrass), Phototrophs(sugar cane), Calciophiles(bone meal), Sulfurophiles(gunpowder)가 있습니다. 채취 장소는 [Bacteria Grafting](bacteria_grafting.md)을 참고하세요.

Cyanobacteria, Halobacteria, Methanogens, Thermophiles는 아무것도 생산하지 않으며 변이용으로만 사용합니다.

군체를 분석하면 능력치를 볼 수 있습니다. 분석하지 않아도 모든 기계에서 사용할 수 있지만, 어떤 군체를 남길지 결정할 때 분석 결과가 도움이 됩니다.

***

## <Color id="gold">2단계: 생산 라인 구축</Color>

**제작 순서:** Mutator → Bio Reactor → Incubator.

**1. 원하는 균주로 변이시키세요.** 작고 새로운 군체와 촉매를 Mutator에 넣습니다. 먼저 키우지 마세요. 큰 군체일수록 변이 확률이 조금 낮고, 결과 군체의 크기는 부모 크기와 관계없이 고유한 시작 크기로 정해집니다. 가능하면 Booster 슬롯에 Electrolyte Algae Serum Vial을 넣으세요. 성공 확률이 3배가 되고 실패해도 군체가 줄어들지 않으며, 성공할 때만 소모됩니다. 초반 변이는 대부분 15% 확률이므로 혈청 없이 약 7번, 사용하면 2~3번 시도해야 합니다.

**2. 생산을 시작하세요.** Bio Reactor에 군체를 넣고 영양분 슬롯에 해당 영양분을 공급합니다. JEI의 Colony Feeding 분류나 빈 영양분 슬롯에 커서를 올리면 필요한 먹이를 알 수 있습니다. 먹이를 공급받는 군체는 노화하지 않아 계속 넣어 둘 수 있습니다. 여러 금속 균주는 자신이 생산하는 아이템을 먹으므로 반응로의 출력으로 자체 공급할 수 있습니다.

**3. 필요하면 군체를 키우세요.** Incubator로 크기를 최대로 키우면 작은 군체보다 생산 속도가 최대 2배 빨라집니다. 유용한 장치이지만 새 군체도 먹이를 공급받는 반응로에서는 바로 생산하므로 생산 라인을 먼저 가동해도 됩니다. 노쇠(Senescent)한 군체를 회복시키는 용도로도 사용합니다.

새 군체는 느리지만 쓸모가 있습니다. 새 Ferrophiles 군체는 분당 철 주괴 약 24개를 생산하고 철 주괴 1개를 먹습니다.

**이 단계의 전력 공급:**

* Analyzer와 Mutator: 각각 Catalyst 1개.
* Incubator: 위아래에 Catalyst 각 1개.
* Bio Reactor: 해치마다 Catalyst 하나씩, 군체 1개에는 2개, 군체 2개에는 3개가 필요합니다. 군체 3개에는 50 AP가 필요하므로 Budding Prismarine을 각각 붙인 Catalyst 4개 또는 여러 Catalyst의 빔을 하나의 해치로 합치는 [Laser Junction](nautec:laser_chemistry/laser_manipulation.md)을 사용하세요.

***

## <Color id="gold">3단계: 생산 확장</Color>

**FE 전력으로 전환하세요.** [Energy Converter](nautec:laser_chemistry/energy_converter.md)는 10 FE를 1 AP로 변환하며 틱당 최대 150 AP를 출력합니다. 수신 장치가 일직선상에 있는 모든 면으로 발사하며 전력을 나누므로 Mutator와 Incubator 사이에 놓으면 둘 다 공급할 수 있습니다. 진행 단계별 추천 발전원은 다음과 같습니다.

| 발전기 | 틱당 FE | 변환기 출력 AP |
|---|---|---|
| Tidal Rotor | 40~80 | 각 4~8 |
| Lipophiles 기름을 사용하는 Combustion Dynamo | 320 | 32 |
| Thermal Vent Tap | 350~1,250 | 35~125 |

[해양 발전기](nautec:getting_started/ocean_generators.md)를 참고하세요.

**더 좋은 능력치를 육종하세요.** 군체 능력치는 Mutator에서만 변경됩니다. 균주를 유지하며 강화하려면 그 군체가 생산하는 아이템의 저장 블록(Ferrophiles는 Iron Block)을 촉매로 사용하세요. 이를 정제라고 하며 기본 성공 확률은 25%입니다. 균주는 유지되고 능력치가 조금씩 변합니다. 더 좋은 결과만 남겨 다시 정제하세요. 반응로용 군체는 Production Rate부터 높이는 것이 좋습니다. 각 능력치는 [Bacteria Stats](bacteria_stats.md)를 참고하세요.

**반응로를 업그레이드하세요.** [Reactor Upgrades](reactor_upgrades.md)는 Aquatic Chips, Deep Steel Plating, Resonant Shards, Flawless Prismarine Crystals로 만듭니다. AP당 생산량을 기준으로 Yield Upgrade가 Speed Upgrade보다 효율적입니다.

**오래된 군체를 발전에 활용하세요.** [Bacterial Fuel Cell](bacterial_fuel_cell.md)은 노쇠 여부와 관계없이 군체를 태워 최대 48 AP의 빔을 만듭니다. Mutation Resistance가 높은 군체일수록 순도가 높아집니다. 저항 0.8이면 순도 2.0입니다.

**군체를 분류해 보관하세요.** [Dish Storage](dish_storage.md)는 접시를 합치거나 섞지 않고 보관합니다.

**Mutator에 강한 빔을 공급하세요.** 40 AP를 공급하면 10 AP보다 분당 시도 횟수가 2배로 늘어납니다.

***

## <Color id="gold">4단계: 후반부</Color>

[Prismarine Crystal](nautec:getting_started/laser_power.md)의 순도 3.0 빔을 확보하면 높은 순도가 필요한 생물학 기계가 열립니다.

* **[Grafting Station](bacteria_grafting.md):** 도구나 생물군계 없이 매 주기 확정적으로 채취합니다. Grafting Anchor를 장착하면 블록 하나를 계속 사용할 수 있어 대량 군체를 얻기 좋습니다.
* **[Colony Replicator](colony_replicator.md):** 같은 균주의 군체나 그 균주가 생산하는 아이템을 생체 재료로 사용해 우수한 군체를 복제합니다. 좋은 군체 하나를 육종한 뒤 복제본으로 반응로를 채우세요. 정확한 복제를 원한다면 Mutation Resistance를 먼저 높이세요.
* **[Advanced Bacterial Analyzer](bacterial_analyzer.md):** 접시 9개를 한 번에 분석합니다.
* **[Industrial Bio Reactor](industrial_bio_reactor.md):** 군체 9개와 업그레이드 슬롯 4개를 제공합니다. 지붕 해치에 Energy Converter 여러 개를 연결해 공급하세요.

이 기계들은 모두 Dish Port가 있어 파이프로 접시를 연속 이송할 수 있습니다. 예를 들어 Grafting Station → Analyzer → Replicator → 반응로 순으로 연결합니다. 반응로가 가득 찼을 때 새 군체가 들어오면 가장 오래된 노쇠 군체와 교체하고, 기존 군체는 같은 접시에 담겨 나옵니다.

***

## <Color id="gold">흔히 하는 실수</Color>

* **반응로 전력 부족:** 작동하지 않고 진행도가 모두 초기화됩니다. 진행 화살표에 커서를 올려 공급 전력과 필요 전력을 비교하세요.
* **반응로 군체의 "!" 표시:** 영양분이 없거나 군체가 노쇠했습니다. 커서를 올려 원인을 확인하세요.
* **영양분 미공급:** 새 군체의 Lifespan은 45초~2분이며, 이후 노쇠해 크기가 줄어듭니다. 영양분 한 묶음만 넣어도 이를 방지할 수 있습니다.
* **영양분 종류가 슬롯보다 많음:** Bio Reactor는 최대 2종류, Industrial Bio Reactor는 최대 3종류의 영양분을 공급합니다. 같은 영양분을 먹는 균주끼리 배치하세요.
* **출력 슬롯이 가득 참:** 공간이 생길 때까지 해당 군체의 생산이 중단되므로 파이프로 출력을 빼내세요.
* **변이 전에 군체를 키움:** 변이 확률만 낮아지고 실패 시 잃는 군체의 양이 많아집니다.
* **기본 균주를 반응로에 넣음:** Cyanobacteria, Halobacteria, Methanogens, Thermophiles는 아무것도 생산하지 않습니다.
* **반응로 Dish Port에 빈 접시를 넣음:** 빈 접시는 군체를 꺼냅니다.
