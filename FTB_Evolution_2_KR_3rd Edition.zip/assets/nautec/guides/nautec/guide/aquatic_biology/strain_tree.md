---
navigation:
  title: Strain Tree
  icon: nautec:mutator
  position: 2
  parent: aquatic_biology/aquatic_biology-index.md
---

# <Color id="light_purple">Strain Tree</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="mutator" scale="2"/>
  어떤 균주가 어떤 균주로 변이하는지, 촉매와 성공 확률을 보여 줍니다.
</Column>

직접 채취하는 균주를 제외한 모든 균주는 [Mutator](mutator.md)에서 얻습니다. 아래 표의 각 행은 변이 하나를 나타냅니다. 부모 균주의 군체와 촉매를 Mutator에 넣으세요. 촉매는 소모되지 않습니다. 모드팩에 따라 제작법이 달라질 수 있으며 JEI의 Bacteria Mutations 분류에는 현재 변이 목록이, Strain Lineage 분류에는 채취 가능한 균주부터 목표 균주까지의 최단 경로가 표시됩니다. 원하는 균주의 Petri Dish 제작법을 조회하세요.

***

## <Color id="gold">변이에 걸리는 시간</Color>

10 AP 빔(시도당 12초)으로 새 군체를 변이시킬 때의 평균입니다.

| 확률 | 시도 횟수 | 소요 시간 | Booster 사용 시 |
|---|---|---|---|
| 75% | 1~2회 | 약 15초 | 1회 |
| 30% | 3~4회 | 약 40초 | 1~2회 |
| 15% | 약 7회 | 1.5분 미만 | 2~3회 |
| 9% | 약 11회 | 약 2분 | 약 4회 |
| 5% | 20회 | 4분 | 약 7회 |
| 3% | 33회 | 약 7분 | 약 11회 |

40 AP 빔을 사용하면 각 소요 시간이 절반으로 줄어듭니다. Booster 슬롯의 Electrolyte Algae Serum Vial은 성공 확률을 3배로 높이고 실패 시 군체 크기 감소를 막으며 성공할 때만 소모됩니다.

***

## <Color id="gold">시작 균주</Color>

| 균주 | 채취 블록 | 장소 |
|---|---|---|
| Thermophiles | Netherrack | 네더 |
| Lithophiles | <ItemLink id="budding_prismarine"/> | Prismarine Reef, Bioluminescent Grove, Abyssal Trench, Warm Ocean, Deep Lukewarm Ocean |
| Halobacteria | Sand | 모든 해변 |
| Cyanobacteria | Stone 또는 Bioluminescent Grove의 Glow Polyp | 모든 바다 |
| Methanogens | Podzol | 모든 숲 |

[Bacteria Grafting](bacteria_grafting.md)에는 첫 변이를 건너뛰는 심해 균주를 포함한 모든 채취 방법이 나옵니다.

***

## <Color id="gold">돌·광물·금속</Color>

가장 가치 있는 계통입니다. Budding Prismarine에서 Lithophiles를 직접 채취하면 첫 변이를 건너뜁니다. 철·레드스톤·청금석까지의 단계는 모두 15%, 금·다이아몬드·에메랄드는 5%입니다.

| 균주 | 생산물 | 부모 | 촉매 | 확률 |
|---|---|---|---|---|
| Lithophiles | Stone | Thermophiles | Stone | 15% |
| Calciophiles | Bone Meal | Lithophiles | Bone Meal | 15% |
| Silicophiles | Sand | Lithophiles | Sand | 15% |
| Carbophages | Coal | Lithophiles | Coal | 15% |
| Metallophiles | Copper Ingot | Carbophages | Copper Ingot | 15% |
| Ferrophiles | Iron Ingot | Metallophiles | Iron Ingot | 15% |
| Acidophiles | Redstone | Metallophiles | Redstone | 15% |
| Azuritophiles | Lapis Lazuli | Metallophiles | Lapis Lazuli | 15% |
| Sulfurophiles | Gunpowder | Acidophiles | Gunpowder | 15% |
| Aurrophiles | Gold Ingot | Ferrophiles | Gold Ingot | 5% |
| Adamantophiles | Diamond | Aurrophiles | Diamond | 5% |
| Smaragdophiles | Emerald | Adamantophiles | Emerald | 5% |
| Prismatophiles | 없음 | Smaragdophiles | Atlantic Gold Ingot | 5% |
| Prismatophiles (정제) | 없음 | Prismatophiles | Prismarine Crystal Shard | 25% |

Sulfurophiles는 Hydrothermal Vents의 Vent Tubeworm에서도 채취할 수 있습니다.

직접 채취한 Lithophiles에서 시작하는 최단 경로는 다음과 같습니다.

| 목표 | 경로 | 변이 횟수 |
|---|---|---|
| Coal | Lithophiles, Carbophages | 1 |
| Copper | 이후 Metallophiles | 2 |
| Iron, Redstone 또는 Lapis | 이후 Ferrophiles, Acidophiles 또는 Azuritophiles | 3 |
| Gold 또는 Gunpowder | 이후 Aurrophiles 또는 Sulfurophiles | 4 |
| Diamond | 이후 Adamantophiles | 5 |
| Emerald | 이후 Smaragdophiles | 6 |
| Prismatophiles | 이후 Prismatophiles | 7 |

Thermophiles부터 시작하면 한 단계가 더 필요합니다. 경로에 있는 촉매를 하나씩 준비해야 하지만 소모되지 않으므로 철 주괴 하나만 있으면 Ferrophiles를 계속 만들 수 있습니다.

Prismatophiles는 Bio Reactor에서 아무것도 생산하지 않습니다. [Bacterial Enrichment Catalyst](nautec:deep_engineering/bacterial_enrichment_catalyst.md)에 사용합니다.

***

## <Color id="gold">다른 모드의 재료</Color>

다른 모드의 금속·보석 균주는 모드팩에 해당 재료를 추가하는 모드가 있을 때만 존재합니다. 촉매는 항상 해당 재료의 주괴나 보석이며 부모 균주는 희귀도에 따라 달라집니다.

| 부모 | 확률 | 재료 |
|---|---|---|
| Lithophiles | 30% | aluminum, bauxite, brass, bronze, graphite, lead, pig iron, steel, tin, zinc, apatite |
| Metallophiles | 30% | silver, nickel, antimony, bismuth, boron, constantan, electrum, invar, rose gold, stainless steel, amethyst bronze 및 ruby, sapphire, peridot, topaz 등의 보석 |
| Ferrophiles | 5% | osmium, uranium, cobalt, titanium, tungsten 및 대부분의 중급 금속, certus quartz와 black quartz |
| Aurrophiles | 5% | platinum, iridium, palladium, enderium 및 기타 귀금속 |
| Adamantophiles | 3% | netherite, allthemodium, vibranium, unobtainium 및 기타 최상급 금속 |

모든 재료와 Strain Yield 목록은 [생산 속도](production_rates.md)를 참고하세요.

***

## <Color id="gold">해양 식물과 기름</Color>

| 균주 | 생산물 | 부모 | 촉매 | 확률 |
|---|---|---|---|---|
| Halotrophs | Kelp | Halobacteria | Kelp | 75% |
| Algaeformers | Seagrass | Halobacteria | Seagrass | 75% |
| Lipophiles | Algal Lipid | Halotrophs | Kelp Slurry | 30% |
| Phototrophs | Sugar Cane | Halotrophs | Sugar Cane | 15% |
| Phototrophs | Sugar Cane | Cyanobacteria | Sugar Cane | 30% |
| Cryobionts | Ice | Algaeformers | Blue Ice | 15% |

Lipophiles는 [Combustion Dynamo](nautec:getting_started/combustion_dynamo.md)의 기름으로 바뀌는 지질을 생산합니다. 자체 전력을 충당하는 첫 단계가 됩니다.

***

## <Color id="gold">작물</Color>

| 균주 | 생산물 | 부모 | 촉매 | 확률 |
|---|---|---|---|---|
| Cactophyles | Cactus | Phototrophs | Cactus | 30% |
| Rhizobacteria | Wheat | Phototrophs | Wheat | 15% |
| Bamboophages | Bamboo | Rhizobacteria | Bamboo | 30% |
| Beta Phylobacteria | Beetroot | Rhizobacteria | Beetroot | 30% |
| Carotophyles | Carrot | Rhizobacteria | Carrot | 30% |
| Solanophiles | Potato | Rhizobacteria | Potato | 30% |
| Cucurbitophiles | Pumpkin | Rhizobacteria | Pumpkin | 30% |
| Melophages | Melon Slice | Cucurbitophiles | Melon Slice | 30% |
| Bryophytophiles | Moss Block | Rhizobacteria | Moss Block | 15% |

***

## <Color id="gold">나무·균류·고기</Color>

| 균주 | 생산물 | 부모 | 촉매 | 확률 |
|---|---|---|---|---|
| Lignocytes | Oak Log | Methanogens | Oak Log | 15% |
| Betulophiles, Boreophiles, Acaciophyles, Junglophiles, Dark Lignocytes, Prunus Lignocytes, Rhizophora Lignocytes | Birch, Spruce, Acacia, Jungle, Dark Oak, Cherry, Mangrove Logs | Lignocytes | 해당 원목 | 15% |
| Crimson Lignocytes, Warped Lignocytes | Crimson, Warped Stems | Lignocytes | 해당 줄기 | 9% |
| Cocoaphiles | Cocoa Beans | Junglophiles | Cocoa Beans | 30% |
| Carnivorous Bacteria | Rotten Flesh | Methanogens | Rotten Flesh | 15% |
| Brown Mycotrophic Bacteria | Brown Mushroom | Methanogens | Brown Mushroom Block | 60% |
| Red Mycotrophic Bacteria | Red Mushroom | Methanogens | Red Mushroom Block | 60% |
| Crimson Microbes, Warped Microbes | Crimson, Warped Fungus | Mycotrophic 균주 중 하나 | 해당 균류 | 9% |

***

## <Color id="gold">정제</Color>

아이템을 생산하는 모든 균주는 자기 자신으로 변이할 수도 있습니다. 해당 아이템의 저장 블록(Ferrophiles는 Iron Block, Rhizobacteria는 Hay Bale)을 촉매로 사용하고 저장 블록이 없다면 아이템 자체를 사용하세요. 정제의 기본 성공 확률은 25%이며 균주와 크기를 유지한 채 능력치를 조금 변경합니다. 이미 보유한 균주를 더 우수하게 육종하는 방법입니다. [Mutator](mutator.md)를 참고하세요.
