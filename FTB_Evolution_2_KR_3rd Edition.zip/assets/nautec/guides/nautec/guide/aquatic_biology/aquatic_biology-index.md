---
navigation:
  title: 수생 생물학
  icon: nautec:petri_dish
  position: 3
---

# <Color id="gold">수생 생물학</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="petri_dish" scale="2"/>
  박테리아 군체를 접합·분석·배양·변이시키고, 이를 자원이나 동력으로 전환하는 방법을 설명합니다.
</Column>

***

<SubPages icons={true}/>
