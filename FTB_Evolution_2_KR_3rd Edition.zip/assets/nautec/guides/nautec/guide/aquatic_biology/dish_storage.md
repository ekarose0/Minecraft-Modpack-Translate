---
navigation:
  title: Dish Storage
  icon: nautec:aquarine_dish_storage
  position: 16
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:aquarine_dish_storage
  - nautec:deep_steel_dish_storage
  - nautec:atlantic_gold_dish_storage
---

# <Color id="light_purple">Dish Storage</Color>

<Row>
  <ItemImage id="aquarine_dish_storage" scale="2"/>
  <ItemImage id="deep_steel_dish_storage" scale="2"/>
  <ItemImage id="atlantic_gold_dish_storage" scale="2"/>
</Row>

Petri Dish를 보관하는 캐비닛입니다. 접시마다 독립된 슬롯을 사용하므로 균주, 군체 크기, 능력치가 서로 다른 배양 접시가 섞이지 않습니다.

| 블록 | 보관 가능한 접시 수 |
|---|---|
| Aquarine Dish Storage | 48 |
| Deep Steel Dish Storage | 96 |
| Atlantic Gold Dish Storage | 192 |

각 단계는 이전 단계의 보관함으로 제작하며, 비어 있거나 내용물이 있는 Petri Dish만 넣을 수 있습니다.

우클릭하면 보관함이 열립니다. 한 번에 48개의 접시가 표시되며, 마우스 휠을 굴리거나 오른쪽 스크롤바를 드래그하면 나머지를 볼 수 있습니다. 인벤토리의 접시를 Shift+클릭하면 화면에 보이지 않는 슬롯까지 포함하여 첫 번째 빈 슬롯에 들어갑니다. 모서리에는 현재 보관 중인 접시 수가 표시됩니다.

호퍼, 파이프 및 [Nautechnical Distributor](nautec:getting_started/distributor.md)를 사용하면 모든 면에서 접시를 넣거나 꺼낼 수 있습니다. 옆에 설치한 비교기는 보관함이 얼마나 찼는지에 따라 신호를 출력합니다.

블록을 부수면 보관 중이던 모든 접시가 떨어집니다.

<RecipeFor id="aquarine_dish_storage"/>

<RecipeFor id="deep_steel_dish_storage"/>

<RecipeFor id="atlantic_gold_dish_storage"/>
