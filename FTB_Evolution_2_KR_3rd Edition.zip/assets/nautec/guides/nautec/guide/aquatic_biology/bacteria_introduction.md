---
navigation:
  title: Bacteria Introduction
  icon: nautec:petri_dish
  position: 0
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:petri_dish
---
# <Color id="light_purple">박테리아 소개</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="petri_dish" scale="2"/>
  박테리아 군체는 레이저 에너지를 꾸준한 아이템 생산이나 자체 광선으로 바꿉니다.
</Column>

군체마다 균주, 크기, 네 가지 능력치가 있습니다. 능력치는 성장 속도, 생산 성능, 활동 가능한 시간을 결정합니다. 군체는 Petri Dish에 담아 운반하고 생물학 기계 사이에서 옮길 수 있습니다.

***

## <Color id="gold">기본 진행 순서</Color>

* Grafting Tool로 빈 Petri Dish에 첫 군체를 [채취](bacteria_grafting.md)합니다.
* 접시를 [분석](bacterial_analyzer.md)해 크기와 능력치를 확인합니다.
* 원하는 균주가 되도록 [변이](mutator.md)시킵니다. 돌, 모래, 회백토, 네더랙에서 채취하는 균주는 변이의 출발점으로만 사용합니다.
* [배양](incubator.md)하여 크기를 키우고 활력(Vitality)을 회복합니다.
* [Bio Reactor](bio_reactor.md)에서 아이템을 생산합니다. 군체가 노화하지 않도록 영양분을 함께 넣거나, [Bacterial Fuel Cell](bacterial_fuel_cell.md)에 넣어 광선을 생산합니다.

[박테리아 능력치](bacteria_stats.md)에서는 각 수치의 의미를 설명합니다. [박테리아 진행 과정](bacteria_progression.md)에서는 첫 군체부터 완성된 반응로까지 필요한 에너지를 단계별로 안내합니다. [균주 계통도](strain_tree.md)에서는 균주 간 변이 경로를 확인할 수 있습니다.

***

## <Color id="gold">Petri Dish</Color>

<RecipeFor id="petri_dish"/>

Petri Dish에는 군체 하나만 들어가며 중첩되지 않습니다. 빈 접시의 박테리아 이름에는 "Empty"가 표시되고, 분석하지 않은 군체의 능력치는 "???"로 표시됩니다.

접시에 들어간 군체는 활동이 정지되므로 성장하거나 노화하지 않습니다.

***

## <Color id="gold">군체 옮기기</Color>

Incubator, Mutator, Bio Reactor 화면에는 박테리아 슬롯이 있습니다. Petri Dish를 커서에 든 상태에서 박테리아 슬롯을 클릭하세요.

* 빈 접시로 클릭하면 슬롯의 군체를 전부 꺼냅니다.
* 군체가 든 접시로 빈 슬롯을 클릭하면 군체를 넣습니다.
* 슬롯의 군체와 균주 및 모든 능력치가 정확히 같은 군체를 든 접시로 클릭하면 슬롯의 군체를 가져와 합칩니다.

군체 두 개는 균주와 모든 능력치가 정확히 일치할 때만 합쳐집니다. 실제로는 하나의 군체를 둘로 나눈 경우에 해당합니다. 합친 군체에는 두 군체 중 더 오래된 나이가 적용됩니다. 크기는 상한(기본 40,000, 설정 가능)을 넘을 수 없으며, 초과분은 원래 위치에 남습니다.

Bacterial Analyzer는 접시 자체를 아이템 슬롯에 넣습니다. Bacterial Fuel Cell은 접시를 든 채 우클릭하거나 파이프로 접시를 공급합니다. Incubator, Mutator, Colony Replicator 및 두 종류의 Bio Reactor에는 Dish Port도 있습니다. 군체가 든 접시는 투입되고, 군체와 빈 접시는 각각 별도 슬롯으로 배출됩니다.

***

## <Color id="gold">JEI</Color>

JEI에는 각 단계별 항목이 있습니다. Bacteria Grafting에는 균주별 채취 위치, Bacteria Mutations에는 촉매와 확률, Strain Lineage에는 채취 가능한 균주에서 목표 균주까지의 최단 변이 경로가 나옵니다. Bacteria Incubation에는 영양분·성장 범위·소모 확률, Colony Feeding에는 반응로에서 노화를 막는 영양분, Bio Reactor에는 균주별 생산품·Strain Yield·초기 Production Rate 범위·새 군체의 분당 생산량이 표시됩니다. 균주별 자세한 정보는 JEI를 확인하세요.

다른 모드의 금속이나 보석을 생산하는 균주는 모드팩에 해당 재료를 추가하는 모드가 있을 때만 등장합니다.
