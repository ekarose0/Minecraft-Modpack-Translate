---
navigation:
  title: Reactor Upgrades
  icon: nautec:reactor_speed_upgrade
  position: 11
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:reactor_speed_upgrade
  - nautec:reactor_yield_upgrade
  - nautec:reactor_efficiency_upgrade
  - nautec:reactor_fusion_upgrade
---
# <Color id="light_purple">Reactor 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reactor_speed_upgrade" scale="2"/>
  업그레이드로 더 많이 생산하거나 영양분 소비를 줄일 수 있지만, 필요한 에너지가 증가합니다.
</Column>

[Bio Reactor](bio_reactor.md)에는 업그레이드 슬롯이 2개, [Industrial Bio Reactor](industrial_bio_reactor.md)에는 4개 있습니다. 슬롯마다 업그레이드를 하나씩 넣으며 종류를 자유롭게 섞을 수 있습니다. 같은 종류를 두 개 넣으면 효과도 두 번 적용됩니다. 업그레이드는 반응로 안의 모든 군체에 영향을 줍니다. 호퍼와 파이프로도 업그레이드를 넣을 수 있지만 업그레이드 슬롯에만 들어갑니다.

업그레이드 툴팁에서는 현재 설정값 기준 효과와 에너지 배율을 볼 수 있습니다.

***

## <Color id="gold">업그레이드 종류</Color>

<Row>
  <ItemImage id="reactor_speed_upgrade"/>
  ### <Color id="aqua">Reactor Speed Upgrade</Color>
</Row>

한 개마다 생산 속도가 50%씩 추가됩니다. 한 개는 1.5배, 두 개는 2배, 네 개는 3배입니다. 에너지 요구량에는 1.6배를 곱합니다.

<Row>
  <ItemImage id="reactor_yield_upgrade"/>
  ### <Color id="aqua">Reactor Yield Upgrade</Color>
</Row>

완료되는 주기마다 아이템을 하나 추가합니다. 한 개는 주기당 2개, 두 개는 3개, 네 개는 5개를 생산합니다. 에너지 요구량은 1.8배입니다. 주기를 완료하려면 출력 슬롯에 생산품 전체를 담을 공간이 있어야 합니다.

<Row>
  <ItemImage id="reactor_efficiency_upgrade"/>
  ### <Color id="aqua">Reactor Efficiency Upgrade</Color>
</Row>

업그레이드 한 개마다 각 군체의 틱당 [영양분 버퍼](colony_feeding.md) 소비를 25%씩 줄이며, 감소 배율은 서로 곱해집니다. 한 개는 기존의 75%, 두 개는 56%, 세 개는 42%, 네 개는 32%만 소비합니다. 영양분 한 개가 1,200틱 유지된다면 한 개 장착 시 80초, 두 개면 107초, 네 개면 190초 동안 작업할 수 있습니다. 최소 소비량은 25%(설정 가능)이며 기본 수치로 네 개를 장착해도 그 하한에는 도달하지 않습니다. 에너지 요구량은 1.2배입니다. 아이템 생산 속도에는 영향이 없습니다.

Speed 및 Yield Upgrade도 생산 아이템 하나당 영양분 소비를 줄입니다. 영양분은 아이템마다가 아니라 작업하는 틱마다 소모되기 때문입니다. AP 대비 생산량으로 보면 Yield Upgrade(아이템 2배, 에너지 1.8배)가 Speed Upgrade(아이템 1.5배, 에너지 1.6배)보다 유리합니다.

<Row>
  <ItemImage id="reactor_fusion_upgrade"/>
  ### <Color id="aqua">Reactor Fusion Upgrade</Color>
</Row>

다른 세 종류를 하나씩 조합해 만듭니다. 슬롯 하나에서 Speed·Yield·Efficiency Upgrade를 각각 한 개 장착한 효과를 내며, 일반 업그레이드 및 다른 Fusion Upgrade와 중첩됩니다. 에너지 요구량은 2.5배로, 세 개를 따로 장착했을 때의 3.46배보다 적습니다.

업그레이드 슬롯이 모두 찬 반응로에서 특히 유용합니다. Industrial Bio Reactor에 Fusion Upgrade 네 개를 넣으면 속도 3배, 주기당 5개 생산, 영양분 소비 32%가 되며 에너지 요구량은 기본의 약 39배입니다.

***

## <Color id="gold">에너지 계산식</Color>

필요 AP = (기본값 + 군체 하나당 요구량 × 군체가 들어간 슬롯 수) × Speed Upgrade 개수만큼 1.6배 × Yield Upgrade 개수만큼 1.8배 × Efficiency Upgrade 개수만큼 1.2배 × Fusion Upgrade 개수만큼 2.5배. 결과는 올림 처리합니다.

업그레이드마다 전체 요구량에 다시 배율을 곱하므로 비용이 빠르게 증가합니다. 기본값과 군체당 값은 [생산 속도](production_rates.md) 페이지에서 확인할 수 있습니다.

군체 3개가 든 Bio Reactor:

| 업그레이드 | 필요 AP |
|---|---|
| 없음 | 50 |
| Speed 1개 | 80 |
| Speed 2개 | 128 |
| Yield 1개 | 90 |
| Yield 2개 | 162 |
| Speed 1개, Yield 1개 | 144 |
| Yield 1개, Efficiency 1개 | 108 |
| Efficiency 2개 | 72 |
| Fusion 1개 | 125 |
| Fusion 1개, Yield 1개 | 225 |
| Fusion 2개 | 313 |

군체 9개가 든 Industrial Bio Reactor:

| 업그레이드 | 필요 AP |
|---|---|
| 없음 | 550 |
| Efficiency 4개 | 1,141 |
| Yield 2개, Efficiency 2개 | 2,567 |
| Speed 4개 | 3,605 |
| Speed 2개, Yield 2개 | 4,562 |
| Yield 4개 | 5,774 |
| Fusion 1개 | 1,375 |
| Fusion 2개 | 3,438 |
| Fusion 2개, Yield 2개 | 11,138 |
| Fusion 4개 | 21,485 |

이 페이지의 모든 보너스와 배율은 설정에서 조정할 수 있습니다.

***

## <Color id="gold">제작법</Color>

재료는 [심해 재료](nautec:deep_engineering/materials.md) 페이지에 나와 있습니다.

***

## <Color id="gold">강한 광선의 효과</Color>

반응로에 필요한 것보다 강한 광선을 공급하면 Speed Upgrade에 따른 속도 증가에 추가 배율이 적용되며 둘은 곱해집니다. 에너지 요구량을 늘리는 업그레이드를 장착할수록 속도 증가가 시작되는 광선 출력 기준도 높아지므로, 광선에 따른 속도는 항상 업그레이드된 반응로의 필요 출력을 기준으로 계산합니다.

공식과 적용 기계 목록은 [강한 광선](nautec:getting_started/stronger_beams.md)을 확인하세요.

<RecipeFor id="reactor_speed_upgrade"/>

<RecipeFor id="reactor_yield_upgrade"/>

<RecipeFor id="reactor_efficiency_upgrade"/>

<RecipeFor id="reactor_fusion_upgrade"/>
