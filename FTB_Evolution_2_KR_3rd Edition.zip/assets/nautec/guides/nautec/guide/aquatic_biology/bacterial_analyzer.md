---
navigation:
  title: Bacterial Analyzer
  icon: nautec:bacterial_analyzer
  position: 4
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:bacterial_analyzer
  - nautec:advanced_bacterial_analyzer
---
# <Color id="light_purple">Bacterial Analyzer</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="bacterial_analyzer" scale="2"/>
  Bacterial Analyzer는 군체의 크기, 활력(Vitality), 능력치를 밝혀냅니다.
</Column>

분석하지 않은 군체가 들어 있는 <ItemLink id="petri_dish"/>를 왼쪽 슬롯에 넣으세요. 3초 뒤 분석이 완료된 접시가 오른쪽 슬롯으로 이동합니다. 오른쪽 슬롯을 비워야 다음 접시를 분석할 수 있습니다. 왼쪽 슬롯은 미분석 군체가 든 접시만 받으므로 파이프로 빈 접시나 이미 분석한 접시가 들어와 막히는 일은 없습니다.

모든 기계는 분석하지 않은 군체도 사용할 수 있습니다. 분석은 단지 수치를 확인하기 위한 절차이지만 변이·성장·연소할 군체를 고르려면 중요합니다. [Mutator](mutator.md)에서 나온 군체는 다시 미분석 상태가 됩니다.

***

## <Color id="gold">설치</Color>

Analyzer는 높이가 2블록이므로 설치하려는 위치 위에 빈 공간이 하나 필요합니다. 위아래 어느 쪽을 우클릭해도 화면이 열립니다.

아래쪽 면에 최소 5 AP의 광선을 넣어야 합니다. 이는 소모량이 아니라 작동 기준입니다. 5 AP 미만이면 일시 정지하고 5 AP면 기본 속도, 더 강하면 속도가 빨라집니다(아래 참고).

시간(60틱)과 요구 출력(5 AP)은 설정에서 변경할 수 있습니다.

호퍼와 파이프로 아래쪽 블록에 접시를 넣거나 분석된 접시를 꺼낼 수 있으며, 기본적으로 모든 면을 사용할 수 있습니다. [면 설정](nautec:getting_started/utilities.md)에서 면별 허용 작업을 바꿀 수 있습니다.

***

## <Color id="gold">분석된 접시 읽기</Color>

툴팁에는 크기, 활력, 생산하는 균주의 경우 Strain Yield가 표시됩니다. Shift를 누르면 생산 아이템과 네 가지 능력치를 볼 수 있습니다. Shift와 Control을 함께 누르면 다음 변이 때 각 능력치가 변할 수 있는 범위도 표시됩니다. Shift 화면에는 반응로에서 먹는 영양분, Incubator의 성장 재료, 변이 가능한 균주와 촉매·확률도 나옵니다. 빨간색 능력치는 상한에 도달한 값입니다. 각 수치의 의미는 [박테리아 능력치](bacteria_stats.md)를 참고하세요.

***

## <Color id="gold">제작법</Color>

<Recipe id="nautec:bacterial_analyzer"/>

***

## <Color id="gold">Advanced Bacterial Analyzer</Color>

<Row>
  <ItemImage id="advanced_bacterial_analyzer" scale="2"/>
</Row>

접시 아홉 개를 동시에 분석합니다. 입력 슬롯 9개와 출력 슬롯 9개가 있으며 각 입력 접시는 독립적으로 60틱의 분석이 진행되므로, 한 번에 아홉 개를 넣어도 기본 Analyzer의 접시 한 개와 같은 시간에 모두 끝납니다. 각 입력 슬롯의 진행 막대는 아래에서부터 차오릅니다.

* 에너지: 전면을 제외한 모든 면에 순도 2.1 이상, 출력 40 AP 이상의 광선이 필요합니다. 둘 중 하나라도 부족하면 진행 상태를 보존한 채 멈춥니다. [Prismarine Crystal](nautec:getting_started/laser_power.md) 광선(순도 3.0)이나 최고 순도의 <ItemLink id="bacterial_fuel_cell"/>(2.5)로 순도 조건을 충족할 수 있습니다.
* 미분석 군체가 든 접시만 받으므로 파이프를 연결해도 완성된 접시나 빈 접시 때문에 막히지 않습니다.
* 출력 슬롯 아홉 개가 가득 차면 완성된 접시는 빈 출력 슬롯이 생길 때까지 입력 슬롯에서 대기합니다.

화살표에 마우스를 올리면 무엇을 기다리는지 확인할 수 있으며 <ItemLink id="prism_monocle"/>로 들여다볼 수도 있습니다. 호퍼와 파이프는 기본적으로 모든 면에서 넣기와 빼기가 가능합니다([면 설정](nautec:getting_started/utilities.md)). 작업 시간·출력·순도는 `config/nautec-common.toml`에서 설정합니다.

<Recipe id="nautec:advanced_bacterial_analyzer"/>

***

## <Color id="gold">강한 광선의 효과</Color>

두 Analyzer 모두 필요한 것보다 강한 광선을 받으면 빨라집니다. 속도 배율은 √(공급 출력 ÷ 필요 출력)입니다. 기본 Bacterial Analyzer는 5 AP가 필요하므로 20 AP면 두 배 빨라집니다. Advanced Bacterial Analyzer는 순도 2.1에서 40 AP가 필요하므로 같은 순도의 160 AP로 접시 아홉 개를 모두 두 배 빨리 분석합니다. 순도 자체는 속도를 높이지 않습니다.

| 필요 출력 대비 공급 배율 | 속도 |
|---|---|
| 1× | ×1 (기본) |
| 4× | ×2 |
| 9× | ×3 |
| 16× | ×4 |

기본 Bacterial Analyzer의 접시당 3초는 5 AP를 기준으로 합니다.

이 공식과 적용되는 전체 기계 목록은 [강한 광선](nautec:getting_started/stronger_beams.md)을 참고하세요.
