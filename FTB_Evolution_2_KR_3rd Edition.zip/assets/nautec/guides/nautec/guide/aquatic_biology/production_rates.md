---
navigation:
  title: Production Rates
  icon: minecraft:clock
  position: 10
  parent: aquatic_biology/aquatic_biology-index.md
---

# <Color id="light_purple">Production Rates</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="minecraft:clock" scale="2"/>
  군체가 반응로에서 아이템을 생산하는 속도와 필요한 전력량을 설명합니다.
</Column>

여기에 나온 수치는 [Bio Reactor](bio_reactor.md)와 [Industrial Bio Reactor](industrial_bio_reactor.md)에 모두 적용됩니다. Industrial Bio Reactor는 군체 하나의 생산 속도가 더 빠른 것이 아니라, 업그레이드를 더 많이 장착하고 더 많은 군체를 동시에 가동할 수 있습니다.

***

## <Color id="gold">계산 공식</Color>

가동 중인 군체는 매 틱 다음 공식에 따라 진행도를 쌓습니다.

틱당 진행도 = Production Rate × 크기 계수 × 기본 속도 × Strain Yield × 속도 보너스

* Production Rate는 군체의 능력치이며 최대 2입니다([박테리아 능력치](bacteria_stats.md)).
* 크기 계수는 0.5 + 0.5 × 크기 / 40,000입니다. 아주 작은 군체는 0.5, 크기 상한에 도달한 군체는 1입니다.
* 기본 속도는 두 반응로 모두 16.8이며 각각 설정할 수 있습니다.
* Strain Yield는 균주별 고유 값입니다. 아래 표를 참고하세요.
* 속도 보너스는 기본 1이며 [Reactor Speed Upgrade](reactor_upgrades.md) 하나당 0.5씩 증가합니다.

진행도 100마다 한 주기가 완료되어 군체의 출력 슬롯에 아이템 1개가 들어갑니다. Reactor Yield Upgrade 하나당 주기별 생산량이 1개씩 늘어납니다. 남은 진행도는 다음 주기로 이월됩니다. 1분은 1,200틱이므로 다음과 같습니다.

분당 생산량 = 틱당 진행도 × 12 × 주기당 아이템 수

***

## <Color id="gold">Strain Yield</Color>

모든 균주는 기본적으로 Production Rate를 최대 2.0까지 육종할 수 있습니다. Strain Yield는 그 값에 나중에 곱해지며 능력치 상한을 낮추지 않습니다. 가장 좋은 원본 군체를 잃지 않고 능력치를 높이려면 [Mutator의 능력치 육종 절차](mutator.md#stat-breeding)를 따르세요.

| Strain Yield | NauTec 균주 | 다른 모드의 재료 |
|---|---|---|
| 1 | Lithophiles (stone), Silicophiles (sand), Calciophiles (bone meal), Cryobionts (ice), Carnivorous Bacteria (rotten flesh), 모든 나무·식물·작물·균류·버섯 균주 | aluminum, bauxite, brass, bronze, graphite, lead, pig iron, steel, tin, zinc 주괴; apatite |
| 0.8 | Carbophages (coal), Metallophiles (copper ingots), Sulfurophiles (gunpowder) | silver, nickel, antimony, bismuth, boron, constantan, electrum, invar, rose gold, stainless steel, amethyst bronze 주괴; amber, fluorite, jade, peridot, ruby, sapphire, topaz |
| 0.6 | Ferrophiles (iron ingots) | osmium, uranium, cobalt, titanium, tungsten, chromium, manganese, molybdenum, neodymium, niobium, thorium, vanadium, beryllium, monazite, cyanite, desh, hepatizon, iesnium, knightslime, slimesteel, lumium, signalum, manasteel, refined glowstone, refined obsidian 주괴; certus quartz, black quartz, cinnabar, dark gem, moonstone, sunstone |
| 0.5 | Acidophiles (redstone), Azuritophiles (lapis lazuli) | |
| 0.4 | Aurrophiles (gold ingots) | platinum, iridium, palladium, enderium, elementium, manyullyn, queen's slime, blutonium, calorite, draconium and ostrum ingots |
| 0.12 | Adamantophiles (diamonds) | netherite, allthemodium, vibranium, unobtainium, neutronium, plutonium and terrasteel ingots |
| 0.1 | Smaragdophiles (emeralds) | |

다른 모드의 재료를 생산하는 균주는 해당 재료를 사용하는 모드가 모드팩에 있을 때만 존재합니다. 여러 모드가 같은 재료를 추가했다면 반응로는 `config/nautec-common.toml`의 `preferredTagNamespaces`에 먼저 나열된 모드(기본값 `minecraft`)의 아이템을 생산합니다. 해당 목록으로 결정할 수 없으면 아이템 ID를 알파벳순으로 정해 가장 앞선 것을 사용합니다. Cyanobacteria, Halobacteria, Methanogens, Prismatophiles, Thermophiles는 아무것도 생산하지 않으므로 Strain Yield가 의미 없습니다.

JEI의 Bio Reactor 분류와 분석된 Petri Dish의 툴팁에서 균주의 Strain Yield를 확인할 수 있습니다. 모드팩 제작자는 균주 JSON의 선택 항목인 `production_multiplier`로 값을 설정할 수 있으며 기본값은 1입니다.

***

## <Color id="gold">계산 예시</Color>

업그레이드가 없고 능력치 상한(Production Rate 2, 크기 40,000)에 도달한 군체의 생산량입니다.

| Strain Yield | 틱당 진행도 | 아이템 1개당 시간 | 분당 생산량 |
|---|---|---|---|
| 1 (stone) | 33.6 | 0.15초 | 약 403개 |
| 0.8 (coal, copper) | 26.9 | 0.19초 | 약 323개 |
| 0.6 (iron) | 20.2 | 0.25초 | 약 242개 |
| 0.5 (redstone, lapis) | 16.8 | 0.3초 | 약 202개 |
| 0.4 (gold) | 13.4 | 0.37초 | 약 161개 |
| 0.12 (diamond) | 4.03 | 1.2초 | 약 48개 |
| 0.1 (emerald) | 3.36 | 1.5초 | 약 40개 |

막 채취한 군체는 훨씬 느립니다. 크기 400, Production Rate 0.4인 Ferrophiles는 0.4 × 0.505 × 16.8 × 0.6 = 틱당 진행도 2.04를 얻습니다. 철 주괴 하나를 약 2.5초마다, 분당 약 24개 생산하는 셈입니다.

업그레이드는 생산량을 배가합니다. 상한에 도달한 다이아몬드 군체는 Reactor Speed Upgrade 2개로 분당 약 97개, Reactor Yield Upgrade 2개로 약 145개를 생산합니다. 후자의 경우 한 주기에 3개가 나오기 때문입니다.

상한에 도달한 돌 생산 군체는 약 10초 만에 64개짜리 출력 슬롯을 가득 채웁니다. 슬롯이 가득 차면 해당 군체가 멈추므로 출력을 계속 빼내세요.

***

## <Color id="gold">필요 전력</Color>

전력은 작동을 위한 최소 기준입니다. 매 틱 필요한 AP가 공급되지 않으면 반응로는 작동하지 않고 모든 진행도가 초기화됩니다. 기준보다 강한 빔은 생산 속도를 높입니다. [강한 빔](nautec:getting_started/stronger_beams.md)을 참고하세요.

필요 AP = (기본값 + 군체당 소비량 × 채워진 군체 슬롯 수) × 업그레이드 배율, 올림 처리

| 반응로 | 기본값 | 군체당 | 모든 슬롯 사용, 업그레이드 없음 |
|---|---|---|---|
| Bio Reactor | 5 | 15 | 군체 3개에 50 AP |
| Industrial Bio Reactor | 100 | 50 | 군체 9개에 550 AP |

이 네 값은 모두 설정할 수 있습니다. 빈 군체 슬롯은 계산에 포함되지 않습니다. 업그레이드 배율과 일반적인 업그레이드 조합의 소비 전력은 [Reactor Upgrades](reactor_upgrades.md)를 참고하세요.
