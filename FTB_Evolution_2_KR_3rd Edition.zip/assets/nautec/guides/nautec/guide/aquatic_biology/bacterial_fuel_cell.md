---
navigation:
  title: Bacterial Fuel Cell
  icon: nautec:bacterial_fuel_cell
  position: 13
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:bacterial_fuel_cell
---

# <Color id="light_purple">Bacterial Fuel Cell</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="bacterial_fuel_cell" scale="2"/>
  Bacterial Fuel Cell은 박테리아 군체를 연료로 사용하여 레이저 빔을 발사합니다.
</Column>

<ItemLink id="petri_dish"/>를 들고 Fuel Cell을 우클릭하면 군체를 투입합니다. 빈 접시를 들고 우클릭하면 남은 군체를 회수합니다. 새 군체는 기존 군체와 균주와 능력치가 완전히 같을 때만 합쳐집니다.

호퍼와 파이프로도 공급할 수 있습니다. 군체가 담긴 접시는 어느 면으로든 투입되며, Fuel Cell이 비어 있거나 같은 군체를 추가할 공간이 있으면 즉시 투입됩니다. 빈 접시는 다시 추출할 수 있습니다. 빈 접시나 아직 투입할 수 없는 군체는 받지 않으므로 뒤쪽에 접시가 담긴 상자를 연결하면 군체를 하나씩 연속으로 연소시킬 수 있습니다. Fuel Cell에는 별도 화면이 없으므로 렌치로 [Side Configuration](nautec:getting_started/utilities.md)을 설정합니다.

분석 여부와 관계없이 모든 군체를 사용할 수 있으며, [Bio Reactor](bio_reactor.md)에서 아무것도 생산하지 못하는 균주도 연료로 사용할 수 있습니다.

***

## <Color id="gold">설치하기</Color>

설치할 때 바라본 면의 반대쪽에서 빔이 발사되므로 플레이어와 반대 방향으로 나갑니다. 좌우뿐 아니라 위나 아래로도 발사할 수 있습니다.

발사 방향의 16블록 이내에 빔을 받을 수 있는 블록이 있을 때만 발사하고 군체를 소모합니다. 빔을 받을 대상이 없으면 군체는 그대로 유지됩니다.

***

## <Color id="gold">출력</Color>

| 능력치 | 효과 |
|---|---|
| Production Rate | 1당 24 AP 출력(상한 2에서는 48 AP). 또한 매 틱 Production Rate 1당 군체 크기 0.5를 소모합니다. |
| Mutation Resistance | 저항력이 최대이면 순도 2.5이며 저항력이 0이면 순도도 0입니다. |
| Size | 연료 지속시간을 결정합니다. |

출력과 소모 속도가 함께 증가하므로 군체 크기 1당 얻는 총에너지는 같습니다. 생산 속도가 높은 군체는 더 빨리 소모할 뿐입니다. 크기 40,000의 군체는 Production Rate 1에서 약 67분간 24 AP를, Production Rate 2에서 약 33분간 48 AP를 공급합니다.

NauTec의 대부분의 [Item Transformation](nautec:getting_started/item_transformation.md) 제작법은 순도 2.0 이하를 요구하며, 군체의 Mutation Resistance가 0.8이면 충족합니다. 따라서 Prismarine Crystal 코어 없이도 작동할 수 있습니다. Cast Iron Block에서 Gear를 만드는 제작법은 순도 2.5가 필요하므로 저항력이 최대인 군체만 사용할 수 있습니다.

기본 출력(24), 소모 속도(0.5), 최대 순도(2.5)는 모두 설정에서 변경할 수 있습니다.

***

## <Color id="gold">물질과 에너지 중 선택</Color>

Fuel Cell에서는 군체가 노화하지 않으므로 Vitality가 중요하지 않습니다. 노쇠한 군체도 신선한 군체와 똑같이 연소합니다. 따라서 더 이상 먹이를 줄 가치가 없는 오래된 군체를 활용하기에 좋습니다. Bio Reactor도 같은 군체를 활용하므로 군체마다 아이템 생산과 동력 생산 중 선택해야 합니다.

***

## <Color id="gold">제작법</Color>

<Recipe id="nautec:bacterial_fuel_cell"/>
