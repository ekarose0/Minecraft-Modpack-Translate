---
navigation:
  title: Industrial Bio Reactor
  icon: nautec:industrial_bio_reactor
  position: 12
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:industrial_bio_reactor
---

# <Color id="light_purple">Industrial Bio Reactor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="industrial_bio_reactor" scale="2"/>
  가로 5 × 세로 5 × 높이 4 구조물로, 업그레이드 슬롯 4개와 군체 슬롯 9개를 제공합니다.
</Column>

기본 원리는 [Bio Reactor](bio_reactor.md)와 같습니다. [생산 공식](production_rates.md), 기본 속도, [먹이 공급](colony_feeding.md), 노화와 크기 감소, [업그레이드](reactor_upgrades.md) 방식이 동일합니다. 차이점은 군체 슬롯 9개, 출력 슬롯 9개, 영양분 슬롯 3개, 업그레이드 슬롯 4개로 용량이 커졌다는 것입니다.

***

## <Color id="gold">건설 방법</Color>

각 층은 5 × 5이며 총 4층입니다.

* 1층(바닥): 네 모서리에 Dark Prismarine Pillar, 나머지에는 Polished Prismarine을 배치합니다.
* 2~3층: 모서리에 Dark Prismarine Pillar, 가장자리에 Bacteria Containment Shield를 배치하고 중앙 3 × 3은 비워 둡니다. 2층의 벽 한쪽 중앙 Shield를 Industrial Bio Reactor로 교체합니다.
* 4층(지붕): 모서리에 Dark Prismarine Pillar, 나머지에는 Aquarine Steel Block을 배치합니다.

<GameScene zoom="3" background="#333333" interactive={true}>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="0" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="4" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="0" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="4" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="0" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="4" y="0" z="3"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="0" z="4"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="4"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="4"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="0" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="1" z="0"/>
  <Block id="nautec:industrial_bio_reactor" x="2" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="1" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="1" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="1" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="1" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="1" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="1" z="3"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="1" z="3"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="1" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="1" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="1" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="1" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="1" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="2" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="2" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="2" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="2" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="2" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="2" z="3"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="2" z="3"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="2" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="2" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="2" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="2" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="2" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="3" z="0"/>
  <Block id="nautec:aquarine_steel_block" x="1" y="3" z="0"/>
  <Block id="nautec:aquarine_steel_block" x="2" y="3" z="0"/>
  <Block id="nautec:aquarine_steel_block" x="3" y="3" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="3" z="0"/>
  <Block id="nautec:aquarine_steel_block" x="0" y="3" z="1"/>
  <Block id="nautec:aquarine_steel_block" x="1" y="3" z="1"/>
  <Block id="nautec:aquarine_steel_block" x="2" y="3" z="1"/>
  <Block id="nautec:aquarine_steel_block" x="3" y="3" z="1"/>
  <Block id="nautec:aquarine_steel_block" x="4" y="3" z="1"/>
  <Block id="nautec:aquarine_steel_block" x="0" y="3" z="2"/>
  <Block id="nautec:aquarine_steel_block" x="1" y="3" z="2"/>
  <Block id="nautec:aquarine_steel_block" x="2" y="3" z="2"/>
  <Block id="nautec:aquarine_steel_block" x="3" y="3" z="2"/>
  <Block id="nautec:aquarine_steel_block" x="4" y="3" z="2"/>
  <Block id="nautec:aquarine_steel_block" x="0" y="3" z="3"/>
  <Block id="nautec:aquarine_steel_block" x="1" y="3" z="3"/>
  <Block id="nautec:aquarine_steel_block" x="2" y="3" z="3"/>
  <Block id="nautec:aquarine_steel_block" x="3" y="3" z="3"/>
  <Block id="nautec:aquarine_steel_block" x="4" y="3" z="3"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="3" z="4"/>
  <Block id="nautec:aquarine_steel_block" x="1" y="3" z="4"/>
  <Block id="nautec:aquarine_steel_block" x="2" y="3" z="4"/>
  <Block id="nautec:aquarine_steel_block" x="3" y="3" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="3" z="4"/>
  <IsometricCamera yaw="225" pitch="30"/>
</GameScene>

Industrial Bio Reactor는 네 벽 가운데 원하는 벽의 중앙에 놓을 수 있습니다. 먼저 틀을 만든 뒤 자신이 바라보는 방향의 벽에 설치해도 됩니다. 그림에서는 북쪽 벽에 배치했습니다. 내부 3 × 3 × 2 공간은 물이나 다른 블록 없이 공기로 비워 두어야 합니다. 지붕을 덮기 전 모습은 다음과 같습니다.

<GameScene zoom="3" background="#333333" interactive={true}>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="0" z="0"/>
  <Block id="nautec:polished_prismarine" x="0" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="4" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="0" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="4" y="0" z="2"/>
  <Block id="nautec:polished_prismarine" x="0" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="3"/>
  <Block id="nautec:polished_prismarine" x="4" y="0" z="3"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="0" z="4"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="4"/>
  <Block id="nautec:polished_prismarine" x="2" y="0" z="4"/>
  <Block id="nautec:polished_prismarine" x="3" y="0" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="0" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="1" z="0"/>
  <Block id="nautec:industrial_bio_reactor" x="2" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="1" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="1" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="1" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="1" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="1" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="1" z="3"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="1" z="3"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="1" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="1" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="1" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="1" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="1" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="2" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="2" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="2" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="2" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="2" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="2" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="2" z="3"/>
  <Block id="nautec:bacterial_containment_shield" x="4" y="2" z="3"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="2" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="2" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="2" z="4"/>
  <Block id="nautec:bacterial_containment_shield" x="3" y="2" z="4"/>
  <Block id="nautec:dark_prismarine_pillar" x="4" y="2" z="4"/>
  <IsometricCamera yaw="225" pitch="30"/>
</GameScene>

웅크리지 않고 <ItemLink id="aquarine_steel_wrench"/>를 Rotate 모드로 설정해 Industrial Bio Reactor를 우클릭하면 구조물이 완성됩니다. 잘못된 블록이 있으면 채팅에 위치와 현재 블록, 필요한 블록이 표시됩니다. 완성된 구조물의 블록을 하나라도 부수면 해체됩니다.

완성 후 렌치를 들지 않은 상태에서 구조물의 아무 블록이나 우클릭하면 화면이 열립니다.

***

## <Color id="gold">전력</Color>

기본 100 AP에 채워진 군체 슬롯당 50 AP가 필요합니다. 업그레이드 적용 전 기준으로 군체 1개는 150 AP, 9개는 550 AP입니다. Bio Reactor와 마찬가지로 최소 작동 기준이므로 부족하면 모든 작업이 멈추고 진행도가 초기화됩니다. 더 강한 빔은 반응로를 가속합니다(아래 강한 빔 참고).

전력은 지붕의 해치로 공급합니다. 완성된 지붕의 Aquarine Steel Block을 렌치로 우클릭하면 해치로 바뀌고 다시 클릭하면 원래대로 돌아옵니다. 반응로 면을 설정하는 Item Sides 모드에서는 작동하지 않습니다. 해치는 위에서 아래로 들어오는 빔을 받으며, 지붕 가장자리의 해치는 바깥쪽 옆면으로 들어오는 빔도 받습니다. 해치를 여러 개 열면 전력이 합산됩니다. Industrial Bio Reactor 블록 전면으로 들어오는 빔도 계산에 포함됩니다.

Catalyst 하나로는 부족한 전력입니다. 업그레이드가 없는 [Energy Converter](nautec:laser_chemistry/energy_converter.md)는 틱당 최대 150 AP를 공급하므로 4개를 해치 4개에 연결하면 업그레이드 없이 군체 9개를 가동할 수 있습니다. 해치에 도달하기 전에 <ItemLink id="laser_junction"/>으로 빔을 합칠 수도 있습니다.

***

## <Color id="gold">화면 구성</Color>

* 왼쪽 3 × 3 격자에 군체를 넣습니다. 각 군체 오른쪽의 가는 막대는 영양분 완충량이고 아래 막대는 진행도입니다.
* 오른쪽 3 × 3 격자는 출력 슬롯이며 왼쪽 군체와 같은 순서로 일대일 대응합니다.
* 아래쪽 줄의 왼쪽에는 영양분 슬롯 3개, 오른쪽에는 업그레이드 슬롯 4개가 있습니다.
* 중앙 화살표는 평균 진행도를 보여 줍니다. 커서를 올리면 공급 전력과 필요 전력, 업그레이드 효과를 확인할 수 있습니다.

군체 9개를 영양분 슬롯 3개로 먹여야 하므로 한 번에 3종류 이하의 영양분만 사용하는 것이 좋습니다. 자세한 내용은 [군체 먹이 공급](colony_feeding.md)을 참고하세요.

***

## <Color id="gold">자동화</Color>

* 구조물의 모든 블록 바깥면에서 아이템을 주고받습니다. 지붕이나 벽에 연결한 호퍼는 영양분과 업그레이드를 공급하고, 바닥 아래 호퍼는 출력을 꺼내며 파이프는 외부 어디든 연결할 수 있습니다.
* [면 설정](nautec:getting_started/utilities.md)으로 각 면의 역할을 지정합니다. 화면 오른쪽 탭 또는 Item Sides 모드의 렌치를 이용하세요. 설정은 면 전체에 적용됩니다. Front는 Industrial Bio Reactor 블록이 있는 벽이며, Left와 Right는 밖에서 해당 블록을 바라볼 때 좌우 벽입니다. 예를 들어 지붕을 Insert, 바닥을 Extract로 지정하면 지붕의 파이프는 출력물을 빼내지 않고 바닥 파이프는 아이템을 넣지 않습니다.

군체는 Dish Port를 통해 넣고 뺍니다. 군체 격자와 출력 사이의 위쪽 슬롯에 접시를 넣고, 아래 슬롯에서 군체가 담긴 접시를 꺼냅니다. 빈 접시는 맨 아래 영양분과 업그레이드 사이의 슬롯으로 나옵니다. 군체가 담긴 Petri Dish를 넣으면 군체 전체를 수용할 수 있는 첫 슬롯에 넣습니다. 모든 슬롯이 찼다면 새 군체는 가장 오래된 노쇠(Senescent) 군체와만 교체됩니다. 교체된 군체는 같은 접시에 담겨 나오므로 빈 접시가 남지 않습니다. 노쇠 군체가 없거나 출력 슬롯이 가득 찼으면 교체를 기다립니다. 빈 접시는 가장 오래된 노쇠 군체를 꺼내며 그런 군체가 없으면 포트에서 대기합니다. 노쇠 군체가 담긴 접시는 포트가 받지 않아 상자 하나로 공급과 회수를 동시에 할 수 있습니다. 노쇠하지 않은 군체는 빈 접시로 해당 군체 슬롯을 클릭해 꺼내세요. 자동화 장치는 다른 슬롯과 같은 면에서 포트에도 접근합니다.

자동화 장치는 영양분·업그레이드·Dish Port에만 넣고 출력 슬롯과 Dish Port에서만 꺼냅니다. 지붕 해치 위에 호퍼를 놓지 마세요. 해치 위의 블록이 아래로 들어오는 빔을 막습니다.

간단한 배치 예시: 지붕 한쪽 모서리에 영양분용 상자와 호퍼를 놓고 나머지 지붕에는 빔이 들어오는 해치를 설치합니다. 바닥 아래에는 저장소로 이어지는 호퍼를 배치하세요. 최대치 군체는 약 10초 만에 출력 슬롯을 가득 채울 수 있으므로 성장 후에는 출력용 호퍼를 여러 개 사용하는 것이 좋습니다.

***

## <Color id="gold">제작법</Color>

<RecipeFor id="industrial_bio_reactor"/>

***

## <Color id="gold">강한 빔</Color>

Industrial Bio Reactor는 군체와 업그레이드에 따라 필요 AP를 계산합니다. 그보다 강한 빔을 공급하면 Speed Upgrade 효과에 추가로 생산 속도가 빨라집니다. 속도 배율은 √(빔 전력 ÷ 필요 전력)입니다.

| 필요 전력 대비 빔 배율 | 속도 |
|---|---|
| 1× | ×1 (기본) |
| 4× | ×2 |
| 9× | ×3 |
| 16× | ×4 |

두 효과는 곱해집니다. Speed Upgrade로 ×1.5가 된 반응로에 필요 전력의 4배를 공급하면 ×3으로 작동합니다. 영양분은 작업 틱마다 소모되므로 강한 빔으로 같은 영양분에서 더 많은 아이템을 얻습니다. 진행 화살표에 커서를 올리면 빔 속도와 업그레이드를 포함한 총 속도를 확인할 수 있으며 Jade에도 빔 속도가 표시됩니다.

공식과 적용 기계 목록은 [강한 빔](nautec:getting_started/stronger_beams.md)을 참고하세요.
