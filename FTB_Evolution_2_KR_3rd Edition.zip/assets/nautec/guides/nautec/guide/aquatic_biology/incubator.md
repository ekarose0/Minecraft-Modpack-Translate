---
navigation:
  title: Incubator
  icon: nautec:incubator
  position: 7
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:incubator
---
# <Color id="light_purple">Incubator</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="incubator" scale="2"/>
  Incubator는 군체를 성장시키고 활력(Vitality)을 회복합니다.
</Column>

박테리아 슬롯에는 군체를, 아이템 슬롯에는 해당 균주의 영양분을 넣습니다. 균주별 영양분과 성장 범위·소모 확률은 JEI의 Bacteria Incubation 항목에 나옵니다. 군체가 들어간 상태에서 빈 영양분 슬롯에 커서를 올리면 성장 재료가, 진행 화살표에 올리면 대기 이유가 표시됩니다. Incubator는 영양분과 균주가 일치할 때만 가동되며 아이템 슬롯에는 한 종류의 영양분만 넣습니다.

영양분이 있는 모든 균주는 자신이 생산하는 아이템과 그 저장 블록도 먹습니다. 예를 들어 Ferrophiles는 철 광석, 철 주괴, 철 블록을 사용할 수 있습니다. 생산 아이템의 소모 확률은 고유 영양분의 1.5배, 저장 블록의 소모 확률은 그 1/9이므로 블록 하나가 아이템 아홉 개와 같은 시간 동안 유지됩니다. 저장 블록을 찾는 방식은 [군체 영양 공급](colony_feeding.md)을 참고하세요.

Cyanobacteria, Halobacteria, Methanogens, Thermophiles에는 영양분이 없습니다. 먼저 [변이](mutator.md)시키세요.

***

## <Color id="gold">성장 주기</Color>

한 주기는 5초입니다. 끝날 때 다음 효과가 적용됩니다.

* 제작법의 성장 범위에서 무작위로 선택한 값에 현재 크기의 3%를 더하고, 모두 Growth Rate를 곱한 만큼 크기가 증가합니다. 큰 군체일수록 더 빨리 자랍니다.
* 영양분은 제작법에 정해진 확률로 소모됩니다. 소모 여부와 관계없이 군체는 성장합니다.
* 군체의 나이가 초기화되어 활력이 100%로 돌아옵니다.

예를 들어 Lithophiles를 돌로 키우면 주기당 기본 성장량 8~25가 정해지고 돌 소모 확률은 5%입니다. Growth Rate가 1이고 크기 400인 군체는 첫 주기에 약 28, 크기 10,000인 군체는 약 316만큼 자랍니다. 크기 400에서 상한까지는 약 150주기, 20 AP 광선에서 약 13분이 걸리며 평균 20주기마다 돌 하나를 먹습니다. Growth Rate가 2면 시간은 대략 절반으로 줄어듭니다.

성장은 크기 상한 40,000(설정 가능)에서 정확히 멈춥니다. 상한에 도달한 군체도 주기는 계속 진행되며 크기는 그대로이고 나이만 초기화됩니다.

***

## <Color id="gold">에너지</Color>

위 또는 아래 면으로 최소 20 AP의 광선이 들어와야 하며 양쪽에서 들어온 출력은 합산됩니다. <ItemLink id="aquatic_catalyst"/> 한 개에서 <ItemLink id="prismarine_crystal_shard"/>를 태우면 정확히 20 AP가 나옵니다. Prismarine Shard를 쓰면 12 AP이므로 위아래 양쪽에 하나씩 설치하거나 <ItemLink id="laser_junction"/>에서 광선을 먼저 합치세요. 주기 시간(100틱)과 출력은 설정 가능합니다.

***

## <Color id="gold">Incubator와 Reactor의 차이</Color>

작업 중인 군체를 굳이 이곳으로 되돌릴 필요는 없습니다. [Bio Reactor](bio_reactor.md)는 영양분 슬롯에서 군체에 먹이를 공급하여 노화를 막고, 기본적으로 군체는 Incubator에서 먹던 영양분을 그대로 먹습니다. [군체 영양 공급](colony_feeding.md)을 참고하세요.

다만 군체 크기를 키우거나 이미 진행된 노화를 초기화하는 유일한 방법은 Incubator입니다. Senescent가 된 뒤 영양분을 공급하기 시작한 군체는 반응로 안에서 계속 노쇠 상태로 남지만, 여기에서 성장 주기를 한 번 끝내면 활력이 다시 100%가 됩니다.

호퍼와 파이프로 영양분을 넣을 수 있어 상자와 연결하면 장시간 배양할 수 있습니다. 기본적으로 모든 면이 영양분을 받으며 [면 설정](nautec:getting_started/utilities.md)에서 바꿀 수 있습니다.

왼쪽 아래의 두 슬롯은 Dish Port입니다. 왼쪽에 접시를 넣고 오른쪽에서 군체가 담긴 접시를 꺼냅니다. 군체가 담긴 Petri Dish를 넣으면 군체가 투입됩니다. 다만 박테리아 슬롯이 비어 있거나 균주·모든 능력치가 정확히 같고 합칠 공간이 있어야 하며, Incubator가 키울 수 있는 균주여야 합니다. 이미 크기가 상한인 군체는 활력이 줄어든 경우에만 투입됩니다. 활력이 가득하면 더 얻을 것이 없기 때문입니다. 비워진 접시는 포트에 남아 있다가 군체가 최대 크기에 도달하면 군체를 다시 담아 출력 슬롯으로 보내며, 그제야 다음 접시를 받습니다. 포트는 즉시 처리할 수 있는 접시만 받으므로 파이프나 호퍼는 다른 접시를 그대로 보관해 기계를 막지 않습니다.

***

## <Color id="gold">제작법</Color>

<Recipe id="nautec:incubator"/>

***

## <Color id="gold">강한 광선의 효과</Color>

Incubator의 기본 요구 출력은 20 AP입니다. 더 강한 광선은 성장 주기를 √(공급 출력 ÷ 20)배 빠르게 합니다.

| 광선 출력 | 속도 |
|---|---|
| 20 AP | ×1 (기본) |
| 80 AP | ×2 |
| 180 AP | ×3 |
| 320 AP | ×4 |

영양분의 소모 확률은 각 주기마다 그대로 적용되므로 성장 속도가 높아진 만큼 영양분도 더 빨리 소비합니다. 주기당 5초는 20 AP 광선을 기준으로 합니다.

공식과 적용 기계 전체 목록은 [강한 광선](nautec:getting_started/stronger_beams.md)을 참고하세요.
