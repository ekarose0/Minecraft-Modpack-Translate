---
navigation:
  title: Colony Feeding
  icon: minecraft:bone_block
  position: 9
  parent: aquatic_biology/aquatic_biology-index.md
---
# <Color id="light_purple">군체 영양 공급</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="minecraft:bone_block" scale="2"/>
  반응로의 영양분 슬롯에 넣은 재료가 군체의 노화를 막아 줍니다.
</Column>

이 방식은 [Bio Reactor](bio_reactor.md)와 [Industrial Bio Reactor](industrial_bio_reactor.md)에 똑같이 적용됩니다.

***

## <Color id="gold">영양분 버퍼</Color>

각 군체 슬롯에는 군체 옆의 얇은 막대로 표시되는 영양분 버퍼가 있습니다. 군체가 작업하는 동안 나이가 드는 대신 매 틱 버퍼 1틱을 소비합니다. 버퍼가 비면 반응로가 영양분 슬롯에서 해당 군체에 맞는 재료 하나를 꺼내 그 제작법의 유지 시간을 버퍼에 더합니다. 기본으로 제공되는 모든 균주는 아이템 하나당 1,200틱, 즉 작업 1분을 얻습니다. 저장 블록은 이 시간의 아홉 배입니다.

따라서 작동 중인 군체 하나는 분당 영양분 하나를 소비합니다. 버퍼는 실제 작업 중에만 줄어듭니다. 에너지가 부족하거나 출력 슬롯이 가득 차 있으면 소비하지 않습니다. [Reactor Efficiency Upgrade](reactor_upgrades.md)를 넣으면 재료 하나가 더 오래갑니다.

막대에 커서를 올리면 남은 시간이 초 단위로 표시됩니다. 버퍼가 비고 알맞은 영양분도 없으면 "No nutrients: the colony is aging"이라고 나오며 [박테리아 능력치](bacteria_stats.md)에 설명된 대로 노화가 시작됩니다. 굶주린 노쇠 군체는 작업하는 동안 매초 크기의 2%씩 줄어들고, 영양분 하나를 공급하면 즉시 멈춥니다. 영양분을 줘도 나이는 초기화되지 않습니다. 나이를 되돌리는 방법은 [Incubator](incubator.md)뿐입니다.

***

## <Color id="gold">필요한 영양분</Color>

각 균주는 고유 영양분이 있으며 기본적으로 Incubator에서 성장할 때 먹는 재료와 같습니다. JEI의 Colony Feeding 항목에 전부 나옵니다. 균주로 검색하면 영양분을, 아이템의 사용처를 보면 어떤 균주에 공급할 수 있는지 확인할 수 있습니다. 예시는 다음과 같습니다.

| 균주 | 영양분 |
|---|---|
| Lithophiles | 돌 |
| Silicophiles 및 Halotrophs | 모래 |
| Lipophiles | Kelp Slurry |
| Calciophiles | 뼈 블록 |
| Crimson Microbes | 진홍빛 네사체 |
| Carbophages | 모든 종류의 석탄 광석 |
| Ferrophiles | 모든 종류의 철 광석 |
| Adamantophiles | 모든 종류의 다이아몬드 광석 |
| Plumbophiles | 납 주괴 |

다른 모드에서 추가한 금속·보석 균주는 자신이 생산하는 주괴나 보석을 먹습니다. 따라서 생산품의 일부를 영양분 슬롯으로 되돌릴 수 있습니다.

기본 영양분 외에도 영양분이 있는 모든 균주는 자신이 생산하는 아이템과 그 저장 블록을 먹을 수 있습니다. Ferrophiles는 철 광석뿐 아니라 철 주괴·철 블록을, Rhizobacteria는 밀뿐 아니라 건초 더미를, 주석 균주는 주석 블록을 먹습니다. 생산 아이템은 기본 영양분과 같은 시간 동안, 저장 블록은 아홉 배 동안 유지됩니다. 이는 다른 모드의 균주나 `/nautec bacteria generate`로 만든 균주에도 적용됩니다. JEI에도 함께 나옵니다.

Cyanobacteria, Halobacteria, Methanogens, Thermophiles는 영양분이 없으므로 작업하는 동안 항상 노화합니다.

***

## <Color id="gold">영양분 슬롯</Color>

Bio Reactor에는 2개, Industrial Bio Reactor에는 3개의 영양분 슬롯이 있습니다. 어떤 균주든 먹을 수 있는 아이템만 넣을 수 있습니다. 군체에 영양분이 필요하면 반응로는 슬롯을 순서대로 확인해 일치하는 첫 재료를 소비합니다. 따라서 한 묶음으로 같은 균주의 모든 군체를 먹일 수 있습니다.

슬롯 하나에는 아이템 한 종류만 들어갑니다. Bio Reactor는 동시에 서로 다른 영양분을 최대 두 종류, Industrial Bio Reactor는 세 종류 공급할 수 있습니다. 모든 군체를 계속 먹이려면 영양분을 공유하는 균주를 모으거나 영양분 슬롯 수 이하의 균주 종류만 넣으세요. 반응로 안의 누구도 먹지 않는 영양분은 슬롯만 차지합니다.

***

## <Color id="gold">영양분 자동화</Color>

호퍼와 파이프로 영양분을 넣을 수 있습니다.

* Bio Reactor: Bio Reactor 블록 위에 호퍼를 놓거나 바닥 받침대 아래에 파이프를 연결합니다.
* Industrial Bio Reactor: 구조물을 이루는 블록의 바깥쪽 면 어디든 연결할 수 있습니다. 지붕 위 호퍼도 가능합니다.

자동화로 넣은 영양분은 영양분 슬롯에만, 업그레이드는 업그레이드 슬롯에만 들어가며 둘 다 자동으로 꺼내지지 않습니다. 영양분 상자를 연결하고 생산품만 빼면 반응로를 계속 가동할 수 있습니다.

***

## <Color id="gold">모드팩에서 급식 설정 바꾸기</Color>

급식은 데이터로 정의됩니다. 각 규칙은 `nautec:colony_feeding` 유형의 제작법이며 기본 파일은 `data/nautec/recipe/colony_feeding/<strain>.json`에 있습니다. 데이터팩으로 교체하거나 추가할 수 있습니다.

| 필드 | 의미 |
|---|---|
| `bacteria` | 균주 ID 또는 `#`를 붙인 박테리아 태그. 생략하면 모든 균주에 일치합니다. |
| `ingredient` | 아이템 `ingredient`와 선택적 `count`(기본 1)를 담는 객체입니다. 슬롯에 필요한 수량 이상이 있어야 하며 급식 한 번에 전부 소비합니다. |
| `vitality_ticks` | 급식 한 번으로 버퍼에 추가되는 틱 수입니다. |

한 군체에 여러 제작법이 동일한 아이템을 허용한다면 특정 균주를 지정한 제작법이 태그보다 우선하며, 태그는 전체 균주 제작법보다 우선합니다. 직접 작성한 제작법은 자동으로 정해지는 생산품·저장 블록 규칙보다 항상 우선합니다.

저장 블록은 아이템의 `c:ingots`, `c:gems`, `c:dusts` 태그에 대응하는 `c:storage_blocks/<material>` 태그로 찾습니다. 밀이나 뼛가루처럼 해당 태그가 없는 아이템은 `nautec:storage_blocks` 아이템 데이터 맵에서 저장 블록을 지정하며 데이터팩으로 추가할 수 있습니다. `config/nautec-common.toml`의 `bacteriaProductNutrients`를 끄면 이 자동 규칙이 비활성화됩니다. `/nautec bacteria generate`는 생성하는 균주마다 급식 제작법을 작성합니다. 자세한 내용은 [맞춤형 박테리아](custom_bacteria.md)를 참고하세요.
