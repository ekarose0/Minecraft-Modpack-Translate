---
navigation:
  title: Bio Reactor
  icon: nautec:bio_reactor
  position: 8
  parent: aquatic_biology/aquatic_biology-index.md
item_ids:
  - nautec:bio_reactor
  - nautec:bacterial_containment_shield
---

# <Color id="light_purple">Bio Reactor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="bio_reactor" scale="2"/>
  Bio Reactor는 최대 3개 군체를 이용해 아이템을 생산합니다.
</Column>

각 군체는 전력이 공급되는 동안 해당 균주의 아이템을 하나씩 생산합니다. 생산 과정에서 군체가 소모되지 않으며 반응로의 영양분 슬롯으로 먹이를 공급하면 노화하지도 않습니다. [Industrial Bio Reactor](industrial_bio_reactor.md)는 9개 군체를 수용하는 대형 버전입니다.

***

## <Color id="gold">건설 방법</Color>

가로 3 × 세로 3 × 높이 2의 구조물입니다.

* 아래층: 모서리에는 Dark Prismarine Pillar, 가장자리에는 Bacteria Containment Shield, 중앙에는 Polished Prismarine을 배치합니다.
* 위층: 모서리에는 Dark Prismarine Pillar, 가장자리에는 Bacteria Containment Shield, 중앙에는 Bio Reactor를 배치합니다.

<GameScene zoom="4" background="#333333" interactive={true}>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="1" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="2" y="1" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="1" z="1"/>
  <Block id="nautec:bio_reactor" x="1" y="1" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="1" z="1"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="1" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="1" z="2"/>
  <Block id="nautec:dark_prismarine_pillar" x="2" y="1" z="2"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="0" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="0" z="0"/>
  <Block id="nautec:dark_prismarine_pillar" x="2" y="0" z="0"/>
  <Block id="nautec:bacterial_containment_shield" x="0" y="0" z="1"/>
  <Block id="nautec:polished_prismarine" x="1" y="0" z="1"/>
  <Block id="nautec:bacterial_containment_shield" x="2" y="0" z="1"/>
  <Block id="nautec:dark_prismarine_pillar" x="0" y="0" z="2"/>
  <Block id="nautec:bacterial_containment_shield" x="1" y="0" z="2"/>
  <Block id="nautec:dark_prismarine_pillar" x="2" y="0" z="2"/>
  <IsometricCamera yaw="225" pitch="30"/>
</GameScene>

웅크리지 않은 상태에서 <ItemLink id="aquarine_steel_wrench"/>를 Rotate 모드로 설정하고 Bio Reactor를 우클릭하면 구조물이 완성됩니다. 잘못된 블록이 있으면 채팅에 해당 위치, 현재 블록, 필요한 블록이 표시됩니다. 완성된 구조물의 블록 하나라도 부수면 다시 해체됩니다.

완성한 뒤 Bio Reactor를 우클릭하면 화면이 열립니다.

***

## <Color id="gold">화면 구성</Color>

* 군체 슬롯 3개에는 [박테리아 소개](bacteria_introduction.md)에 설명된 방식으로 Petri Dish의 군체를 넣습니다.
* 각 군체 옆의 가는 막대는 영양분 완충량입니다. 커서를 올리면 먹이가 몇 초 남았는지 알 수 있습니다.
* 각 군체 오른쪽에는 전용 출력 슬롯이 있습니다.
* 가장 왼쪽의 슬롯 2개는 영양분 슬롯입니다. 필요한 아이템은 [군체 먹이 공급](colony_feeding.md)을 참고하세요.
* 가장 오른쪽의 슬롯 2개에는 [Reactor Upgrades](reactor_upgrades.md)를 하나씩 장착합니다.
* 진행 화살표에 커서를 올리면 공급 전력과 필요 전력을 비교할 수 있습니다.
* 군체에 노란색이나 빨간색 "!"가 뜨면 영양분이 없거나 노화 중이거나 노쇠(Senescent)했다는 뜻입니다. 군체에 커서를 올려 원인과 필요한 먹이를 확인하세요.

***

## <Color id="gold">전력과 해치</Color>

반응로는 해치를 통해 전력을 받습니다. 위층의 Bacteria Containment Shield 4개 중 하나를 렌치로 우클릭하면 해치로 전환되며 다시 클릭하면 원래대로 돌아옵니다. 그런 다음 위에서 아래로 해치에 빔을 쏘세요. 반응로 면을 설정하는 Item Sides 모드에서는 작동하지 않습니다. 여러 해치를 열 수 있으며 공급 전력은 합산됩니다.

| 군체 수 | 필요 AP |
|---|---|
| 1 | 20 |
| 2 | 35 |
| 3 | 50 |

기본 5 AP에 채워진 군체 슬롯당 15 AP가 더해지며 둘 다 설정할 수 있습니다. 업그레이드는 합계에 배율을 적용합니다([Reactor Upgrades](reactor_upgrades.md)). 이는 소비량이 아니라 최소 작동 기준입니다. 부족하면 작동하지 않고 모든 진행도가 초기화되며, 더 강한 빔은 생산 속도를 높입니다(아래 강한 빔 참고).

<ItemLink id="aquatic_catalyst"/> 하나는 Prismarine Shards를 연료로 12 AP를 생산하므로 해치 2개에 Catalyst 2개를 연결하면 군체 1개, 3개면 군체 2개를 가동할 수 있습니다. 군체 3개를 가동하려면 Catalyst에 <ItemLink id="budding_prismarine"/>을 붙여 출력을 높이고 네 번째 해치를 사용하거나, 해치에 도달하기 전에 <ItemLink id="laser_junction"/>으로 빔을 합치세요. [Bacterial Fuel Cell](bacterial_fuel_cell.md)은 단일 빔으로 최대 48 AP를 출력합니다.

***

## <Color id="gold">생산 속도</Color>

생산 속도는 Production Rate × 크기 계수 × 균주의 Strain Yield로 결정됩니다. 크기 계수는 작은 군체에서 0.5, 최대 크기에서 1입니다. Lithophiles처럼 Strain Yield가 1인 균주를 예로 들면 다음과 같습니다.

| 군체 | 아이템 1개당 시간 |
|---|---|
| Production Rate 0.3, 크기 400 | 약 2초 |
| Production Rate 1, 크기 20,000 | 약 0.4초 |
| Production Rate 2, 크기 40,000 | 약 0.15초 |

가치가 높은 균주는 더 느립니다. 다이아몬드 군체는 약 8배 이상 오래 걸립니다. 자세한 공식과 모든 균주의 Strain Yield는 [생산 속도](production_rates.md)를 참고하세요.

군체마다 출력 슬롯이 따로 있습니다. 슬롯이 가득 차면 공간이 생길 때까지 해당 군체가 멈춥니다. 이때는 생산도, 영양분 소비도, 노화도, 크기 감소도 일어나지 않습니다.

***

## <Color id="gold">자동화</Color>

* 완성된 구조물의 모든 바깥면에서 아이템을 주고받을 수 있습니다. 바닥 아래 호퍼는 출력을 꺼내고 Bio Reactor 블록 위 호퍼는 영양분을 공급하며 파이프는 어느 면에도 연결할 수 있습니다.
* [면 설정](nautec:getting_started/utilities.md)으로 각 면의 역할을 지정할 수 있습니다. 화면 오른쪽 탭을 이용하거나 렌치를 Item Sides 모드로 설정해 반응로 블록을 클릭하세요. 설정 하나가 면 전체에 적용됩니다. 예를 들어 Bottom을 Extract로 지정하면 바닥 전체에서 파이프로 꺼내기만 할 수 있습니다. 반응로의 북쪽을 전면으로 취급합니다.
* 군체는 Dish Port를 통해 넣고 뺍니다. 왼쪽 아래 슬롯에 접시를 넣고 그 옆 슬롯에서 군체가 담긴 접시를 꺼냅니다. 빈 접시는 업그레이드 아래 슬롯으로 나옵니다. 군체가 담긴 Petri Dish를 넣으면 군체 전체를 수용할 수 있는 첫 슬롯에 넣습니다. 모든 군체 슬롯이 찼다면 새 군체는 가장 오래된 노쇠(Senescent) 군체와만 교체할 수 있습니다. 교체된 기존 군체는 같은 접시에 담겨 나오므로 빈 접시가 남지 않습니다. 노쇠 군체가 없거나 출력 슬롯이 가득 찼으면 교체를 기다립니다. 빈 접시는 가장 오래된 노쇠 군체를 꺼내며, 그런 군체가 없으면 포트에서 대기합니다. 노쇠 군체가 들어 있는 접시는 포트가 받지 않으므로 상자 하나로 공급과 회수를 함께 할 수 있습니다. 노쇠하지 않은 군체를 꺼내려면 빈 접시로 해당 군체 슬롯을 클릭하세요. 자동화 장치는 다른 슬롯과 같은 면에서 포트에도 접근할 수 있습니다.

자동화 장치는 영양분·업그레이드·Dish Port 슬롯에만 넣고, 출력 슬롯과 Dish Port에서만 꺼냅니다. 영양분을 공급하고 출력을 회수하면 반응로가 계속 작동합니다.

***

## <Color id="gold">노화와 감소</Color>

작동 중인 군체는 노화하는 대신 영양분 완충량을 소모합니다. 완충량이 바닥나면 반응로가 영양분 슬롯에서 맞는 먹이를 추가합니다. 맞는 먹이가 없을 때만 작동한 틱마다 1틱씩 노화하며, 막대에 "영양분 없음: 군체가 노화 중"이라고 표시됩니다.

군체의 나이가 Lifespan을 넘으면 노쇠(Senescent) 상태가 됩니다. 노쇠한 군체가 굶주리면 작동하는 매초 크기의 2%(최소 1)를 잃어 약 35초 뒤에는 절반이 사라집니다. 감소율은 설정할 수 있습니다.

먹이를 주면 즉시 크기 감소가 멈추지만 군체가 젊어지지는 않습니다. 노쇠 상태는 유지되어 먹이가 다시 떨어지면 줄어들기 시작합니다. [Incubator](incubator.md)에서 한 주기를 완료하면 나이가 초기화됩니다.

***

## <Color id="gold">제작법</Color>

<Recipe id="nautec:bio_reactor"/>

<RecipesFor id="bacterial_containment_shield"/>

***

## <Color id="gold">강한 빔</Color>

Bio Reactor는 군체와 업그레이드에 따라 필요한 AP를 먼저 계산합니다. 그보다 강한 빔은 Speed Upgrade 효과에 더해 생산을 가속합니다. 속도 배율은 √(빔 전력 ÷ 필요 전력)입니다.

| 필요 전력 대비 빔 배율 | 속도 |
|---|---|
| 1× | ×1 (기본) |
| 4× | ×2 |
| 9× | ×3 |
| 16× | ×4 |

두 효과는 곱해집니다. Speed Upgrade로 ×1.5가 된 반응로에 필요 전력의 4배를 공급하면 ×3으로 작동합니다. 영양분은 작업 틱마다 소모되므로 강한 빔을 사용하면 같은 영양분으로 더 많은 아이템을 생산할 수 있습니다. 진행 화살표에 커서를 올리면 빔 속도와 업그레이드 포함 총 속도를 확인할 수 있고, Jade에서도 빔 속도를 볼 수 있습니다.

공식과 적용 기계 목록은 [강한 빔](nautec:getting_started/stronger_beams.md)을 참고하세요.

<RecipeFor id="polished_prismarine"/>

<RecipeFor id="dark_prismarine_pillar"/>
