---
navigation:
  title: ME Requester
  icon: requester
  position: 100
item_ids:
  - merequester:requester
  - merequester:requester_terminal
---

# ME Requester

<Row>
  <ItemImage id="requester" scale="3"/>
  <ItemImage id="requester_terminal" scale="3"/>
</Row>

[ME 시스템](ae2:getting-started.md#your-very-first-me-system)에 아이템과 액체를 지정된 수량만큼 항상 비축하도록 도와주는 애드온 모드입니다.
<br/>

## 시작하기

먼저 <ItemLink id="requester"/>를 설치하고 네트워크에 연결하세요. [자동 제작](ae2:ae2-mechanics/autocrafting.md) 기능이 구성된 네트워크와 동일한 곳에 연결해야 합니다. 이 네트워크에는 [Crafting CPU](ae2:ae2-mechanics/autocrafting.md#the-crafting-cpu)와 <ItemLink id="ae2:pattern_provider"/>가 있어야 합니다.

<RecipeFor id="requester"/>

<ItemLink id="requester"/>가 작동하려면 비축할 아이템이나 액체에 해당하는 제작 패턴이 있어야 하며, 플레이어가 직접 요청했을 때도 정상적으로 제작할 수 있어야 합니다. ME Requester는 제작 요청을 자동으로 보내는 역할만 합니다. 실제 제작은 [ME 시스템](ae2:getting-started.md#your-very-first-me-system)이 담당합니다.
<br/>

<FloatingImage src="assets/gui.png" align="right"/>

## 설정

<ItemLink id="requester"/>를 처음 열면 요청 설정의 전체 목록이 표시됩니다. 블록 하나에 설정할 수 있는 슬롯 수는 설정 파일에서 조정할 수 있습니다. GUI의 각 행은 독립된 제작 요청을 나타냅니다.
<br/>

### 활성화 스위치

왼쪽 체크박스는 해당 행에 설정된 요청을 켜거나 끕니다. 요청을 비활성화하면 비축 수량을 확인하지 않으며 자동 보충도 수행하지 않습니다.<br/>
특정 요청을 일시적으로 중지하거나, 행을 설정하는 동안 <ItemLink id="requester"/>가 제작 작업을 보내지 못하게 할 때 유용합니다.
<br/>

### 비축할 항목

두 번째 열에서는 비축할 아이템이나 액체를 지정합니다. 이 슬롯은 실제 아이템을 보관하지 않는 고스트 슬롯입니다. 아이템을 슬롯으로 드래그할 때 우클릭하면 수량을 1로 지정하고, 좌클릭하면 드래그한 스택의 수량을 사용합니다. 액체가 든 양동이를 드래그할 때 우클릭하면 안에 든 액체를, 좌클릭하면 양동이 아이템 자체를 지정합니다. Shift+클릭으로 아이템 종류를 빠르게 설정할 수도 있습니다. 인벤토리에 원하는 아이템이 없다면 Applied Energistics가 지원하는 레시피 뷰어에서 끌어다 놓을 수도 있습니다.
<br/>

### 비축 수량

Amount to Stock은 유지할 목표 수량을 뜻합니다. 먼저 비축할 항목을 지정한 다음 원하는 수량을 입력하세요. 아이템이 아닌 항목에서는 입력란이 종류에 맞게 바뀝니다. 예를 들어 액체는 양동이를 나타내는 `B`가 표시됩니다.<br/>
현재 비축량이 설정한 수량 아래로 떨어지면 <ItemLink id="requester"/>가 추가 제작을 요청합니다.
<br/>

### 일괄 요청 수량

Batch Size는 현재 비축량이 Amount to Stock의 기준보다 낮아졌을 때 한 번에 요청할 제작 수량을 지정합니다.<br/>
작업을 여러 번 나누어 요청하는 대신 한꺼번에 요청하므로 [Crafting CPU](ae2:ae2-mechanics/autocrafting.md#the-crafting-cpu)와 제작 기계의 부하를 줄이는 데 도움이 됩니다.
<br/>

### 적용 버튼

요청 설정을 적용하려면 Amount to Stock과 Batch Size에 원하는 값을 입력한 뒤 Enter를 누르거나 해당 행 오른쪽의 적용 버튼을 클릭하세요. 다른 행을 클릭하면 아직 적용하지 않은 값은 이전 상태로 돌아갑니다.
<br/>

### 상태 표시줄

입력란과 적용 버튼 아래의 막대는 현재 요청 상태를 나타냅니다.
<br clear="all" />
<br/>

## 상태 표시

각 요청의 상태 표시줄에는 다음 상태가 표시됩니다.
<br/>

### 회색 - 비어 있음

해당 행이 비활성화되었거나 비축할 항목이 지정되지 않았습니다.
<br/>

### 초록색 - 대기 중

목표 비축량을 이미 채웠거나 설정한 요청에 사용할 제작 패턴이 없습니다.
<br/>

### 빨간색 - 재료 부족

현재 제작 작업을 요청하는 데 필요한 재료가 부족합니다. 시스템에 재료가 충분히 확보되면 작업을 계속합니다.
<br/>

### 노란색 - 제작 중

요청한 항목을 현재 제작하고 있습니다. ME Requester는 작업이 완료되기를 기다립니다.<br/>
이 상태에서는 <ItemLink id="requester"/>의 해당 요청 설정이 잠겨 변경할 수 없습니다.
<br/>

### 보라색 - 내보내는 중

<ItemLink id="requester"/>가 현재 제작 작업의 결과물을 모두 받았으며 저장 시스템으로 내보내는 중입니다.<br/>
보통은 거의 보이지 않는 상태입니다. 너무 오래 지속되면 저장 시스템의 공간이 부족하다는 뜻입니다.
<br/>

### 블록 외형

<ItemLink id="requester"/>에 등록된 요청 중 하나라도 대기 중 또는 비어 있음 이외의 상태가 되면 블록 외형이 바뀝니다.

<Row>
  <Column>
    비활성
    <BlockImage id="requester" scale="3" p:active="false"/>
  </Column>
  <Column>
    활성
    <BlockImage id="requester" scale="3" p:active="true"/>
  </Column>
</Row>
<br/>

## Terminal

이 모드는 <ItemLink id="requester_terminal"/>이라는 새로운 Terminal도 제공합니다. 같은 네트워크에 연결된 모든 <ItemLink id="requester"/>를 한곳에서 관리할 수 있습니다.

이 Terminal은 <ItemLink id="ae2:pattern_access_terminal"/>과 동일한 기능을 제공하며 특정 요청을 검색할 수 있습니다. 모든 <ItemLink id="requester"/>의 기본 이름은 같으므로 요청이 하나의 제목 아래 묶여 표시됩니다. <ItemLink id="requester_terminal"/>에서 서로 다른 그룹으로 분리하려면 모루 또는 <ItemLink id="ae2:name_press"/>로 각 <ItemLink id="requester"/>의 이름을 변경하세요.
