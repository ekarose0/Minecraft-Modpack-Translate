---
navigation:
  title: "Little Big Redstone"
  position: 0
---

# Little Big Redstone

<MarginFloatingImage src="assets/logo.png" left="0" right="10" />

Little Big Redstone에는 [Microchip](microchips.md) 블록이 추가됩니다. 이 블록 안에 [logic](logic/introduction.md)을 배치하면 복잡한 논리 회로도 블록 하나에 압축할 수 있습니다.

[NOT](logic/not_gate.md), [AND](logic/and_gate.md), [OR](logic/or_gate.md) 같은 기본 논리 게이트를 사용할 수 있습니다. 또한 [Sequencer](logic/sequencer.md)와 [Pulse Throttler](logic/pulse_throttler.md)처럼 신호를 지연하거나 펄스 길이를 줄이거나 늘리는 부품도 있습니다.

Microchip 작업을 돕는 도구도 있습니다. [Logic Array](logic_arrays.md)에는 Microchip에서 사용하는 아이템을 보관할 수 있고, [Floppy Disk](floppy_disks.md)로 회로를 복사하여 다른 곳에 붙여넣을 수 있습니다.

모든 아이템은 16가지 염료 색상으로 제공되어 원하는 색으로 꾸미거나 구분하고 정리할 수 있습니다!