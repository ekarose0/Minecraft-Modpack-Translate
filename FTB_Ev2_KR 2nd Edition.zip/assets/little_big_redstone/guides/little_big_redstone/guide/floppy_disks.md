---
navigation:
  title: "Floppy Disks"
  icon: "red_floppy_disk"
  position: 4
item_ids:
  - little_big_redstone:white_floppy_disk
  - little_big_redstone:light_gray_floppy_disk
  - little_big_redstone:gray_floppy_disk
  - little_big_redstone:black_floppy_disk
  - little_big_redstone:brown_floppy_disk
  - little_big_redstone:red_floppy_disk
  - little_big_redstone:orange_floppy_disk
  - little_big_redstone:yellow_floppy_disk
  - little_big_redstone:lime_floppy_disk
  - little_big_redstone:green_floppy_disk
  - little_big_redstone:cyan_floppy_disk
  - little_big_redstone:light_blue_floppy_disk
  - little_big_redstone:blue_floppy_disk
  - little_big_redstone:purple_floppy_disk
  - little_big_redstone:magenta_floppy_disk
  - little_big_redstone:pink_floppy_disk
---

# Floppy Disks

<FloatingColumn align="right">
	<PaddedBox left="5">
		<Recipe id="little_big_redstone:floppy_disk/red" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="0">
		<Row gap="1">
			<ItemImage id="red_floppy_disk" />
			<ItemImage id="orange_floppy_disk" />
			<ItemImage id="yellow_floppy_disk" />
			<ItemImage id="lime_floppy_disk" />
		</Row>
		<Row gap="1">
			<ItemImage id="green_floppy_disk" />
			<ItemImage id="cyan_floppy_disk" />
			<ItemImage id="light_blue_floppy_disk" />
			<ItemImage id="blue_floppy_disk" />
		</Row>
		<Row gap="1">
			<ItemImage id="purple_floppy_disk" />
			<ItemImage id="magenta_floppy_disk" />
			<ItemImage id="pink_floppy_disk" />
			<ItemImage id="brown_floppy_disk" />
		</Row>
		<Row gap="1">
			<ItemImage id="white_floppy_disk" />
			<ItemImage id="light_gray_floppy_disk" />
			<ItemImage id="gray_floppy_disk" />
			<ItemImage id="black_floppy_disk" />
		</Row>
	</PaddedBox>
</FloatingColumn>

Floppy Disk에는 [Microchip](microchips.md)의 프로그램을 저장한 뒤 다른 Microchip에 간편하게 설치할 수 있습니다.

Floppy Disk를 든 상태에서 Microchip을 **<KeyBind id="key.sneak" />** + **<KeyBind id="key.use" />** 하면 해당 Microchip의 프로그램이 디스크에 저장됩니다.

프로그램을 저장한 뒤 필요한 논리 부품과 Redstone Bit을 갖춘 상태에서 Microchip을 **<KeyBind id="key.use" />** 하면 프로그램을 설치할 수 있습니다. 보조 손에 Floppy Disk를 들고 Microchip을 설치할 때도 적용됩니다. [Logic Array](logic_arrays.md)에 들어 있는 아이템도 프로그램 설치 시 인벤토리에 있는 것으로 취급합니다. Floppy Disk를 든 채 Microchip을 바라보면 설치에 필요한 아이템이 단축바 위에 표시됩니다.

프로그램은 로컬 컴퓨터의 파일로 저장하거나 파일에서 불러올 수도 있습니다! Microchip을 바라보지 않은 상태에서 Floppy Disk를 들고 **<KeyBind id="key.use" />** 하면 관련 메뉴가 열립니다. "Save" 버튼은 "Program Name" 입력란에 적은 이름으로 현재 프로그램을 파일에 저장합니다. "Load" 버튼은 입력한 이름의 파일에서 프로그램을 불러옵니다. 해당 이름의 파일이 없으면 "Load" 버튼을 누를 수 없습니다. 저장한 프로그램은 게임 폴더의 **/little_big_redstone/microchips** 디렉터리에 보관되며, 다른 월드나 서버에서도 사용할 수 있습니다.