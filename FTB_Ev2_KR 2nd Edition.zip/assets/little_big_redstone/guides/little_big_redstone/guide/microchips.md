---
navigation:
  title: "Microchips"
  icon: "red_microchip"
  position: 1
item_ids:
  - little_big_redstone:white_microchip
  - little_big_redstone:light_gray_microchip
  - little_big_redstone:gray_microchip
  - little_big_redstone:black_microchip
  - little_big_redstone:brown_microchip
  - little_big_redstone:red_microchip
  - little_big_redstone:orange_microchip
  - little_big_redstone:yellow_microchip
  - little_big_redstone:lime_microchip
  - little_big_redstone:green_microchip
  - little_big_redstone:cyan_microchip
  - little_big_redstone:light_blue_microchip
  - little_big_redstone:blue_microchip
  - little_big_redstone:purple_microchip
  - little_big_redstone:magenta_microchip
  - little_big_redstone:pink_microchip
---

# Microchips

<FloatingColumn align="right">
	<PaddedBox left="5">
		<Recipe id="little_big_redstone:microchip/red" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="5">
		<GameScene zoom="1.5" padding="0" background="transparent">
			<ImportStructure src="assets/structures/microchips.snbt" />
			<IsometricCamera yaw="135" pitch="30" />
		</GameScene>
	</PaddedBox>
</FloatingColumn>

Microchip은 내부에 [logic](logic/introduction.md)을 배치해 복잡한 회로를 구성하는 블록입니다. 논리 부품 사이에 [Wires](redstone_bits.md)를 연결하면 한 부품에서 다른 부품으로 신호를 전달할 수 있습니다.

Microchip 메뉴에서는 마우스 휠로 확대하거나 축소할 수 있습니다. 마우스 왼쪽 버튼을 누른 채 드래그하면 회로 화면을 이동할 수 있습니다.

### 방향

외부 월드에서 신호를 입력받거나 출력하는 논리 부품에는 방향을 지정해야 합니다. Microchip은 <Color color="#4CFF00">북쪽</Color>, <Color color="#0094FF">남쪽</Color>, <Color color="#FF0000">동쪽</Color>, <Color color="#FF6A00">서쪽</Color>과 <Color color="#FFFFFF">위쪽</Color>, <Color color="#FFD800">아래쪽</Color> 방향을 사용합니다. **<KeyBind id="key.sneak" />** 상태에서 Microchip을 바라보면 각 방향에 해당하는 색을 블록 측면에서 확인할 수 있습니다.

### 색상 변경

Microchip은 기본 염료 16가지 색상으로 염색할 수 있으며, 메뉴에도 해당 색상이 적용됩니다. 논리 부품은 Microchip과 별도로 염색할 수 있지만, 기본적으로 배치된 Microchip의 색을 따릅니다. 논리 부품을 염색하려면 제작대에서 염료와 조합하거나 메뉴에서 부품을 염료로 우클릭하면 됩니다.

물 양동이나 눈덩이로 논리 부품의 색을 제거할 수도 있습니다. 눈덩이는 소모되지만 물 양동이는 소모되지 않습니다.