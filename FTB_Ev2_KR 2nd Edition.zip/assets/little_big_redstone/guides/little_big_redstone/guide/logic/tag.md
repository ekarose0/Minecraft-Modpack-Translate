---
navigation:
  title: "Tag"
  icon: "tag"
  parent: little_big_redstone:logic.md
  position: 12
categories:
  - logic
item_ids:
  - little_big_redstone:tag
---

# Tag

<FloatingColumn width="100" align="right">
	### 아날로그
	Tag는 입력과 같은 신호 세기를 출력합니다. 입력이 여러 개일 때(예: 임계값이 1보다 큰 경우)는 가장 높은 신호 세기를 사용합니다.
</FloatingColumn>

<Recipe id="little_big_redstone:logic/tag" />

Tag를 사용하면 회로 사이에서 무선으로 신호를 주고받을 수 있습니다. Tag에는 Sensor(수신)와 Emitter(송신) 두 모드가 있습니다. Sensor는 신호를 받고 Emitter는 신호를 보냅니다.

<br />

각 Tag에는 레이블을 지정할 수 있습니다. Sensor가 Emitter를 감지하려면 두 Tag의 레이블이 같아야 합니다. 레이블은 **대소문자를 구분**합니다. 레이블은 필수가 아니며, 비워 두면 레이블이 비어 있는 다른 Tag하고만 연결됩니다.

Sensor에는 ON 출력을 내기 위해 감지해야 하는 Emitter의 개수를 정하는 임계값(Threshold) 설정이 있습니다. 예를 들어 임계값이 2이고 레이블이 "something"인 Sensor는 레이블이 "something"이며 ON인 Emitter가 두 개 있어야 ON이 됩니다.

Sensor는 같은 회로에 있는 Emitter도 감지할 수 있습니다.

<br />

Sensor는 Global(전역) 여부도 설정할 수 있습니다. 멀티플레이어 서버에서 다른 플레이어가 설치한 Emitter까지 감지할지 결정하는 설정입니다. 기본적으로 Global은 꺼져 있어 자신이 설치한 Emitter만 감지합니다.

<br />

아래 예시에서는 Emitter와 Sensor의 레이블이 같습니다. Sensor의 임계값이 1이므로 Emitter가 ON이면 Sensor도 ON이 됩니다.

<Row>
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input1" x="0" y="0" type="io" hide={true} />
			<Logic name="output1" x="32" y="0" type="tag" data="{config:{input:false,label:'something'}}" />

			<Logic name="tag2" x="64" y="0" type="tag" data="{config:{label:'something'}}" />
			<Logic name="input2" x="64" y="0" type="io" data="{config:{direction:'south'}}" hide={true} />
			<Logic name="output2" x="96" y="0" type="io" data="{config:{input:false,direction:'east',signal_strength:15}}" hide={true} />

			<Wire from="input1" fromPort="0" to="output1" toPort="0" />
			<Wire from="input2" fromPort="0" to="output2" toPort="0" />

			<RedstoneSignal step="0" direction="north" strength="15" />
			<RedstoneSignal step="0" direction="south" strength="15" />
			<RedstoneSignal step="1" direction="north" strength="0" />
			<RedstoneSignal step="1" direction="south" strength="0" />
		</MicrochipScene>
	</Column>
</Row>

아래 두 Tag의 레이블은 서로 다릅니다. 따라서 Sensor가 Emitter를 감지하지 못합니다.

<Row>
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input1" x="0" y="0" type="io" hide={true} />
			<Logic name="output1" x="32" y="0" type="tag" data="{config:{input:false,label:'something'}}" />

			<Logic name="input2" x="64" y="0" type="tag" data="{config:{label:'something_else'}}" />
			<Logic name="output2" x="96" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

			<Wire from="input1" fromPort="0" to="output1" toPort="0" />
			<Wire from="input2" fromPort="0" to="output2" toPort="0" />

			<RedstoneSignal step="0" direction="north" strength="15" />
			<RedstoneSignal step="1" direction="north" strength="0" />
		</MicrochipScene>
	</Column>
</Row>