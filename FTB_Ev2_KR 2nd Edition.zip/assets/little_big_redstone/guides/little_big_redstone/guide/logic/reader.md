---
navigation:
  title: "Reader"
  icon: "reader"
  parent: little_big_redstone:logic.md
  position: 11
categories:
  - logic
item_ids:
  - little_big_redstone:reader
---

# Reader

<FloatingColumn width="100" align="right">
	### 아날로그
	Comparator 모드에서는 Reader가 해당 블록의 비교기 출력과 같은 아날로그 신호 세기를 출력합니다. 다른 모드에서는 0(OFF) 또는 1(ON)만 출력합니다.
</FloatingColumn>

<Recipe id="little_big_redstone:logic/reader" />

Reader는 회로 내부에 입력 포트가 없는 논리 부품입니다. 대신 설정한 방향에서 Microchip과 바로 인접한 저장 블록의 채워진 정도를 읽고 신호를 출력합니다.

Reader가 읽을 수 있는 저장 블록에는 아이템 저장소(상자, 통, 화로 등), 유체 저장소(모드의 유체 탱크), 에너지 저장소(배터리 같은 모드의 FE 저장 블록)가 있습니다. 기본값은 아이템 저장량을 읽도록 설정되어 있지만, 논리 부품 설정 메뉴에서 변경할 수 있습니다.

Reader는 저장소 내용물이 일정 기준 이상일 때 ON이 되도록 임계값을 설정할 수 있습니다. 임계값은 백분율 또는 고정값으로 지정할 수 있습니다. 백분율을 사용하려면 값 끝에 %를 붙이세요.

아래 예시는 상자가 50% 이상 차면 Reader가 레드스톤 램프를 켜는 회로입니다.

<PaddedBox left="5" top="5">
	<Row>
		<Column>
			<PaddedBox top="4">
				<GameScene zoom="2" padding="0">
					<Block id="minecraft:chest" />
					<BlockAnnotation>
						상자가 50% 이상 차 있습니다
					</BlockAnnotation>
					<Block id="red_microchip" x="-1" />
					<Block id="minecraft:redstone_lamp" x="-2" p:lit="true" />
					<IsometricCamera yaw="200" pitch="30" />
				</GameScene>
			</PaddedBox>
		</Column>
	
		<Column>
			<MicrochipScene color="red" padding="0" marginWidth="16">
				<Logic name="reader" x="0" y="0" type="reader" data="{config:{direction:'west'}}" />
				<Logic name="output" x="32" y="0" type="io" data="{config:{direction:'east',input:false,signal_strength:15}}" />
	
				<Wire from="reader" fromPort="0" to="output" toPort="0" powered="1" />
			</MicrochipScene>
		</Column>
	</Row>
	
	<Row>
		<Column>
			<PaddedBox top="4">
				<GameScene zoom="2" padding="0">
					<Block id="minecraft:chest" />
					<BlockAnnotation>
						상자가 50% 미만으로 차 있습니다
					</BlockAnnotation>
					<Block id="red_microchip" x="-1" />
					<Block id="minecraft:redstone_lamp" x="-2" p:lit="false" />
					<IsometricCamera yaw="200" pitch="30" />
				</GameScene>
			</PaddedBox>
		</Column>
	
		<Column>
			<MicrochipScene color="red" padding="0" marginWidth="16">
				<Logic name="reader" x="0" y="0" type="reader" data="{config:{direction:'west'}}" />
				<Logic name="output" x="32" y="0" type="io" data="{config:{direction:'east',input:false,signal_strength:15}}" />
	
				<Wire from="reader" fromPort="0" to="output" toPort="0" />
			</MicrochipScene>
		</Column>
	</Row>
</PaddedBox>