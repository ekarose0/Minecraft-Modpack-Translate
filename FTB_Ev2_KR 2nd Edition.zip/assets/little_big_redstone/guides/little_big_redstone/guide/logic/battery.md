---
navigation:
  title: "Battery"
  icon: "battery"
  parent: little_big_redstone:logic.md
  position: 13
categories:
  - logic
item_ids:
  - little_big_redstone:battery
---

# Battery

<FloatingColumn width="100" align="right">
	### 아날로그
	Battery의 출력 신호는 설정한 신호 세기와 같으며, 0~15 범위를 벗어나지 않습니다.
</FloatingColumn>

<Row>
	<Column>
		<Recipe id="little_big_redstone:logic/battery" />
	</Column>

	<Column>
		<GameScene zoom="1.48" padding="3" interactive={true}>
			<ImportStructure src="../assets/structures/battery.snbt" />
			<IsometricCamera yaw="150" pitch="30" />
		</GameScene>
	</Column>
</Row>

Battery는 매우 단순한 논리 부품입니다. 출력 신호 세기는 언제나 설정한 값으로 유지됩니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="battery" x="0" y="0" type="battery" />
	<Logic name="output" x="32" y="0" type="io" data="{config:{input:false,signal_strength:15}}" hide={true} />

	<Wire from="battery" fromPort="0" to="output" toPort="0" />
</MicrochipScene>