---
navigation:
  title: "T Flip-Flop"
  icon: "t_flip_flop"
  parent: little_big_redstone:logic.md
  position: 25
categories:
  - logic
item_ids:
  - little_big_redstone:t_flip_flop
---

# T Flip-Flop

<FloatingColumn width="100" align="right">
	### 아날로그
	T Flip-Flop의 출력 신호 세기는 출력을 ON으로 바꾼 입력 신호의 세기와 같습니다.
</FloatingColumn>

<Row>
	<Column>
		<Recipe id="little_big_redstone:logic/t_flip_flop" />
	</Column>

	<Column>
		<GameScene zoom="1.48" padding="3" interactive={true}>
			<ImportStructure src="../assets/structures/t_flip_flop.snbt" />
			<IsometricCamera yaw="150" pitch="30" />
		</GameScene>
	</Column>
</Row>

T Flip-Flop은 새로운 ON 입력 신호가 들어올 때마다 출력 상태를 ON과 OFF 사이에서 전환하는 논리 부품입니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="1" x="0" y="0" type="io" hide={true} />
	<Logic name="2" x="32" y="0" type="t_flip_flop" />
	<Logic name="3" x="64" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="1" fromPort="0" to="2" toPort="0" />
	<Wire from="2" fromPort="0" to="3" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
</MicrochipScene>