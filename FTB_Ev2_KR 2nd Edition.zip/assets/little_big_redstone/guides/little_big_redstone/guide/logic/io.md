---
navigation:
  title: "I/O Port"
  icon: "io"
  parent: little_big_redstone:logic.md
  position: 10
categories:
  - logic
item_ids:
  - little_big_redstone:io
---

# I/O Port

<FloatingColumn width="100" align="right">
	### 아날로그
	I/O Port의 출력 신호 세기는 입력 신호 세기와 같습니다.
</FloatingColumn>

<Recipe id="little_big_redstone:logic/io" />

I/O Port는 회로와 외부 월드 사이에서 레드스톤 신호를 입력하거나 출력하는 부품입니다. 회로에 배치하면 Microchip 블록의 측면에 신호를 받거나 내보내는 레드스톤 면이 표시됩니다.

<br />

각 I/O Port에는 연결할 방향이 지정됩니다. <Color color="#4CFF00">북쪽</Color>, <Color color="#0094FF">남쪽</Color>, <Color color="#FF0000">동쪽</Color>, <Color color="#FF6A00">서쪽</Color>, <Color color="#FFFFFF">위쪽</Color>, <Color color="#FFD800">아래쪽</Color>을 사용할 수 있습니다. 웅크린 상태에서 Microchip을 바라보면 측면에 표시된 방향별 색상을 확인할 수 있습니다.

**주의:** 각 방향은 입력 또는 출력 중 하나로만 동작할 수 있습니다. 동일한 면을 입력과 출력으로 동시에 사용하도록 I/O Port를 배치하면 두 포트 모두 작동하지 않고 경고 표시가 나타납니다.

<br />

I/O Port의 신호 세기도 설정할 수 있습니다. 입력 모드에서는 외부에서 들어오는 레드스톤 신호가 설정한 세기 이상이어야 ON 신호를 출력합니다. 출력 모드에서는 내부 입력 포트가 ON 신호를 받으면 설정한 세기의 레드스톤 신호를 외부로 출력합니다.

<Row>
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input" x="0" y="0" type="io" />
			<Logic name="output" x="32" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

			<Wire from="input" fromPort="0" to="output" toPort="0" />
		</MicrochipScene>
	</Column>
	
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input" x="0" y="0" type="io" hide={true} />
			<Logic name="output" x="32" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" />
		
			<Wire from="input" fromPort="0" to="output" toPort="0" />
		</MicrochipScene>
	</Column>
</Row>