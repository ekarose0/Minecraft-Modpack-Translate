---
navigation:
  title: "Sequencer"
  icon: "sequencer"
  parent: little_big_redstone:logic.md
  position: 19
categories:
  - logic
item_ids:
  - little_big_redstone:sequencer
---

# Sequencer

<FloatingColumn width="100" align="right">
	### 아날로그
	Sequencer는 기본적으로 입력과 같은 신호 세기를 출력합니다. 다만 입력이 계속 ON일 필요 없이 출력이 ON으로 유지되는 경우도 있습니다. 이때는 출력을 ON으로 만든 입력 신호의 세기가 출력에 사용됩니다.
</FloatingColumn>

<Row>
	<Column>
		<Recipe id="little_big_redstone:logic/sequencer" />
	</Column>

	<Column>
		<GameScene zoom="1.48" padding="3" interactive={true}>
			<ImportStructure src="../assets/structures/sequencer.snbt" />
			<BoxAnnotation min="2 1 0" max="3 1.5 1" color="#FFFFFF">
				Sequencer는 Repeater보다 훨씬 유연하지만 기본 개념은 비슷합니다.
			</BoxAnnotation>
			<IsometricCamera yaw="150" pitch="30" />
		</GameScene>
	</Column>
</Row>

> **참고:** 마인크래프트에서는 실제 시간 1초가 20틱입니다.

Sequencer는 신호 지연 시간을 정밀하게 제어하는 논리 부품입니다.

Weak, Strong, Counter의 세 가지 모드를 사용할 수 있습니다(아래 항목 참고). Sequencer에는 0부터 설정한 지연값(기본 20)까지 변하는 내부 카운터가 있습니다. 선택한 모드에 따라 카운터가 서로 다른 방식으로 증가하거나 감소합니다. 카운터가 최대값에 도달하면 출력이 ON이 되고, 그렇지 않으면 OFF입니다.

내부 카운터가 최대값에 도달하면 0으로 자동 초기화하도록 설정할 수 있습니다. 이 경우 출력은 정확히 한 틱 동안만 ON이 됩니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:30,auto_reset:true}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal direction="north" strength="15" />
</MicrochipScene>

두 번째 입력 포트를 추가할 수도 있습니다. 이 포트에 ON 신호가 들어오면 내부 카운터가 0으로 초기화됩니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input1" x="0" y="12" type="io" data="{config:{direction:'east'}}" hide={true} />
	<Logic name="input2" x="0" y="20" type="io" data="{config:{direction:'west'}}" hide={true} />
	<Logic name="sequencer" x="32" y="16" type="sequencer" data="{config:{delay:50,reset_port:true}}" />
	<Logic name="output" x="80" y="16" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input1" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="input2" fromPort="0" to="sequencer" toPort="1" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="east" strength="15" />
	<RedstoneSignal step="1" direction="east" strength="0" />
	<RedstoneSignal step="2" direction="east" strength="0" />
	<RedstoneSignal step="3" direction="west" strength="15" />
	<RedstoneSignal step="4" direction="west" strength="0" />
</MicrochipScene>

<br />

### Weak 모드

Weak 모드에서는 첫 번째 입력 포트에 ON 신호가 한 번 들어오면, 신호가 얼마나 오래 지속되든 관계없이 설정한 지연값에 도달할 때까지 카운터가 증가합니다. 단순히 일정 시간만큼 신호를 지연시키려면 이 모드를 사용하세요.

아래 예시는 지연 시간이 100틱(5초)이고 완료 시 자동 초기화되는 Sequencer입니다. 입력 신호는 짧게 들어오지만, 입력이 계속 ON인지와 관계없이 카운터는 계속 증가합니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,auto_reset:true}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
	<RedstoneSignal step="2" direction="north" strength="0" />
	<RedstoneSignal step="3" direction="north" strength="0" />
</MicrochipScene>

<br />

### Strong 모드

Strong 모드에서는 첫 번째 입력 포트에 ON 신호가 들어오는 동안 카운터가 증가합니다. 입력 신호가 끊기면 카운터가 감소합니다.

아래는 지연 시간이 100틱(5초)으로 설정된 Sequencer의 예시입니다.

첫 번째 예시에서는 입력이 충분히 오래 ON으로 유지되어 Sequencer가 ON 상태에 도달합니다. 이후 같은 시간만큼 OFF 상태가 이어져 카운터가 원래 상태로 돌아옵니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,mode:'strong'}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="15" />
	<RedstoneSignal step="2" direction="north" strength="15" />
	<RedstoneSignal step="3" direction="north" strength="15" />
	<RedstoneSignal step="4" direction="north" strength="0" />
	<RedstoneSignal step="5" direction="north" strength="0" />
	<RedstoneSignal step="6" direction="north" strength="0" />
	<RedstoneSignal step="7" direction="north" strength="0" />
</MicrochipScene>

두 번째 예시에서는 입력이 카운터의 절반 정도까지 도달할 만큼만 ON으로 유지됩니다. 이후 입력이 OFF가 되어 카운터가 원래 상태까지 감소합니다. 따라서 완료 상태에 도달하지 못하며 출력은 계속 OFF입니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,mode:'strong'}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="15" />
	<RedstoneSignal step="2" direction="north" strength="0" />
	<RedstoneSignal step="3" direction="north" strength="0" />
</MicrochipScene>

<br />

### Counter 모드

Counter 모드에서는 첫 번째 입력 포트가 ON인 동안 카운터가 증가합니다. 이 모드에서 카운터가 감소하는 경우는 자동 초기화 옵션 또는 초기화 포트로 카운터를 재설정할 때뿐입니다.

아래 예시는 지연 시간이 100틱(5초)이고 완료 시 자동 초기화되는 Sequencer입니다. 입력이 자주 ON과 OFF로 바뀌지만 입력이 OFF일 때도 카운터가 감소하지 않습니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,mode:'counter',auto_reset:true}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
</MicrochipScene>

아래 예시는 지연 시간이 5틱이고 완료 시 자동 초기화되는 Sequencer입니다. [Pulse Throttler](pulse_throttler.md)로 입력을 한 틱짜리 펄스로 줄여 입력 신호가 한 틱 이상 지속되지 않게 합니다. 이렇게 하면 서로 다른 ON 입력을 다섯 번 받았을 때만 Sequencer가 한 틱 동안 출력 신호를 내보냅니다.

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="pulse_throttler" x="32" y="0" type="pulse_throttler" />
	<Logic name="sequencer" x="64" y="0" type="sequencer" data="{config:{delay:5,mode:'counter',auto_reset:true}}" />
	<Logic name="output" x="112" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="pulse_throttler" toPort="0" />
	<Wire from="pulse_throttler" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
</MicrochipScene>