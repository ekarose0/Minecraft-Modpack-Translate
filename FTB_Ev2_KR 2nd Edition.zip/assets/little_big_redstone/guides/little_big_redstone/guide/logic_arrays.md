---
navigation:
  title: "Logic Arrays"
  icon: "red_logic_array"
  position: 3
item_ids:
  - little_big_redstone:white_logic_array
  - little_big_redstone:light_gray_logic_array
  - little_big_redstone:gray_logic_array
  - little_big_redstone:black_logic_array
  - little_big_redstone:brown_logic_array
  - little_big_redstone:red_logic_array
  - little_big_redstone:orange_logic_array
  - little_big_redstone:yellow_logic_array
  - little_big_redstone:lime_logic_array
  - little_big_redstone:green_logic_array
  - little_big_redstone:cyan_logic_array
  - little_big_redstone:light_blue_logic_array
  - little_big_redstone:blue_logic_array
  - little_big_redstone:purple_logic_array
  - little_big_redstone:magenta_logic_array
  - little_big_redstone:pink_logic_array
---

# Logic Arrays

<FloatingColumn align="right">
	<PaddedBox left="5">
		<Recipe id="little_big_redstone:logic_array/red" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="0">
		<Row gap="1">
			<ItemImage id="red_logic_array" />
			<ItemImage id="orange_logic_array" />
			<ItemImage id="yellow_logic_array" />
			<ItemImage id="lime_logic_array" />
		</Row>
		<Row gap="1">
			<ItemImage id="green_logic_array" />
			<ItemImage id="cyan_logic_array" />
			<ItemImage id="light_blue_logic_array" />
			<ItemImage id="blue_logic_array" />
		</Row>
		<Row gap="1">
			<ItemImage id="purple_logic_array" />
			<ItemImage id="magenta_logic_array" />
			<ItemImage id="pink_logic_array" />
			<ItemImage id="brown_logic_array" />
		</Row>
		<Row gap="1">
			<ItemImage id="white_logic_array" />
			<ItemImage id="light_gray_logic_array" />
			<ItemImage id="gray_logic_array" />
			<ItemImage id="black_logic_array" />
		</Row>
	</PaddedBox>
</FloatingColumn>

Logic Array에는 [logic](logic/introduction.md), [Redstone Bits](redstone_bits.md), [Sticky Notes](sticky_notes.md)를 보관할 수 있습니다. 인벤토리 공간을 절약하면서 회로 제작에 필요한 아이템을 쉽게 꺼낼 수 있습니다.

### 인벤토리

Logic Array에는 슬롯이 28개 있습니다. 손에 들고 **<KeyBind id="key.use" />** 하면 인벤토리를 열 수 있습니다. [Microchip](microchips.md) 메뉴에서는 인벤토리에 있는 모든 Logic Array의 내용물을 볼 수 있습니다. 기본적으로 첫 번째 Logic Array가 표시되며, Microchip 메뉴에서 다른 Logic Array를 좌클릭하면 언제든지 선택할 수 있습니다. 따라서 Logic Array를 여러 개 가지고 있어도 회로 작업 중 모두 이용할 수 있습니다.

아래는 Logic Array 메뉴의 두 가지 예시입니다. 왼쪽은 Logic Array를 단독으로 열었을 때이고, 오른쪽은 Microchip 내부에서 Logic Array를 열었을 때입니다.

<FloatingImage src="assets/logic_array_menu.png" />

<FloatingImage src="assets/logic_array_in_microchip_menu.png" />