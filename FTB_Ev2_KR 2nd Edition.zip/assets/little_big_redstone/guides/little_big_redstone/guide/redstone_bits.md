---
navigation:
  title: "Redstone Bits"
  icon: "redstone_bit"
  position: 2
item_ids:
  - little_big_redstone:redstone_bit
---

# Redstone Bits

<FloatingColumn align="right">
	<PaddedBox left="5">
		<Recipe id="little_big_redstone:redstone_bit" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<ItemImage id="redstone_bit" scale="2" />
</FloatingColumn>

Redstone Bit은 포트 사이를 연결하는 전선을 만드는 데 사용합니다. 포트란 [logic](logic/introduction.md) 부품 측면에 튀어나온 삼각형 부분을 말합니다. 출력 포트는 항상 부품 오른쪽에, 입력 포트는 왼쪽에 있습니다.

입력 포트 하나에는 전선을 정확히 하나만 연결할 수 있습니다. 반면 출력 포트에는 전선을 개수 제한 없이 연결할 수 있습니다. 여러 전선을 하나의 입력 포트에 합치려면 [OR Gate](logic/or_gate.md)를 사용하세요.

Redstone Bit은 일반 레드스톤 가루와 비슷하게 0~15의 신호 세기를 전달합니다. 신호 세기가 0이면 꺼짐(OFF), 1 이상이면 켜짐(ON)으로 간주합니다.

### 전선 사용법

전선을 만들려면 출력 포트를 좌클릭한 다음 연결할 입력 포트를 좌클릭하세요. 연결 중인 전선은 우클릭으로 취소할 수 있습니다. 이미 배치된 전선도 좌클릭하여 회수할 수 있습니다.

전선 하나에는 Redstone Bit이 정확히 하나 필요하며, 입력 포트에 전선 연결을 완료했을 때만 소모됩니다.