---
navigation:
  title: "Sticky Notes"
  icon: "red_sticky_note"
  position: 5
item_ids:
  - little_big_redstone:white_sticky_note
  - little_big_redstone:light_gray_sticky_note
  - little_big_redstone:gray_sticky_note
  - little_big_redstone:black_sticky_note
  - little_big_redstone:brown_sticky_note
  - little_big_redstone:red_sticky_note
  - little_big_redstone:orange_sticky_note
  - little_big_redstone:yellow_sticky_note
  - little_big_redstone:lime_sticky_note
  - little_big_redstone:green_sticky_note
  - little_big_redstone:cyan_sticky_note
  - little_big_redstone:light_blue_sticky_note
  - little_big_redstone:blue_sticky_note
  - little_big_redstone:purple_sticky_note
  - little_big_redstone:magenta_sticky_note
  - little_big_redstone:pink_sticky_note
---

# Sticky Notes

<FloatingColumn align="right">
	<PaddedBox left="5">
		<Recipe id="little_big_redstone:sticky_note/red" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="5">
		<Row gap="1">
			<ItemImage id="red_sticky_note" />
			<ItemImage id="orange_sticky_note" />
			<ItemImage id="yellow_sticky_note" />
			<ItemImage id="lime_sticky_note" />
		</Row>
		<Row gap="1">
			<ItemImage id="green_sticky_note" />
			<ItemImage id="cyan_sticky_note" />
			<ItemImage id="light_blue_sticky_note" />
			<ItemImage id="blue_sticky_note" />
		</Row>
		<Row gap="1">
			<ItemImage id="purple_sticky_note" />
			<ItemImage id="magenta_sticky_note" />
			<ItemImage id="pink_sticky_note" />
			<ItemImage id="brown_sticky_note" />
		</Row>
		<Row gap="1">
			<ItemImage id="white_sticky_note" />
			<ItemImage id="light_gray_sticky_note" />
			<ItemImage id="gray_sticky_note" />
			<ItemImage id="black_sticky_note" />
		</Row>

		<PaddedBox left="2" top="10">
			<GameScene zoom="3.3" padding="0" background="transparent">
				<Entity id="little_big_redstone:sticky_note" x="0.75" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:' ',TextColor:'black',Color:'red',Facing:'north',AttachedFace:'north',Quadrant:'top_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'orange',Facing:'north',AttachedFace:'north',Quadrant:'top_right'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'yellow',Facing:'north',AttachedFace:'north',Quadrant:'top_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'lime',Facing:'north',AttachedFace:'north',Quadrant:'top_right'}" />

				<Entity id="little_big_redstone:sticky_note" x="0.75" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'green',Facing:'north',AttachedFace:'north',Quadrant:'bottom_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:' ',TextColor:'black',Color:'cyan',Facing:'north',AttachedFace:'north',Quadrant:'bottom_right'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'light_blue',Facing:'north',AttachedFace:'north',Quadrant:'bottom_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'blue',Facing:'north',AttachedFace:'north',Quadrant:'bottom_right'}" />
	
				<Entity id="little_big_redstone:sticky_note" x="0.75" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'purple',Facing:'north',AttachedFace:'north',Quadrant:'top_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'magenta',Facing:'north',AttachedFace:'north',Quadrant:'top_right'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:' ',TextColor:'black',Color:'pink',Facing:'north',AttachedFace:'north',Quadrant:'top_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'brown',Facing:'north',AttachedFace:'north',Quadrant:'top_right'}" />
	
				<Entity id="little_big_redstone:sticky_note" x="0.75" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'white',Facing:'north',AttachedFace:'north',Quadrant:'bottom_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'light_gray',Facing:'north',AttachedFace:'north',Quadrant:'bottom_right'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:'',Color:'gray',Facing:'north',AttachedFace:'north',Quadrant:'bottom_left'}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{block_pos:[0,0,0],StickyNote:' ',TextColor:'white',Color:'black',Facing:'north',AttachedFace:'north',Quadrant:'bottom_right'}" />
	
				<IsometricCamera yaw="180" pitch="0" />
			</GameScene>
		</PaddedBox>
	</PaddedBox>
</FloatingColumn>

Sticky Notes는 아이템 액자처럼 월드에 설치할 수 있는 아이템입니다. 블록의 각 면에 색상과 회전 방향을 자유롭게 조합하여 최대 4개까지 붙일 수 있습니다.

Sticky Notes는 [Microchips](microchips.md) 내부에도 [logic](logic/introduction.md)을 배치하듯 설치할 수 있습니다. 이를 이용하면 논리 회로를 더 쉽게 정리할 수 있습니다. Microchip 안에 설치한 Sticky Notes는 우클릭하여 편집할 수 있습니다.

### 읽기 / 편집

Sticky Notes에 적힌 내용을 보려면 해당 메모를 **<KeyBind id="key.use" />** 하세요. 메모가 열리면 Edit 버튼을 눌러 내용을 편집할 수 있습니다. 또는 메모를 **<KeyBind id="key.sneak" />** + **<KeyBind id="key.use" />** 하면 바로 편집 메뉴가 열립니다. Sticky Notes는 부수었다가 다시 설치해도 글과 색상이 유지됩니다.

월드에 설치한 Sticky Notes에는 글을 적어야만 글줄이 표시됩니다.

표지판처럼 벌집(Honeycomb)으로 Sticky Notes를 봉인할 수 있습니다. 봉인된 메모는 더 이상 편집할 수 없습니다. 제작대에서 Sticky Notes와 Honeycomb을 조합하거나, 월드에 설치된 메모를 Honeycomb으로 **<KeyBind id="key.sneak" />** + **<KeyBind id="key.use" />** 하면 됩니다.

### 마크다운

Sticky Notes에 적는 글에는 다음과 같은 기본 마크다운 서식을 사용할 수 있습니다.

\**기울임꼴*\, \*\***굵게**\*\, \_\_<Underlined>밑줄</Underlined>\_\_, 그리고 \~\~~취소선~\~\

논리 부품의 기호는 자리표시자 형식으로 Sticky Notes에 입력할 수 있습니다. 표시하려는 논리 부품의 ID를 꺾쇠괄호(<, >)로 감싸서 적으면 됩니다. 예: \<io\> \<not_gate\> \<and_gate\>

하이픈(\-) 또는 별표(\*) 다음에 공백을 넣어 글머리 기호 목록을 만들 수도 있습니다. 줄 맨 앞에 공백을 여러 개 넣으면 들여쓰기된 항목을 만들 수 있습니다. 글머리 기호 뒤의 공백 다음에 \[ \] 또는 \[x\]를 넣으면 체크박스도 표시할 수 있습니다. 예:

\- 일반 목록 항목

\- \[ \] 체크하지 않은 항목

\- \[x\] 체크한 항목

### 색상 변경

염료를 들고 Sticky Notes를 **<KeyBind id="key.sneak" />** + **<KeyBind id="key.use" />** 하면 글자 색을 변경할 수 있습니다.

물 양동이나 눈덩이로 논리 부품의 색을 제거할 수도 있습니다. 눈덩이는 소모되지만 물 양동이는 소모되지 않습니다.

변경한 글자 색은 월드에 설치된 메모와 읽기/편집 메뉴에 모두 표시됩니다.

### 아이템 표시

월드에 설치한 Sticky Notes를 아이템으로 **<KeyBind id="key.use" />** 하면 메모에 아이템을 올려놓을 수 있습니다. 그러면 글줄 대신 해당 아이템이 표시됩니다. 글자 색이 그 메모 색상의 기본값이 아닌 경우, 아이템도 글자 색에 맞춰 색조가 적용됩니다.

### Note Board

Note Board는 월드의 메모를 바라볼 때 화면에 표시되는 위치를 바꾸거나, 직접 작성한 메모를 화면에 고정할 수 있는 메뉴입니다! "Open Note Board" 단축키(**<KeyBind id="key.little_big_redstone.open_note_board" />**)로 열 수 있습니다. 인벤토리에 있는 Sticky Notes를 메뉴의 원하는 위치에 배치할 수 있습니다. 고정한 메모는 **마우스 오른쪽 버튼**으로 편집할 수 있고, 커서에 들고 있는 메모는 마우스 휠로 크기를 조절할 수 있습니다. Note Board의 메모는 월드별, 플레이어별로 저장됩니다. 플레이어가 사망해도 Note Board의 메모는 사라지지 않습니다.