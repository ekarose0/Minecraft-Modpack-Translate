---
navigation:
  title: Colossal Reactors 가이드
  position: 0
---

# Colossal Reactors

Colossal Reactors는 멀티블록 **핵분열 원자로**, **증기 터빈**, 그리고 관련 기계들을 추가합니다. 이 가이드에서는 게임 안에서 각 블록과 포트, 가공 기계를 **어떻게 사용하는지** 설명합니다.

**첫 번째 원자로 제작:** [시작하기](multiblock/getting_started.md)에서 점검 목록과 구조물 예시를 확인하세요.

## 목차

<SubPages icons={true} />
