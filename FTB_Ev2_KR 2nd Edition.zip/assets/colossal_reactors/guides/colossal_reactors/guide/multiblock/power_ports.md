---
navigation:
  parent: multiblock/multiblock-index.md
  title: Reactor Power Ports
  icon: power_port
  position: 36
item_ids:
  - colossal_reactors:power_port
  - colossal_reactors:high_cond_power_port
categories:
  - ports
---

# Reactor Power Ports

<Row gap="16" fullWidth={true}>
  <BlockImage id="power_port" scale="4" />
  <BlockImage id="high_cond_power_port" scale="4" />
</Row>

**원자로 전력 포트**는 외벽의 **면에만** 설치할 수 있는 부품입니다. 원자로에서 생산한 에너지를 **바깥쪽**의 케이블, 도관, 기계로 보냅니다. **별도의 화면은 없으며**, 외부 면에 케이블을 연결한 뒤 에너지 네트워크에서 흐름을 확인하면 됩니다.

## Reactor Power Port

일반적인 **Reactor Power Port**는 대부분의 모드팩과 보통 수준의 RF 생산량에 충분합니다.

## Reactor High Conduction Power Port

**Reactor High Conduction Power Port**는 틱당 엄청난 RF를 생산하는 초대형 원자로용입니다. 훨씬 많은 에너지를 저장하고 전송할 수 있으며, Draconic Evolution이나 Flux Networks처럼 대용량 전력을 지원하는 모드와 함께 사용할 때 특히 유용합니다(설치된 경우).

**Reactor Power Port**와 상위 등급 재료로 제작합니다. 모드팩의 정확한 조합법은 **JEI**에서 확인하세요.

## 저장 용량 자동 조정

원자로가 **구조를 재검증**할 때(컨트롤러 재부팅 또는 구조 변경 후 검사), 멀티블록의 모든 **전력 포트**가 RF 저장 용량을 조정합니다.

- 목표 용량은 대략 **예상 RF/t × 10**(여유분 포함)이며, 최소 **10,000 RF**입니다.
- **Reactor Power Port**의 최대 용량은 **21억 RF**(2,147,483,647)입니다.
- **High Conduction Power Port**는 **64비트** 저장 방식을 사용하며, 실질적인 최대치는 **9.22×10¹⁸ RF**입니다.

원자로에 더 큰 여유 용량이 필요해지면 **즉시 확장**됩니다. 반대로 줄어들 때는 이미 저장된 에너지가 새 목표 용량에 모두 들어갈 수 있는 경우에만 **축소**되어, 용량 조정으로 에너지가 사라지지 않습니다.

연료, 냉각수, 방열판을 크게 변경했다면 구조를 재검증하여 포트의 저장 용량을 새로운 출력에 맞추세요.

## 공통 기능

- 케이싱의 바깥쪽 면에 설치하며, 포트의 **안쪽**은 원자로 내부를 향해야 합니다.

- 포트 **바깥쪽**에 다른 모드의 호환 에너지 장치를 연결합니다.
