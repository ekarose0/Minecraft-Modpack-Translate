---
navigation:
  parent: multiblock/multiblock-index.md
  title: Reactor Resource Port
  icon: resource_port
  position: 35
item_ids:
  - colossal_reactors:resource_port
categories:
  - ports
---

# Reactor Resource Port

<BlockImage id="resource_port" scale="4" />

**Reactor Resource Port**를 **케이싱**에 설치하면 원자로와 외부 사이에서 아이템이나 액체를 주고받을 수 있습니다.

## 일반적인 배치

### 수동 조작 / RF 전용(자원 포트 불필요)

연료와 폐기물은 [Reactor Controller](reactor_controller.md) GUI에서 직접 처리할 수 있습니다. 다만 [Power Port](power_ports.md)는 최소 1개 필요합니다.

### 자동화: 연료 입력 + 폐기물 출력(**포트 2개**, 컨트롤러와 같은 면)

**자원 포트 두 개를 원자로 컨트롤러와 같은 벽**에 설치합니다. [시작하기](getting_started.md)의 예시에서는 같은 면의 서로 떨어진 위치에 포트를 설치했습니다. 장면의 마름모 표시에 마우스를 올리면 설정 방법이 표시됩니다.

| 포트 위치(예시) | 모드 | 필터 | 이동하는 자원 |
|----------------|------|--------|-------|
| 왼쪽 아래 | **INSERT** | **Fuel** | 고체 연료를 연료봉 **안으로** 넣음 |
| 오른쪽 아래 | **EXTRACT** | **Waste** | **폐기물을 밖으로** 꺼냄 |

같은 면에 **전력 포트**도 추가합니다. 각 자원 포트의 **바깥쪽**에 파이프나 호퍼를 연결하세요.

<GameScene zoom="6" interactive={true} background="transparent">
  <ImportStructure src="/assets/assemblies/minimal_reactor_automation.snbt" />
  <IsometricCamera yaw="200" pitch="28" />
  <BlockAnnotation x="1" y="2" z="0" color="#55ff55">
**예시: 연료 입력** — 포트를 열어 **Insert** → **Fuel** 필터를 선택하고, 필요에 따라 **Solid** / **Liquid**를 활성화합니다. **Insert** 툴팁: *원자로가 고체 연료와 냉각수를 받아들입니다.*
  </BlockAnnotation>
  <BlockAnnotation x="5" y="2" z="0" color="#ffaa55">
**예시: 폐기물 출력** — **Extract** → **Waste** 필터를 선택합니다. **Extract** 툴팁: *원자로에서 핵폐기물과 사용한 냉각수를 추출합니다.*
  </BlockAnnotation>
</GameScene>

### 냉각수 순환 회로(**추가 포트**, 선택 사항)

**능동형 냉각수**를 사용하는 경우([시작하기](getting_started.md)의 설정 2):

- **INSERT** + **Coolant** 필터 — 냉각수를 파이프로 **입력**합니다(*입력: 냉각수 액체만 허용*).
- **EXTRACT** + **Coolant** 필터 — **증기 / 사용한 액체**를 파이프로 **출력**하여 [터빈 시작하기](../turbine/getting_started.md)로 보냅니다(*출력: 사용한 액체 냉각수만 허용*).
- **폐기물 EXTRACT**는 별도의 포트에 유지하세요. EXTRACT 포트 하나가 서로 다른 종류의 액체를 모두 배출한다고 생각하시면 안 됩니다.

## GUI — 버튼과 툴팁

포트 GUI를 열고 **각 조작 버튼에 마우스를 올려** 설명을 확인하세요. 아래는 게임에서 표시되는 기본 영문 명칭을 기준으로 정리한 내용입니다.

### 모드(상단 버튼 — 클릭하여 순환 선택)

| 표시 이름 | 설명 |
|-------|---------|
| **Insert** | 원자로가 고체 연료와 냉각수를 받아들입니다. |
| **Extract** | 원자로에서 핵폐기물과 사용한 냉각수를 추출합니다. |
| **Eject** | 원자로 안에 있는 고체 연료를 내보냅니다. |

### 필터(원자로 전용 — 연료/냉각수 역할을 순환 선택)

현재 **모드**에 따라 사용할 수 있는 필터가 달라집니다. 버튼에 마우스를 올려 현재 필터를 확인하세요.

| 모드 | 필터 이름 | 설명 |
|------|--------------|---------|
| **Insert** | All / Fuel / Coolant | *입력: 연료와 냉각수 모두.* / *입력: 연료만(아이템 또는 액체).* / *입력: 냉각수 액체만.* |
| **Extract** | All / Waste / Coolant | *출력: 고체 폐기물과 액체 냉각수.* / *출력: 고체 폐기물만.* / *출력: 사용한 액체 냉각수만.* |
| **Eject** | Both / Fuel Only / Coolant Only | *배출: 연료봉의 연료 아이템과 냉각수 액체.* / *배출: 연료 아이템만.* / *배출: 냉각수 액체만.* |

### 매체 전환 버튼(클릭하여 허용 — 활성화 시 밑줄 표시)

| 버튼 | 설명 |
|--------|---------|
| **Solid** | 이 포트를 통한 고체 아이템의 이동을 허용하거나 차단합니다. |
| **Liquid** | 이 포트를 통한 액체 이동을 허용하거나 차단합니다. |
| **Gas** | 이 포트를 통한 Mekanism 가스 이동을 허용하거나 차단합니다. |

### 탱크와 비우기

| 조작 요소 | 설명 |
|---------|---------|
| **Liquid tank**(표시줄에 마우스 올리기) | 액체 종류와 양 / 최대 용량(mB) |
| **Gas tank**(표시줄에 마우스 올리기, Mekanism) | 가스 종류와 양 / 최대 용량(mB) |
| 액체 탱크 아래의 **D** | Dump: 내부 액체 탱크를 비웁니다(액체는 버려짐). |
| 가스 탱크 아래의 **D** | Dump: 가스 탱크를 비웁니다(가스는 버려짐). |

- **아이템 슬롯** — 직접 아이템을 넣거나 빼거나, 포트 **바깥쪽**에 연결한 호퍼/파이프를 사용합니다.

모드나 필터를 바꾼 다음에는 [Reactor Controller](reactor_controller.md)에서 **Reboot**를 실행하세요.

## 저장 용량 자동 조정

원자로가 **재검증**될 때 각 자원 포트는 액체/가스 탱크의 용량을 조정합니다(Mekanism 가스 기능이 활성화된 경우 포함).

- 목표 용량 ≈ **해당 포트의 모드와 필터에 따른 예상 mB/t × 10**, 탱크당 최소 **16,000 mB**.
- 대형 원자로를 위한 액체/가스 탱크에는 **고정된 최대 용량이 없습니다.**
- 필요량이 증가하면 용량이 **즉시 확장**되며, 저장된 내용물이 줄어든 목표 용량에 모두 들어갈 때만 **축소**됩니다.
