---
navigation:
  parent: multiblock/multiblock-index.md
  title: Reactor Controller
  icon: reactor_controller
  position: 20
item_ids:
  - colossal_reactors:reactor_controller
categories:
  - multiblock
---

# Reactor Controller

<BlockImage id="reactor_controller" scale="4" />

**Reactor Controller**를 케이싱의 **옆면**(위·아래 제외)에 설치한 다음 **우클릭**하면 화면이 열립니다. 외부 프레임의 케이싱 블록을 컨트롤러로 **교체**하되, 화면은 **바깥쪽**을 향하게 하세요.

멀티블록이 처음이라면 [시작하기](colossal_reactors:multiblock/getting_started.md)부터 확인하세요.

## 작동 방식

- **검증 / 가동**: 처음 화면을 열면 구조 검증이 실행됩니다. 유효한 구조라면 원자로를 **ON**으로 전환할 수 있으며, RF/틱, 연료, 냉각수 정보가 표시됩니다.
- **연료**: 슬롯이 표시될 때 인벤토리와 연료봉 저장 공간 사이에서 연료를 옮길 수 있습니다.
- **냉각수**: 냉각수의 양을 확인하고, 조작 기능이 제공되는 경우 채우거나 배출할 수 있습니다. **RF만 생산**한다면 냉각수 버퍼를 비워 두어도 됩니다.
- **Reboot**: 구조를 다시 검증하고, 구조나 포트 설정을 바꾼 뒤 포트 탱크 용량을 새로 계산합니다.

## 멀티블록을 해체하지 않고 정지하기

외부 레드스톤 신호로 가동을 **억제**하거나 **정지**하려면 [Reactor Redstone Port](redstone_port.md)를 사용하세요. 레드스톤 포트가 **없으면**, 구조가 유효하고 **ON** 상태인 동안 원자로는 계속 작동합니다(레드스톤 차단 기능 없음).

모드팩에서 **안정성** 표시를 활성화했다면 이 화면에 나타납니다. [원자로 불안정성](reactor_instability.md)을 참고하세요.

## 원자로는 유효한데 전력이 생산되지 않나요?

| 확인 사항 | 설명 |
|-------|---|
| 전력 포트와 케이블이 있나요? | RF를 내보내려면 [Power Port](power_ports.md)가 있어야 하고, **바깥쪽**에 에너지를 받을 장치가 연결되어야 합니다. |
| RF 전용 모드인가요? | 냉각수 버퍼가 비어 있으면 액체가 필요하지 않습니다. 물/증기 모드에서는 냉각수와 배출 경로가 필요합니다. |
| 레드스톤 포트가 있나요? | 포트의 모드와 신호가 가동을 허용할 때까지 원자로가 **OFF**로 유지될 수 있습니다. |
| 폐기물이 쌓였나요? | **EXTRACT** [Resource Port](resource_port.md)를 추가하거나 폐기물을 직접 비우세요. |

현재 상태에 관한 설명은 화면의 툴팁과 상태 표시줄에서 확인할 수 있습니다.
