---
navigation:
  parent: multiblock/multiblock-index.md
  title: 원자로 구조
  icon: reactor_casing
  position: 10
item_ids:
  - colossal_reactors:reactor_casing
  - colossal_reactors:reactor_glass
  - colossal_reactors:reactor_rod
  - colossal_reactors:rod_controller
---

# 원자로 구조

## 외벽 만들기

<Row gap="16" fullWidth={true}>
  <BlockImage id="reactor_casing" scale="4" />
  <BlockImage id="reactor_glass" scale="4" />
</Row>

- 불투명한 벽에는 **Reactor Casing**, 내부를 들여다보거나 빛을 통과시키려는 면에는 **Reactor Glass**를 사용합니다.

- 내부가 **완전히 닫힌 상자**가 되도록 하고, 유효한 면은 바깥쪽에만 배치해야 합니다. 마지막 블록으로 봉하기 전에 연료봉, 액체, 내부 부품, 케이싱 포트가 들어갈 공간을 확보하세요.

## Rod Controller

<BlockImage id="rod_controller" scale="4" />

**Rod Controller**는 연료봉 기둥을 만들 위치의 상자 **최상단 외벽 층**에 설치합니다. 그 아래 기둥에 있는 모든 내부 칸은 **Reactor Rod**로 채워야 하며, 그렇지 않으면 구조 검증에 실패합니다. 이 블록은 멀티블록의 연료봉 위치와 구조를 지정합니다. 외벽에 설치하여 GUI를 여는 **Reactor Controller**와는 다른 블록입니다.

## 연료봉

<BlockImage id="reactor_rod" scale="4" />

- **Reactor Rod**는 연료 아이템을 저장합니다. 설계에 맞춰 설치하세요. 인접한 연료봉과 배치 방식에 따라 컨트롤러에 표시되는 **RF 출력**과 **연료 소비량**이 달라집니다.

- **Reactor Controller** 또는 연료 슬롯에 접근하는 자동화 장치를 통해 연료를 넣고 꺼냅니다(컨트롤러 항목 참고).

## 방열판(수동형)

**방열판**은 원자로 **내부 공간**에 배치하는 **수동형** 열 제어 부품입니다. 고체 블록이나 외벽 안에 고정해 둔 **액체 공간**으로 구성할 수 있습니다. 배치 규칙에서는 내부를 채우는 것으로 계산되며, 능동형 냉각수 순환 회로와는 다릅니다.

방열판은 능동형 냉각수의 정의와 함께 **RF 출력** 및 **연료 소비량**을 변화시킵니다. 고급 원자로 동작이 활성화된 경우 과열 관련 수치에도 영향을 줍니다.

방열판은 능동형 냉각수처럼 **소모되지 않습니다.**

## 냉각수(능동형)

**능동형 냉각수**는 순환 회로에서 사용하는 **작동 유체**로, 원자로가 가동되는 동안 **소모**됩니다. 일부 냉각수(예: **증기** 모드의 물)는 원래 생산할 **RF**를 **배출 유체**로 전환합니다. 전환량이 충분하면 연료가 계속 연소해도 **RF가 0까지 떨어질 수 있습니다.** 여기에 데이터팩의 **RF** 및 **소비량** 배율이 추가로 적용됩니다. 다른 냉각수는 이런 전환 없이 RF와 액체 소비량만 조정할 수도 있습니다. 냉각수가 **부족**하면 공급이 회복될 때까지 **RF**가 줄어들 수도 있습니다.

구조에 따라 **Reactor Controller** 또는 호환되는 **액체 처리 포트**를 통해 냉각수를 채우거나 배출하세요.
