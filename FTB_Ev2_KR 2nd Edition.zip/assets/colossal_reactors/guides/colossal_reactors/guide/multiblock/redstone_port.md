---
navigation:
  parent: multiblock/multiblock-index.md
  title: Reactor Redstone Port
  icon: redstone_port
  position: 37
item_ids:
  - colossal_reactors:redstone_port
categories:
  - ports
---

# Reactor Redstone Port

<BlockImage id="redstone_port" scale="4" />

**Reactor Redstone Port**는 원자로의 상태를 **레드스톤**과 연결합니다. 선택한 모드에 따라 비교기 출력을 제공하거나 레드스톤 신호에 반응하도록 설정할 수 있습니다.

## 기능

- **우클릭**하여 설정 화면을 열고 원자로 상태를 레드스톤 신호에 어떻게 반영할지 선택합니다. 각 버튼에 마우스를 올리면 해당 모드에 대한 설명이 나옵니다.

- 원자로 외벽의 **바깥쪽**에서 자동화 장치가 신호를 읽거나 전달할 수 있도록 포트 방향을 맞추세요.
