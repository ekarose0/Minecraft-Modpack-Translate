---
navigation:
  parent: multiblock/multiblock-index.md
  title: Reactor Builder
  icon: reactor_builder
  position: 30
item_ids:
  - colossal_reactors:reactor_builder
categories:
  - multiblock
---

# Reactor Builder

<BlockImage id="reactor_builder" scale="4" />

**Reactor Builder**는 내부 버퍼와 탱크의 재료를 사용하여 **원자로 내부와 외벽**을 자동으로 설치합니다. **Reactor Controller**, **전력 포트**, **자원 포트**는 설치하지 않으므로 [시작하기](getting_started.md)를 참고하세요.

## Build가 설치하는 순서

1. **Casing** 외벽(나중에 수정할 수 있도록 **윗면을 열어 두는 옵션** 사용 가능)
2. 각 연료봉 기둥 위쪽 층의 **Rod Controller**
3. 내부 패턴에 맞춘 **Reactor Rod**
4. 설정된 경우 액체 **방열판**(칸당 1,000 mB)
5. 남은 내부 칸의 고체 **방열판** 블록

## 일반적인 사용 순서

1. 원하는 구조물의 설치 범위에 맞춰 **Builder를 배치**합니다. 방향이 중요합니다.
2. GUI를 열어 **크기**, **연료봉 패턴**, **패턴 모드**, 방열판 종류, 필요한 경우 **윗면 개방**을 설정합니다.
   - **Website** 패턴: 설계 **시드 / URL**을 붙여 넣습니다. 방열판과 연료봉 위치가 시드에 따라 결정되며, 기둥마다 서로 다른 방열판을 섞어 사용할 수도 있습니다. Website 모드에서는 방열판 순환 선택 버튼이 비활성화됩니다.
3. **Preview**(Center 아래)에서 확인합니다. 보라색 테두리는 범위, 노란색은 연료봉 위치, 빨간색은 잘못되었거나 불필요한 블록을 나타냅니다. 상태 경고는 **Center 옆**에 표시됩니다.
4. Builder 버퍼 바로 위의 **Mark Input**을 사용합니다.
   - 버퍼 슬롯마다 사용할 아이템을 지정합니다(버튼 설명 참고).
   - **JEI에서 아이템을 끌어** 버퍼 슬롯에 놓으면 가상 필터를 설정할 수 있습니다. 슬롯을 두 번 클릭하면 필터가 해제됩니다.
5. 버퍼와 탱크에 재료가 충분하면 **Build**를 누릅니다. 빨간색 영역이 보이거나 수정이 필요하면 **Stop**으로 중지합니다.
6. **Builder 블록을 제거하거나 그대로 둡니다.** Builder 자체는 멀티블록의 일부가 아닙니다.
7. 제작이 끝나면 [컨트롤러, 전력 포트, 자원 포트](getting_started.md)를 **직접 설치**합니다. 컨트롤러는 한쪽 벽의 **바깥쪽**, 포트는 **같은 면**의 **유리** 칸을 교체하여 설치합니다.

**Simulation**은 예상 성능과 필요한 재료 수량을 계산합니다. 유효한 Website 시드도 반영되지만, **실제 원자로를 가동하지는 않습니다.**

<GameScene zoom="4" background="transparent">
  <ImportStructure src="/assets/assemblies/minimal_reactor_automation.snbt" />
  <IsometricCamera yaw="210" pitch="25" />
</GameScene>

**완성된** 배치 예시입니다(Builder와 케이싱 프레임에 직접 설치한 포트). 각 부품의 명칭은 [시작하기](getting_started.md)에서 확인하세요.
