---
navigation:
  parent: index.md
  title: 원자로
  icon: reactor_controller
  position: 10
---

# 원자로

원자로는 **Reactor Casing**과 **Reactor Glass**(투명한 면)로 만드는 속이 빈 상자형 구조물입니다. 내부에는 연료를 담는 **Reactor Rods**, 선택 사항인 **방열판**, **냉각수**, 외벽의 **포트**, 그리고 가동과 상태 표시를 담당하는 **Reactor Controller** 하나가 들어갑니다.

**처음 사용하시나요?** 먼저 [시작하기](getting_started.md)의 **완성 예시**를 살펴본 뒤, **설정 1**(RF만 생산) 또는 **설정 2**(냉각수 → 터빈)를 따라 해 보세요.

## 항목

<SubPages icons={true} />
