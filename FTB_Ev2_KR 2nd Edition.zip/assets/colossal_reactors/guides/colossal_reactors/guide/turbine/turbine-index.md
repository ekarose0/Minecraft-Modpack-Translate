---
navigation:
  parent: index.md
  title: 터빈
  icon: turbine_controller
  position: 15
---

# 터빈

**터빈**은 **증기**를 **RF**로 바꾸는 대형 멀티블록 구조물입니다. **Turbine Casing**과 **Turbine Glass**로 외벽을 만들고, 내부에 회전자용 **Rod와 Blade**를 설치한 다음, 위쪽을 금속 저장 블록으로 만든 **코일**로 채웁니다. **포트**를 추가하고 옆면에 **Turbine Controller** 하나를 설치하세요.

대부분의 플레이어는 Colossal Reactors **핵분열 원자로**에서 나온 증기를 터빈으로 공급하고, 전력 포트에서 RF를 꺼냅니다. 후반부에 강력한 전력 공급 체계를 구성할 수 있습니다.

**처음 사용하시나요?** [시작하기](getting_started.md)의 **완성 예시**를 먼저 살펴본 뒤, **설정 1**(독립적인 증기 공급원) 또는 **설정 2**(원자로 냉각수 회로)를 따라 해 보세요.

## 항목

<SubPages icons={true} />
