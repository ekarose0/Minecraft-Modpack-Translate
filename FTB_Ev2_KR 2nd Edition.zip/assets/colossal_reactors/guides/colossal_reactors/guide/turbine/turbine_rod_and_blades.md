---
navigation:
  parent: turbine/turbine-index.md
  title: Rod와 Blade
  icon: turbine_blade
  position: 15
item_ids:
  - colossal_reactors:turbine_blade
  - colossal_reactors:turbine_rod
categories:
  - multiblock
---

# Rod와 Blade

<Row gap="16" fullWidth={true}>
  <ItemImage id="turbine_rod" scale="4" />
  <ItemImage id="turbine_blade" scale="4" />
</Row>

## Blade 설치하기

**Turbine Blade**는 일반 블록처럼 설치하지 않습니다. Blade 아이템을 손에 든 채 **Turbine Rod를 우클릭**하면 해당 Rod에 다음 Blade가 부착됩니다. 클릭할 때마다 인벤토리의 Blade 하나를 사용합니다.

Blade는 Rod를 중심으로 바깥쪽으로 **고리**를 이루며 자라고, 네 방향이 균형을 이루도록 배치됩니다.

1. **첫 단계** — 서로 반대쪽에 Blade 2개.
2. **다음 단계** — 네 방향에 하나씩 Blade 4개.
3. **그다음** — 8개, 12개, 16개… 모드팩의 한도까지 증가합니다(기본적으로 Rod 하나당 최대 **31개 고리**, Blade **124개**).

게임은 다음 고리로 넘어가기 전에 항상 배치가 균형을 이루는 방향을 먼저 선택합니다.

## 월드에 설치된 Blade

- Blade는 **비물질적**입니다. 플레이어가 부딪히거나 손으로 캐거나 직접 회수할 수 없습니다.

- **Rod를 파괴**하면 그 Rod에 달린 모든 Blade가 제거되고 **Rod 블록 위치에 아이템으로 떨어집니다.** 터빈 내부를 돌아다니며 찾을 필요가 없습니다.

## 높이에 따른 Blade 보너스

Rod Controller가 향하는 방향을 따라 Blade를 **층별**로 계산합니다(수직 축의 높이마다 바닥 층이 있다고 생각하면 됩니다).

| 층별 비교 | 효과 |
|--------------------|--------|
| 위층의 Blade 수가 아래층보다 **많음** | 한 단계당 출력 보너스 **+3%**(모드팩 기본값) |
| Blade 수가 같음 | 변화 없음 |
| 위층의 Blade 수가 **적음** | 누적 보너스가 **사라지고**, 감소한 단계마다 약 **−3%** 적용 |

최고의 보너스를 얻으려면 **아래에서 위로 갈수록 고리를 늘리세요.** Builder의 **Efficient** 배치가 이 방식입니다. 모든 층을 처음부터 최대로 채우는 **Productive** 방식은 높이 증가 보너스를 얻지 못하지만, 증기 처리량을 더 빨리 최대로 올릴 수 있습니다.

일부 모드팩에서는 **짝수 고리**(한 층에 Blade 4개, 8개, 12개 등)만 증기 처리 한도에 온전히 반영됩니다. 수치가 예상보다 낮다면 모드 설정을 확인하세요.

## Rod Controller 누락 페널티

터빈에 **Rod 기둥**이 있는데 구획 층의 해당 칸에 [Turbine Rod Controller](turbine_structure.md)가 **없으면**, Blade 효율에 **0.95배(−5%)**가 적용됩니다.

- 축 하나를 사용하는 배치에 컨트롤러 하나가 있다면 페널티가 없습니다.
- 여러 기둥을 사용하는 배치(**HyperFlow**, Website 시드, 수동 건설)에서는 **모든 Rod 기둥**에 컨트롤러를 설치해야 −5% 페널티가 사라집니다.

## Builder의 배치 방식

[Turbine Builder](turbine_builder.md)는 Rod, Blade, Rod Controller를 자동으로 설치할 수 있습니다.

- **Website** — 가져온 설계 시드에 따라 Rod를 배치하고, Blade 고리는 시드의 증가/전체 배치 방식을 따릅니다.
- **Flow** — 중앙에 Rod 기둥 하나를 설치합니다. 두 번째 조작 버튼에서 **Efficient**(층마다 Blade 고리가 **증가**)와 **Productive**(모든 층에 최대 고리)를 전환합니다.
- **HyperFlow** — 설치 범위에 가장 적합한 다중 Rod 격자를 사용합니다(ModDecoded Rod 격자 알고리즘). Builder가 **모든 기둥에 Rod Controller**를 설치합니다. Flow와 동일하게 Efficient / Productive를 전환할 수 있습니다.
- **Custom / None** — 회전자 부품 없이 외벽만 설치합니다(Custom은 코일도 설치).

직접 Blade 아이템을 설치할 때도 Builder와 같은 고리 순서를 따릅니다.
