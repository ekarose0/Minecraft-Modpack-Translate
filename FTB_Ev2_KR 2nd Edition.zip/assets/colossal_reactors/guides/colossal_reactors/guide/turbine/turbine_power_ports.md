---
navigation:
  parent: turbine/turbine-index.md
  title: Turbine Power Ports
  icon: turbine_power_port
  position: 36
item_ids:
  - colossal_reactors:turbine_power_port
  - colossal_reactors:turbine_high_cond_power_port
categories:
  - ports
---

# Turbine Power Ports

<Row gap="16" fullWidth={true}>
  <BlockImage id="turbine_power_port" scale="4" />
  <BlockImage id="turbine_high_cond_power_port" scale="4" />
</Row>

전력 포트는 터빈에서 생산한 **RF**를 **바깥쪽**의 케이블과 기계로 내보냅니다. **별도의 GUI는 없으며**, 바깥쪽 면에 연결한 뒤 에너지 네트워크에서 전력 흐름을 확인하면 됩니다.

## Turbine Power Port

일반적인 **Turbine Power Port**는 대부분의 모드팩과 보통 수준의 RF 생산량에 충분합니다.

## Turbine High Conduction Power Port

**High Conduction** 변형은 틱당 엄청난 RF를 생산하는 **초대형** 터빈용입니다. 훨씬 많은 에너지를 저장하고 전송할 수 있으며(모드 설정에서 조정 가능), Draconic Evolution이나 Flux Networks처럼 대용량 전력을 지원하는 모드와 함께 사용하기에 적합합니다(설치된 경우).

**Turbine Power Port**와 상위 등급 재료로 제작합니다. 정확한 조합법은 **JEI**에서 확인하세요.

## 저장 용량 자동 조정

터빈이 **재검증**될 때마다 모든 **전력 포트**가 예상 터빈 출력에 맞춰 RF 저장 용량을 조정합니다.

- 목표 용량은 대략 **예상 RF/t × 10**이며, 최소 **10,000 RF**입니다.
- **Turbine Power Port**의 최대 용량은 **21억 RF**입니다.
- **High Conduction** 변형의 최대 용량은 **9.22×10¹⁸ RF**(64비트 버퍼)입니다.

출력이 증가하면 용량이 즉시 확장됩니다. 반대로 줄어들 때는 저장된 에너지가 새로운 목표 용량에 모두 들어갈 수 있는 경우에만 축소됩니다.

## 두 변형의 공통 사항

- **케이싱 면**에 설치하며, 안쪽은 터빈 내부를 향해야 합니다.

- **바깥쪽**에 에너지 케이블이나 기계를 연결합니다.

출력은 증기, 코일, 날개에 따라 달라집니다. [증기, RF와 코일](turbine_generation_and_coils.md)을 참고하세요.
