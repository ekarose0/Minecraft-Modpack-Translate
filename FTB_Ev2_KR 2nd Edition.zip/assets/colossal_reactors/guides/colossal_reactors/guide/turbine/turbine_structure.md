---
navigation:
  parent: turbine/turbine-index.md
  title: 터빈 구조
  icon: turbine_casing
  position: 10
item_ids:
  - colossal_reactors:turbine_casing
  - colossal_reactors:turbine_glass
  - colossal_reactors:turbine_rod_controller
categories:
  - multiblock
---

# 터빈 구조

## 외벽 만들기

<Row gap="16" fullWidth={true}>
  <BlockImage id="turbine_casing" scale="4" />
  <BlockImage id="turbine_glass" scale="4" />
</Row>

- 단단한 벽에는 **Turbine Casing**, 내부를 볼 수 있는 면에는 **Turbine Glass**를 사용합니다.

- **완전히 닫힌 상자**를 만드세요. 기본 최대 크기는 **65×65×65**입니다(대형 원자로와 비슷하며, 모드팩에 따라 더 작을 수 있습니다).

- 내부에는 **Rod와 Blade**, **코일** 구역을 위한 공간이 필요합니다. 벽에는 **포트**를, 외부 **옆면**(북·남·동·서쪽, 위·아래 제외)에는 **Turbine Controller** 하나를 설치합니다.

## Rod Controller

<ItemImage id="turbine_rod_controller" scale="4" />

**Turbine Rod Controller**는 **구획 층(Closure deck)**에 설치합니다. 이 층은 아래쪽의 **회전자**와 위쪽의 **코일 영역**을 구분하는 케이싱 층입니다. 컨트롤러는 회전축의 방향을 지정하며, Heating Coil처럼 **여섯 방향**으로 설치할 수 있습니다.

- **최소 1개**가 필요합니다. Rod 기둥마다 **컨트롤러 하나씩** 설치할 수 있으며, 각 기둥의 맨 위 Rod **바로 위쪽 구획 칸**에 배치합니다.
- 모든 컨트롤러는 **같은 구획 평면**에 있고 **같은 방향**을 향해야 합니다.
- 컨트롤러를 외벽의 **가장자리**에 설치하면 안 됩니다.

Rod 기둥이 있는데 해당 구획 칸에 컨트롤러가 **없다면**, Blade 효율에 **−5%** 페널티가 적용됩니다([Rod와 Blade](turbine_rod_and_blades.md) 참고). **모든 기둥**에 컨트롤러를 설치하면 페널티가 사라집니다.

- Rod는 컨트롤러 축과 일치해야 합니다. 가능하다면 터빈 구조를 검사할 때 방향이 잘못된 Rod가 수정됩니다.

- 이것은 외벽에 설치하여 메인 화면을 여는 **Turbine Controller**와는 **다른 블록**입니다.

## Turbine Rod

<ItemImage id="turbine_rod" scale="4" />

- **Turbine Rod**는 회전축을 구성하며, Rod Controller의 방향(위/아래 또는 벽을 따라 수평)을 따릅니다.

- **바닥이나 천장을 우클릭**하면 **수직** 축을, **벽을 우클릭**하면 해당 벽을 따라 **수평** 축을 설치합니다.

- Blade 아이템을 사용해 **Blade를 부착**합니다. [Rod와 Blade](turbine_rod_and_blades.md)를 참고하세요. Rod를 부수면 해당 위치에 모든 Blade가 아이템으로 떨어집니다.

## 영역별 구성 요약

| 영역 | 위치 | 설치할 것 |
|------|--------|-------------------|
| **회전자(Rotor)** | 코일 아래쪽의 주 내부 공간 | Rod, Blade |
| **구획 층(Closure deck)** | 회전자와 코일 사이 | Casing + Rod 기둥 위의 Rod Controller |
| **코일(Coils)** | 내부 상단 층 | 금속 저장 블록(금, 구리 등) |
| **포트(Ports)** | 케이싱 면 | 증기 입력, RF 출력, 레드스톤 |

코일 층수(기본 **3**)는 [Turbine Builder](turbine_builder.md)에서 설정합니다. RF와 증기 수치는 [증기, RF와 코일](turbine_generation_and_coils.md)을 참고하세요.
