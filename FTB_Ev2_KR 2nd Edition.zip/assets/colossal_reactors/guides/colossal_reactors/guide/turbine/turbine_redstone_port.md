---
navigation:
  parent: turbine/turbine-index.md
  title: Turbine Redstone Port
  icon: turbine_redstone_port
  position: 37
item_ids:
  - colossal_reactors:turbine_redstone_port
categories:
  - ports
---

# Turbine Redstone Port

<BlockImage id="turbine_redstone_port" scale="4" />

**Turbine Redstone Port**는 터빈의 상태를 **레드스톤**과 연결합니다. 선택한 모드에 따라 비교기 출력을 제공하거나 레드스톤 신호에 반응하도록 설정할 수 있습니다.

## 기능

- **우클릭**하여 터빈 상태를 레드스톤에 어떻게 반영할지 선택합니다. 각 버튼에 마우스를 올리면 해당 모드에 대한 설명이 나옵니다.

- 멀티블록을 해체하지 않고 외부에서 터빈을 **정지하거나 일시 중지**할 수 있습니다. [Reactor Redstone Port](../multiblock/redstone_port.md)와 같은 원리입니다.

- 외벽 **바깥쪽**의 레드스톤 가루, 비교기, 기계 등이 포트에 접근할 수 있도록 설치하세요.
