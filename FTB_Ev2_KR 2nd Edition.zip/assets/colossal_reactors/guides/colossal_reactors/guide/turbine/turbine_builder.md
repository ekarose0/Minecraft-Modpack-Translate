---
navigation:
  parent: turbine/turbine-index.md
  title: Turbine Builder
  icon: turbine_builder
  position: 30
item_ids:
  - colossal_reactors:turbine_builder
categories:
  - multiblock
---

# Turbine Builder

<BlockImage id="turbine_builder" scale="4" />

**Turbine Builder**는 자체 인벤토리에 있는 아이템을 사용하여 터빈을 자동으로 건설합니다. [Reactor Builder](../multiblock/reactor_builder.md)와 비슷한 기계입니다.

## 일반적인 사용 순서

1. 터빈 외벽이 시작될 면에 **Builder를 배치**합니다.
2. 화면을 열어 **가로, 높이, 깊이**를 설정합니다(모드팩의 크기 제한 내에서).
3. Builder에 **Casing**, **Glass**, **Rod Controller**(패턴에 필요한 연료봉 기둥마다 하나), **Rod**, **Blade**, 코일로 사용할 **금속 저장 블록**을 채웁니다.
4. **배치 방식**을 선택합니다([Rod와 Blade](turbine_rod_and_blades.md) 참고).
   - **Website** — 설계 입력란에 **시드 / URL**을 붙여 넣습니다. 연료봉 위치와 Website 모드의 코일 선택은 해당 설계를 따릅니다.
   - **Flow** — 중앙의 축 하나를 사용합니다. 패턴 선택 줄 아래에서 **Efficient**(날개 고리가 위로 갈수록 증가하며, 높이 보너스 **+3%** 가능)와 **Productive**(모든 층에 최대 고리 배치)를 전환할 수 있습니다.
   - **HyperFlow** — 설치 범위에 가장 적합한 다중 축 격자를 사용합니다(홀수×홀수 또는 엇갈린 배치, ModDecoded Rod 격자와 같은 방식). **모든 기둥에 Rod Controller**를 배치합니다. Flow와 마찬가지로 Efficient / Productive를 전환할 수 있으며, 고리 크기는 해당 배치의 최적값으로 제한됩니다.
   - **Custom / None** — 회전자 부품 없이 외벽만 설치합니다(Custom은 코일도 설치). 패턴 줄 아래의 긴 버튼은 비어 있고 비활성화됩니다.
5. **코일 종류**(지원되는 금속을 순환 선택, Website에서도 변경 가능)와 **코일 층수**(Preview 아래 옆에 있는 넓은 버튼)를 선택합니다.
6. **Preview**(Center 아래, 같은 너비)와 **Simulation** 패널에서 RF/t, 증기량, 재료 수량을 확인합니다. 경고는 **Center 옆**에 표시됩니다.
7. Builder 버퍼 바로 위의 **Mark Input**을 사용합니다.
   - Mark Input이 켜져 있을 때 버퍼 슬롯을 클릭하여 건설 단계에서 해당 슬롯이 받을 아이템을 지정합니다.
   - **JEI에서 아이템을 끌어** 버퍼 슬롯에 놓으면 가상 필터를 설정할 수 있습니다. 슬롯을 두 번 클릭하면 해제됩니다.
8. 준비가 끝나면 **Build**를 누릅니다.

건설 순서: **외벽** → **구획을 나누는 층(Closure deck)** → **Rod Controller**(기둥마다 하나) → **Rod** → **Blade** → 상단 내부 층의 **코일 블록**.

Builder는 외부의 **Turbine Controller**나 포트를 설치하지 않습니다. 건설이 끝난 뒤 직접 추가하세요.

## Simulation 패널

예상 **RF/t**와 **증기량**, 코일 및 날개 보너스(기둥에 Rod Controller가 없을 때의 **−5%** 페널티 포함), **재료 목록**을 표시합니다. 유효한 Website 설계 시드도 계산에 반영됩니다. 버전에 따라 버튼 이름이 다를 수 있으므로 작업 중 화면의 툴팁을 확인하세요.
