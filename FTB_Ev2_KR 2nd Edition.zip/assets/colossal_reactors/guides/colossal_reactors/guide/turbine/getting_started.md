---
navigation:
  parent: turbine/turbine-index.md
  title: 시작하기
  icon: getting_started
  position: 5
item_ids:
  - colossal_reactors:turbine_casing
  - colossal_reactors:turbine_glass
  - colossal_reactors:turbine_rod
  - colossal_reactors:turbine_rod_controller
  - colossal_reactors:turbine_blade
  - colossal_reactors:turbine_power_port
  - colossal_reactors:turbine_resource_port
  - colossal_reactors:turbine_builder
categories:
  - multiblock
---

# 시작하기 — 첫 번째 터빈

내부에 회전자와 코일을 갖춘 밀폐된 터빈 외벽을 만든 뒤, 아래의 두 설정 중 하나를 선택하세요. 예시 장면을 회전하면 각 면의 구조를 확인할 수 있습니다.

## 외벽 배치

- **바닥과 지붕**: **Turbine Casing**으로 막힌 프레임을 만듭니다.
- **수직 모서리**: 네 모서리에 **Turbine Casing** 기둥을 세웁니다(y=1…5).
- **서쪽, 동쪽, 남쪽 벽**: 각 면에 **5×5 Turbine Glass** 패널을 배치합니다.
- **구획 벽**: **Rod Controller 높이**(예시에서는 y=3)에 설치합니다. 내부에는 **Turbine Casing** 고리를 만들고, 옆면에는 **케이싱 띠**를 둘러야 합니다. 이 층이 세 면의 5×5 유리 패널 중 한 줄을 **가로지릅니다.**
- **컨트롤러가 있는 면**(예시의 북쪽): **Turbine Controller**는 **블록 하나만 외부로 돌출**되게 설치합니다. 해당 면에서 포트가 없는 칸은 **Turbine Glass**로 채웁니다. **포트는 유리를 대체**하여 설치하며, [원자로 예시](../multiblock/getting_started.md)와 같은 방식입니다.
- **코일 영역**(구획 위): 내부 최상단의 **두 개 층**(예시에서는 y=4–5)에 **구리 블록**을 채웁니다. 지붕 케이싱 바로 아래입니다.
- **회전자 영역**(구획 아래): **Rod 두 구간**(y=1–2)을 설치합니다. 아래쪽 고리에는 **Blade 4개**, 위쪽 구간에는 두 고리에 **Blade 8개**를 부착합니다. **Turbine Rod Controller**는 구획 층(y=3)에 설치합니다.

[Turbine Builder](turbine_builder.md)는 외벽, 회전자, 코일을 설치하지만 **컨트롤러와 포트는 설치하지 않습니다.**

## 코일

**코일 영역**은 구획 벽보다 위쪽, 지붕 아래의 **상단 내부 공간**입니다. 구리, 금, 네더라이트, 일렉트럼 등 모드에서 인식하는 **금속 저장 블록**으로 채웁니다.

| | 설명 |
|---|---|
| **역할** | 증기에서 얻는 **RF**를 증가시킵니다(아래 RF 공식의 `coil strength`). |
| **위치** | 구획 층 **위쪽**의 내부 층. 회전자나 Blade가 있는 공간이 아닙니다. |
| **사용할 블록** | 일반적인 **금속 저장 블록**(예: 구리 블록). 강도와 상한은 **JEI**에서 확인하세요. |
| **사용하지 말 것** | 원자로의 **Heating Coil** 블록. 이는 별도의 기계 부품입니다. |
| **빈 칸** | 약한 코일로 계산됩니다(기본 강도 약 **30%**). |
| **층수** | 예시는 **두 개 층**을 사용합니다. [Turbine Builder](turbine_builder.md)에서 층수를 설정할 수 있습니다. |

금속을 섞어 사용해도 됩니다. 터빈은 전체 코일 영역의 **평균 강도**를 사용합니다. 자세한 수치는 [증기, RF와 코일](turbine_generation_and_coils.md)을 참고하세요.

## 완성 예시

<GameScene zoom="4" interactive={true} background="transparent">
  <ImportStructure src="/assets/assemblies/minimal_turbine.snbt" />
  <IsometricCamera yaw="225" pitch="28" />
</GameScene>

| 북쪽 면(컨트롤러 벽) | 블록 |
|------------------------------|-------|
| 바깥쪽 중앙(블록 하나만 돌출) | [Turbine Controller](turbine_controller.md) |
| 왼쪽 아래 / 오른쪽 아래(떨어져 배치) | Turbine Resource Port ×2 |
| 컨트롤러 바로 아래 한 칸, 중앙 기둥 | Turbine Power Port |
| 서쪽 / 동쪽 / 남쪽 벽 | **5×5** 유리(구획 층의 Rod Controller 높이에서 한 줄이 나뉨) |

원자로 예시와 마찬가지로 컨트롤러가 있는 면에 **자원 포트 2개 + 전력 포트 1개**를 설치합니다(원자로 예시와 동일한 위치).

## 효율 — RF 출력에 영향을 주는 요소

터빈이 **올바르게 형성**되고 **가동 중**이라면 틱당 RF 생산량은 다음과 같이 계산됩니다.

**RF/t** ≈ 소비한 증기량 × **1mB당 RF** × **코일 강도** × **날개 배치 보너스**

자세한 계산은 [증기, RF와 코일](turbine_generation_and_coils.md)을 참고하세요. 주요 요소는 다음과 같습니다.

- **증기 공급량** — Blade 수와 배치에 따라 소비 한도가 정해집니다. 균형 잡힌 고리가 많을수록 틱당 증기 처리량이 증가합니다.
- **코일 블록** — **상단 내부의 두 개 층**에 배치한 금속 저장 블록(구리, 금, 네더라이트 등)입니다. 빈 칸은 약한 코일(강도 약 30%)로 계산됩니다. 블록별 수치는 JEI에서 확인하세요.
- **날개 높이 보너스** — 구획 층에 가까워질수록 고리 크기가 커지면 Blade가 증가하는 층마다 **+3%** 보너스를 얻습니다. 반대로 고리가 작아지면 **−3%** 페널티가 적용됩니다. 다중 기둥 구조에서는 **모든 기둥에 Rod Controller**가 있어야 하며, 하나라도 빠지면 **−5%**가 적용됩니다. [Rod와 Blade](turbine_rod_and_blades.md)를 참고하세요.
- **유효한 구조** — 외벽, 코일, 구획 층의 Rod Controller, 포트가 모두 구조 검증을 통과해야 전력 생산이 시작됩니다.

## 설정 1: 간단한 전력 생산(독립적인 증기 공급원)

탱크, 다른 모드 또는 크리에이티브 기능 등으로 **증기를 이미 확보**했고, **터빈에서 RF만 생산**하려는 경우에 사용합니다.

1. 외벽, 회전자(Rod + Blade), 코일, **Rod Controller**를 설치하거나 [Turbine Builder](turbine_builder.md)를 사용합니다.
2. 예시처럼 한쪽 면에 **컨트롤러 + 포트 3개**를 설치합니다. 컨트롤러는 **바깥쪽**에, 포트는 **같은 면의 서로 떨어진 위치**에 둡니다.
3. **자원 포트 2개**를 설정합니다. 하나는 **INSERT**(증기 입력), 다른 하나는 **EXTRACT**(물 / 사용한 액체 출력)입니다. 두 포트 모두 **바깥쪽**에 파이프를 연결합니다.
4. **전력 포트 바깥쪽**을 에너지 수신 장치에 연결합니다.
5. 컨트롤러를 열어 **valid** 상태를 확인하고 **ON**으로 전환합니다. **RF/t**와 증기 소비량을 확인하세요.

| 포트 위치(예시) | 모드 | 역할 |
|------|------|------|
| 컨트롤러 면의 왼쪽 아래 | Resource Port — **INSERT** | 증기 **입력** |
| 컨트롤러 면의 오른쪽 아래 | Resource Port — **EXTRACT** | 물 / 배출 유체 **출력** |
| 컨트롤러 바로 아래 한 칸, 중앙 기둥 | Power Port | RF **출력** |

**자원 포트 2개**의 GUI에서 설정하고, 각 버튼에 마우스를 올려 설명을 확인하세요([전체 목록](turbine_resource_port.md)). 포트 모드나 회전자 배치를 바꾼 뒤에는 **Reboot**를 실행하세요.

## 설정 2: 냉각수 순환 회로(원자로에서 만든 증기)

[원자로 시작하기 — 설정 2(냉각수)](../multiblock/getting_started.md)와 함께 사용합니다. 핵분열 원자로에서 **증기**를 만들고, 터빈에서 이를 **더 많은 RF**로 변환합니다.

1. 설정 1과 동일하게 터빈을 만듭니다(외벽, 회전자, 코일, 컨트롤러, **한쪽 면**의 포트).
2. 원자로에서 **설정 2**를 적용합니다. 컨트롤러에 냉각수를 설정하고, **원자로 컨트롤러와 같은 면**에 냉각수 **INSERT**와 증기/사용한 액체 **EXTRACT** 포트를 설치합니다.
3. 원자로 **EXTRACT** 포트에서 터빈 자원 포트의 **INSERT**로 **증기**를 공급합니다. 터빈 자원 포트의 **EXTRACT**에서 나온 **물**은 탱크에 저장하거나 원자로 냉각수 회로로 되돌립니다.
4. 터빈 **전력 포트**에서 **RF**를 꺼냅니다. 원자로 전력 포트는 예비 RF 출력용으로 사용할 수 있습니다.

원자로의 증기 생산량에 맞춰 터빈 크기와 Blade 수를 조정하세요. [증기, RF와 코일](turbine_generation_and_coils.md)을 참고하세요. 증기가 밀려 쌓인다면 저장 용량이나 터빈 크기를 늘리거나 Blade를 추가합니다.

## 점검 목록

1. 밀폐된 외벽: 케이싱 바닥/지붕, 모서리 기둥, 세 면의 **5×5 유리**(구획 층 **y=3**에서 한 줄이 끊김). 컨트롤러 면은 **유리 + 포트**로 구성합니다.
2. 구획 아래의 올바른 **회전자**: **Rod 블록 2개**(y=1–2), 아래 고리의 **Blade 4개**, 위 구간의 **Blade 8개**(고리 2개). 상단에는 **코일 층 2개**(y=4–5, 예: 구리 블록)를 배치합니다.
3. 옆면에 **[Turbine Controller](turbine_controller.md) 하나**를 상자 **바깥쪽**으로 돌출되게 설치합니다.
4. 컨트롤러 면에 **자원 포트 2개 + 전력 포트 1개**를 설치합니다(같은 면이라면 위치는 자유).
5. **설정 1**(임의의 증기 공급원) 또는 **설정 2**(원자로 냉각수 회로)를 선택합니다.
6. **Redstone Port**는 선택 사항입니다.

## Turbine Builder(선택 사항)

1. Builder는 **외벽 + 회전자 + 코일**만 설치합니다.
2. **Stop**으로 제작을 중단하거나 완료한 뒤, 예시처럼 **한쪽 면**에 컨트롤러(바깥쪽)와 포트를 추가합니다.
3. 컨트롤러에서 구조를 검증합니다.

## 터빈이 작동하지 않나요?

| 증상 | 예상 원인 |
|---------|----------------|
| 상태가 **Invalid** | 외벽, Rod, Blade, 코일 또는 Rod Controller를 수정하세요(상태 표시줄 참고). |
| **ON**인데 RF/t가 0 | 증기가 공급되지 않거나 전력 포트 또는 에너지 수신 장치가 없습니다. |
| 증기 공급량에 비해 RF가 적음 | 증기량에 비해 Blade/코일이 부족합니다. [Rod와 Blade](turbine_rod_and_blades.md)를 참고하세요. |
| 증기가 소비되지 않음 | 자원 포트가 **INSERT**가 아니거나 파이프가 잘못된 면에 연결되었습니다. |
| 물이 쌓임 | **EXTRACT** 자원 포트가 없거나 바깥쪽에 탱크/파이프가 연결되지 않았습니다. |

## 함께 보기

- [Turbine Builder](turbine_builder.md)
- [Turbine Controller](turbine_controller.md)
- [Turbine Resource Port](turbine_resource_port.md)
- [Turbine Power Ports](turbine_power_ports.md)
- [원자로 시작하기 — 냉각수 설정](../multiblock/getting_started.md)
- [증기, RF와 코일](turbine_generation_and_coils.md)
