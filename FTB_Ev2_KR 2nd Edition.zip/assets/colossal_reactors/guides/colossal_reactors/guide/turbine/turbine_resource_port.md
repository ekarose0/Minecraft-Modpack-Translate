---
navigation:
  parent: turbine/turbine-index.md
  title: Turbine Resource Port
  icon: turbine_resource_port
  position: 35
item_ids:
  - colossal_reactors:turbine_resource_port
categories:
  - ports
---

# Turbine Resource Port

<BlockImage id="turbine_resource_port" scale="4" />

**Turbine Resource Port**를 케이싱에 설치하면 파이프나 탱크와 터빈 사이에서 **증기**, **물**, 기타 모드팩에서 허용한 액체를 주고받을 수 있습니다.

일반적인 배치는 [Turbine Controller](turbine_controller.md)와 같은 면에 **자원 포트 2개 + 전력 포트 1개**를 설치하는 것입니다. [시작하기](getting_started.md)를 참고하세요. 아래 장면의 마름모 표시에 마우스를 올리면 설명이 나옵니다.

<GameScene zoom="6" interactive={true} background="transparent">
  <ImportStructure src="/assets/assemblies/minimal_turbine.snbt" />
  <IsometricCamera yaw="200" pitch="28" />
  <BlockAnnotation x="1" y="2" z="0" color="#55ffff">
**예시: 증기 입력** — **Insert** 모드, **Liquid** 활성화. 툴팁: *증기(및 허용된 다른 액체)를 터빈으로 끌어옵니다.*
  </BlockAnnotation>
  <BlockAnnotation x="5" y="2" z="0" color="#5599ff">
**예시: 물 출력** — **Extract** 모드, **Liquid** 활성화. 툴팁: *물 또는 배출 액체를 파이프로 내보냅니다.*
  </BlockAnnotation>
</GameScene>

[핵분열 원자로](../multiblock/getting_started.md)(또는 다른 증기 공급원)에서 나온 증기를 **INSERT** 포트로 공급합니다. **EXTRACT** 포트로 **물 / 배출 유체**를 꺼냅니다. 터빈이 사용할 수 있는 양은 날개에 따라 달라집니다. [증기, RF와 코일](turbine_generation_and_coils.md)을 참고하세요.

## GUI — 버튼과 툴팁

터빈 포트는 원자로 포트와 비슷한 화면을 사용하지만 **Solid 행**과 **Fuel/Coolant 필터**가 없습니다. 게임에서 각 조작 요소에 마우스를 올리면 아래와 같은 기본 설명이 표시됩니다.

### 모드(상단 버튼 — 클릭하여 순환 선택)

| 표시 이름 | 설명 |
|-------|---------|
| **Insert** | 증기(및 허용된 다른 액체)를 터빈으로 끌어옵니다. |
| **Extract** | 물 또는 배출 액체를 파이프로 내보냅니다. |
| **Eject** | 포트 탱크에 저장된 액체를 바깥쪽으로 배출합니다. |

### 매체 전환 버튼(클릭하여 허용 — 활성화 시 밑줄 표시)

| 버튼 | 설명 |
|--------|---------|
| **Liquid** | 이 포트를 통한 액체 이동을 허용하거나 차단합니다. |
| **Gas** | 이 포트를 통한 Mekanism 가스 이동을 허용하거나 차단합니다. |

### 탱크와 비우기

| 조작 요소 | 설명 |
|---------|---------|
| **Liquid tank**(표시줄에 마우스 올리기) | 액체 종류와 양 / 최대 용량(mB) |
| **Gas tank**(표시줄에 마우스 올리기, Mekanism) | 가스 종류와 양 / 최대 용량(mB) |
| 액체 탱크 아래의 **D** | Dump: 내부 액체 탱크를 비웁니다(액체는 버려짐). |
| 가스 탱크 아래의 **D** | Dump: 가스 탱크를 비웁니다(가스는 버려짐). |

파이프와 탱크는 **바깥쪽**에 연결해야 하며, 포트의 **안쪽**은 터빈 내부를 향해야 합니다.

모드를 바꾼 다음에는 [Turbine Controller](turbine_controller.md)에서 **Reboot**를 실행하세요.

## 저장 용량 자동 조정

터빈이 **재검증**될 때 포트의 액체 탱크 용량이 예상 **증기 mB/t × 10**을 기준으로 조정됩니다. 최소 용량은 **16,000 mB**이며 **고정된 최대 용량은 없습니다.** 필요량이 증가하면 즉시 확장되고, 저장된 증기가 더 작은 용량에도 모두 들어갈 때만 축소됩니다.
