---
navigation:
  parent: turbine/turbine-index.md
  title: Turbine Controller
  icon: turbine_controller
  position: 20
item_ids:
  - colossal_reactors:turbine_controller
categories:
  - multiblock
---

# Turbine Controller

<BlockImage id="turbine_controller" scale="4" />

터빈이 **올바르게 완성된 상태**에서 컨트롤러를 **우클릭**하면 메인 화면이 열립니다.

멀티블록이 처음이라면 [시작하기](colossal_reactors:turbine/getting_started.md)부터 확인하세요.

## 작동 방식

- 터빈을 **시작하거나 정지**하고, 화면에서 **RF 출력**, **증기 소비량**, 효율을 확인할 수 있습니다.

- 터빈은 가동 중에도 주기적으로 구조를 다시 검사합니다. 구조가 손상되면 정지하고 원인을 알려 줍니다(액션바와 GUI 메시지).

- 일반적으로 멀티블록 하나에는 터빈 컨트롤러를 **하나만** 설치할 수 있습니다.

- 컨트롤러는 외벽의 **옆면**(월드의 북·남·동·서쪽)에 설치해야 합니다. 위쪽이나 아래쪽에는 설치할 수 없습니다. 이는 내부 **회전축**의 방향과는 별개입니다.

## 액체와 전력

- **증기**는 [Turbine Resource Port](turbine_resource_port.md)를 통해 공급합니다.

- **RF**는 [Turbine Power Port](turbine_power_ports.md)를 통해 내보냅니다.

- 사용한 증기는 보통 **물**(또는 모드팩에서 정의한 다른 액체)로 바뀝니다. [증기, RF와 코일](turbine_generation_and_coils.md)을 참고하세요.

## 블록을 해체하지 않고 정지하기

[**Turbine Redstone Port**](turbine_redstone_port.md)를 사용하면 구조를 유지한 채 외부 레드스톤 신호로 터빈을 정지할 수 있습니다. [Reactor Redstone Port](../multiblock/redstone_port.md)와 같은 역할입니다.

컨트롤러에 표시되는 값은 **날개 배치**와 **코일 블록**에 따라 달라집니다. 화면만 조작하지 말고 터빈 내부의 부품도 조정하세요.
