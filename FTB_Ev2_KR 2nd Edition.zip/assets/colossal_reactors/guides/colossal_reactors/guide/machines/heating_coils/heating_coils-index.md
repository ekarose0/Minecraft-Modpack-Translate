---
navigation:
  parent: machines/machines-index.md
  title: Heating coils
  icon: heating_coil_energy_off
  position: 50
---

# Heating coils

Heating coils는 **데이터팩에 정의된 조합법**에 따라 작동하는 특수 블록입니다. 코일 종류에 따라 **아이템**, **액체**, **에너지** 또는 이들의 조합을 소비하며, 작동 중에는 외형이 **꺼짐**에서 **켜짐** 상태로 바뀝니다.

<SubPages icons={true} />
