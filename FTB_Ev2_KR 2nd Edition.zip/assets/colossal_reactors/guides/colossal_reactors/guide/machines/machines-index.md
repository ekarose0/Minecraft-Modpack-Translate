---
navigation:
  parent: index.md
  title: 기계
  icon: melter
  position: 20
---

# 기계

원자로 외벽에 설치하는 포트와는 별개로 작동하는 독립형 가공 블록입니다.

<SubPages icons={true} />
