---
navigation:
  parent: machines/machines-index.md
  title: Melter
  icon: melter
  position: 40
item_ids:
  - colossal_reactors:melter
categories:
  - processing
---

# Melter

<BlockImage id="melter" scale="4" />

**Melter**는 고체 재료를 녹여 액체로 바꿉니다. 이렇게 만든 용융 액체는 원자로 생산 과정이나 다른 기계에 사용할 수 있습니다.

## 조작 방법

- **입력 슬롯**: 가공할 아이템을 넣습니다. 사용 가능한 조합법은 JEI에서 확인하세요.

- **진행도 표시줄**: 현재 조합법의 진행 상황을 보여줍니다. JEI가 설치되어 있다면 **JEI에서 해당 표시줄을 클릭**해 관련 조합법을 열 수 있습니다.

- **액체 탱크**: 마우스를 올리면 액체 종류와 양이 표시됩니다. 탱크 아래의 **D**를 누르면 저장된 액체를 버립니다.

- **레드스톤 톱니바퀴 버튼**: 클릭할 때마다 레드스톤 동작 방식(무시, 낮음, 높음 등)이 바뀝니다. 버튼의 표기가 함께 바뀌며, 마우스를 올리면 현재 모드 이름을 확인할 수 있습니다.
