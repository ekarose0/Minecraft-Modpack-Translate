---
item_ids:
  - colossal_reactors:radiation_scrubber
  - colossal_reactors:radiation_cure
categories:
  - processing
---

# 방사선 관리

설정에서 **방사선 관리**가 활성화되어 있고, 현재 환경에 관련 통합 콘텐츠(일반적으로 **Mekanism**)가 포함된 경우에만 사용할 수 있습니다. 해당 월드에 조합법과 블록이 존재하는지 **JEI**에서 확인하세요.

## Radiation Scrubber

<BlockImage id="radiation_scrubber" scale="4" />

**Radiation Scrubber**는 에너지와 선택 사항인 **촉매** 아이템을 소비하여 공기 중 방사선 관련 물질을 처리합니다. 처리 결과는 탱크에 표시되는 **화학물질/가스 버퍼**에 저장됩니다.

### 조작 방법

- 촉매를 설정하는 **아이템 슬롯 2개**. 사용 가능한 촉매는 JEI와 데이터팩을 참고하세요.

- **가스/화학물질 탱크**: 마우스를 올리면 내용물과 저장량을 확인할 수 있습니다.

- 측면의 **에너지 표시줄**: 마우스를 올리면 저장된 에너지양이 표시됩니다.

**Mekanism**이 설치되어 있다면 블록이 제공하는 Mekanism 화학물질 API를 통해 자동화 장치가 상호작용할 수 있습니다. 그렇지 않다면 지원되는 범위에서 GUI와 연결된 파이프를 이용해 직접 조작하세요.

## Radiation Cure

<ItemImage id="radiation_cure" scale="2" />

**Radiation Cure**는 방사선 관리 과정에서 사용하는 소모품입니다. GuideME의 **가이드 열기** 단축키가 설정되어 있다면 아이템 툴팁에서 이 설명을 열 수 있습니다.
