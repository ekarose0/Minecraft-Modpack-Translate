---
navigation:
  title: Applied Oritech
  position: 0
item_ids:
  - applied_oritech:me_dock
  - applied_oritech:me_pattern_provider_addon
  - applied_oritech:me_interface_addon
  - applied_oritech:me_extended_pattern_provider_addon
  - applied_oritech:me_extended_interface_addon
---

# Applied Oritech

Applied Oritech는 Oritech 기계를 Applied Energistics 2의 ME 네트워크에 연결합니다. ME Dock이 기계와 네트워크를 연결하고 애드온이 자동 제작과 재고 보충 기능을 제공합니다.

## 설치 방법

<ItemImage id="applied_oritech:me_dock" scale="4" />

1. 정상 작동하는 Oritech 기계를 조립하고 에너지를 공급합니다.
2. 기계의 애드온 설치 위치에 ME Dock을 설치하고 기계가 이를 인식하도록 합니다.
3. Dock에 ME 케이블을 연결합니다. 네트워크에 전력이 공급되고 사용 가능한 채널이 있어야 합니다.
4. ME 애드온을 기계의 애드온 구조에 부착하거나 해당 기계에 연결된 Dock에 맞닿도록 설치합니다. 필요하면 기계가 애드온을 다시 감지하도록 합니다.
5. 애드온을 우클릭하여 설정 메뉴를 엽니다. 애드온은 기계와 Dock 양쪽에 연결되어 있어야 사용할 수 있습니다.

각 Dock과 이에 연결된 애드온은 채널 하나를 공유합니다. 애드온은 케이블에 직접 연결되지 않고 Dock을 통해 네트워크에 참여합니다. Dock을 여러 개 사용할 수 있으며 애드온은 자신의 기계에 맞는 Dock을 선택합니다.

## ME Pattern Provider Addon

<ItemImage id="applied_oritech:me_pattern_provider_addon" scale="4" />

일반 애드온은 패턴 슬롯 9개를 제공합니다. 기계 레시피에 맞는 처리 패턴을 인코딩해 애드온에 넣으면 ME 네트워크가 해당 기계를 자동 제작에 사용할 수 있습니다. 재료는 출력 슬롯이 아닌 기계의 입력 슬롯으로 전달되며, 지원되는 유체는 기계의 유체 저장소로 공급됩니다.

애드온은 차단 모드, 우선순위, 패턴 접근 등 AE2의 패턴 공급기 동작을 사용합니다. 기계에서 제작 결과를 네트워크로 돌려보낼 다른 수단이 없다면 자동 출력 반환을 켜세요. 반환된 결과는 먼저 공급기의 반환 인벤토리로 들어가고 이후 AE2에서 처리됩니다.

## ME Interface Addon

<ItemImage id="applied_oritech:me_interface_addon" scale="4" />

인터페이스 메뉴에서 유지할 자원 종류와 수량을 지정합니다. 인터페이스는 네트워크에서 해당 자원을 가져와 내부 버퍼에 보관한 다음 연결된 기계로 전달합니다. 기계가 받을 수 없는 자원은 버퍼에 남습니다. 지원되는 기계에는 아이템뿐 아니라 유체도 공급할 수 있습니다.

Crafting Card를 설치하면 저장소에 없는 지정 자원의 자동 제작을 요청할 수 있습니다. Fuzzy Card는 AE2에서 지원하는 퍼지 일치 기능을 활성화합니다. 자동 출력 반환은 재고 보충과 별개로 기계의 출력물을 ME 저장소로 돌려보냅니다.

## ExtendedAE 연동

<ItemImage id="applied_oritech:me_extended_pattern_provider_addon" scale="4" />

<ItemImage id="applied_oritech:me_extended_interface_addon" scale="4" />

ExtendedAE가 설치되어 있으면 확장 패턴 공급기 애드온은 패턴 슬롯 36개를 제공하고, 확장 인터페이스 애드온은 ExtendedAE의 페이지 메뉴를 통해 설정 슬롯 36개를 제공합니다. 두 애드온 모두 Applied Oritech의 애드온으로서 동일한 기계 연결, Dock, 자동 출력 반환 방식을 사용합니다. ExtendedAE는 선택 사항입니다.

## 자동 출력 반환

애드온 메뉴에서 우선순위 버튼 바로 왼쪽 버튼을 사용합니다. 아이콘이 원래 색상이면 켜짐, 어두우면 꺼짐입니다. 버튼 배경색은 바뀌지 않습니다. 마우스를 올리면 현재 상태를 확인할 수 있습니다.

설정은 애드온별로 저장되며 초기값은 공통 설정에서 가져옵니다. 웅크리기 + 우클릭은 전환 기능이 아닙니다. 이 버튼은 Applied Oritech 애드온 메뉴에만 추가되며 AE2 또는 ExtendedAE의 기본 장치에는 나타나지 않습니다.

자동 반환은 기계의 **출력 자원**을 수집하며 임의의 입력 내용물을 가져오지 않습니다. 전송하려면 ME 네트워크가 온라인이어야 하고 저장 공간이 충분해야 하며, 설정에서 요구하는 기계 에너지도 있어야 합니다. 출력물을 다른 시스템에서 처리하려면 이 기능을 끄세요.

## 문제 해결

- **기계에 연결되지 않음:** 기계의 애드온 위치와 인식 상태를 확인하거나 해당 기계에 연결된 Dock 옆에 애드온을 설치하세요.
- **Dock 없음:** 같은 기계에 속하는 ME Dock을 설치하고 인식시키세요.
- **Dock 오프라인:** ME 케이블, 네트워크 전력, 사용 가능한 채널을 확인하세요.
- **자동 제작이 완료되지 않음:** 처리 패턴, 기계 입력 재료, 전력, 출력 공간, 자동 반환 설정을 확인하세요.
- **자원이 전송되지 않음:** 기계가 해당 자원을 받을 수 있는지, 필요한 아이템·유체 저장 기능을 지원하는지, 네트워크와 기계에 에너지가 충분한지 확인하세요.
- **출력물이 기계에 남음:** 자동 반환 전환, 네트워크 저장 용량, 패턴 공급기의 반환 인벤토리를 확인하세요.

애드온을 부수면 저장된 내용물, 인코딩된 패턴, 설치된 카드가 떨어집니다. 작동 중인 설비를 변경하기 전에 진행 중인 제작 작업을 완료하거나 취소하세요.
