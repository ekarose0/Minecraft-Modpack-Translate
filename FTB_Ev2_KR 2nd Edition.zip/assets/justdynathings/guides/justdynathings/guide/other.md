---
navigation:
  title: 기타 장치
  icon: "justdynathings:stabilizer"
  position: 99
---

# 기타 장치

다른 분류에 속하지 않는 블록과 아이템입니다. 그렇다고 쓸모없는 것은 아닙니다!

<SubPages />
