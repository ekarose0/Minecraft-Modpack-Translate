---
navigation:
  title: 크리에이티브 구
  icon: "justdynathings:creative_goo"
  parent: goo.md
  position: 99
categories:
  - goo
item_ids:
  - justdynathings:creative_goo
---

# 크리에이티브 구

죽지 않는 특별한 구입니다.
아무 렌치로든 상태를 전환할 수 있습니다.

단계: **최대(MAX)**

<BlockImage id="justdynathings:creative_goo" scale="4.0" p:alive="false"/> 
<BlockImage id="justdynathings:creative_goo" scale="4.0" p:alive="true" />

<RecipeFor id="justdynathings:creative_goo" />
