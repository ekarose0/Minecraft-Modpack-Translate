---
navigation:
  title: 에너지 구
  icon: "justdynathings:energized_goo"
  parent: goo.md
  position: 1
categories:
  - goo
item_ids:
  - justdynathings:energized_goo
---

# 에너지 구

살아 있는 상태를 유지하려면 **Forge Energy**가 필요한 새로운 구입니다.

단계: **5**

<BlockImage id="justdynathings:energized_goo" scale="4.0" p:alive="false"/>
<BlockImage id="justdynathings:energized_goo" scale="4.0" p:alive="true"/>

<RecipeFor id="justdynathings:energized_goo" />
