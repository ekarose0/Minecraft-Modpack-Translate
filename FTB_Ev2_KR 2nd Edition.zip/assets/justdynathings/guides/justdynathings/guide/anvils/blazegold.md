---
navigation:
  title: 블레이즈골드 모루
  icon: "justdynathings:blazegold_anvil"
  position: 2
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:blazegold_anvil
---

# 블레이즈골드 모루

[고온 유체](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/fluid/anvils/blazegold_repair.json)를 사용해 아이템을 수리하는 모루입니다.

<BlockImage id="justdynathings:blazegold_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:blazegold_anvil" />
