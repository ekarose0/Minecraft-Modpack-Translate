---
navigation:
  title: 이클립스 합금 모루
  icon: "justdynathings:eclipse_alloy_anvil"
  position: 4
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:eclipse_alloy_anvil
---

# 이클립스 합금 모루

<ItemLink id="justdynathings:celestigem_anvil"/>처럼 Forge Energy(FE)를 사용해 아이템을 수리하는 모루입니다.
[냉각수](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/fluid/anvils/eclipsealloy_repair.json)를 추가하면 `냉각수 효율 / 100 × 총 내구도 손상량`에 따라 수리합니다. 틱당 수리량이 1,000을 넘을 수 있으며, 아이템이 완전히 수리될 수도 있습니다.

<BlockImage id="justdynathings:eclipse_alloy_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:eclipse_alloy_anvil" />
