---
navigation:
  title: 셀레스티젬 모루
  icon: "justdynathings:celestigem_anvil"
  position: 3
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:celestigem_anvil
---

# 셀레스티젬 모루

Forge Energy(FE)를 사용해 아이템을 수리하는 모루입니다.

<BlockImage id="justdynathings:celestigem_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:celestigem_anvil" />
