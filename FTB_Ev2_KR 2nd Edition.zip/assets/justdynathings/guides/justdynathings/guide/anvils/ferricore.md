---
navigation:
  title: 페리코어 모루
  icon: "justdynathings:ferricore_anvil"
  position: 1
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:ferricore_anvil
---

# 페리코어 모루

특정 [촉매](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/item/anvils/ferricore_repair.json)를 사용해 도구를 수리하는 모루입니다.

<BlockImage id="justdynathings:ferricore_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:ferricore_anvil" />
