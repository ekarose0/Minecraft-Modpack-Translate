---
navigation:
  title: 소개
  icon: "minecraft:redstone"
  position: 0
---

# Just Dyna Things

JustDireThings에 새로운 아이템과 장치를 추가하는 애드온입니다.

<SubPages />
