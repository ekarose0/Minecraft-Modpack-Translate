---
navigation:
  title: 이클립스 합금 태양광 패널
  icon: "justdynathings:eclipse_alloy_solar_panel"
  position: 4
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:eclipse_alloy_solar_panel
---

# 이클립스 합금 태양광 패널

Forge Energy를 생산하는 태양광 패널입니다.

기본 최대 FE 생산량: **11520**

**기본 작동 조건:**

- 주변에 태양광 패널이 많을수록 생산량이 증가합니다.
- Y 좌표가 높거나 낮으면 생산 배율이 증가하고, 중간 높이에서는 감소합니다.

<BlockImage id="justdynathings:eclipse_alloy_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:eclipse_alloy_solar_panel" />

_참고: 모든 수치는 설정 파일에서 변경할 수 있으므로 실제 서버의 값과 다를 수 있습니다!_
