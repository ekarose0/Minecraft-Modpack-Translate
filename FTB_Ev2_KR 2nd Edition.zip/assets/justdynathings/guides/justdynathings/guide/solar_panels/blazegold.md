---
navigation:
  title: 블레이즈골드 태양광 패널
  icon: "justdynathings:blazegold_solar_panel"
  position: 2
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:blazegold_solar_panel
---

# 블레이즈골드 태양광 패널

Forge Energy를 생산하는 태양광 패널입니다.

기본 최대 FE 생산량: **960**

**기본 작동 조건:**

- 차원 = 네더

<BlockImage id="justdynathings:blazegold_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:blazegold_solar_panel" />

_참고: 모든 수치는 설정 파일에서 변경할 수 있으므로 실제 서버의 값과 다를 수 있습니다!_
