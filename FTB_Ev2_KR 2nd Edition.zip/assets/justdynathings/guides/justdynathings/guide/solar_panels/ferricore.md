---
navigation:
  title: 페리코어 태양광 패널
  icon: "justdynathings:ferricore_solar_panel"
  position: 1
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:ferricore_solar_panel
---

# 페리코어 태양광 패널

Forge Energy를 생산하는 태양광 패널입니다.

기본 최대 FE 생산량: **240**

**기본 작동 조건:**

- 차원 = 오버월드
- 하늘이 보여야 함 = true
- 낮이어야 함 = true

<BlockImage id="justdynathings:ferricore_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:ferricore_solar_panel" />

_참고: 모든 수치는 설정 파일에서 변경할 수 있으므로 실제 서버의 값과 다를 수 있습니다!_
