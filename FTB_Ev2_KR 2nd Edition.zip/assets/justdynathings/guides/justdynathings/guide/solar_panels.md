---
navigation:
  title: 태양광 패널
  icon: "justdynathings:blazegold_solar_panel"
  position: 4
---

# 태양의 힘

주변 환경 조건에 따라 Forge Energy를 생산하는 새로운 발전기들입니다.

<SubPages />
