---
navigation:
  title: 다양한 모루
  icon: "justdynathings:eclipse_alloy_anvil"
  position: 2
---

# 다양한 모루

경험치를 소모하지 않고 아이템을 수리할 수 있는 특별한 모루입니다.

<SubPages />
