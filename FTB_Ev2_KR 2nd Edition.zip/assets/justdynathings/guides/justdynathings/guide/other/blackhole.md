---
navigation:
  title: 블랙홀
  icon: "justdynathings:blackhole"
  position: 5
  parent: justdynathings:other.md
item_ids:
  - justdynathings:blackhole
---

# 블랙홀

흔히 _만능 쓰레기통_이라고 부르는 장치입니다.

기능을 꺼 두면 적은 공간에 막대한 양의 에너지나 유체를 저장할 수도 있습니다!

<BlockImage id="justdynathings:blackhole" scale="4.0"/>

<Recipe id="justdynathings:blackhole" />
