---
navigation:
  title: 안정화 장치
  icon: "justdynathings:stabilizer"
  position: 3
  parent: justdynathings:other.md
item_ids:
  - justdynathings:stabilizer
---

# 안정화 장치

Forge Energy를 사용해 위에 놓인 모든 종류의 구를 되살릴 수 있습니다.

<BlockImage id="justdynathings:stabilizer" scale="4.0" p:active="false" p:facing="down" p:goo_found="false"/>

블레이즈블룸 구 아래에 동력이 공급된 안정화 장치를 설치해 구를 되살린 예시입니다.

<GameScene zoom="4" interactive={true}>
  <Block id="justdynathings:stabilizer" p:active="true" p:facing="down" p:goo_found="true"/>
  <Block y="1" id="justdirethings:gooblock_tier2" p:alive="true"/>
</GameScene>

시간 유체를 사용해 에너지를 공급하면 패러독스 혼합기의 작동 상태를 유지하는 데에도 사용할 수 있습니다.

<GameScene zoom="4" interactive={true}>
  <Block id="justdynathings:stabilizer" p:active="true" p:facing="down" p:goo_found="true" p:energized="true"/>
  <Block y="1" id="justdynathings:paradox_mixer" p:alive="true"/>
</GameScene>

<Recipe id="justdynathings:stabilizer" />
