---
navigation:
  title: 틱 가속기
  icon: "justdynathings:ticker"
  position: 8
  parent: justdynathings:other.md
item_ids:
  - justdynathings:ticker
---

# 시간은 상대적입니다

시간 유체와 에너지를 소모해 강조 표시된 면에 있는 블록의 작동 속도를 높입니다(기본 16배).

<BlockImage id="justdynathings:ticker" scale="4.0"/>

<Recipe id="justdynathings:ticker" />
