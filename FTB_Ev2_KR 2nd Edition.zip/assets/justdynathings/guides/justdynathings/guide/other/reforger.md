---
navigation:
  title: 재단조기
  icon: "justdynathings:reforger"
  position: 2
  parent: justdynathings:other.md
item_ids:
  - justdynathings:reforger
---

# 재단조기

_빨간색 면_에 놓인 입력 블록을 _촉매_를 소모해 다른 _출력 블록_으로 변환하는 강력한 기계입니다.

<BlockImage id="justdynathings:reforger" p:facing="up" p:active="true" scale="4.0"/>

<Recipe id="justdynathings:reforger" />
