---
navigation:
  title: 열 발전기
  icon: "justdynathings:thermo_generator"
  position: 6
  parent: justdynathings:other.md
item_ids:
  - justdynathings:thermo_generator
---

# 대지의 힘

열원 블록과 냉각 유체를 이용해 Forge Energy를 생산하는 새로운 발전기입니다.

<BlockImage id="justdynathings:thermo_generator" scale="4.0" p:facing="down" p:active="true"/>

<Recipe id="justdynathings:thermo_generator" />

## 내부 작동 방식

FE 생산량 = 125 × 냉각수 효율 × 열원 효율

유체 소모량(mB) = 125 / 냉각수 효율

_향후 계산 방식이 단순해질 수 있습니다._
