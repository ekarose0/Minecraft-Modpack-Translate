---
navigation:
  title: 위상 상자
  icon: "justdynathings:phase_box"
  position: 1
  parent: justdynathings:other.md
item_ids:
  - justdynathings:phase_box
---

# 위상 상자

_에테리얼 유리라고도 합니다._

고체 상태를 켜거나 꺼서 충돌 판정을 전환할 수 있는 블록입니다.

**Fusion** ~~ConnectedTexturesMod~~이 설치되어 있으면 연결 텍스처(CTM)도 사용할 수 있습니다.

<BlockImage id="justdynathings:phase_box" scale="4.0"/>

<Recipe id="justdynathings:phase_box" />
