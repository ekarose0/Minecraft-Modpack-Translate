---
navigation:
  title: 패러독스 혼합기
  icon: "justdynathings:paradox_mixer"
  position: 7
  parent: justdynathings:other.md
item_ids:
  - justdynathings:paradox_mixer
---

# 패러독스 혼합기

유체를 떨어뜨리는 제작법을 대량으로 처리할 수 있는 _불안정한_ 블록입니다.

<BlockImage id="justdynathings:paradox_mixer" scale="4.0" p:alive="false"/>
<BlockImage id="justdynathings:paradox_mixer" scale="4.0" p:alive="true"/>

작동 상태를 유지하려면 에너지가 공급된 안정화 장치가 최소 하나 필요합니다.

<GameScene zoom="4" interactive={true}>
  <Block id="justdynathings:stabilizer" p:active="true" p:facing="down" p:goo_found="true" p:energized="true"/>
  <Block y="1" id="justdynathings:paradox_mixer" p:alive="true"/>
</GameScene>

<Recipe id="justdynathings:paradox_mixer" />
