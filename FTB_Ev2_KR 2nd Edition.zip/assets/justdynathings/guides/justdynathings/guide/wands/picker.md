---
navigation:
  title: 집기 지팡이
  icon: "justdynathings:picker_wand"
  position: 2
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:picker_wand
---

# 집기 지팡이

블록을 집어 원하는 위치에 다시 놓을 수 있는 지팡이입니다.

<ItemImage id="justdynathings:picker_wand" scale="4.0"/>

<Recipe id="justdynathings:picker_wand" />
