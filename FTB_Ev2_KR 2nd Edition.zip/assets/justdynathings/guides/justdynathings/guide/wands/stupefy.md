---
navigation:
  title: 시간 마비 지팡이
  icon: "justdynathings:temporal_stupefy_wand"
  position: 4
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:temporal_stupefy_wand
---

# 시간 마비 지팡이

시간 지팡이로 생성된 개체를 제거하고, 짧은 시간 동안 마비 효과를 부여하는 지팡이입니다.

<ItemImage id="justdynathings:temporal_stupefy_wand" scale="4.0"/>

<Recipe id="justdynathings:temporal_stupefy_wand" />
