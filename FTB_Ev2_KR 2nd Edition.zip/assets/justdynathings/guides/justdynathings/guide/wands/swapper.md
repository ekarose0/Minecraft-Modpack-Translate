---
navigation:
  title: 교환 지팡이
  icon: "justdynathings:swapper_wand"
  position: 3
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:swapper_wand
---

# 교환 지팡이

월드에서 블록을 파괴하지 않고 다른 블록과 서로 바꿀 수 있는 지팡이입니다.

<ItemImage id="justdynathings:swapper_wand" scale="4.0"/>

<Recipe id="justdynathings:swapper_wand" />
