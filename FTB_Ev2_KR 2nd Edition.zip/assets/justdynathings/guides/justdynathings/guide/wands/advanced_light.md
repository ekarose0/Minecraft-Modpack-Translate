---
navigation:
  title: 고급 빛 지팡이
  icon: "justdynathings:advanced_light_wand"
  position: 6
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:advanced_light_wand
---

# 빛이 있으라! 2부

<ItemLink id="justdynathings:light_wand"/>와 동일하게 작동하지만 사용할 때마다 FE를 소모합니다.

<ItemImage id="justdynathings:advanced_light_wand" scale="4.0"/>

<Recipe id="justdynathings:advanced_light_wand" />
