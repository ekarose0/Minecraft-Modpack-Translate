---
navigation:
  title: 고급 시간 지팡이
  icon: "justdynathings:advanced_time_wand"
  position: 1
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:advanced_time_wand
---

# 고급 시간 지팡이

<ItemLink id="justdirethings:time_wand"/>의 강화 버전으로, 더 큰 용량과 클릭 동작을 설정할 수 있는 여러 모드를 제공합니다.

기본 모드:

_설정 파일에서 변경하거나 비활성화할 수 있습니다!_

- 일반:

일반 <ItemLink id="justdirethings:time_wand"/>와 동일하게 작동합니다.

- 속도 2배:

클릭 동작이 2배로 적용됩니다. → 4 > 16 > 64 > 256

- 속도 4배:

클릭 동작이 4배로 적용됩니다. → 16 > 256

- 최대 속도:

클릭 동작이 8배로 적용되며, 항상 256배 속도로 작동합니다.

<ItemImage id="justdynathings:advanced_time_wand" scale="4.0"/>

<Recipe id="justdynathings:advanced_time_wand" />
