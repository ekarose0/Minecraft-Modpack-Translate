---
navigation:
  title: 빛 지팡이
  icon: "justdynathings:light_wand"
  position: 5
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:light_wand
---

# 빛이 있으라!

빛 블록을 설치하거나 제거할 수 있는 새로운 지팡이입니다.
바라보는 개체에 발광 효과를 부여할 수도 있습니다.

사용할 때마다 내구도를 소모합니다.

<ItemImage id="justdynathings:light_wand" scale="4.0"/>

<Recipe id="justdynathings:light_wand" />
