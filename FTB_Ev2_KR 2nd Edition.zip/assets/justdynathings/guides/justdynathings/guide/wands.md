---
navigation:
  title: 새로운 지팡이
  icon: "justdynathings:swapper_wand"
  position: 5
---

# 새로운 지팡이

특수 효과를 지닌 새로운 아이템들입니다.

<CategoryIndex category="wands"></CategoryIndex>
