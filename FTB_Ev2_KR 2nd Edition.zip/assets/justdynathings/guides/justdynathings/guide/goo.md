---
navigation:
  title: 새로운 구
  icon: "justdirethings:gooblock_tier1"
  position: 3
---

# 구(Goo)

새로운 단계의 구가 추가됩니다!

<CategoryIndex category="goo"></CategoryIndex>

_모든 단계의 구를 <ItemLink id="justdynathings:energized_goo"/>와 같은 방식으로 사용할 수 있다면 좋겠다고 생각해서 만들었습니다!
-DevDyna_

<CategoryIndex category="energy_goo"></CategoryIndex>
