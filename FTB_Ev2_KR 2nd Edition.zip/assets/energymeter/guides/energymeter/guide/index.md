---
navigation:
  title: Energy Meter
  icon: meter
item_ids:
  - meter
---

# Energy Meter

**Energy Meter** 모드의 소개 페이지에 오신 것을 환영합니다!

<br clear="all" />

![](assets/preview.png)

<FloatingImage src="assets/logo.png" align="right"/>

Energy Meter는 에너지 흐름 속도를 측정하는 <ItemLink id="meter" components="rarity=epic"/> 블록을 추가하는 소규모 모드입니다. 이 블록은 케이블처럼 작동하여 입력된 에너지 요청을 출력 쪽으로 그대로 전달합니다. 요청 값은 모두 기록되며 설정한 간격마다 흐름 속도를 계산하는 데 사용됩니다.

블록에는 상세한 설정 화면뿐 아니라 앞면에 디지털 표시창도 있습니다. 현재 전송 속도를 언제든 확인할 수 있습니다. 표시창은 위쪽과 아래쪽을 포함해 원하는 방향으로 회전할 수 있습니다. 앞면은 표시창으로 사용하므로 나머지 5개 면만 입력 또는 출력으로 설정할 수 있습니다.

새로 설치한 Energy Meter는 모든 면이 비활성화되어 있어 에너지를 전송하거나 측정하지 않습니다. 사용하기 전에 설정 화면의 I/O 격자에서 입력과 출력 면을 지정해야 합니다. 자세한 내용은 [Global Panel](interface.md#global-panel)을 참고하세요.

이전 구간의 전송 속도를 확인할 수 있는 그래프도 있습니다. 최근 10개 측정 구간을 표시하며 일시 정지할 수 있습니다. 측정 방식, 측정 간격, 계산 모드 등 여러 설정을 조절할 수 있습니다.<br/>
자세한 내용은 [Interface](interface.md) 페이지를 참고하세요.

<br clear="all" />
<RecipeFor id="meter"/>
