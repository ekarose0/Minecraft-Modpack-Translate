---
navigation:
  title: 링크 및 감사 인사
  position: 10
---

# 링크 및 감사 인사

Logistics Networks를 사용해 주셔서 감사합니다! 설치한 노드 하나, 구축한 네트워크 하나, 설정한 채널 하나하나가 모두 큰 힘이 됩니다. 모드가 유용했다면 커뮤니티에 참여하거나 저장소에 별을 눌러 프로젝트의 성장을 도와주세요.

## 커뮤니티 및 소스 코드

- **Discord** — [discord.gg/xTeHR2tdYh](https://discord.gg/xTeHR2tdYh) — 도움말, 버그 신고, 기능 제안, 제작물 공유를 위한 공간입니다.
- **GitHub** — [github.com/Almana-mc/LogisticsNetworks](https://github.com/Almana-mc/LogisticsNetworks) — 소스 코드 확인, 이슈 등록, 풀 리퀘스트 기여가 가능합니다.

버그를 발견하거나 아이디어가 있다면 Discord 또는 GitHub 이슈 추적기를 이용하는 것이 가장 빠릅니다. 플레이해 주셔서 다시 한번 감사합니다.
