---
navigation:
  title: ComputerCraft
  parent: integrations/index.md
  position: 1
---

# ComputerCraft

[CC: Tweaked](https://modrinth.com/mod/cc-tweaked)가 설치되어 있으면 Computer를 주변기기(peripheral)로 사용할 수 있습니다. 스크립트로 Computer 화면에 표시되는 네트워크, 채널, 노드, 연결 그래프, 실시간 I/O 통계를 읽고 모니터에 출력할 수 있습니다.

## 연결

CC 컴퓨터를 Computer 블록 옆에 설치하거나 유선 모뎀으로 연결합니다. 주변기기 종류는 `logistics_computer`입니다.

```lua
local lc = peripheral.find("logistics_computer")
```

## 소유권

Computer의 소유자는 설치한 플레이어입니다. 스크립트에서는 서버의 노드 접근 규칙과 FTB Teams에 따라 소유자가 열 수 있는 네트워크만 보입니다. 하지만 연결된 CC 컴퓨터의 사용자는 누구든 그 네트워크를 읽을 수 있으므로 접근을 제한할 수 있는 곳에 설치하세요.

업데이트 이전에 설치한 Computer에는 소유자가 없습니다. ComputerCraft에서 사용하려면 부수고 다시 설치해야 합니다.

## 메서드

`net`은 네트워크 ID 또는 정확한 이름입니다. 채널 목록은 화면 순서이며 각 항목의 `index`는 [I/O Monitor](../computer/io-monitor.md)의 `CH` 번호입니다. 번호는 0부터 시작하므로 CH0은 `channels[1]`에 해당합니다. 그래프 간선의 `channels`에도 CH 번호가 들어갑니다.

| 메서드 | 반환값 |
|---|---|
| `listNetworks()` | `{ {id, name, nodeCount, starred, color, createdAt}, ... }` |
| `getChannels(net)` | `{ {index, name, type, types, nodeCount}, ... }` — `types`는 채널의 모든 자원 종류, `type`은 첫 종류입니다. 활성 노드가 없으면 둘 다 nil입니다. |
| `getNodes(net)` | `{ {id, label, block, pos, attachedPos, dimension, visible, highlighted}, ... }` — 로드된 노드만 반환합니다. |
| `getGraph(net)` | `{ name, totalNodes, vertices, edges }` — 정점은 `key, label, x, y, nodes`, 간선은 `from, to, type, channels`를 가집니다. |
| `watch(net)` | 해당 컴퓨터의 실시간 통계 수집을 시작합니다. |
| `unwatch(net)` | 통계 수집을 중지합니다. |
| `getFlow(net)` | 마지막 통계 샘플을 반환합니다. 첫 1초가 지나기 전에는 nil이며 감시하지 않는 네트워크는 오류가 발생합니다. |

자원 종류는 `item`, `fluid`, `energy`입니다.

## 실시간 통계

`watch`를 호출하면 매초 `logistics_flow` 이벤트가 도착합니다.

```lua
local _, side, networkId, sample = os.pullEvent("logistics_flow")
-- sample.channels[1].total, sample.channels[1].resources[1].displayName
```

각 채널에는 `index`, `type`, `types`, `total`(그 1초 동안 첫 자원 종류가 이동한 양, I/O Monitor와 같은 단위), `totals`(자원 종류 이름을 키로 하는 종류별 이동량), `resources`(상위 16개 아이템 또는 유체의 `kind`, `name`, `displayName`, `amount`)가 있습니다. 에너지 채널의 자원 목록은 비어 있습니다.

컴퓨터가 재시작되거나 연결이 끊어지면 감시가 종료되므로 `startup` 스크립트에서 `watch`를 호출하세요. 소유자가 네트워크 접근 권한을 잃거나 네트워크가 삭제되어도 오류 없이 중지됩니다.

## 예제

연결된 모니터에 모든 채널의 실시간 속도를 표시합니다.

```lua
local lc = peripheral.find("logistics_computer")
local mon = peripheral.find("monitor")
local net = "Main Base"

mon.setTextScale(0.5)
lc.watch(net)
while true do
  local _, _, _, sample = os.pullEvent("logistics_flow")
  mon.clear()
  for i, ch in ipairs(sample.channels) do
    mon.setCursorPos(1, i)
    mon.write(("CH%d %-8s %d/s"):format(ch.index, ch.type or "-", ch.total))
  end
end
```
