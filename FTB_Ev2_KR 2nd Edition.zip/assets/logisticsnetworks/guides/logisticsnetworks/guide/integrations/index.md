---
navigation:
  title: 모드 연동
  position: 6
---

# 모드 연동

Logistics Networks는 여러 모드와 함께 작동합니다. 여기서는 플레이 방식에 영향을 주는 연동 기능을 소개합니다. 해당 모드가 설치되어 있을 때만 연동이 활성화됩니다.

- [ComputerCraft](computercraft.md) — Lua 스크립트와 모니터에서 네트워크, 노드, 연결 그래프, 실시간 I/O 통계를 읽습니다.
- [Building Gadgets](building-gadgets.md) — Cut and Paste 도구로 노드를 이동하고 Copy and Paste 도구와 템플릿으로 설정을 복사합니다.
- [Curios](curios.md) — 렌치를 전용 슬롯에 장착하고 단축키로 활성화하여 단축바를 비울 수 있습니다.
