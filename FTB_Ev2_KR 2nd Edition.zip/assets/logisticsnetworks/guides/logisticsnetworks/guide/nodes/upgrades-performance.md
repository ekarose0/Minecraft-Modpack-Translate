---
item_ids: [logisticsnetworks:iron_upgrade, logisticsnetworks:gold_upgrade, logisticsnetworks:diamond_upgrade, logisticsnetworks:netherite_upgrade]
navigation:
  title: 성능 업그레이드
  parent: nodes/index.md
  icon: logisticsnetworks:diamond_upgrade
  position: 4
---

# 성능 업그레이드

성능 업그레이드는 노드의 **최대 전송량**(한 번에 옮길 수 있는 양)을 높이고 **최소 지연**(전송 시도 간격)을 줄입니다. 업그레이드는 채널별이 아니라 노드별이므로 모든 채널에 적용됩니다.

[Filters & Upgrades](filters-upgrades.md) 화면의 업그레이드 슬롯 6개 중 아무 곳에나 설치할 수 있습니다. 같은 업그레이드를 중복 설치할 수는 없습니다.

유효 등급이 올라가면 각 채널의 Batch가 새 최대값으로 설정됩니다. 아이템과 유체의 Delay는 기존 설정을 유지하므로 더 빠르게 전송하려면 직접 낮춰야 합니다. 에너지는 기존에 고정된 지연을 유지합니다. 등급을 낮추면 남은 등급의 한도에 맞춰 값이 제한됩니다. 클립보드와 라벨 설정에는 저장된 값이 유지됩니다.

## 가장 높은 등급만 적용

노드는 설치된 업그레이드 중 **가장 높은 등급**을 사용합니다.

| 등급 | 업그레이드 |
|------|---------|
| 1 | Iron |
| 2 | Gold |
| 3 | Diamond |
| 4 | Netherite |

Iron + Gold + Diamond를 모두 설치해도 **Diamond** 한도만 적용됩니다. Iron과 Gold의 효과는 합산되지 않습니다. 차원을 넘어 전송하려면 [Dimensional Upgrade](upgrades-special.md#dimensional-upgrade)를 사용하세요. Chemical과 Source 업그레이드는 아이템으로 남아 있지만 현재 비활성화되어 있습니다.

## 등급별 비교

| 등급 | 아이템 전송량 | 유체 전송량 | 에너지 전송량 | 최소 지연 |
|------|------------|------------|------------|----------|
| **업그레이드 없음** | 설정값 | 설정값 | 설정값 | 설정값 |
| **Iron** | 16개 | 1,000 mB | 10,000 RF | 10틱 |
| **Gold** | 32개 | 5,000 mB | 50,000 RF | 5틱 |
| **Diamond** | 64개 | 20,000 mB | 250,000 RF | 1틱 |
| **Netherite** | 10,000개 | 1,000,000 mB | 137,438,953,408 RF | 1틱 |

표의 수치는 **상한**입니다. [Channel Settings](channel-settings.md)의 Batch와 Delay는 해당 한도에 맞춰 제한됩니다. 예를 들어 Batch에 100,000을 입력해도 Iron 등급 노드는 16개까지만 처리합니다. 상한을 높이려면 업그레이드 등급을 올리세요.

네 등급의 한도는 서버 설정(`UpgradeLimitsConfig`)에서 정하므로 관리자가 값을 바꿀 수 있습니다. 실제 동작이 표와 다르다면 서버 설정을 확인하세요.

## Iron Upgrade

입문용 업그레이드입니다. 업그레이드가 없는 노드의 기본 한계를 넘어 소규모 설비에서 실용적인 전송량을 제공합니다.

<RecipeFor id="logisticsnetworks:iron_upgrade" />

## Gold Upgrade

중간 등급입니다. Iron의 아이템 한도를 두 배로 높이고 유체와 에너지 처리량을 5배로 늘립니다.

<RecipeFor id="logisticsnetworks:gold_upgrade" />

## Diamond Upgrade

고급 등급입니다. 아이템을 한 번에 64개까지 전송하고 최소 지연이 1틱이므로 매 틱 채널을 실행할 수 있습니다.

<RecipeFor id="logisticsnetworks:diamond_upgrade" />

## Netherite Upgrade

최고 성능입니다. 한 번에 아이템 10,000개, 유체 100만 mB, 에너지 약 1,374억 RF를 처리합니다. 허브 상자, 주 유체 분배기, 대형 에너지 버퍼처럼 전송량이 많은 노드에 사용하세요.

<RecipeFor id="logisticsnetworks:netherite_upgrade" />
