---
item_ids: [logisticsnetworks:dimensional_upgrade, logisticsnetworks:mekanism_chemical_upgrade, logisticsnetworks:ars_source_upgrade, logisticsnetworks:network_upgrade]
navigation:
  title: 특수 업그레이드
  parent: nodes/index.md
  icon: logisticsnetworks:dimensional_upgrade
  position: 5
---

# 특수 업그레이드

특수 업그레이드는 전송량 상한을 바꾸지 않습니다. Dimensional Upgrade는 차원 간 전송을, Network Upgrade는 저장소 네트워크 직접 접근을 활성화합니다. 두 업그레이드는 같은 노드의 [성능 업그레이드](upgrades-performance.md)와 함께 사용할 수 있습니다. Chemical과 Source 업그레이드 아이템은 향후 호환성을 위해 남아 있지만 현재는 비활성화되어 있습니다.

업그레이드 슬롯은 [Filters & Upgrades](filters-upgrades.md)에 있습니다. 중복 설치는 불가능하지만 서로 다른 활성 업그레이드는 6개 슬롯에 함께 설치할 수 있습니다.

## Dimensional Upgrade

**차원 간 전송을 활성화합니다.** 이 업그레이드가 없으면 같은 차원의 노드끼리만 통신합니다. 설치하면 오버월드와 네더, 엔드와 오버월드 또는 모드에서 추가한 차원 사이에서도 전송할 수 있습니다.

**양쪽 모두 필요합니다.** Sender와 Receiver 노드에 Dimensional Upgrade가 각각 설치되어 있어야 합니다. 한쪽에만 설치하면 차원 간 전송이 허용되지 않습니다.

같은 차원에서는 추가 효과가 없으며 업그레이드 없이도 정상 전송됩니다.

<RecipeFor id="logisticsnetworks:dimensional_upgrade" />

## Mekanism Chemical Upgrade

향후 호환성을 위해 유지되는 아이템입니다. 현재는 Chemical 채널이나 전송을 활성화하지 않습니다. Mekanism이 설치된 경우에만 제작법이 표시됩니다.

<RecipeFor id="logisticsnetworks:mekanism_chemical_upgrade" fallbackText="이 제작법을 보려면 Mekanism을 설치하세요." />

## Ars Source Upgrade

향후 호환성을 위해 유지되는 아이템입니다. 현재는 Source 채널이나 전송을 활성화하지 않습니다. Ars Nouveau가 설치된 경우에만 제작법이 표시됩니다.

<RecipeFor id="logisticsnetworks:ars_source_upgrade" fallbackText="이 제작법을 보려면 Ars Nouveau를 설치하세요." />

## Network Upgrade

**저장소 네트워크에 직접 접근할 수 있게 합니다.** Applied Energistics 2 또는 Refined Storage Interface에 설치된 노드에 이 업그레이드가 있으면 [Channel Settings](channel-settings.md)에 설명된 것처럼 연결된 저장소 네트워크 전체를 통해 아이템과 유체를 이동합니다. 업그레이드가 없으면 Interface는 일반 인벤토리로 취급되어 그 안에 보관된 자원만 보입니다.

저장소 네트워크에 접근해야 하는 Interface의 각 노드에는 개별 Network Upgrade가 필요합니다. 다른 블록의 노드에는 필요하지 않습니다.

저장소 모드별로 제작법이 두 가지이며 해당 모드가 설치된 경우에만 표시됩니다.

<Recipe id="logisticsnetworks:network_upgrade_ae2" fallbackText="이 제작법을 보려면 Applied Energistics 2를 설치하세요." />

<Recipe id="logisticsnetworks:network_upgrade_refinedstorage" fallbackText="이 제작법을 보려면 Refined Storage를 설치하세요." />
