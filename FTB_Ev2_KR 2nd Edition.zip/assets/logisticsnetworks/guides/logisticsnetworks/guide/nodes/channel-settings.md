---
navigation:
  title: 채널 설정
  parent: nodes/index.md
  position: 2
---

# 채널 설정

이 패널에서는 [Header](header.md)에서 현재 선택한 채널을 설정합니다. 모든 노드에는 9개 채널이 있고, 아래 설정은 채널마다 독립적으로 저장됩니다. 여기서 값을 변경해도 현재 보고 있는 채널에만 적용됩니다.

**보조 키 3(기본값: Alt)**을 누른 상태에서 **주 상호작용(기본값: 좌클릭)** 하면 설정값을 최대로, **보조 상호작용(기본값: 우클릭)** 하면 최소로 지정할 수 있습니다.

화면 위쪽의 채널 번호 버튼을 주 상호작용 하여 편집할 채널을 전환합니다.

## Status

![Status: Enabled](images/channel-status-enabled.png)

![Status: Disabled](images/channel-status-disabled.png)

**의미:** 채널의 켜기/끄기 스위치입니다.

**동작:**

- **Enabled:** 채널이 활성화됩니다. Delay와 Redstone 등의 조건에 따라 매 틱 처리 대상이 됩니다.
- **Disabled:** 전송 엔진이 채널을 완전히 건너뜁니다. 추출, 삽입, 레드스톤 검사 등 어떤 작업도 수행하지 않습니다.

**변경:** 값 버튼을 주 상호작용 하여 Enabled와 Disabled를 전환합니다.

**주의:** 비활성화해도 필터, Batch, Delay 등의 설정은 그대로 유지됩니다. 삭제하는 것이 아니라 일시 정지하는 것이므로 다시 켜면 기존 설정대로 작동합니다.

## Mode

![Mode: Sender](images/channel-mode-sender.png)

![Mode: Receiver](images/channel-mode-receiver.png)

**의미:** 채널의 전송 방향입니다.

**동작:**

- **Sender:** 노드가 부착된 블록에서 자원을 **꺼냅니다**. 전송을 주도하며 네트워크에서 같은 채널 번호를 사용하는 Receiver를 찾아 자원을 보냅니다.
- **Receiver:** 노드가 부착된 블록으로 자원을 **받아들입니다**. 같은 채널 번호의 Sender가 자원을 보내기를 기다리는 수동적인 역할입니다.

**변경:** 값 버튼을 주 상호작용 하여 Sender와 Receiver를 전환합니다.

**주의:** Receiver만 있거나 Sender만 있는 네트워크에서는 아무것도 이동하지 않습니다. 같은 채널 번호에 각각 하나 이상 있어야 합니다.

## Resources

**의미:** 이 채널이 옮길 자원 종류인 Item, Fluid, Energy를 설정합니다.

**동작:** 켜 둔 모든 자원 종류를 전송합니다. 새 채널은 처음에 세 종류가 모두 켜져 있으므로 한 채널로 아이템, 유체, 에너지를 동시에 옮길 수 있습니다. Receiver도 자신이 켠 종류만 받습니다.

**변경:** Resources 행을 눌러 팝오버를 엽니다. 종류마다 체크박스로 켜고 끌 수 있고 Sender에는 종류별 Batch도 있습니다. **All**과 **None**으로 전체를 한 번에 설정할 수 있습니다.

### AE2 및 Refined Storage Interface

Applied Energistics 2 또는 Refined Storage Interface에 [Network Upgrade](upgrades-special.md)가 설치된 노드는 연결된 저장소 네트워크 전체에서 아이템과 유체를 직접 전송합니다. 업그레이드가 없으면 Interface는 일반 인벤토리로 취급되어 Interface 자체에 보관된 아이템과 탱크만 보입니다. Sender가 꺼낼 수 있는 자원은 Interface에 설정된 내보내기 항목과 해당 모드의 퍼지(fuzzy) 설정을 따르지만, Interface에 지정한 수량이 Logistics의 Batch를 제한하지는 않습니다. Receiver는 자신의 Logistics 채널 필터가 허용하는 자원을 넣을 수 있습니다.

아이템 Sender는 먼저 저장소 네트워크에서 꺼내고, Batch에 남은 공간이 있으면 Interface에 보관된 아이템으로 채웁니다. Interface 버퍼에만 있는 아이템은 이후 전송에 남겨 두어 Interface가 비워질 수 있도록 합니다. 유체 직접 전송은 노출된 탱크를 계속 무시합니다. Logistics 슬롯 매핑을 명시적으로 추가하면 해당 아이템 채널은 Interface의 노출된 인벤토리를 사용하는 방식으로 되돌아갑니다. 저장소 네트워크가 끊어지거나 비활성화되면 Interface 버퍼를 사용하지 않고 기다리며, 직접 전송은 자동 제작을 요청하지 않습니다.

이 노드에서 Stock은 저장소 네트워크 전체가 아니라 **Interface 자체의 보관량만** 확인합니다. Sender는 Interface에 Stock 지정량보다 많이 있을 때만 해당 자원을 옮기므로 Interface 설정에도 그 자원을 등록해야 합니다. Receiver는 Interface 보관량이 Stock에 도달하면 멈추므로 Interface가 보관하지 않는 자원은 Stock으로 제한되지 않습니다.

## Side

![Side: Up](images/channel-side-up.png)

![Side: All](images/channel-side-all.png)

**의미:** 채널이 부착된 블록의 어느 면과 상호작용할지 지정합니다.

**동작:** 일부 블록은 삽입·추출 면에 따라 동작이 다릅니다. 화로가 대표적인 예입니다. 위쪽은 연료를 받고, 앞쪽은 제련된 아이템을 받거나 내보내며, 아래쪽은 출력만 내보냅니다. Side로 사용할 면을 정확히 고를 수 있습니다.

- **Up / Down / North / East / South / West:** 해당 면 하나만 사용합니다. 엔진은 그 면에서 블록이 제공하는 인벤토리, 탱크 또는 에너지 저장소와 슬롯을 검사합니다.
- **All:** 모든 면을 하나의 통합 처리기로 합칩니다. 각 면에서 노출된 슬롯·탱크·버퍼를 하나의 저장소처럼 취급합니다. 여러 면이 완전히 같은 처리기를 노출한다면(대부분의 블록은 모든 면에 같은 인벤토리를 노출합니다) 중복을 제거해 두 번 계산하지 않습니다.

**변경:** 주 상호작용 할 때마다 Up → Down → N → E → S → W → All → Up 순서로 전환합니다.

**주의:** 화로, 양조기, 일부 기계처럼 면마다 다른 슬롯을 제공하는 블록에서 **All**을 사용하면 입력, 연료, 출력 슬롯이 모두 보일 수 있습니다. 대부분 원치 않는 동작이므로 필터가 필요한 슬롯에만 적용되도록 특정 면을 선택하세요.

## Redstone

![Redstone: High Signal](images/channel-redstone-high-signal.png)

![Redstone: Low Signal](images/channel-redstone-low-signal.png)

**의미:** 채널의 레드스톤 제어입니다.

**동작:** 엔진은 **노드가 부착된 블록**에서 레드스톤 신호를 확인합니다. 레버, 레드스톤 횃불, 가루, 비교기 등 이웃 블록의 신호를 기준으로 실행 여부를 결정합니다.

- **Ignored**(기본값): 신호와 무관하게 실행하며 신호를 검사하지 않습니다.
- **High Signal:** 레드스톤 신호가 있을 때(강도 > 0)만 실행합니다.
- **Low Signal:** 레드스톤 신호가 없을 때(강도 = 0)만 실행합니다.

**변경:** 주 상호작용 하여 모드를 순환합니다.

레드스톤 제어는 Sender와 Receiver 모두에 적용됩니다.

## Distribution

![Distribution: Priority](images/channel-distribution-priority.png)

![Distribution: Nearest First](images/channel-distribution-nearest-first.png)

![Distribution: Farthest First](images/channel-distribution-farthest-first.png)

![Distribution: Equal Distribution](images/channel-distribution-round-robin.png)

**의미:** Sender가 같은 채널 번호의 Receiver 여러 개 중 어떤 순서로 전송할지 정합니다.

**동작:** Receiver가 하나뿐이라면 효과가 없습니다. 여러 개일 때 다음 분배 방식을 사용합니다.

- **Priority:** Receiver의 **Priority** 값이 높은 순서대로 전송합니다. 값이 같으면 순서는 정해져 있지 않습니다.
- **Nearest First:** Sender에서 직선거리가 가까운 Receiver부터 전송합니다.
- **Farthest First:** Sender에서 가장 먼 Receiver부터 전송합니다.
- **Equal Distribution:** Sender가 사용할 수 있는 자원을 Batch 한도 안에서 일치하는 Receiver에게 최대한 균등하게 나눕니다. 아이템 10개를 Receiver 10개에 나누면 각 1개, 20개라면 각 2개입니다.
- **Priority Robin:** 작업 한 번에 Receiver 하나로 전송하고 다음 작업에서는 다음 Receiver로 넘어갑니다. Priority가 높은 순서대로 순환하며 가득 찬 Receiver는 건너뜁니다.

**변경:** 주 상호작용 하여 모드를 순환합니다.

**주의 — Equal Distribution:** 순환 위치를 기억하지 않습니다. 균등하게 나누고 남은 자원은 **Priority** 순서로 앞쪽 Receiver부터 하나씩 추가됩니다. 가득 찬 Receiver의 몫은 여유 있는 Receiver로 넘어갑니다. 아이템·유체 종류마다 이를 허용하는 Receiver를 따로 계산하며, Sender 저장소의 자원 순서대로 Batch가 소진될 때까지 처리합니다. Sender의 내보내기 필터가 보존하는 양은 분배에서 제외됩니다. 모든 채널 종류에 적용됩니다.

**주의 — Priority Robin:** 월드 또는 Sender의 청크가 다시 로드되면 순환 위치가 가장 높은 우선순위의 Receiver로 초기화됩니다. 선택한 Receiver가 Batch의 일부만 받았다면 나머지는 다음 전송 작업까지 대기합니다. 모든 채널 종류에 적용됩니다.

**Receiver에서는 비활성화:** Receiver 모드에서는 이 행이 회색으로 표시됩니다. 분배는 Sender에서만 설정합니다.

## Priority

![Priority 행](images/channel-priority.png)

**의미:** 채널의 작은 정수 우선순위로 범위는 **–99~+99**입니다.

**동작:** Sender는 대상 Receiver를 이 값이 높은 순서로 정렬합니다. **Priority** 모드에서는 높은 Receiver가 먼저 받고, **Priority Robin**에서는 순환 순서를 정합니다. 원본 슬롯은 순서대로 읽기 때문에 여러 슬롯에 걸친 Batch는 앞쪽 슬롯의 자원으로 첫 Receiver를 채운 다음 남은 양을 다음 Receiver로 보낼 수 있습니다.

**변경:** 숫자 입력란을 주 상호작용 하고 –99부터 99 사이의 숫자를 입력한 뒤 Enter를 누릅니다.

**주의:** Priority는 Priority와 Priority Robin의 처리 순서, Equal Distribution의 나머지 배분 순서를 정합니다. Nearest/Farthest에서는 무시됩니다. 먼저 자원을 받아야 하는 **Receiver**에 Priority를 설정해야 하며 Sender에 설정하는 것이 아닙니다.

## Batch

![Batch 행](images/channel-batch.png)

**의미:** 한 번의 전송 작업에서 옮길 수 있는 최대 자원량입니다.

**동작:** 자원 종류별로 전송 시도 한 번의 양을 제한합니다. 아이템은 개수, 유체는 mB 단위입니다. 에너지는 업그레이드가 허용하는 최대량을 항상 전송합니다.

**변경:** Batch 또는 Resources 행을 눌러 팝오버를 열고 자원 종류의 수량을 누릅니다. 좌클릭은 +1, 우클릭은 –1, **보조 키 1(기본값: Shift)**은 8씩 조절, **보조 키 3(기본값: Alt)**은 Max 또는 1로 이동합니다. 두 번 클릭하면 수치를 직접 입력할 수 있습니다. 입력란은 `+ - * /`와 괄호를 사용한 간단한 수식도 지원하므로 `64*7`을 입력하면 448이 저장됩니다. **Max**는 업그레이드 등급을 따릅니다.

**주의:** Batch는 노드에 설치된 업그레이드의 상한을 넘을 수 없습니다. 상한보다 큰 값은 Max로 취급됩니다. 한도를 높이려면 [성능 업그레이드](upgrades-performance.md)를 참고하세요.

**Receiver에서는 비활성화:** Receiver 모드에서는 회색으로 표시되며 Batch는 Sender가 결정합니다.

## Delay

![Delay 행](images/channel-delay.png)

**의미:** 채널의 전송 작업 사이 대기 시간이며 **틱** 단위입니다. `20t`는 20틱, 즉 실제 시간 약 1초입니다.

**동작:** 전송이 성공하면 지정한 틱 수만큼 기다린 뒤 다시 시도합니다. 매 틱 전송할 필요가 없는 채널의 처리 빈도를 낮추는 데 사용합니다.

**변경:** 숫자 입력란을 주 상호작용 하여 값을 입력하고 Enter를 누릅니다. 최소값은 1틱입니다.

**주의:** 에너지는 **Delay를 무시**하고 매 틱 이동합니다. 다른 자원 종류에는 Delay가 적용되며 종류마다 독립적으로 대기하므로 유체 전송이 막혀도 아이템 전송이 느려지지 않습니다. 에너지만 취급하는 채널에서는 Delay 행이 회색으로 표시됩니다.

**주의 — 업그레이드:** Delay는 업그레이드 등급의 최소 지연에 의해 제한됩니다. 1을 입력해도 업그레이드가 최소 10틱만 허용한다면 실제로는 10틱을 사용합니다. 상위 업그레이드일수록 더 짧은 지연을 사용할 수 있습니다.

**Receiver에서는 비활성화:** Receiver 모드에서는 회색으로 표시되며 전송 속도는 Sender가 결정합니다.

---

이 페이지의 모든 설정은 현재 선택한 채널에만 적용됩니다. 다른 채널을 설정하려면 [Header](header.md)에서 전환하고, 필터와 업그레이드 관련 내용은 [Filters & Upgrades](filters-upgrades.md)를 참고하세요.
