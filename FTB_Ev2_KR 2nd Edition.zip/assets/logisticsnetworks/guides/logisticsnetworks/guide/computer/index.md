---
item_ids: [logisticsnetworks:computer]
navigation:
  title: 컴퓨터
  icon: logisticsnetworks:computer
  position: 5
---

# Computer

Computer는 물류 네트워크를 감시하고 관리할 수 있는 터미널 화면을 제공하는 설치형 블록입니다. 기지에 설치하고 **보조 상호작용(기본값: 우클릭)** 하면 전체 네트워크 목록, 활성 채널별 실시간 처리량, 노드 원격 설정, 노드 표시 일괄 전환 기능을 갖춘 대시보드가 열립니다.

![네트워크를 마운트하지 않은 Network Manager 대기 화면](images/network-manager-idle.png)

## 컴퓨터 열기

설치된 Computer를 **보조 상호작용** 하면 **Network Manager** 화면이 열립니다. 인벤토리에 [Wrench](../wrench/index.md)가 있다면 그중 하나가 일시적으로 오른쪽 위의 내부 드라이브 슬롯으로 옮겨집니다. 이 슬롯에서 렌치를 직접 꺼낼 수는 없습니다. 화면을 닫으면 변경된 렌치가 자동으로 인벤토리에 돌아옵니다.

드라이브 슬롯은 Network Directory 페이지에서만 조작할 수 있습니다. I/O Monitor나 Node Table로 이동하면 디렉터리로 돌아올 때까지 렌치 슬롯을 조작할 수 없습니다.

## 세 가지 하위 기능

디렉터리에서 네트워크를 선택하면 두 가지 하위 기능으로 이동할 수 있습니다. 각 기능은 별도 장에서 설명합니다.

- [Network Directory](network-directory.md) — 왼쪽 네트워크 목록, 검색, 즐겨찾기, 네트워크 마운트
- [I/O Monitor](io-monitor.md) — 9개 채널의 실시간 처리량과 이동 중인 아이템·유체 확인
- [Node Table](node-table.md) — 마운트된 네트워크의 모든 노드를 라벨별로 분류하고 행별 작업 수행

노드 설정을 백업하거나 Computer의 렌치에 불러오려면 [네트워크 저장 및 불러오기](save-load.md)를 참고하세요.

CC: Tweaked가 설치되어 있다면 [ComputerCraft](../integrations/computercraft.md)에서 Lua 스크립트와 모니터로 같은 데이터를 읽는 방법을 확인할 수 있습니다.

네트워크를 마운트하기 전에는 오른쪽 영역에 **No Network Mounted**가 표시됩니다. 디렉터리에서 네트워크를 선택하면 하위 기능 버튼이 활성화됩니다.

## 즐겨찾기 네트워크

디렉터리의 네트워크 항목 오른쪽에는 작은 **별** 아이콘이 있습니다. **주 상호작용(기본값: 좌클릭)** 으로 별을 누르면 목록 상단에 고정됩니다. 고정된 네트워크가 먼저 정렬되고 나머지가 뒤따릅니다. 별 상태는 플레이어가 아니라 해당 Computer 블록에 저장되므로 세션을 넘어 유지되며, 컴퓨터마다 서로 다른 즐겨찾기를 가질 수 있습니다.

각 Computer는 현재 플레이어가 서버의 **Node Access** 설정에 따라 접근 가능한 네트워크를 보여줍니다. [네트워크 접근 권한](../index.md#network-access)을 참고하세요.

## 제작법

<RecipeFor id="logisticsnetworks:computer" />
