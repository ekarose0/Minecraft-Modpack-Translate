---
navigation:
    title: 차원 자원 안내서
    position: 0
    icon: 'dimresources:laser'
item_ids:
  - 'dimresources:planet_locator'
  - 'dimresources:deepslate_dimensional_ore'
  - 'dimresources:dimensional_ore'
  - 'dimresources:dimensional_shard'
  - 'minecraft:spyglass'
---

# 차원 자원 안내서

## 차원 자원

Dimensional Resources는 행성을 발견하고 레이저를 사용해 그 행성의 자원을 채굴할 수 있게 해 주는 모드입니다!

## 시작하기

먼저 월드의 Y좌표 -16에서 -64 사이 깊은 곳에서 새로운 광석인 차원 광석을 찾으세요. 이 광석을 채굴하면 모드의 핵심 재료인 차원 조각을 얻을 수 있습니다.
<Row>
    <BlockImage id="dimresources:deepslate_dimensional_ore" scale="4" />
    <BlockImage id="dimresources:dimensional_ore" scale="4" />
</Row>

다음으로 망원경과 행성 탐지기를 제작해야 합니다.
<Row>
    <Recipe id="minecraft:spyglass" />
    <Recipe id="dimresources:planet_locator" />
</Row>
보조 손에 행성 탐지기를 들고 망원경으로 하늘을 바라보며 행성을 찾으세요! 행성을 발견하면 행성 탐지기가 해당 행성으로 설정됩니다.
