---
navigation:
    title: 레이저
    icon: 'dimresources:laser'
    parent: index.md
    position: 5
item_ids:
    - 'dimresources:laser'
---

# 레이저

## 레이저 설치

차원 간 레이저는 다른 행성에서 블록을 채굴하는 장치입니다. 레이저는 차원석과 차원석 벽돌로 만든 구조물 위에 설치해야 합니다. 아래 예시를 참고하세요.

<GameScene zoom="1" interactive={true}>
  <ImportStructure src="assets/structures/laser.nbt" />
</GameScene>

어느 행성에서 채굴할지 지정하려면 레이저 GUI에 행성 탐지기를 넣어야 합니다.

일부 행성에서는 더 높은 단계의 레이저 멀티블록이 필요합니다. 행성 레벨은 1~12이며, 레벨이 올라갈 때마다 멀티블록 높이를 한 블록씩 높여야 합니다.

<GameScene zoom="1" interactive={true}>
  <ImportStructure src="assets/structures/lasermax.nbt" />
</GameScene>
