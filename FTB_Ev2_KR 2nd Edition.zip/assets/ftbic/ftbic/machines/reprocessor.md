---
navigation:
  title: Reprocessor
  icon: ftbic:reprocessor
  parent: machines/index.md
  position: 9
item_ids:
  - ftbic:reprocessor
  - ftbic:scrap
  - ftbic:scrap_box
---

# <Color id="gold">Reprocessor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reprocessor" scale="2" />

  **각종 잡동사니 아이템**을 <ItemLink id="scrap" />으로 재활용합니다. Scrap은 Basic Generator의 고효율 연료이며, <ItemLink id="scrap_box" />로 제작해 무작위 보상을 얻을 수도 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="reprocessor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* 입력: Cobblestone, Dirt, Rotten Flesh, Stick 또는 재활용 가능 태그가 붙은 모든 아이템.
* 출력: 작업 1회당 약 12.5% 확률로 Scrap 생성(설정에서 변경 가능).
* **성능:** MV 등급, 에너지 저장량 <Energy config="machines.reprocessor_capacity" />, 소비량 <Energy config="machines.reprocessor_use" rate="true" />.

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="scrap_box" />
  ### <Color id="aqua">Scrap Box</Color>
</Row>

Scrap 9개를 압축하면 Scrap Box 1개가 됩니다. 사용하면 일반 재료부터 희귀한 Iridium Dust까지 무작위 아이템 하나가 나옵니다. 상자를 여러 개 들고 웅크린 채 사용하면 한 번에 모두 개봉합니다.

<RecipeFor id="scrap_box" />
