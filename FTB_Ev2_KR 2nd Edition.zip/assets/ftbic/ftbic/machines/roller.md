---
navigation:
  title: Roller
  icon: ftbic:roller
  parent: machines/index.md
  position: 6
item_ids:
  - ftbic:roller
  - ftbic:advanced_roller
---

# <Color id="gold">Roller</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="roller" scale="2" />

  Ingot을 평평하게 압연하여 **Plate**를 생산합니다. <ItemLink id="extruder" />의 Plate 제작법과 입력·출력은 같지만 사용하는 기계가 다릅니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="roller" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

**성능:** LV 등급, 에너지 저장량 <Energy config="machines.roller_capacity" />, 소비량 <Energy config="machines.roller_use" rate="true" />.

Roller를 사용하면 Extruder와 Plate 생산 공정을 분리해 병렬화할 수 있습니다. Cable 제작에 Copper Plate가 대량으로 필요해질 때 유용합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_roller" />
  ### <Color id="aqua">Advanced Roller</Color>
</Row>

MV 등급입니다. 소비량 <Energy config="machines.advanced_roller_use" rate="true" />, 에너지 저장량 <Energy config="machines.advanced_roller_capacity" />입니다. 제작법과 속도는 동일하며 <ItemLink id="parallel_processing_upgrade" />를 장착할 수 있습니다.

<RecipeFor id="advanced_roller" />
