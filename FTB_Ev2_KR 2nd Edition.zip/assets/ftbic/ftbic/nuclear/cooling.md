---
navigation:
  title: 냉각 구성품
  icon: ftbic:heat_vent
  parent: nuclear/index.md
  position: 3
item_ids:
  - ftbic:small_coolant_cell
  - ftbic:medium_coolant_cell
  - ftbic:large_coolant_cell
  - ftbic:heat_vent
  - ftbic:reactor_heat_vent
  - ftbic:overclocked_heat_vent
  - ftbic:component_heat_vent
  - ftbic:advanced_heat_vent
  - ftbic:heat_exchanger
  - ftbic:reactor_heat_exchanger
  - ftbic:component_heat_exchanger
  - ftbic:advanced_heat_exchanger
---

# <Color id="gold">냉각 구성품</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="heat_vent" scale="2" />

  냉각 방식은 두 가지입니다. **냉각 셀**은 내부 저장 공간이 포화될 때까지 열을 흡수하고, **열 배출구와 열 교환기**는 연료봉 → 배출구 → 외부 공기 순서로 열을 지속적으로 이동시킵니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">냉각 셀</Color>
</Column>

제한된 저장 공간에 열을 보관합니다. 셀이 포화되면 더 이상 열을 흡수하지 못합니다. 냉각 셀에만 의존하는 설계는 계획된 휴지 시간이 필요한 **간헐 가동형** 설계입니다.

<Row>
  <ItemImage id="small_coolant_cell" />
  ### <Color id="aqua">소형 냉각 셀</Color>
</Row>

<RecipeFor id="small_coolant_cell" />

<Row>
  <ItemImage id="medium_coolant_cell" />
  ### <Color id="aqua">중형 냉각 셀</Color>
</Row>

<RecipeFor id="medium_coolant_cell" />

<Row>
  <ItemImage id="large_coolant_cell" />
  ### <Color id="aqua">대형 냉각 셀</Color>
</Row>

<RecipeFor id="large_coolant_cell" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">열 배출구</Color>
</Column>

열 배출구는 원자로 본체 또는 인접한 구성품에서 열을 외부로 방출합니다. **연속 가동형** 설계에 필요합니다.

<Row>
  <ItemImage id="heat_vent" />
  ### <Color id="aqua">열 배출구</Color>
</Row>

기본 장치입니다. 원자로 본체에서 열을 끌어와 공기 중으로 방출합니다.

<RecipeFor id="heat_vent" />

<Row>
  <ItemImage id="reactor_heat_vent" />
  ### <Color id="aqua">원자로 열 배출구</Color>
</Row>

본체의 열을 더 강하게 방출하는 장치입니다. 원자로 챔버 자체에서 틱당 더 많은 열을 제거합니다.

<RecipeFor id="reactor_heat_vent" />

<Row>
  <ItemImage id="component_heat_vent" />
  ### <Color id="aqua">구성품 열 배출구</Color>
</Row>

본체가 아닌 인접한 **구성품**(냉각 셀)에서 열을 끌어옵니다. 냉각 셀의 열을 반복해서 제거하는 설계의 핵심입니다.

<RecipeFor id="component_heat_vent" />

<Row>
  <ItemImage id="overclocked_heat_vent" />
  ### <Color id="aqua">오버클럭 열 배출구</Color>
</Row>

혼합형 배출구로, 본체와 인접 구성품 양쪽의 열을 방출합니다. 부하가 높으면 자체적으로 손상되지만 올바른 위치에 배치하면 강력합니다.

<RecipeFor id="overclocked_heat_vent" />

<Row>
  <ItemImage id="advanced_heat_vent" />
  ### <Color id="aqua">고급 열 배출구</Color>
</Row>

최종 단계의 열 배출구입니다. IV 등급 설계에 사용합니다.

<RecipeFor id="advanced_heat_vent" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">열 교환기</Color>
</Column>

열 교환기는 열을 **균등하게 분배**합니다. 더 뜨거운 인접 구성품에서 차가운 구성품으로 열을 옮기거나, 원자로 본체에서 구성품으로 열을 전달합니다. 열 교환기가 없으면 연료봉 주변에 열이 집중됩니다.

<Row>
  <ItemImage id="heat_exchanger" />
  ### <Color id="aqua">열 교환기</Color>
</Row>

<RecipeFor id="heat_exchanger" />

<Row>
  <ItemImage id="reactor_heat_exchanger" />
  ### <Color id="aqua">원자로 열 교환기</Color>
</Row>

원자로 본체와 열을 교환하는 데 특화되어 있습니다. 본체의 열을 구성품 배치 영역으로 끌어와 열 배출구가 방출하도록 합니다.

<RecipeFor id="reactor_heat_exchanger" />

<Row>
  <ItemImage id="component_heat_exchanger" />
  ### <Color id="aqua">구성품 열 교환기</Color>
</Row>

인접한 구성품 사이에서만 열을 균등하게 분배합니다. 제작 비용이 저렴합니다.

<RecipeFor id="component_heat_exchanger" />

<Row>
  <ItemImage id="advanced_heat_exchanger" />
  ### <Color id="aqua">고급 열 교환기</Color>
</Row>

최종 단계의 열 교환기입니다.

<RecipeFor id="advanced_heat_exchanger" />
