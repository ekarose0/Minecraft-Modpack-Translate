---
navigation:
  title: 원자력
  icon: ftbic:nuclear_reactor
  position: 40
---

# <Color id="gold">원자력 발전</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nuclear_reactor" scale="2" />

  이 모드에서 가장 높은 출력을 내는 발전원이지만 실수했을 때의 피해도 가장 큽니다. 정상 작동하는 원자로는 **틱당 수백~수천 <EnergyUnit />**를 생산합니다. 반면 고장 난 원자로는 **기지를 통째로 날려 버릴 수 있습니다.**
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">세 가지 핵심 변수</Color>
</Column>

원자로 설계는 서로 영향을 주는 세 가지 수치를 조절하는 작업입니다.

* <Color id="red">**열**</Color>: 연료봉에서 생성되며 원자로 내부에 축적됩니다.
* <Color id="aqua">**냉각**</Color>: 냉각 셀과 열 배출구가 인접 연료봉의 열을 흡수하고 방출합니다.
* <Color id="gold">**출력**</Color>: 틱당 <EnergyUnit /> 생산량입니다. 인접한 중성자 반사판과 이중·사중 연료봉에 따라 증가합니다.

열이 100%에 도달하면 원자로가 **폭발**합니다. 폭발 반경은 기본 **10블록**에서 최대 **80블록**까지 증가할 수 있으며, 기반암까지 닿는 거대한 구덩이를 만들 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
