---
navigation:
  title: 연료봉
  icon: ftbic:uranium_fuel_rod
  parent: nuclear/index.md
  position: 2
item_ids:
  - ftbic:uranium_fuel_rod
  - ftbic:dual_uranium_fuel_rod
  - ftbic:quad_uranium_fuel_rod
---

# <Color id="gold">연료봉</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quad_uranium_fuel_rod" scale="2" />

  연료봉은 **열**과 **출력**을 생성합니다. 연료봉을 이중·사중으로 묶으면 출력과 발열량이 모두 급격히 증가하지만 훨씬 강력한 냉각 장치가 필요합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="uranium_fuel_rod" />
  ### <Color id="aqua">우라늄 연료봉</Color>
</Row>

고갈 우라늄을 <ItemLink id="canning_machine" />에서 가공해 제작합니다. 기본 단위로 출력 1배, 발열량 1배입니다.

<RecipeFor id="uranium_fuel_rod" />

<Row>
  <ItemImage id="dual_uranium_fuel_rod" />
  ### <Color id="aqua">이중 우라늄 연료봉</Color>
</Row>

연료봉 두 개를 결합한 것입니다. 출력 4배, 발열량 2배입니다. 슬롯당 효율은 높지만 냉각 부하도 두 배입니다.

<RecipeFor id="dual_uranium_fuel_rod" />

<Row>
  <ItemImage id="quad_uranium_fuel_rod" />
  ### <Color id="aqua">사중 우라늄 연료봉</Color>
</Row>

고출력 설계의 핵심입니다. 출력 10배, 발열량 4배이며 강력한 냉각 장치 옆에 신중하게 배치해야 합니다.

<RecipeFor id="quad_uranium_fuel_rod" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">배치 규칙</Color>
</Column>

연료봉은 **유효한 인접 구성품**(연료봉, 반사판, 방열 구성품)마다 열과 출력을 생성합니다. 빈 슬롯은 계산에 포함되지 않습니다. 설계할 때 다음 기준을 참고하세요.

* 반사판 4개와 인접한 단일 연료봉은 반사판 2개와 인접한 사중 연료봉만큼 출력합니다. 처음에는 이 배치부터 시도하세요.
* 냉각 능력을 충분히 확장한 뒤에 이중·사중 연료봉으로 규모를 늘리세요.
