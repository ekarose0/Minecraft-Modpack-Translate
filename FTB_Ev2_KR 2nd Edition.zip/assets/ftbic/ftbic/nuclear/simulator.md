---
navigation:
  title: 원자로 시뮬레이터
  icon: ftbic:reactor_simulator
  parent: nuclear/index.md
  position: 10
item_ids:
  - ftbic:reactor_simulator
---

# <Color id="gold">원자로 시뮬레이터</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reactor_simulator" scale="2" />

  원자로를 설계하는 작업대입니다. 구성품을 배치하고 최대 1,000배 속도로 시뮬레이션하여 실제 월드에 원자로를 건설하기 전에 얼마나 뜨거워지는지 정확히 확인할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">사용 방법</Color>
</Column>

1. 시뮬레이터를 설치하고 GUI를 엽니다.
2. 챔버 수 조절 버튼으로 실제 설계에서 사용할 원자로 챔버 수를 정합니다(0~6개, 활성화되는 열은 3~9열).
3. 물 접촉 면 조절 버튼으로 원자로 본체가 물과 얼마나 접촉할지 설정합니다. 실제 원자로의 주변 환경 냉각 배율과 일치합니다.
4. 격자에 유령 구성품을 배치합니다. 구성품 선택기나 JEI에서 아이템을 끌어다 놓습니다. 슬롯을 우클릭하면 지워집니다. 실제 아이템은 소모되지 않습니다.
5. **Analyze**를 눌러 빠르게 안정성을 평가합니다. 시뮬레이터가 설계 복사본으로 연료봉의 전체 수명을 계산한 뒤 **STABLE**(안정적) 또는 **OVERHEATS @ cycle N**(N번째 주기에 과열)을 표시합니다.
6. **Start**를 눌러 실시간 시뮬레이션을 실행합니다. 속도 줄에서 20배 / 100배 / 500배 / 1,000배를 선택할 수 있습니다. 틱당 현재 출력, 누적 발전량, 경과 주기 수가 실시간으로 갱신됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">조작 버튼</Color>
</Column>

* **Start**: 시뮬레이션을 시작하거나 이어서 실행합니다.
* **Pause**: 진행 중인 시뮬레이션을 일시 정지합니다. 슬롯을 다시 편집할 수 있고 주기 카운터는 유지됩니다.
* **Reset**: 모든 슬롯과 카운터를 초기화하여 설계판을 완전히 비웁니다.
* **Restart**: 현재 설계를 0주기부터 다시 실행합니다. 연료봉과 냉각 셀의 내구도가 완전히 복구됩니다.
* **Analyze**: 실시간 카운터에 영향을 주지 않고 연료봉의 전체 수명을 백그라운드에서 검사합니다.

시뮬레이션이 실행 중이고 일시 정지 상태가 아니라면 슬롯이 잠기고 챔버·물 조절 버튼도 비활성화됩니다. 수정하려면 먼저 일시 정지하세요.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">설계 공유</Color>
</Column>

* **Export**는 현재 설계를 JSON 형식으로 클립보드에 복사합니다. 채팅에 붙여 넣거나 메모 파일에 저장할 수 있습니다.
* **Import**는 클립보드의 JSON을 읽어 시뮬레이터에 불러옵니다.

[원자로 설계도](blueprint.md)를 사용하면 실제 원자로로 배치를 옮기거나 다른 플레이어와 공유할 수 있습니다. 인벤토리에 빈 설계도를 넣고 **Write Blueprint**를 누르세요. 원자로에서 **Load Preset**으로 저장된 프리셋을 불러오거나 **Paste Design**으로 내보낸 배치를 불러올 수도 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

시뮬레이터에는 전력이 필요하지 않습니다. 여러 개 만들어 다른 플레이어와 공유해 보세요. 실제 기지에 원자로를 설치할 때는 이미 어떻게 작동할지 알고 있을 것입니다.
