---
navigation:
  title: 원자로
  icon: ftbic:nuclear_reactor
  parent: nuclear/index.md
  position: 1
item_ids:
  - ftbic:nuclear_reactor
  - ftbic:nuclear_reactor_chamber
---

# <Color id="gold">원자로</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nuclear_reactor" scale="2" />

  원자로 본체에는 **6칸씩 3열**(총 18칸)의 구성품 슬롯이 있습니다. 각 면에 하나씩 최대 **6개의 원자로 챔버**를 연결하면 **9열, 총 54칸**까지 확장할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="nuclear_reactor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">원자로 챔버</Color>
</Column>

원자로의 어느 면에든 챔버를 연결하면 **구성품 슬롯 6칸**이 한 열 추가됩니다. 챔버 6개를 모두 설치하면 최대 9열, 54칸입니다. 챔버는 중앙 원자로로 **전력**과 **아이템**도 전달하므로 챔버를 통해 케이블이나 아이템 파이프를 연결할 수 있습니다.

<RecipeFor id="nuclear_reactor_chamber" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">작동 방식</Color>
</Column>

* **등급:** 기본 출력은 EV이며, 최고 수준의 설계는 IV 영역까지 도달할 수 있습니다.
* **내부 저장량:** <Energy config="machines.nuclear_reactor_capacity" />.
* GUI를 열고 연료봉, 열 배출구, 냉각 셀, 반사판, 장갑판 등의 구성품을 배치합니다.
* 레드스톤으로 원자로를 켜고 끌 수 있습니다. 신호가 없으면 일시 정지하므로 가동 사이에 냉각할 수 있습니다.
* Jade / Top에서 현재 열 비율(%)과 출력을 확인할 수 있습니다.

[원자로 설계도](blueprint.md)를 사용하면 계획한 배치를 유령 슬롯으로 불러오고, **Build from Inventory**로 인벤토리의 구성품을 채울 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">주변 환경을 이용한 냉각</Color>
</Column>

원자로는 매 주기마다 본체와 연결된 챔버의 외부로 노출된 모든 면을 검사합니다. **물** 블록과 닿아 있는 면의 비율에 따라 내부의 <ItemLink id="heat_vent" /> / <ItemLink id="reactor_heat_vent" /> / <ItemLink id="overclocked_heat_vent" /> / <ItemLink id="advanced_heat_vent" />가 원자로 본체에서 열을 제거하는 성능에 보너스를 받습니다.

* 물과 닿은 면이 0개 → 냉각 성능 **1배**(기본값)
* 완전히 물에 잠긴 상태 → 냉각 성능 **2배**

간단한 방법은 원자로를 얕은 물웅덩이에 설치하고 위를 유리로 덮는 것입니다. 모든 `reactorCool` 수치가 추가 비용 없이 두 배가 됩니다. 흐르는 물과 물 원천 모두 인정되지만 용암과 공기는 인정되지 않습니다.

강화 케이블과 그 케이블이 타버린 형태는 **중립적인 면**으로 취급되어 비율 계산에서 완전히 제외됩니다. 따라서 물에 잠긴 원자로에서 강화 케이블로 전력을 빼내도 수랭 보너스가 감소하지 않습니다.

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">격납</Color>
</Column>

원자로는 열이 100%에 도달하면 반드시 폭발합니다. 고출력 설계를 시도하기 전에 내폭성 블록(<ItemLink id="reinforced_stone" /> 또는 <ItemLink id="reinforced_glass" />)으로 원자로 주변을 둘러싸세요. 폭발 반경은 기본 **10블록**에서 최대 **80블록**까지 증가하며, 기반암까지 도달할 수 있습니다.

슬롯에 넣을 구성품에 대해서는 [연료봉](fuel_rods.md), [냉각](cooling.md), [반사판](reflectors.md), [장갑판](plating.md)을 참고하세요.
