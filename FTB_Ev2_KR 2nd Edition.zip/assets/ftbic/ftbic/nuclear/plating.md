---
navigation:
  title: 원자로 장갑판
  icon: ftbic:reactor_plating
  parent: nuclear/index.md
  position: 4
item_ids:
  - ftbic:reactor_plating
  - ftbic:heat_capacity_reactor_plating
  - ftbic:containment_reactor_plating
---

# <Color id="gold">원자로 장갑판</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reactor_plating" scale="2" />

  장갑판은 **원자로 본체**의 총 열용량과 최악의 상황에서 발생하는 폭발 반경을 변경합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="reactor_plating" />
  ### <Color id="aqua">원자로 장갑판</Color>
</Row>

원자로가 과열로 파괴될 때 폭발 피해를 줄입니다.

<RecipeFor id="reactor_plating" />

<Row>
  <ItemImage id="heat_capacity_reactor_plating" />
  ### <Color id="aqua">열용량 원자로 장갑판</Color>
</Row>

원자로의 총 열 저장 용량을 늘립니다. 위험 온도에 도달하는 시간을 늦추므로 간헐 가동형 설계를 운영하기 쉬워집니다.

<RecipeFor id="heat_capacity_reactor_plating" />

<Row>
  <ItemImage id="containment_reactor_plating" />
  ### <Color id="aqua">격납 원자로 장갑판</Color>
</Row>

격납에 실패했을 때 폭발 위력을 크게 줄입니다. 고출력 설계를 위한 안전장치입니다.

<RecipeFor id="containment_reactor_plating" />
