---
navigation:
  title: 중성자 반사판
  icon: ftbic:thick_neutron_reflector
  parent: nuclear/index.md
  position: 5
item_ids:
  - ftbic:neutron_reflector
  - ftbic:thick_neutron_reflector
  - ftbic:iridium_neutron_reflector
---

# <Color id="gold">중성자 반사판</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iridium_neutron_reflector" scale="2" />

  반사판은 출력 계산에서 연료봉의 **유효한 인접 구성품**으로 인정됩니다. 반사판 옆의 연료봉은 그 자리에 다른 연료봉이 있는 것처럼 작동합니다. 이리듐 반사판을 제외한 반사판에는 사용 수명 제한이 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="neutron_reflector" />
  ### <Color id="aqua">중성자 반사판</Color>
</Row>

제작 비용이 저렴한 소모품입니다. 시간이 지나면 수명이 다합니다.

<RecipeFor id="neutron_reflector" />

<Row>
  <ItemImage id="thick_neutron_reflector" />
  ### <Color id="aqua">두꺼운 중성자 반사판</Color>
</Row>

수명이 더 깁니다. 중반부 설계에서 표준적으로 사용합니다.

<RecipeFor id="thick_neutron_reflector" />

<Row>
  <ItemImage id="iridium_neutron_reflector" />
  ### <Color id="aqua">이리듐 중성자 반사판</Color>
</Row>

수명이 무한합니다. 비싸지만 영구 가동형 설계에서 기본으로 사용합니다.

<RecipeFor id="iridium_neutron_reflector" />
