---
navigation:
  title: 퓨즈
  icon: ftbic:fuse
  parent: utilities/index.md
  position: 6
item_ids:
  - ftbic:fuse
---

# <Color id="gold">퓨즈</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="fuse" scale="2" />

  **타버린 기계**를 한 번 수리할 수 있는 소모품입니다. 퓨즈를 손에 들고 타버린 FTBIC 기계를 우클릭하면 복구됩니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="fuse" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

기계가 허용 전압보다 높은 전압을 공급받으면 타버립니다. [변압기](../energy/transformers.md)와 [에너지 네트워크](../energy/index.md) 페이지의 과부하 설명을 참고하세요. 타버린 케이블은 수리할 수 없으며 <ItemLink id="scrap" />으로 재활용해야 합니다.
