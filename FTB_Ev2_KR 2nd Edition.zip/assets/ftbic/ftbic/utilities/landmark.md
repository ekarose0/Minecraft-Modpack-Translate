---
navigation:
  title: 랜드마크
  icon: ftbic:landmark
  parent: utilities/index.md
  position: 2
item_ids:
  - ftbic:landmark
---

# <Color id="gold">랜드마크</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="landmark" scale="2" />

  <ItemLink id="quarry" />의 작업 영역을 지정하는 표식 기둥입니다. 채굴할 구역의 서로 마주 보는 모서리에 랜드마크 두 개를 설치하세요.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="landmark" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

설치한 랜드마크를 우클릭하면 짝이 되는 랜드마크와 시각적으로 연결됩니다. 채석기는 두 기둥으로 둘러싸인 직사각형 영역을 기반암까지 채굴합니다.
