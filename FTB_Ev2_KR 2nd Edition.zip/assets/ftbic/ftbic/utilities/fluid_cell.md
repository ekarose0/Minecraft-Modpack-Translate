---
navigation:
  title: 유체 셀
  icon: ftbic:fluid_cell
  parent: utilities/index.md
  position: 4
item_ids:
  - ftbic:fluid_cell
---

# <Color id="gold">유체 셀</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="fluid_cell" scale="2" />

  유체 한 양동이를 담을 수 있는 휴대용 용기입니다. 모든 종류의 유체를 담을 수 있고, 내용물이 같으면 최대 16개까지 겹칠 수 있습니다. <ItemLink id="geothermal_generator" />를 포함하여 유체 슬롯이 있는 모든 기계와 연동됩니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="fluid_cell" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* 용량: 1,000 mB(한 양동이).
* 빈 셀은 서로 겹칠 수 있습니다. 채워진 셀도 유체 종류와 양이 같으면 겹칠 수 있습니다.
* 유체 원천 블록을 우클릭해 채우고, 공중을 우클릭해 비웁니다.
* 기계의 유체 슬롯에 넣으면 기계에 따라 내용물을 주입하거나 추출할 수 있습니다.
* 떨어진 셀이 유체 원천을 소모하지 않으므로 양동이보다 안전합니다.
