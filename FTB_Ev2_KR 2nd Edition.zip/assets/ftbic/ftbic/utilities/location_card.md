---
navigation:
  title: 위치 카드
  icon: ftbic:location_card
  parent: utilities/index.md
  position: 7
item_ids:
  - ftbic:location_card
---

# <Color id="gold">위치 카드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="location_card" scale="2" />

  <ItemLink id="teleporter" />를 간편하게 연결할 수 있는 휴대용 카드입니다. 텔레포터의 좌표를 카드에 저장한 뒤 다른 텔레포터의 목적지로 설정할 수 있습니다. 상대 텔레포터 검색 목록을 스크롤할 필요가 없습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="location_card" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">사용 방법</Color>
</Column>

1. **목적지 저장:** 빈 위치 카드를 들고 <ItemLink id="teleporter" />를 우클릭합니다. 카드에 해당 텔레포터의 차원, 위치, 이름이 저장됩니다.
2. **다른 텔레포터 설정:** 연결된 카드를 들고 자신이 소유한 다른 텔레포터를 우클릭합니다. 클릭한 텔레포터의 목적지가 카드에 저장된 위치로 설정됩니다.
3. **카드 초기화:** 공중을 Shift+우클릭하면 저장된 연결 정보가 지워집니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

연결된 카드는 **광택 효과**(마법이 부여된 아이템과 같은 빛)를 가지며, 툴팁에 저장된 차원, 좌표, 텔레포터 이름이 표시됩니다. 기지나 네트워크 거점별로 이름이 붙은 카드를 보관하면 편리합니다.
