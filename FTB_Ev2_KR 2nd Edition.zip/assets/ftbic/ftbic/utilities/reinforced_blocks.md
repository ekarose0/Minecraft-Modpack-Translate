---
navigation:
  title: 강화 블록
  icon: ftbic:reinforced_stone
  parent: utilities/index.md
  position: 8
item_ids:
  - ftbic:reinforced_stone
  - ftbic:reinforced_glass
---

# <Color id="gold">강화 블록</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reinforced_stone" scale="2" />

  폭발에 강한 건축 블록입니다. <ItemLink id="nuclear_reactor" />를 격납하거나 폭발물 시험장의 벽을 만드는 데 가장 적합합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="reinforced_stone" />
  ### <Color id="aqua">강화석</Color>
</Row>

<RecipeFor id="reinforced_stone" />

<Row>
  <ItemImage id="reinforced_glass" />
  ### <Color id="aqua">강화 유리</Color>
</Row>

투명한 강화 블록입니다. 원자로실을 들여다볼 수 있는 관찰창으로 사용하세요.

<RecipeFor id="reinforced_glass" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

격납벽을 뚫지 않고 전력을 전달해야 하나요? [케이블](../energy/cables.md) 페이지의 강화 케이블 계열을 참고하세요. 강화 케이블은 동일한 내구성을 가지면서도 해당 전압 등급의 전송량으로 전력을 전달합니다.
