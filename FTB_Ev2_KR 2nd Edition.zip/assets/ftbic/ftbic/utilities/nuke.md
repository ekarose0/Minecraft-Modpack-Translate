---
navigation:
  title: 핵폭탄과 핵화살
  icon: ftbic:nuke
  parent: utilities/index.md
  position: 3
item_ids:
  - ftbic:nuke
  - ftbic:active_nuke
  - ftbic:nuke_arrow
---

# <Color id="dark_red">핵폭탄</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nuke" scale="2" />

  <Color id="red">**경고: 완전한 파괴를 일으킵니다.**</Color> 기본 폭발 반경은 **36블록**입니다. 폭발 구체 안의 모든 구조물이 증발하며 떨어진 아이템도 모두 사라집니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="nuke" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="active_nuke" />
  ### <Color id="aqua">활성화된 핵폭탄</Color>
</Row>

설치한 뒤 레드스톤으로 기폭합니다. 점화된 TNT처럼 카운트다운한 후 폭발합니다.

<Row>
  <ItemImage id="nuke_arrow" />
  ### <Color id="aqua">핵화살</Color>
</Row>

일반 화살에 핵폭탄을 결합한 것입니다. 활로 발사하면 충돌 시 폭발합니다. **기지를 향해 발사하지 마세요.**

<RecipeFor id="nuke_arrow" />
