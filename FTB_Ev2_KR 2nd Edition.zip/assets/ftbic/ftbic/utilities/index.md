---
navigation:
  title: 유틸리티
  icon: ftbic:teleporter
  position: 70
---

# <Color id="gold">유틸리티와 특수 장치</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="teleporter" scale="2" />

  발전기, 기계, 방어구에 속하지 않는 여러 장치입니다. 텔레포터, 랜드마크, 핵폭탄, 스프레이 페인트, 유체 저장 용기, 퓨즈, 스크랩 상자 등을 다룹니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
