---
navigation:
  title: 스프레이 페인트
  icon: ftbic:dark_spray_paint_can
  parent: utilities/index.md
  position: 5
item_ids:
  - ftbic:light_spray_paint_can
  - ftbic:dark_spray_paint_can
---

# <Color id="gold">스프레이 페인트 캔</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="dark_spray_paint_can" scale="2" />

  기계 블록의 외형을 바꾸는 장식용 아이템입니다. 모든 FTBIC 기계는 **밝은색**과 **어두운색**의 두 가지 도색 상태를 지원합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="light_spray_paint_can" />
  ### <Color id="aqua">스프레이 페인트 캔(밝은색)</Color>
</Row>

<Row>
  <ItemImage id="dark_spray_paint_can" />
  ### <Color id="aqua">스프레이 페인트 캔(어두운색)</Color>
</Row>

<ItemLink id="canning_machine" />에서 <ItemLink id="empty_can" />과 해당 색상의 염료를 사용해 채웁니다.

도색할 수 있는 기계를 우클릭하면 외형이 바뀝니다. 캔마다 사용할 수 있는 횟수가 제한되어 있습니다.
