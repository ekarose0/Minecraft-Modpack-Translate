---
navigation:
  title: 자동 배출 업그레이드
  icon: ftbic:ejector_upgrade
  parent: upgrades/index.md
  position: 4
item_ids:
  - ftbic:ejector_upgrade
---

# <Color id="gold">자동 배출 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="ejector_upgrade" scale="2" />

  기계의 출력 슬롯에 있는 완성된 아이템을 아이템 출력이 허용된 면을 통해 인접한 인벤토리로 자동으로 밀어 넣습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="ejector_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* [측면 설정](../machines/side_configuration.md)에서 출력 면을 선택하세요. 입력 전용 면이나 아이템 전송이 비활성화된 면으로는 배출되지 않습니다.
* <ItemLink id="powered_crafting_table" />와 함께 사용하면 호퍼를 길게 연결하지 않고도 자동화 생산 라인을 만들 수 있습니다.
* 자동 배출 업그레이드는 하나면 충분합니다. 추가로 설치해도 배출 속도는 빨라지지 않습니다.
