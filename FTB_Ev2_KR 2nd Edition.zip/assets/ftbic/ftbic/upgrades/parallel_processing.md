---
navigation:
  title: 병렬 처리
  icon: ftbic:parallel_processing_upgrade
  parent: upgrades/index.md
  position: 5
item_ids:
  - ftbic:parallel_processing_upgrade
---

# <Color id="gold">병렬 처리 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="parallel_processing_upgrade" scale="2" />

  한 번의 작업 주기에 동일한 조합법을 여러 번 처리합니다. 업그레이드 하나당 **작업 1회**가 추가되어, 업그레이드 3개로 **최대 4회**를 동시에 처리할 수 있습니다.
</Column>

<RecipeFor id="parallel_processing_upgrade" />

## 호환 기계

**Advanced Powered Furnace**, **Advanced Macerator**, **Advanced Compressor**, **Advanced Centrifuge**, **Advanced Ore Washer**, **Advanced Canning Machine**, **Advanced Roller**, **Advanced Extruder**, **Advanced Hydroponic Accelerator**, **Alloy Smelter**, **Reprocessor**에 장착할 수 있습니다. 기계당 **최대 3개**까지 장착할 수 있으며, 업그레이드 슬롯 전체에 걸쳐 제한이 적용됩니다. 기본 가공 기계와 유틸리티 기계에는 장착할 수 없습니다.

## 일괄 처리 방식

* 모든 작업은 **동일한 조합법**을 사용하며 진행 막대 하나를 공유합니다. 한 주기에 걸리는 시간은 일반적인 처리 시간과 같습니다.
* 각 주기가 시작될 때 기계는 재료, 출력 공간, 저장된 에너지가 허용하는 만큼 작업 수를 결정합니다. 조건이 부족하면 더 작은 묶음으로도 작업할 수 있습니다.
* 작업마다 재료 한 세트가 필요합니다. 여러 종류의 아이템을 재료로 쓰는 조합법이라면 각 재료를 별도의 입력 슬롯에 넣고, 묶음 처리에 필요한 수량을 준비하세요.
* 원심분리기의 일괄 처리는 아이템과 유체 수량을 모두 배수로 늘립니다. 확률형 부산물은 작업마다 독립적으로 판정됩니다. 작업을 시작하려면 발생 가능한 모든 출력물을 수용할 공간이 있어야 합니다.
* **Advanced Hydroponic Accelerator**에서는 각 재배 구획이 독립적인 묶음을 처리합니다. 구획은 씨앗 슬롯에 있는 씨앗 하나당 작업 한 번을 실행하며 업그레이드 한도까지만 처리합니다. 작업마다 별도의 물을 소비합니다. 돌연변이 교배에는 작업마다 양쪽 부모 씨앗이 하나씩 필요합니다.
* 재료는 작업 주기가 끝날 때 소비됩니다. 진행 중에 재료를 추가하면 다음 묶음의 작업 수가 증가하며, 이미 진행 중인 묶음의 작업 수는 바뀌지 않습니다.

진행 화살표 아래의 **실행 중 / 최대** 표시에는 현재 처리 중인 작업 수가 나타납니다. 마우스를 올리면 설명을 볼 수 있습니다. 대기 중이거나 막힌 기계는 실행 중인 작업 수가 0으로 표시됩니다.

## 전력 소모와 작업 중단

각 작업은 기계의 원래 틱당 에너지 소비량을 그대로 사용합니다. 4개 작업을 동시에 실행하면 **틱당 에너지를 4배** 소비하지만, 조합법 하나당 총 에너지 비용은 단일 작업과 같습니다. <ItemLink id="overclocker_upgrade" />는 각 작업의 속도와 에너지 비용에 계속 영향을 줍니다.

예를 들어 **<Energy zaps="20" rate="true" />**를 소비하는 기계는 작업 4개를 동시에 처리할 때 **<Energy zaps="80" rate="true" />**를 소비합니다. 케이블, 전력 공급원, 에너지 저장량이 이를 감당할 수 있어야 합니다.

출력 공간이 막히면 에너지를 소비하지 않고 작업이 일시 정지됩니다. 전력이 부족하거나 필요한 재료가 사라지거나 조합법이 바뀌거나 현재 묶음 크기보다 업그레이드 수가 줄어들면 완료되지 않은 진행도가 초기화됩니다. 완료되지 않은 묶음은 재료를 소비하거나 결과물을 생산하지 않습니다. 저장 후 다시 불러와도 묶음 크기와 진행도는 유지됩니다.
