---
navigation:
  title: 채석기 필터
  icon: ftbic:quarry_filter_upgrade
  parent: upgrades/index.md
  position: 6
item_ids:
  - ftbic:quarry_filter_upgrade
---

# <Color id="gold">채석기 필터 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quarry_filter_upgrade" scale="2" />

  <ItemLink id="quarry" />가 지정된 블록만 채굴하고 불필요한 블록은 월드에 남기도록 설정합니다.
</Column>

<RecipeFor id="quarry_filter_upgrade" />

채석기 업그레이드 슬롯에 **1개**를 설치합니다. 채석기 화면 옆의 **F** 버튼을 눌러 블록 샘플이나 블록 태그를 선택하고, 허용 목록 또는 차단 목록을 지정한 뒤 필요하면 광석 전용 모드를 켤 수 있습니다. JEI에서 블록 아이템을 샘플 슬롯으로 끌어 놓거나, 커서에 블록 아이템을 들고 클릭하세요. 블록 태그를 입력한 뒤에는 Enter를 누릅니다.

광석 전용 모드는 `#c:ores` 태그를 사용합니다. 건너뛴 블록에는 채굴 에너지가 소모되지 않습니다. 설정 카드를 이용해 필터 설정을 다른 채석기로 복사할 수 있습니다. 자세한 내용은 <ItemLink id="quarry" /> 항목을 참고하세요.
