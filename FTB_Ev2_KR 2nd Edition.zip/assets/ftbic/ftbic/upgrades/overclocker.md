---
navigation:
  title: 오버클럭 업그레이드
  icon: ftbic:overclocker_upgrade
  parent: upgrades/index.md
  position: 1
item_ids:
  - ftbic:overclocker_upgrade
---

# <Color id="gold">오버클럭 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="overclocker_upgrade" scale="2" />

  업그레이드 하나당 제작 속도가 **1.45배**, 에너지 소비량이 **1.6배**가 됩니다. 여러 개를 장착하면 처리량이 기하급수적으로 늘어나지만 전력 소모도 크게 증가합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="overclocker_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* 최대 중첩 수량은 **슬롯당 4개**입니다. 따라서 한 슬롯만으로도 속도는 1.45⁴ ≈ 4.42배, 에너지 소모는 1.6⁴ ≈ 6.55배가 됩니다.
* 기계의 업그레이드 슬롯 전체에 합계 4개까지 설치할 수 있습니다. 4개 모두 한 슬롯에 넣어도 됩니다.
* 높은 단계의 오버클럭에는 적절한 <ItemLink id="transformer_upgrade" />와 충분한 전송 용량을 가진 케이블을 함께 사용하세요.
