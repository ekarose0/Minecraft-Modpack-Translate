---
navigation:
  title: 에너지 저장 업그레이드
  icon: ftbic:energy_storage_upgrade
  parent: upgrades/index.md
  position: 3
item_ids:
  - ftbic:energy_storage_upgrade
---

# <Color id="gold">에너지 저장 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="energy_storage_upgrade" scale="2" />

  업그레이드 하나당 기계의 내부 에너지 저장 공간이 **<Energy config="machines.storage_upgrade" />**만큼 증가합니다. 전력 사용량이 순간적으로 급증하는 작업을 안정화하거나 전력망에서 잠시 분리된 상태로 기계를 작동시킬 때 유용합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="energy_storage_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

기계당 최대 **4개**를 설치하여 내부 저장 공간을 <Energy config="machines.storage_upgrade" times="4" />만큼 추가할 수 있습니다.
