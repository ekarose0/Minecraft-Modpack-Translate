---
navigation:
  title: 변압기 업그레이드
  icon: ftbic:transformer_upgrade
  parent: upgrades/index.md
  position: 2
item_ids:
  - ftbic:transformer_upgrade
---

# <Color id="gold">변압기 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="transformer_upgrade" scale="2" />

  업그레이드 하나당 기계가 받아들일 수 있는 전압 등급을 **한 단계** 높입니다. LV Macerator에 변압기 업그레이드를 설치하면 타버리지 않고 MV 전력을 받을 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="transformer_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

최대 **4개**를 장착하면 모든 LV 기계가 IV 전력을 직접 받을 수 있습니다. 오버클럭 업그레이드는 전력 소모를 기본 등급의 케이블 용량보다 훨씬 크게 늘리므로, 변압기 업그레이드가 대표적인 보조 장치로 사용됩니다.

**4개**를 모두 설치하면 기계가 zap이나 FE 등 모든 양의 전력을 받을 수 있으며<ZapMode>,</ZapMode> 과전압으로 더 이상 타버리지 않습니다.
