---
navigation:
  title: 업그레이드
  icon: ftbic:overclocker_upgrade
  position: 60
---

# <Color id="gold">기계 업그레이드</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="overclocker_upgrade" scale="2" />

  업그레이드를 지원하는 기계에는 업그레이드 슬롯이 4개 있으며, 슬롯과 종류를 모두 합쳐 **최대 4개의 업그레이드**를 장착할 수 있습니다. 한 슬롯에 4개를 겹쳐 넣어도 됩니다. 병렬 처리 업그레이드는 기계당 최대 3개라는 별도 제한이 있습니다. 업그레이드 묶음을 Shift+클릭해 기계 UI에 넣거나, 업그레이드를 들고 기계를 Shift+우클릭하면 설치 가능한 수량만큼 한 번에 최대 4개를 장착합니다. 초과한 업그레이드는 손이나 인벤토리에 남습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
