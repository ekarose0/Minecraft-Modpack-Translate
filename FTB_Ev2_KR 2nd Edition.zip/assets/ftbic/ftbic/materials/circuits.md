---
navigation:
  title: 회로
  icon: ftbic:advanced_circuit
  parent: materials/index.md
  position: 5
item_ids:
  - ftbic:electronic_circuit
  - ftbic:advanced_circuit
  - ftbic:iridium_circuit
---

# <Color id="gold">회로</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="advanced_circuit" scale="2" />

  Circuit은 제작 가능한 기계의 등급을 결정합니다. 각 단계는 이전 등급의 Circuit을 기반으로 제작합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="electronic_circuit" />
  ### <Color id="aqua">Electronic Circuit</Color>
</Row>

Iron에 Copper Wire와 Redstone을 조합합니다. **LV** 등급을 해금하며 모든 기본 기계에 사용합니다.

<RecipeFor id="electronic_circuit" />

<Row>
  <ItemImage id="advanced_circuit" />
  ### <Color id="aqua">Advanced Circuit</Color>
</Row>

Electronic Circuit에 Glowstone과 <ItemLink id="enderium_ingot" />을 조합합니다. 고급형 기계, Teleporter, Antimatter Constructor 등 **HV/EV** 기계 제작에 필요합니다.

<RecipeFor id="advanced_circuit" />

<Row>
  <ItemImage id="iridium_circuit" />
  ### <Color id="aqua">Iridium Circuit</Color>
</Row>

Advanced Circuit에 <ItemLink id="iridium_alloy" />를 조합합니다. Quantum 장비와 최종 Cable 등급인 **IV/최종 단계**를 해금합니다.

<RecipeFor id="iridium_circuit" />
