---
navigation:
  title: 가루, 판, 막대
  icon: ftbic:dense_copper_plate
  parent: materials/index.md
  position: 1
item_ids:
  - ftbic:coal_dust
  - ftbic:charcoal_dust
  - ftbic:diamond_dust
  - ftbic:obsidian_dust
  - ftbic:dense_copper_plate
  - ftbic:copper_coil
  - ftbic:coal_ball
  - ftbic:compressed_coal_ball
  - ftbic:graphene
---

# <Color id="gold">가루, 판, 가공 형태</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="dense_copper_plate" scale="2" />

  거의 모든 제작법에 사용하는 중간 가공 형태입니다. Dust는 <ItemLink id="macerator" />, Plate는 <ItemLink id="roller" /> 또는 <ItemLink id="extruder" />, Rod와 Gear는 Extruder 공정에서 만듭니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특수 Dust</Color>
</Column>

<Row>
  <ItemImage id="ftbic:coal_dust" />
  ### <Color id="aqua">Coal Dust</Color>
</Row>

분쇄한 Coal입니다. Carbon Fiber와 Coal Ball 제작에 사용합니다.

<RecipesFor id="ftbic:coal_dust" />

<Row>
  <ItemImage id="ftbic:charcoal_dust" />
  ### <Color id="aqua">Charcoal Dust</Color>
</Row>

<Row>
  <ItemImage id="ftbic:obsidian_dust" />
  ### <Color id="aqua">Obsidian Dust</Color>
</Row>

<Row>
  <ItemImage id="ftbic:diamond_dust" />
  ### <Color id="aqua">Diamond Dust</Color>
</Row>

Macerator에서 Diamond를 분쇄하고 Dust 2개를 다시 압축해 Diamond로 만듭니다. 재활용 장비에서 Diamond를 얻는 경우 100% 추가 수익을 얻는 셈입니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특수 Plate와 가공 형태</Color>
</Column>

<Row>
  <ItemImage id="dense_copper_plate" />
  ### <Color id="aqua">Dense Copper Plate</Color>
</Row>

Copper Plate 9개를 압축해 하나로 만듭니다. <ItemLink id="nuclear_reactor" />와 고급 부품 제작에 사용합니다.

<Row>
  <ItemImage id="copper_coil" />
  ### <Color id="aqua">Copper Coil</Color>
</Row>

Iron Rod에 Copper Wire를 감아 만듭니다. Generator와 Transformer에 사용합니다.

<RecipeFor id="copper_coil" />

<Row>
  <ItemImage id="coal_ball" />
  ### <Color id="aqua">Coal Ball</Color>
</Row>

Coal Dust 4개 + Flint 4개 → Coal Ball 1개. Diamond 재활용 공정의 중간 단계입니다.

<RecipeFor id="coal_ball" />

<Row>
  <ItemImage id="compressed_coal_ball" />
  ### <Color id="aqua">Compressed Coal Ball</Color>
</Row>

Coal Ball 8개를 압축합니다. 이후 Diamond 제작법에 사용합니다.

<Row>
  <ItemImage id="graphene" />
  ### <Color id="aqua">Graphene</Color>
</Row>

Carbon과 Silicon을 Extruder로 가공합니다. 최종 단계 Circuit 제작에 사용합니다.

<RecipeFor id="graphene" />
