---
navigation:
  title: 탄소
  icon: ftbic:carbon_plate
  parent: materials/index.md
  position: 3
item_ids:
  - ftbic:carbon_fibers
  - ftbic:carbon_fiber_mesh
  - ftbic:carbon_plate
---

# <Color id="gold">탄소 부품</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="carbon_plate" scale="2" />

  <ItemLink id="carbon_helmet" /> 갑옷에 사용하는 가볍고 에너지 흡수 성능이 높은 재료입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="carbon_fibers" />
  ### <Color id="aqua">Carbon Fibers</Color>
</Row>

제작대에서 Coal Dust로 만듭니다.

<RecipeFor id="carbon_fibers" />

<Row>
  <ItemImage id="carbon_fiber_mesh" />
  ### <Color id="aqua">Carbon Fiber Mesh</Color>
</Row>

Carbon Fiber를 엮어서 만듭니다.

<RecipeFor id="carbon_fiber_mesh" />

<Row>
  <ItemImage id="carbon_plate" />
  ### <Color id="aqua">Carbon Plate</Color>
</Row>

<ItemLink id="compressor" />에서 Mesh를 압축합니다. 갑옷 제작에 사용하는 형태입니다.

<RecipeFor id="carbon_plate" />
