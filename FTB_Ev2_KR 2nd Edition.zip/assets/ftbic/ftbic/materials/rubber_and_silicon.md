---
navigation:
  title: 고무와 실리콘
  icon: ftbic:rubber
  parent: materials/index.md
  position: 4
item_ids:
  - ftbic:rubber
  - ftbic:rubber_sheet
  - ftbic:silicon_gem
---

# <Color id="gold">고무와 실리콘</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="rubber" scale="2" />

  거의 모든 기계 제작에 대량으로 필요한 두 가지 재료입니다. 고무는 모든 케이블을 감싸는 데 사용하고, 실리콘은 모든 회로의 기본 재료입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="rubber" />
  ### <Color id="aqua">고무</Color>
</Row>

바닐라 **슬라임볼**을 제련하면 **고무 8개**를 얻습니다. 이것이 주요 생산 방법입니다. 슬라임 농장은 쉽게 확장할 수 있고, 한 번 제련할 때 8개씩 생산되므로 케이블 제작 비용도 낮게 유지할 수 있습니다.

<RecipesFor id="rubber" />

<Row>
  <ItemImage id="rubber_sheet" />
  ### <Color id="aqua">고무 시트</Color>
</Row>

고무 9개 → 시트 1개. 장식 블록이자 <ItemLink id="mechanical_elytra" /> 제작 재료입니다.

<RecipeFor id="rubber_sheet" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="ftbic:silicon_gem" />
  ### <Color id="aqua">실리콘</Color>
</Row>

실리콘은 **FTB Materials**에서 제공합니다. <ItemLink id="centrifuge" />로 모래나 석영에서 추출할 수 있습니다. 이 모드의 모든 회로는 실리콘을 기반으로 제작합니다.
