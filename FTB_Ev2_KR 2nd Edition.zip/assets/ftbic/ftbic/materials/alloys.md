---
navigation:
  title: 합금
  icon: ftbic:iridium_alloy
  parent: materials/index.md
  position: 2
item_ids:
  - ftbic:mixed_metal_blend
  - ftbic:advanced_alloy
  - ftbic:industrial_grade_metal
  - ftbic:steel_ingot
  - ftbic:bronze_ingot
  - ftbic:electrum_ingot
  - ftbic:invar_ingot
  - ftbic:constantan_ingot
  - ftbic:iridium_alloy
  - ftbic:machine_block
  - ftbic:advanced_machine_block
  - ftbic:enderium_ingot
  - ftbic:enderium_nugget
  - ftbic:enderium_plate
  - ftbic:enderium_rod
  - ftbic:enderium_gear
  - ftbic:enderium_wire
  - ftbic:enderium_block
---

# <Color id="gold">합금</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iridium_alloy" scale="2" />

  복합 금속은 여러 종류의 Ingot을 결합해 높은 등급의 새 재료를 만듭니다. <ItemLink id="alloy_smelter" />는 모든 금속 합금을 생산하는 핵심 기계입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">기본 합금</Color>
</Column>

<ItemLink id="alloy_smelter" />에서 원재료 Ingot으로 제작합니다. 다시 분쇄해 Dust로 만들거나 제련하여 재활용할 수 있습니다.

<Row>
  <ItemImage id="bronze_ingot" />
  ### <Color id="aqua">Bronze</Color>
</Row>

Copper 3개 + Tin 1개 → Bronze 4개. Advanced Alloy의 Bronze 제작 경로에 사용되는 중간 등급 합금입니다.

<RecipeFor id="bronze_ingot" />

<Row>
  <ItemImage id="electrum_ingot" />
  ### <Color id="aqua">Electrum</Color>
</Row>

Silver 1개 + Gold 1개 → Electrum 2개. Advanced Alloy의 Electrum 제작 경로와 전도성 합금 공정에 사용합니다.

<RecipeFor id="electrum_ingot" />

<Row>
  <ItemImage id="invar_ingot" />
  ### <Color id="aqua">Invar</Color>
</Row>

Iron 2개 + Nickel 1개 → Invar 3개. Advanced Alloy의 Invar 제작 경로와 내열성 중간 재료로 사용합니다.

<RecipeFor id="invar_ingot" />

<Row>
  <ItemImage id="constantan_ingot" />
  ### <Color id="aqua">Constantan</Color>
</Row>

Copper 1개 + Nickel 1개 → Constantan 2개. 다양한 용도의 중간 합금입니다.

<RecipeFor id="constantan_ingot" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Steel: Advanced Alloy의 필수 재료</Color>
</Column>

<Row>
  <ItemImage id="steel_ingot" />
  ### <Color id="aqua">Steel Ingot</Color>
</Row>

이 공정에서 가장 중요한 합금입니다. **모든 Advanced Alloy 제작법에는 Steel이 필요합니다.** <ItemLink id="alloy_smelter" />에서 <ItemLink id="industrial_grade_metal" />과 탄소 재료를 합금해 만듭니다.

* Industrial Grade Metal 1개 + Coal 1개 → Steel Ingot 1개
* Industrial Grade Metal 1개 + Charcoal 1개 → Steel Ingot 1개

<RecipesFor id="steel_ingot" />

<ItemLink id="advanced_machine_block" />, <ItemLink id="reactor_plating" />, HV 이상 기계를 제작하기 전에 Steel을 비축하세요. 이 장치들은 후속 제작 과정에서 Advanced Alloy가 필요합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Mixed Metal Blend와 Industrial Grade Metal</Color>
</Column>

<Row>
  <ItemImage id="mixed_metal_blend" />
  ### <Color id="aqua">Mixed Metal Blend</Color>
</Row>

<ItemLink id="advanced_alloy" />를 분쇄해 얻는 혼합물로, 다시 제련하면 Advanced Alloy를 회수할 수 있습니다. Mixed Metal Blend에는 일반 제작대 조합법이 없습니다. Alloy Smelter의 제작법은 이 단계를 건너뜁니다.

<RecipesFor id="mixed_metal_blend" />

<Row>
  <ItemImage id="industrial_grade_metal" />
  ### <Color id="aqua">Industrial Grade Metal</Color>
</Row>

압축된 Iron입니다. Iron Ingot 3개를 압축해 하나로 만듭니다. <ItemLink id="machine_block" /> 제작에 쓰이며 Steel의 주재료입니다.

<RecipeFor id="industrial_grade_metal" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Advanced Alloy</Color>
</Column>

<Row>
  <ItemImage id="advanced_alloy" />
  ### <Color id="aqua">Advanced Alloy</Color>
</Row>

모든 후반 기계, 갑옷, Reactor 구성품, <ItemLink id="iridium_alloy" /> 제작의 핵심 재료입니다. <ItemLink id="alloy_smelter" />에서 다음 세 가지 Steel 기반 제작법 중 하나로 만듭니다.

* Steel 1개 + Bronze 2개 + Aluminum 1개 → Advanced Alloy 1개
* Steel 1개 + Electrum 1개 + Aluminum 1개 → Advanced Alloy 1개
* Steel 1개 + Invar 2개 + Aluminum 1개 → Advanced Alloy 1개

보유한 합금에 따라 제작법을 선택하세요. Copper와 Tin이 넉넉하다면 Bronze가 가장 저렴하고, Invar는 Iron 원료가 더 많이 필요하며, Electrum은 Silver와 Gold가 충분하다면 주괴 수량 기준으로 가장 효율적입니다.

<RecipesFor id="advanced_alloy" />

<Row>
  <ItemImage id="iridium_alloy" />
  ### <Color id="aqua">Iridium Alloy</Color>
</Row>

<ItemLink id="advanced_alloy" />로 강화한 Iridium Plate입니다. 최종 등급의 합금으로 <ItemLink id="iridium_circuit" />, <ItemLink id="iridium_neutron_reflector" />, <ItemLink id="quantum_helmet" /> 제작에 필요합니다.

<RecipeFor id="iridium_alloy" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Enderium</Color>
</Column>

보라색과 푸른색이 섞인 마법 합금입니다. <ItemLink id="teleporter" />, <ItemLink id="iv_cable" />, 고급 Circuit에 사용합니다.

<Row>
  <ItemImage id="enderium_ingot" />
  ### <Color id="aqua">Enderium Ingot</Color>
</Row>

<ItemLink id="alloy_smelter" />에서만 만들 수 있습니다. Lead 3개 + Diamond Dust 1개 + Ender Pearl 2개 → Enderium Ingot 2개. 일반 제작대 조합법은 없습니다.

<Recipe id="ftbic:alloy_smelting/enderium_ingot" />

<RecipesFor id="enderium_ingot" fallbackText="제작법은 Alloy Smelter를 참고하세요." />

<Row>
  <ItemImage id="enderium_block" />
  ### <Color id="aqua">Block of Enderium</Color>
</Row>

Ingot 9개 → Block 1개. 대량 보관용입니다.

<RecipeFor id="enderium_block" />

Enderium은 <ItemLink id="enderium_nugget" />, <ItemLink id="enderium_plate" />, <ItemLink id="enderium_rod" />, <ItemLink id="enderium_gear" />, <ItemLink id="enderium_wire" /> 등 모든 표준 형태로 가공할 수 있습니다.
