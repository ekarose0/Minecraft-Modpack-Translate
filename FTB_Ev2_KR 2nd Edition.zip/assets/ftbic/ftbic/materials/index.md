---
navigation:
  title: 재료
  icon: ftbic:advanced_alloy
  position: 5
---

# <Color id="gold">재료</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="advanced_alloy" scale="2" />

  FTBIC는 광석, 주괴, 조각, 가루, 판, 막대, 기어, 전선에 FTB Materials를 사용합니다. 이 모드는 몇 가지 특수 재료(합금, 탄소 부품, 고무, 실리콘)와 단계별 회로 체계를 추가합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">하위 항목</Color>
</Column>

<SubPages icons={true} />
