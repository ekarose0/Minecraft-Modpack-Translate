---
item_ids:
  - auroral:shimmersteel_pickaxe
  - auroral:shimmersteel_axe
  - auroral:shimmersteel_shovel
  - auroral:shimmersteel_sword
  - auroral:shimmersteel_hoe
navigation:
  title: "Shimmersteel 도구"
  icon: auroral:shimmersteel_pickaxe
  parent: index.md
  position: 43
---

# <Color id="gold">Shimmersteel 도구</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_pickaxe" scale="2" />

  철보다 성능이 조금 뛰어나고 마법 부여 적합성이 높으며, 도구마다 고유 능력이 있습니다. 다섯 종류 모두 오로라 동안 손에 들면 자동으로 수리됩니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">곡괭이</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_pickaxe" />
  ### <Color id="aqua">보석 광석에 기본 적용되는 행운</Color>
</Row>

* 다이아몬드, 에메랄드, 청금석 및 기타 보석 광석에 **행운 III**을 자동 적용합니다.
* 나머지 광석에는 일반적인 행운 확률이 적용됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">도끼</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_axe" />
  ### <Color id="aqua">산화 강제 진행</Color>
</Row>

* 구리 블록을 우클릭하면 산화 단계를 즉시 진행시킵니다.
* 일반 도끼처럼 통나무 껍질을 벗기고, 구리의 산화를 긁어내며, 밀랍을 제거할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">삽</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_shovel" />
  ### <Color id="aqua">기본 섬세한 손길</Color>
</Row>

* 항상 섬세한 손길이 적용된 것처럼 블록을 채집합니다.
* 눈 층과 잔디 블록 등을 수집하기 좋습니다.
* 흙길을 만들거나 모닥불을 끄는 기능도 유지됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">검</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_sword" />
  ### <Color id="aqua">둔화, 처형, 눈 표시</Color>
</Row>

* **구속 I** — 타격할 때마다 대상에게 적용합니다.
* **처형** — 체력이 15% 미만인 적에게 막대한 추가 피해를 줍니다.
* **눈 표시** — 처형된 적이 쓰러진 자리에 눈 층을 만듭니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">괭이</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_hoe" />
  ### <Color id="aqua">섬세한 손길 및 Shimmer Soil 생성</Color>
</Row>

* **기본 섬세한 손길** — 작물과 블록을 섬세한 손길이 적용된 것처럼 채집합니다.
* **Shimmer Soil 생성** — 눈 블록, 가루눈, 흙, 잔디, 눈 층을 우클릭하면 <ItemLink id="shimmer_soil" />을 만듭니다.
* **경작지 강화** — 일반 경작지를 우클릭하여 강화하며 수분 상태도 유지합니다.
* 흙이 없어도 얼어붙은 생물 군계에서 농장을 시작하기 좋습니다.

<Row>
  <ItemImage id="shimmer_soil" />
  ### <Color id="aqua">Shimmer Soil</Color>
</Row>

이 마법 경작지는 작물의 성장을 촉진합니다.

* 밤에는 **3배 빠르게** 성장합니다.
* 오로라 동안에는 **5배 빠르게** 성장합니다.
* 은은하게 빛납니다(밝기 2).
* 반경 4블록 이내의 물 **또는** <ItemLink id="shimmering_ice" />로 수분을 공급받습니다.
* 작물이 심겨 있는 동안 흙으로 되돌아가지 않습니다.
* 일반 경작지처럼 바닐라 및 모드 작물의 씨앗을 심을 수 있습니다.

Shimmering Ice와 함께 사용하면 물이 필요 없는 빛나는 지하 농장을 만들 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">자동 수리</Color>
</Column>

Shimmersteel 도구 5종은 모두 오로라 동안 손에 들고 있으면 자동으로 수리됩니다.
