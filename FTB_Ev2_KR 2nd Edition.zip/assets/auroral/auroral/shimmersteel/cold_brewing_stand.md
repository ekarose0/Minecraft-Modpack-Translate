---
item_ids:
  - auroral:cold_brewing_stand
navigation:
  title: "Cold Brewing Stand"
  icon: auroral:cold_brewing_stand
  parent: index.md
  position: 42
---

# <Color id="gold">Cold Brewing Stand</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="cold_brewing_stand" scale="2" />

  네더에 가지 않아도 사용할 수 있는 바닐라 양조기의 대안입니다. 일반 양조기와 같은 포션을 만들지만 블레이즈 가루 대신 눈덩이를 연료로 사용합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="cold_brewing_stand" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">작동 방식</Color>
</Column>

Cold Brewing Stand는 바닐라 양조기와 똑같이 작동하지만, 연료가 **눈덩이**라는 중요한 차이가 있습니다.

다음과 같은 상황에 적합합니다.

* 스카이블록이나 평화로움 난이도로 플레이할 때
* 아직 네더에 진입하지 못한 플레이어
* 눈덩이가 풍부한 추운 생물 군계의 기지

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">네더 사마귀를 대신하는 Frozen Petals</Color>
</Column>

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">기본 포션 양조</Color>
</Row>

<ItemLink id="frozen_petals" />를 사용하면 네더 사마귀와 똑같이 물병에서 **어색한 포션**을 만들 수 있습니다. 네더에 한 번도 가지 않고 모든 포션 제작을 시작할 수 있습니다.

양조 순서:

1. 양조기에 눈덩이를 넣습니다(최대 20개).
2. 아래쪽 칸에 물병을 놓습니다.
3. 재료 칸에 Frozen Petals를 넣습니다.
4. 양조가 끝날 때까지 기다리면 어색한 포션이 완성됩니다.

그다음부터는 일반 재료를 사용하여 나머지 포션을 양조하면 됩니다.
