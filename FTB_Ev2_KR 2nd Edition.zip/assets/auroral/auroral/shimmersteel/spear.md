---
item_ids:
  - auroral:shimmer_spear
navigation:
  title: "Shimmer Spear"
  icon: auroral:shimmer_spear
  parent: index.md
  position: 45
---

# <Color id="gold">Shimmer Spear</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmer_spear" scale="2" />

  긴 사거리와 관통 공격을 갖춘 창으로, 제대로 찌를수록 강력합니다. 공격할 때마다 Frostbite를 부여하며 오로라 동안에는 피해량도 증가합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmer_spear_smithing" />

대장장이 작업대에서 **Iron Spear**에 **Shimmersteel Upgrade Template**과 <ItemLink id="shimmersteel_ingot" />을 사용해 강화하면 제작할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">창 전투</Color>
</Column>

<Row>
  <ItemImage id="shimmer_spear" />
  ### <Color id="aqua">사거리 및 충전</Color>
</Row>

* 사거리가 길어 더 먼 곳의 적을 공격할 수 있습니다.
* 관통 피해는 검과 다르게 방패와 상호작용합니다.
* 우클릭을 길게 눌러 찌르기를 충전하고 놓으면 강하게 공격합니다.
* 최소 공격 충전량이 100%이며, 공격 재사용 대기시간이 완전히 찼을 때 가장 강력합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">타격 시 Frostbite</Color>
</Column>

명중할 때마다 대상에게 Frostbite를 부여합니다. Frostbite는 이동 속도와 회복량, 방어력을 낮추고 방패 내구도가 더 빨리 줄어들게 합니다. 추가 공격으로 효과 지속시간을 갱신할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aurora 강화</Color>
</Column>

* 오로라 동안 찌르기 공격마다 추가 피해를 줍니다.
* 오로라로 강화된 Frostbite는 더 높은 강도로 두 배 오래 지속됩니다.
* 타격 지점에서 오로라 입자가 흩날립니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 긴 사거리를 이용하면 자신을 노출하지 않고 군중이나 울타리 너머의 적을 찌를 수 있습니다.
* 적이 접근하는 순간 완전히 충전된 찌르기를 사용하세요. 덜 충전하면 피해량이 낮습니다.
* <ItemLink id="shimmerweave_skates" />와 조합하면 얼음 위에서 거리를 유지하며 싸우기 좋습니다.
* 오로라가 떠 있는 동안은 강한 적에게 도전하기 좋은 기회입니다.
