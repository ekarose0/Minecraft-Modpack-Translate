---
item_ids:
  - auroral:glacial_basin
navigation:
  title: "Glacial Basin"
  icon: auroral:glacial_basin
  parent: index.md
  position: 41
---

# <Color id="gold">Glacial Basin</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glacial_basin" scale="2" />

  주요 작업대입니다. 오로라 동안 Liquid Aura를 모아 원재료를 마법이 깃든 재료로 변환합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="glacial_basin" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">작동 방식</Color>
</Column>

1. 하늘이 트인 곳에 Glacial Basin을 **설치**합니다.
2. 오로라가 시작될 때까지 **기다립니다**.
3. 빛나는 Liquid Aura가 채워지는 것을 **확인**합니다(최대 3단계).
4. 변환할 아이템을 들고 **우클릭**합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">변환 목록</Color>
</Column>

| 입력 재료 | 결과물 | Aura 소모량 |
|-------|--------|-----------|
| <ItemLink id="unrefined_shimmersteel" /> | <ItemLink id="shimmersteel_ingot" /> | 3(가득 채움) |
| <ItemLink id="woven_leather" /> | <ItemLink id="shimmerweave_fabric" /> | 1 |
| <ItemLink id="frozen_petals" /> | <ItemLink id="aurora_shard" /> | 1 |
| 얼음 | <ItemLink id="shimmering_ice" /> | 1 |

Shimmersteel Ingot을 주입하려면 Glacial Basin이 **완전히 차 있어야** 하며 Liquid Aura 3단계를 한 번에 모두 소모합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* Glacial Basin을 여러 개 설치하면 이벤트마다 더 많은 Aura를 모을 수 있습니다.
* Glacial Basin 위로 하늘이 막힘없이 보여야 합니다.
* 오로라는 밤새 지속되므로 채울 시간은 충분합니다.
