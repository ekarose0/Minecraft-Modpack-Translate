---
item_ids:
  - auroral:shimmersteel_ingot
  - auroral:unrefined_shimmersteel
navigation:
  title: "Shimmersteel Ingot"
  icon: auroral:shimmersteel_ingot
  parent: index.md
  position: 40
---

# <Color id="gold">Shimmersteel Ingot</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_ingot" scale="2" />

  Auroral의 핵심이 되는 마법 금속입니다. Aurora의 힘이 스며들어 철보다 조금 뛰어나며, 모드의 모든 강화 도구와 무기, 장신구 제작의 출발점이 됩니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">1단계 — Unrefined Shimmersteel</Color>
</Column>

<Row>
  <ItemImage id="unrefined_shimmersteel" />
  ### <Color id="aqua">철 + Aurora Shard</Color>
</Row>

철 주괴와 <ItemLink id="aurora_shard" />를 조합하여 Unrefined Shimmersteel을 제작합니다.

<RecipeFor id="unrefined_shimmersteel" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">2단계 — Glacial Basin 주입</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">주입</Color>
</Row>

Liquid Aura가 채워진 <ItemLink id="glacial_basin" />에 Unrefined Shimmersteel을 넣어 주입합니다.

1. 추운 생물 군계에서 하늘이 트인 곳에 Glacial Basin을 설치합니다.
2. 오로라가 나타나 Glacial Basin이 완전히 찰 때까지 기다립니다(Aura 3/3).
3. Unrefined Shimmersteel을 들고 Glacial Basin을 우클릭합니다.
4. Glacial Basin의 Liquid Aura가 **전부** 소모되고 Shimmersteel Ingot 1개가 만들어집니다.

**중요:** 이 주입을 진행하려면 Glacial Basin이 완전히 차 있어야 합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

* **높은 마법 부여 적합성** — 마법 부여가 잘 적용됩니다.
* **Aurora 친화성** — 오로라 동안 Shimmersteel 도구와 방어구가 자동으로 수리됩니다.
* **성능** — 철보다 조금 좋지만 다이아몬드보다는 낮습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">활용법</Color>
</Column>

Shimmersteel Ingot은 대장장이 작업대에서 철 장비를 강화하는 데 사용합니다. 강화하려면 **Shimmersteel Upgrade Smithing Template**이 필요합니다.

* <ItemImage id="shimmersteel_pickaxe" scale="0.75"/> [Shimmersteel 도구](tools.md) — 곡괭이, 도끼, 삽, 괭이, 검
* <ItemImage id="shimmersteel_bow" scale="0.75"/> [Shimmersteel Bow](bow.md) — 눈덩이로 Star-Shot을 발사합니다.
* <ItemImage id="shimmer_spear" scale="0.75"/> [Shimmer Spear](spear.md) — 사거리가 긴 관통 창
