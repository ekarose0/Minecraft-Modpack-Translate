---
navigation:
  title: "Shimmersteel 갑옷 장식"
  icon: auroral:shimmersteel_ingot
  parent: index.md
  position: 46
---

# <Color id="gold">Shimmersteel 갑옷 장식</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_ingot" scale="2" />

  Shimmersteel Ingot을 갑옷 장식 재료로 사용하면 어떤 갑옷이든 Aurora를 연상시키는 차가운 푸른빛 무늬를 더할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">장식 적용 방법</Color>
</Column>

1. **대장장이 형판**을 구합니다. 바닐라 구조물에서 얻는 갑옷 장식 무늬라면 어느 것이든 됩니다.
2. 대장장이 작업대에 형판, 갑옷, <ItemLink id="shimmersteel_ingot" />을 넣습니다.
3. 완성된 갑옷에는 파란색과 은색 사이에서 반짝이는 얼음빛 장식이 생깁니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">외형</Color>
</Column>

Shimmersteel 장식은 독특한 얼음빛 그라데이션이 특징입니다.

* 짙은 푸른색 그림자
* 차가운 강철빛 파란 중간 색조
* 밝은 얼음처럼 하얀 강조색

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">호환성</Color>
</Column>

Shimmersteel 장식은 다음과 호환됩니다.

* 모든 바닐라 갑옷 — 가죽, 사슬, 철, 금, 다이아몬드, 네더라이트
* 바닐라 장식 시스템을 지원하는 대부분의 모드 갑옷
* 모든 바닐라 장식 무늬 — Coast, Dune, Eye, Host, Raiser, Rib, Sentry, Shaper, Silence, Snout, Spire, Tide, Vex, Ward, Wayfinder, Wild

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 다이아몬드나 철 갑옷과 조합하면 차가운 분위기를 통일하기 좋습니다.
* Shimmerweave 방어구와 함께 착용하면 얼음 탐험가 같은 외형을 완성할 수 있습니다.
* Shimmersteel은 마법 부여 적합성이 높아 장식한 갑옷에도 좋은 마법을 부여할 수 있습니다.
