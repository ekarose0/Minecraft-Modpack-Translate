---
item_ids:
  - auroral:shimmersteel_bow
navigation:
  title: "Shimmersteel Bow"
  icon: auroral:shimmersteel_bow
  parent: index.md
  position: 44
---

# <Color id="gold">Shimmersteel Bow</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_bow" scale="2" />

  평범한 눈덩이를 강력한 Star-Shot으로 바꾸는 원거리 무기입니다. 밝게 빛나며 적의 눈을 멀게 하고, 추운 생물 군계에서는 탄약을 계속 구할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmersteel_bow_smithing" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Star-Shot</Color>
</Column>

Shimmersteel Bow는 **눈덩이**를 탄약으로 사용합니다. 발사할 때마다 눈덩이가 Star-Shot으로 변합니다.

<Row>
  <ItemImage id="shimmersteel_bow" />
  ### <Color id="aqua">특성</Color>
</Row>

* **피해량** — 화살보다 기본 피해량이 높습니다.
* **섬광탄** — 착탄 지점 주변의 적을 잠시 실명시키고 혼란스럽게 합니다.
* **빛의 궤적** — 공중에 입자 궤적이 나타납니다.
* **회수 불가** — 발사한 Star-Shot은 다시 주울 수 없습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 추운 생물 군계에서는 눈덩이를 쉽게 구하므로 탄약 걱정이 적습니다.
* 섬광 효과는 적이 밀집한 곳에서 군중 제어에 효과적입니다.
* 다른 Shimmersteel 장비처럼 오로라 동안 자동으로 수리됩니다.
