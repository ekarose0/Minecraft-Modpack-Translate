---
navigation:
  title: "Hearthwood Log"
  icon: auroral:hearthwood_log
  parent: index.md
  position: 62
item_ids:
  - auroral:hearthwood_log
---

# <Color id="gold">Hearthwood Log</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hearthwood_log" scale="2" />

  마법의 불꽃으로 타오르는 특별한 통나무입니다. 불이 붙은 Hearthwood는 Frostbite를 막고 팬텀을 쫓아내며 오로라 발생 확률을 높입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">획득 방법</Color>
</Column>

Hearthwood Log는 추운 생물 군계에서 자연적으로 자라며, 다음 장소에서도 발견됩니다.

* 눈 덮인 타이가 마을
* 얼어붙은 구조물
* 이글루 지하실(가끔)

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">불 붙이기</Color>
</Column>

**부싯돌과 부시**로 통나무를 우클릭하면 불이 붙습니다. 따뜻하고 신비로운 빛을 내면서 지속 효과가 적용됩니다. 불이 꺼진 통나무에도 같은 방법으로 다시 불을 붙일 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">효과</Color>
</Column>

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">긴 연소 시간</Color>
</Row>

불붙은 Hearthwood Log는 청크가 로드된 시간 기준으로 **게임 내 7일**(168,000틱, 연속 플레이 약 2시간 20분) 동안 타오릅니다. 청크가 활성화된 동안에만 시간이 줄어들므로, 거의 방문하지 않는 청크의 통나무는 실제 시간으로 훨씬 오래 유지됩니다. 연소 시간은 서버 설정에서 변경할 수 있습니다.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Frostbite 면역</Color>
</Row>

불붙은 통나무에서 **반경 16블록** 안에 있는 플레이어는 Frostbite에 면역이 됩니다. 기지 주변을 둘러 설치하면 혹독한 겨울에도 안전합니다.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">팬텀 방어</Color>
</Row>

불붙은 통나무에서 16블록 안으로 들어온 팬텀은 접촉 시 불이 붙습니다. 또한 팬텀은 Frostbite 면역으로 따뜻해진 플레이어를 공격 대상으로 삼지 않습니다. 기지 주변에 통나무를 둘러 설치하면 밤하늘을 안전하게 지킬 수 있습니다.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Aurora 촉매</Color>
</Row>

추운 생물 군계에서 플레이어의 **32블록 이내**에 불붙은 통나무가 있으면 밤이 시작될 때 오로라 발생 확률이 **15%p 증가**합니다. 최대 3개까지 중첩되어 **45%p 증가**하며, 기본 설정에서는 약 78%가 됩니다. 네 번째부터는 추가 효과가 없습니다.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">주민의 안락함</Color>
</Row>

불붙은 통나무 근처의 주민은 더 편안함을 느끼며, 더 유리한 거래를 제안할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 추운 생물 군계의 기지 주변에 설치하면 Frostbite로부터 계속 보호받을 수 있습니다.
* 따뜻한 빛은 분위기 있는 조명으로도 활용할 수 있습니다.
* 오로라 확률 보너스는 불붙은 통나무 3개가 최적입니다. 네 번째는 효과가 늘어나지 않습니다.
