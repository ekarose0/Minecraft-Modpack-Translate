---
item_ids:
  - auroral:snow_angel
navigation:
  title: "Snow Angel"
  icon: auroral:snow_angel
  parent: index.md
  position: 60
---

# <Color id="gold">Snow Angel</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="snow_angel" scale="2" />

  갓 내린 눈에 남기는 장난스러운 자국입니다. 기본적으로 잠시 후 사라지지만 Frozen Petal로 영구 보존할 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Snow Angel 만들기</Color>
</Column>

**양손을 모두 비운 상태에서 웅크리고 눈 표면을 우클릭**합니다. 캐릭터가 눈 위에 장식용 Snow Angel 무늬를 남깁니다.

Snow Angel은 *교체 가능한* 블록으로 취급됩니다. 키 큰 풀이나 눈 층과 마찬가지로 먼저 부수지 않아도 그 자리에 다른 블록을 바로 설치할 수 있습니다.

만들 수 있는 표면:

* 눈 층
* 눈 블록
* 가루눈

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">사라지는 시간</Color>
</Column>

Snow Angel은 본래 일시적인 장식입니다. 새 눈에 남은 발자국처럼 그대로 두면 **5분 후** 사라집니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">영구 보존</Color>
</Column>

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">Frozen Petal로 우클릭</Color>
</Row>

<ItemLink id="frozen_petals" />을 들고 Snow Angel을 우클릭합니다. 꽃잎의 마법이 눈 무늬를 결정화하여 사라지지 않게 합니다. 보존된 Snow Angel은 부술 때까지 남습니다.

Frozen Petals는 오로라 동안 완전히 성장한 <ItemLink id="aurora_bloom" />에서 채집할 수 있습니다.
