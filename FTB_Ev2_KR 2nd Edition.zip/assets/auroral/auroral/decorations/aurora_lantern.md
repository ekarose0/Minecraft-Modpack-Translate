---
item_ids:
  - auroral:aurora_lantern
navigation:
  title: "Aurora Lantern"
  icon: auroral:aurora_lantern
  parent: index.md
  position: 61
---

# <Color id="gold">Aurora Lantern</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_lantern" scale="2" />

  북극광의 신비로운 빛을 담은 장식용 광원입니다. 손에 들면 마법의 어둠을 몰아냅니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="aurora_lantern" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

* **밝기 15** — 최대 밝기를 냅니다.
* **색상 변화** — 오로라의 초록색, 파란색, 분홍색 빛으로 서서히 변합니다.
* **설치 가능** — 바닥과 벽에 설치하거나 천장에 매달 수 있습니다.
* **방수** — 물속에서도 꺼지지 않고 작동합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">어둠 효과 면역</Color>
</Column>

<Row>
  <ItemImage id="aurora_lantern" />
  ### <Color id="aqua">손에 들었을 때</Color>
</Row>

Aurora Lantern을 주 손이나 보조 손에 들면 어둠(Darkness) 효과에 면역이 됩니다. 신비로운 빛이 마법의 어둠을 몰아내므로 딥 다크 탐험이나 워든과의 전투에 특히 유용합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">활용법</Color>
</Column>

* 추운 생물 군계의 건축물 밝히기
* 마법 같은 분위기 연출하기
* 눈 덮인 지형에 길 표시하기
* Shimmerweave 테마의 공간 꾸미기
