---
item_ids:
  - auroral:aurora_shard
navigation:
  title: "Aurora 이벤트"
  icon: auroral:aurora_shard
  parent: index.md
  position: 20
---

# <Color id="gold">Aurora 이벤트</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_shard" scale="2" />

  Auroral의 핵심인 천체 현상입니다. 하늘에 오로라가 펼쳐지면 추운 생물 군계가 활기를 띱니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aurora 발생 시기</Color>
</Column>

추운 생물 군계에서는 매일 밤 **33% 확률**로 Aurora가 시작됩니다. 활성화된 동안에는 다음과 같은 변화가 일어납니다.

* 하늘에 초록색과 분홍색 빛의 띠가 나타납니다.
* 밤에도 완전히 어두워지지 않습니다.
* 모드의 마법 효과가 활성화됩니다.

<Row>
  ### <Color id="aqua">개인 설정</Color>
</Row>

**Mods > Auroral > Config > Client**에서 시각·청각 효과를 설정할 수 있습니다.

* **Aurora Sky Effect**는 하늘의 오로라 효과를 조절합니다.
* **Aurora Sounds**는 음악과 시작·종료 소리를 조절합니다.

두 설정은 각각 끌 수 있습니다. 이 설정은 본인에게만 적용되며 오로라의 게임플레이 효과는 바뀌지 않습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">효과</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">Liquid Aura</Color>
</Row>

하늘이 보이는 곳에 놓인 <ItemLink id="glacial_basin" />에는 Shimmersteel 주입에 필요한 마법 물질인 Liquid Aura가 서서히 차오릅니다.

<Row>
  <ItemImage id="shimmersteel_pickaxe" />
  ### <Color id="aqua">장비 자동 수리</Color>
</Row>

오로라 동안 장착한 Shimmersteel 도구와 Shimmerweave 방어구가 자동으로 수리됩니다.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">생물 생성</Color>
</Row>

오로라 이벤트 중에는 플레이어 근처에 Auroral Nautilus가 떠다니며 나타납니다.

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">식물 성장</Color>
</Row>

눈 블록에 <ItemLink id="aurora_bloom" />이 나타나며, Frozen Petals를 채집할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aurora 촉매</Color>
</Column>

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Hearthwood Log</Color>
</Row>

추운 생물 군계에서 플레이어의 **32블록 이내**에 불이 붙은 <ItemLink id="hearthwood_log" />가 있으면 밤이 시작될 때 오로라 발생 확률이 **15%p 증가**합니다. 최대 3개까지 중첩되어 **45%p 증가**하며, 기본 설정에서 매일 밤 발생 확률이 약 **78%**가 됩니다.

이 촉매는 발생 확률을 크게 높이지만 확정하지는 않습니다. 오로라를 거의 확실하게 보고 싶다면 잠자는 장소 근처에 불붙은 통나무를 여러 개 두고, 밤이 시작될 때 추운 생물 군계에 있어야 합니다.

<RecipeFor id="hearthwood_log" />

불붙은 Hearthwood Log는 Frostbite 면역을 부여하고 팬텀을 쫓아내며 주민 거래 조건도 개선합니다.
