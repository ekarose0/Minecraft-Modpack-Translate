---
item_ids:
  - auroral:auroral_nautilus_spawn_egg
  - auroral:auroral_snowlette_spawn_egg
navigation:
  title: "Aurora 생물"
  icon: auroral:auroral_nautilus_spawn_egg
  parent: index.md
  position: 21
---

# <Color id="gold">Aurora의 생물</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="auroral_nautilus_spawn_egg" scale="2" />

  천체의 빛에서 나타나는 생물들입니다. 길들이거나 타고 다닐 수도 있고, 그저 쓰다듬어 줄 수도 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Auroral Nautilus</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">야생 상태의 행동</Color>
</Row>

오로라가 나타날 때만 생성되는 평화로운 부유 생물입니다. 은은하게 빛나는 껍데기를 지닌 채 하늘을 떠다닙니다.

* 오로라가 활성화된 동안에만 생성됩니다.
* 원을 그리며 천천히 떠다닙니다.
* 평화롭고 적대적이지 않습니다.
* 크기가 세 종류입니다.
* 오로라가 끝난 뒤 30초가 지나면 서서히 사라집니다.

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">Nautilus 유인</Color>
</Row>

야생 Nautilus는 호기심이 많아 <ItemLink id="aurora_shard" />를 들고 있는 플레이어에게 다가옵니다.

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">길들이기</Color>
</Row>

야생 Nautilus에게 Aurora Shard를 먹입니다. 각 조각을 사용할 때마다 **33% 확률**로 길들일 수 있습니다. 길들이면 다음과 같이 바뀝니다.

* 플레이어 주위를 천천히 선회합니다.
* 오로라가 끝나도 사라지지 않습니다.
* 하트 입자로 길들이기에 성공했음을 확인할 수 있습니다.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">명령 내리기</Color>
</Row>

* **Shift + 우클릭** — **따라오기**(플레이어 주위를 선회)와 **대기**(제자리에서 부유) 모드를 전환합니다.
* 근처에서 따라오기 모드인 Nautilus는 차원을 이동할 때 함께 따라옵니다. 대기 모드인 개체는 원래 위치에 남습니다.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">탑승</Color>
</Row>

길들인 Nautilus는 안장 없이 탈 수 있습니다.

1. 우클릭하여 탑승합니다. 소유자만 가능하며 대기 모드여서는 안 됩니다.
2. 이동 키와 바라보는 방향으로 비행을 조종합니다.
3. **스페이스바**를 길게 눌러 충전하고 놓으면 가속합니다. 완전히 충전하면 최대 **3배** 속도까지 높일 수 있습니다.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Nautilus 갑옷</Color>
</Row>

Auroral Nautilus에는 바닐라 Nautilus 갑옷(구리, 철, 금, 다이아몬드, 네더라이트)을 장착할 수 있습니다. 주 손에 갑옷을 들고 길들인 Nautilus를 우클릭하면 장착합니다. 웅크리지 않은 상태에서 **가위**로 우클릭하면 갑옷을 벗기며, 가위의 내구도가 1 감소합니다.

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">드롭 아이템</Color>
</Row>

플레이어가 Nautilus를 처치하면 다음 아이템을 떨어뜨릴 수 있습니다.

* 가죽 1~2개
* 프리즈머린 조각(5% 확률)
* Nautilus 껍데기(15% 확률, 플레이어가 처치한 경우에만)

<Row>
  <ItemImage id="roasted_snowball" />
  ### <Color id="aqua">Nautilus의 노여움</Color>
</Row>

<ItemLink id="roasted_snowball" />을 먹으면 Aurora의 노여움을 삽니다. 이 상태에서는 오로라가 발생해도 야생 Nautilus가 **플레이어 근처에 생성되지 않습니다**. 길들인 개체만 남습니다. 용서를 받으려면 <ItemLink id="sugared_roasted_snowball" />을 제작해 먹으면 됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Auroral Snowlette</Color>
</Column>

<Row>
  <ItemImage id="auroral_snowlette_spawn_egg" />
  ### <Color id="aqua">손바닥만 한 눈 골렘</Color>
</Row>

눈 골렘을 <ItemLink id="aurora_shard" />로 우클릭하여 만드는 작고 친근한 동료입니다.

* 반려동물처럼 플레이어를 따라옵니다.
* 일반 눈 골렘 크기의 약 1/4입니다.
* 눈덩이를 던져 주면 체력을 회복합니다.
* 은은한 오로라 반짝임을 내뿜습니다.
