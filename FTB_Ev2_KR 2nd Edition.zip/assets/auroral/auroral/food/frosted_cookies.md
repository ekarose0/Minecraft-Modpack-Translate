---
item_ids:
  - auroral:frosted_cookies
navigation:
  title: "Frosted Cookies"
  icon: auroral:frosted_cookies
  parent: food/index.md
  position: 2
---

# <Color id="gold">Frosted Cookies</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frosted_cookies" scale="2" />

  마법의 Frozen Petals를 뿌린 달콤한 간식입니다. 오로라 빛 아래 갓 내린 눈처럼 반짝입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="frosted_cookies" />

(Frosted Cookies 4개 제작)

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

* **간편한 간식** — 허기를 조금 회복합니다.
* **반짝이는 입자** — 먹을 때 오로라 입자가 나타납니다.
* **중첩 가능** — 최대 64개까지 겹쳐 보관할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 이동 중 허기를 빠르게 채우기 좋습니다.
* 효율적인 제작법으로 Frozen Petal 1개에서 쿠키 4개를 만듭니다.
* 추운 밤에 <ItemLink id="hot_cocoa" />와 함께 먹기 좋습니다.
