---
item_ids:
  - auroral:sugared_roasted_snowball
navigation:
  title: "Sugared Roasted Snowball"
  icon: auroral:sugared_roasted_snowball
  parent: food/index.md
  position: 4
---

# <Color id="gold">Sugared Roasted Snowball</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="sugared_roasted_snowball" scale="2" />

  Roasted Snowball에 설탕을 굴려 반짝이게 만든 음식입니다. 이 반짝임은 마법이 아니라 먹을 수 있는 사과의 표시입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="sugared_roasted_snowball" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

* **적은 영양** — 기본 Roasted Snowball과 같은 양의 허기를 회복합니다.
* **언제든 섭취 가능** — 허기가 가득 차 있어도 먹을 수 있습니다.
* **사과의 맛** — 먹으면 Auroral Nautilus와 화해합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">사과하기</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Nautilus의 용서</Color>
</Row>

<ItemLink id="roasted_snowball" />을 먹었다면 Nautilus가 불쾌해하며 떠나 버렸을 것입니다. Sugared Roasted Snowball을 먹으면 사과의 뜻을 전할 수 있고, 다음 오로라 때 다시 돌아옵니다.

*"The Majestic Nautili fly once again!"*라는 메시지가 표시되면 관계가 회복된 것입니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 첫 Roasted Snowball을 먹기 전에 하나 만들어 두세요. 그렇지 않으면 후회할 수 있습니다.
* 반짝이는 효과 덕분에 일반 Roasted Snowball과 쉽게 구분됩니다.
* 이미 Nautilus의 호의를 받고 있다면 별도 효과는 없지만 여전히 달콤합니다.
