---
item_ids:
  - auroral:snore
navigation:
  title: "S'nore"
  icon: auroral:snore
  parent: food/index.md
  position: 5
---

# <Color id="gold">S'nore</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="snore" scale="2" />

  쿠키 두 개 사이에 Sugared Roasted Snowball을 넣은 달콤한 샌드위치입니다. 의외로 든든하며 Nautilus도 원망하지 않습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="snore" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

* **든든한 식사** — 구운 소고기만큼 허기와 포만감을 회복합니다.
* **전달체의 힘** — 30초 동안 수중 호흡, 물속 채굴 속도 증가, 수중 시야 개선 효과를 얻습니다.
* **편안한 간식** — 잠을 잔 것처럼 팬텀의 불면 타이머를 초기화합니다.
* **최대 16개 중첩**

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 수중 탐험 전에 먹기 좋습니다. 바다의 심장으로 전달체를 설치하지 않아도 S'nore 하나로 30초 동안 전달체의 힘을 얻습니다.
* 지상에서 오래 여행할 때 침대 없이 팬텀을 막을 수 있도록 하나쯤 챙기세요.
* <ItemLink id="roasted_snowball" />을 그대로 먹는 것과 달리 S'nore를 먹어도 Nautilus는 **화를 내지 않습니다**. 설탕 코팅 덕분입니다.
