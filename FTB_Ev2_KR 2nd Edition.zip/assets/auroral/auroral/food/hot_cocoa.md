---
item_ids:
  - auroral:hot_cocoa
navigation:
  title: "Hot Cocoa"
  icon: auroral:hot_cocoa
  parent: food/index.md
  position: 1
---

# <Color id="gold">Hot Cocoa</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hot_cocoa" scale="2" />

  김이 모락모락 나는 따뜻한 음료입니다. 추위를 막으면서 체력도 회복시켜 줍니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="hot_cocoa" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">효과</Color>
</Column>

* **Frostbite 면역** — 3분 동안 Frostbite 효과를 완전히 막습니다.
* **재생 I** — 30초 동안 적용됩니다.
* **허기 회복** — 적당량의 허기를 회복합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 추운 생물 군계를 탐험할 때 여분을 준비해 두세요.
* 제작 시 빈 우유 양동이를 돌려받으며, 마시면 허기 4포인트를 회복합니다.
* <ItemLink id="frosted_cookies" />와 함께 먹으면 따뜻한 휴식을 즐길 수 있습니다.
