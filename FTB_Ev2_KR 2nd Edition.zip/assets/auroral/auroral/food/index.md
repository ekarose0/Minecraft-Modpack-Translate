---
navigation:
  title: "음식과 음료"
  icon: auroral:hot_cocoa
  parent: index.md
  position: 70
---

# <Color id="gold">음식과 음료</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hot_cocoa" scale="2" />

  추운 생물 군계에서 유용한 식음료입니다. <ItemLink id="cold_brewing_stand" />로 양조하거나 서리의 영향을 받은 재료로 제작합니다. 각각 추위를 버티는 시간과 온기, 생존에 도움이 되는 작은 이점을 제공합니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">제작법</Color>
</Column>

* <ItemImage id="hot_cocoa" scale="0.75"/> [Hot Cocoa](hot_cocoa.md) — 잠시 추위에 저항할 수 있게 해 주는 따뜻한 음료
* <ItemImage id="frosted_cookies" scale="0.75"/> [Frosted Cookies](frosted_cookies.md) — 마법처럼 반짝이는 달콤한 간식
* <ItemImage id="roasted_snowball" scale="0.75"/> [Roasted Snowball](roasted_snowball.md) — Nautilus의 노여움을 사는 구운 눈덩이
* <ItemImage id="sugared_roasted_snowball" scale="0.75"/> [Sugared Roasted Snowball](sugared_roasted_snowball.md) — Nautilus가 받아들이는 사과의 간식
* <ItemImage id="snore" scale="0.75"/> [S'nore](snore.md) — 쿠키 두 개와 설탕을 입힌 눈덩이로 만든 전달체의 힘 간식

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">농장에서 얻는 음식</Color>
</Column>

* <ItemImage id="glow_leek" scale="0.75"/> [Glow Leek](../flora/glow_leeks.md) — Shimmering Ice에서 자라는 발광 채소
* <ItemImage id="candied_glow_leek" scale="0.75"/> [Candied Glow Leek](../flora/glow_leeks.md) — 설탕을 입혀 발광 부작용을 없앤 채소
