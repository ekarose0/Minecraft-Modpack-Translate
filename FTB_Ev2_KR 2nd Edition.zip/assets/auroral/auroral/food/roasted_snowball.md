---
item_ids:
  - auroral:roasted_snowball
navigation:
  title: "Roasted Snowball"
  icon: auroral:roasted_snowball
  parent: food/index.md
  position: 3
---

# <Color id="gold">Roasted Snowball</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="roasted_snowball" scale="2" />

  연한 황금빛 갈색으로 구워져 위에서 김이 피어오르는 눈덩이입니다. 세상에서 가장 작은 마시멜로처럼 생겼지만, 맛과 영양도 그만큼 보잘것없습니다. Nautilus는 이것을 용서하지 않습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="roasted_snowball_from_smelting" />

화로에서 눈덩이를 구워도 만들 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

* **적은 영양** — 허기 반 칸을 회복합니다.
* **언제든 섭취 가능** — 배가 불러도 먹을 수 있습니다.
* **모욕적인 음식** — 먹으면 Aurora에게 불량한 존재로 낙인찍힙니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">경고</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Nautilus는 지켜보고 있습니다</Color>
</Row>

Roasted Snowball을 먹으면 Auroral Nautilus가 크게 분노합니다. 한 번 먹고 나면 오로라가 발생해도 야생 Nautilus가 **플레이어 근처에 더 이상 생성되지 않습니다**. 하늘이 조용해지고 종소리도 사라집니다.

화면에 *"The Magestic Nautili will no longer Soar In your skies"*라는 메시지가 표시되며, 실제로 그 말대로 됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">속죄</Color>
</Column>

<Row>
  <ItemImage id="sugared_roasted_snowball" />
  ### <Color id="aqua">달콤한 사과</Color>
</Row>

<ItemLink id="sugared_roasted_snowball" />을 제작해 먹으세요. Nautilus는 관대하므로 달콤한 사과 한 번이면 다시 하늘에 나타납니다.

결과는 피하고 맛만 즐기고 싶다면 <ItemLink id="snore" />로 만들어 먹으세요. 쿠키가 문제를 해결해 줍니다.
