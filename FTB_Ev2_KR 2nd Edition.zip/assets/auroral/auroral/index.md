---
navigation:
  title: "Auroral"
  icon: auroral:frozen_petals
  position: 0
---

# <Color id="gold">Auroral</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frozen_petals" scale="2" />

  천체 에너지와 신비로운 금속 가공, 혹한 속 생존을 중심으로 한 겨울 확장 모드입니다. Aurora의 힘을 활용해 Shimmersteel 장비와 Shimmerweave 방어구를 제작하고, 오로라가 빛날 때만 피어나는 희귀한 꽃을 찾아보세요.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

> *"하늘은 베풀고, 얼음은 기억합니다."*

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">시작하기</Color>
</Column>

* <ItemImage id="frozen_petals" scale="0.75"/> [소개](getting_started/introduction.md) — Auroral이 추가하는 요소와 진행 과정
* <ItemImage id="glacial_basin" scale="0.75"/> [첫 단계](getting_started/first_steps.md) — 첫 Aurora, 첫 Glacial Basin, 첫 주괴

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aurora</Color>
</Column>

* <ItemImage id="aurora_shard" scale="0.75"/> [Aurora 이벤트](aurora/aurora_events.md) — 오로라가 나타나는 시기와 보상
* <ItemImage id="auroral_nautilus_spawn_egg" scale="0.75"/> [Aurora 생물](aurora/creatures.md) — 빛에 이끌려 나타나는 Nautilus와 Snowlette

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">목차</Color>
</Column>

<ItemImage id="minecraft:air" scale="0.5"/>
<Row>
<Column>

### <Color id="aqua">식물</Color>

* <ItemImage id="frozen_petals" scale="0.75"/> [Aurora Bloom](flora/aurora_blooms.md)
* <ItemImage id="glow_leek" scale="0.75"/> [Glow Leek](flora/glow_leeks.md)
* <ItemImage id="shimmering_ice" scale="0.75"/> [Shimmering Ice](flora/shimmering_ice.md)
* <ItemImage id="aurora_ender_shard" scale="0.75"/> [Ender Bloom](flora/ender_bloom.md)

### <Color id="aqua">Shimmersteel</Color>

* <ItemImage id="shimmersteel_ingot" scale="0.75"/> [Shimmersteel Ingot](shimmersteel/ingots.md)
* <ItemImage id="glacial_basin" scale="0.75"/> [Glacial Basin](shimmersteel/glacial_basin.md)
* <ItemImage id="cold_brewing_stand" scale="0.75"/> [Cold Brewing Stand](shimmersteel/cold_brewing_stand.md)
* <ItemImage id="shimmersteel_pickaxe" scale="0.75"/> [Shimmersteel 도구](shimmersteel/tools.md)
* <ItemImage id="shimmersteel_bow" scale="0.75"/> [Shimmersteel Bow](shimmersteel/bow.md)
* <ItemImage id="shimmer_spear" scale="0.75"/> [Shimmer Spear](shimmersteel/spear.md)
* <ItemImage id="shimmersteel_ingot" scale="0.75"/> [갑옷 장식](shimmersteel/armor_trims.md)

### <Color id="aqua">Shimmerweave</Color>

* <ItemImage id="shimmerweave_fabric" scale="0.75"/> [Shimmerweave Fabric](shimmerweave/fabric.md)
* <ItemImage id="shimmerweave_goggles" scale="0.75"/> [고글](shimmerweave/goggles.md)
* <ItemImage id="shimmerweave_tunic" scale="0.75"/> [상의](shimmerweave/tunic.md)
* <ItemImage id="shimmerweave_leggings" scale="0.75"/> [레깅스](shimmerweave/leggings.md)
* <ItemImage id="shimmerweave_skates" scale="0.75"/> [스케이트](shimmerweave/skates.md)

</Column>
<Column>

### <Color id="aqua">장식</Color>

* <ItemImage id="snow_angel" scale="0.75"/> [Snow Angel](decorations/snow_angel.md)
* <ItemImage id="hearthwood_log" scale="0.75"/> [Hearthwood Log](decorations/hearthwood_log.md)
* <ItemImage id="aurora_lantern" scale="0.75"/> [Aurora Lantern](decorations/aurora_lantern.md)

### <Color id="aqua">음식과 음료</Color>

* <ItemImage id="hot_cocoa" scale="0.75"/> [Hot Cocoa](food/hot_cocoa.md)
* <ItemImage id="frosted_cookies" scale="0.75"/> [Frosted Cookies](food/frosted_cookies.md)
* <ItemImage id="roasted_snowball" scale="0.75"/> [Roasted Snowball](food/roasted_snowball.md)
* <ItemImage id="sugared_roasted_snowball" scale="0.75"/> [Sugared Roasted Snowball](food/sugared_roasted_snowball.md)
* <ItemImage id="snore" scale="0.75"/> [S'nore](food/snore.md)

</Column>
</Row>
