---
navigation:
  title: "Auroral 소개"
  icon: auroral:frozen_petals
  parent: index.md
  position: 10
---

# <Color id="gold">Auroral 소개</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frozen_petals" scale="2" />

  Auroral은 황량했던 추운 생물 군계를 후반부 성장의 중심지로 바꿉니다. 북극광인 Aurora의 힘으로 마법 아이템, 강화된 도구, 강력한 방어구를 제작해 보세요.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aurora</Color>
</Column>

추운 생물 군계의 밤에 무작위로 발생하는 천체 현상입니다. 오로라가 활성화되면 하늘에 초록색과 분홍색 빛의 물결이 펼쳐지며 특별한 마법 효과가 작동합니다.

오로라가 활성화된 동안에는 다음과 같은 일이 일어납니다.

* <ItemLink id="glacial_basin" />에 **Liquid Aura**를 모을 수 있습니다.
* **Shimmersteel 장비**가 자동으로 수리됩니다.
* 하늘에 **Auroral Nautilus**가 나타날 수 있습니다.
* 눈 블록 위에 **Aurora Bloom**이 피어납니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">추운 생물 군계</Color>
</Column>

Auroral의 주요 기능은 다음과 같은 추운 생물 군계를 위해 설계되었습니다.

* 눈 덮인 평원
* 얼음 가시
* 얼어붙은 바다
* 얼어붙은 봉우리
* 산림
* 눈 덮인 타이가

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">진행 순서</Color>
</Column>

1. 추운 생물 군계에서 Aurora가 나타날 때까지 기다립니다.
2. 자연적으로 피어난 Aurora Bloom에서 <ItemLink id="frozen_petals" />을 채집합니다.
3. <ItemLink id="glacial_basin" />과 <ItemLink id="cold_brewing_stand" />를 제작합니다.
4. 오로라 동안 Liquid Aura를 모아 철을 <ItemLink id="shimmersteel_ingot" />으로 변환합니다.
5. 강화된 도구와 무기, 방어구를 제작합니다.
