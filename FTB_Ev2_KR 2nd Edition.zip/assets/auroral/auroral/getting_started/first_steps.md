---
navigation:
  title: "첫 단계"
  icon: auroral:glacial_basin
  parent: index.md
  position: 11
---

# <Color id="gold">첫 단계</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glacial_basin" scale="2" />

  첫 Aurora부터 Glacial Basin, 첫 Shimmersteel 주괴까지 전체 과정을 다섯 단계로 간단히 알아봅니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Frozen Petals 모으기</Color>
</Column>

<ItemLink id="frozen_petals" />은 이 모드의 나머지 콘텐츠를 해금하는 핵심 재료입니다. 획득 방법은 다음과 같습니다.

* 오로라가 나타났을 때 눈 위에 자연 생성되는 <ItemLink id="aurora_bloom" />에서 채집합니다.
* 오로라 동안 Auroral Nautilus가 떨어뜨리기도 합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Glacial Basin 제작</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">Glacial Basin</Color>
</Row>

Glacial Basin은 주요 작업대입니다. 오로라가 발생했을 때 야외에 설치하면 Liquid Aura가 채워집니다.

<RecipeFor id="glacial_basin" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">첫 Shimmersteel 제작</Color>
</Column>

Glacial Basin에 Liquid Aura를 모았다면 다음 순서로 진행합니다.

1. 철 주괴를 들고 Glacial Basin을 우클릭합니다.
2. 철이 <ItemLink id="shimmersteel_ingot" />으로 변환됩니다.
3. Shimmersteel로 강화된 도구와 무기를 제작합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Cold Brewing Stand</Color>
</Column>

<Row>
  <ItemImage id="cold_brewing_stand" />
  ### <Color id="aqua">Cold Brewing Stand</Color>
</Row>

네더에 가지 않고도 포션을 양조할 수 있습니다. 블레이즈 가루 대신 눈덩이를 연료로 사용합니다.

<RecipeFor id="cold_brewing_stand" />

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">네더 사마귀 없이 어색한 포션 만들기</Color>
</Row>

Frozen Petals를 사용하면 네더 사마귀와 마찬가지로 물병에서 어색한 포션을 양조할 수 있습니다. 네더에 한 번도 가지 않고 포션 제작 과정을 시작할 수 있습니다.
