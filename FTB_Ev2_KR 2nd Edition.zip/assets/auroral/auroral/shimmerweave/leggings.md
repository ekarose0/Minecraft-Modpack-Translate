---
item_ids:
  - auroral:shimmerweave_leggings
navigation:
  title: "Shimmerweave Leggings"
  icon: auroral:shimmerweave_leggings
  parent: index.md
  position: 53
---

# <Color id="gold">Shimmerweave Leggings</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_leggings" scale="2" />

  눈과 영혼 모래 위에서 빠르게 이동하도록 돕는 레깅스입니다. 네더와 눈 덮인 평원 어디서든 발걸음이 가벼워집니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_leggings" />

대장장이 작업대에서 철 레깅스에 Shimmersteel Upgrade Template과 <ItemLink id="shimmerweave_fabric" />을 사용하여 강화합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">눈 위 이동 속도</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_leggings" />
  ### <Color id="aqua">눈으로 인한 감속 제거</Color>
</Row>

* 눈 블록 위를 걸을 때 이동 속도가 증가합니다.
* 눈 층으로 인한 감속이 없습니다.
* 눈 덮인 생물 군계를 횡단하기 좋습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">영혼 가속</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_leggings" />
  ### <Color id="aqua">영혼 모래 이동</Color>
</Row>

* 영혼 모래와 영혼 흙 위에서 영혼 가속 효과가 기본 적용됩니다.
* 마법 부여와 달리 레깅스의 내구도가 **감소하지 않습니다**.
* 네더의 영혼 모래 골짜기를 속도 저하 없이 이동할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* <ItemLink id="shimmerweave_skates" />와 함께 사용하면 기동성을 극대화할 수 있습니다.
* 기본 영혼 가속 효과는 바닐라 영혼 가속 마법 부여와 중첩됩니다.
* 오버월드의 눈 덮인 생물 군계와 네더의 영혼 모래 골짜기 양쪽에서 유용합니다.
