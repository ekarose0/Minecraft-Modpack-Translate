---
item_ids:
  - auroral:shimmerweave_fabric
  - auroral:woven_leather
navigation:
  title: "Shimmerweave Fabric"
  icon: auroral:shimmerweave_fabric
  parent: index.md
  position: 50
---

# <Color id="gold">Shimmerweave Fabric</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_fabric" scale="2" />

  Aurora의 힘이 스며든 천으로, 가볍고 튼튼하며 모든 Shimmerweave 방어구의 기본 재료입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Glacial Basin 주입</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">가죽 또는 양털 → Fabric</Color>
</Row>

Liquid Aura가 채워진 <ItemLink id="glacial_basin" />에서 가죽이나 색상에 관계없이 양털을 주입합니다.

1. 하늘이 트인 곳에 Glacial Basin을 설치합니다.
2. 오로라가 나타나 Glacial Basin이 채워질 때까지 기다립니다.
3. 가죽이나 양털을 들고 Glacial Basin을 우클릭합니다.
4. Shimmerweave Fabric을 얻습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Woven Leather</Color>
</Column>

<Row>
  <ItemImage id="woven_leather" />
  ### <Color id="aqua">가죽으로 제작</Color>
</Row>

일부 제작법에는 일반 가죽으로 만든 Woven Leather가 필요합니다.

<RecipeFor id="woven_leather" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

* **가벼움** — Shimmerweave로 만든 방어구는 무게가 매우 가볍습니다.
* **Aurora 친화성** — 오로라 동안 방어구가 자동으로 수리됩니다.
* **마법 전도성** — 방어구 부위별 특수 능력을 사용할 수 있게 합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">활용법</Color>
</Column>

Shimmerweave Fabric은 대장장이 작업대에서 철 방어구를 강화하는 데 사용합니다. 강화하려면 **Shimmersteel Upgrade Smithing Template**이 필요합니다.

* <ItemImage id="shimmerweave_goggles" scale="0.75"/> [Shimmerweave Goggles](goggles.md) — 숨어 있는 적을 드러냅니다.
* <ItemImage id="shimmerweave_tunic" scale="0.75"/> [Shimmerweave Tunic](tunic.md) — 화염 피해로부터 보호합니다.
* <ItemImage id="shimmerweave_leggings" scale="0.75"/> [Shimmerweave Leggings](leggings.md) — 눈 위에서 이동 속도를 높입니다.
* <ItemImage id="shimmerweave_skates" scale="0.75"/> [Shimmerweave Skates](skates.md) — 얼음 위를 자유롭게 이동합니다.
