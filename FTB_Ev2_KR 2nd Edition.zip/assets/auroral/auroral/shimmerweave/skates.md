---
item_ids:
  - auroral:shimmerweave_skates
navigation:
  title: "Shimmerweave Skates"
  icon: auroral:shimmerweave_skates
  parent: index.md
  position: 54
---

# <Color id="gold">Shimmerweave Skates</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_skates" scale="2" />

  Shimmerweave 방어구 중 가장 다재다능한 장비입니다. 얼음, 눈, 물, 심지어 용암까지 다루며 위험한 지형을 빠른 이동 경로로 바꿉니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_skates" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">얼음과 눈 위의 속도</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">지면 속도 증가</Color>
</Row>

* 얼음이나 눈 블록 위에 서 있으면 이동 속도가 증가합니다.
* 꽁꽁 언 얼음과 푸른얼음에서는 추가로 빨라집니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">얼음 위 관성</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">보트처럼 미끄러지기</Color>
</Row>

* 보트처럼 얼음 위에서 관성을 쌓아 가속합니다.
* 계속 이동하면 빨라지고, 이동 키를 놓으면 관성으로 미끄러집니다.
* 푸른얼음이 가장 매끄러운 스케이트 표면입니다.
* 이동 키를 누르지 않아도 관성이 유지됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">차가운 걸음 강화</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">물과 용암 모두 건너기</Color>
</Row>

* 물 위를 걸으면 살얼음이 생성됩니다.
* 접촉한 **용암을 흑요석으로** 바꿉니다.
* 낙하 중 발밑에 용암이 있다면 착지하기 전에 흑요석으로 변합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">낙하 피해 면역</Color>
</Column>

* 얼음이나 흑요석 위에 착지하면 낙하 피해를 받지 않습니다.
* 높은 곳에서 스케이트를 타고 내려올 때 유용합니다.
* 용암을 향해 뛰어내려 새로 생긴 흑요석 위에 착지할 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">시너지</Color>
</Column>

* <ItemLink id="shimmerweave_leggings" /> — 눈과 영혼 모래 위에서 추가 이동 속도를 얻습니다.
* **Shimmersteel Shovel** — 섬세한 손길로 눈길을 빠르게 만들 수 있습니다.
* 용암을 흑요석으로 바꾸는 능력 덕분에 네더 이동이 훨씬 안전해집니다.
