---
item_ids:
  - auroral:shimmerweave_tunic
navigation:
  title: "Shimmerweave Tunic"
  icon: auroral:shimmerweave_tunic
  parent: index.md
  position: 52
---

# <Color id="gold">Shimmerweave Tunic</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_tunic" scale="2" />

  불꽃의 힘을 되돌리는 마법 상의입니다. 착용자의 몸에 붙은 불을 자동으로 끄고 화염 피해를 막아 줍니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_tunic" />

대장장이 작업대에서 철 흉갑에 Shimmersteel Upgrade Template과 <ItemLink id="shimmerweave_fabric" />을 사용하여 강화합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">자동 소화</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_tunic" />
  ### <Color id="aqua">즉각적인 화염 보호</Color>
</Row>

* 착용자에게 불이 붙으면 자동으로 꺼 줍니다.
* 장착한 동안 화염 피해를 받지 않습니다.
* 용암, 불 블록, 블레이즈 공격 등 모든 화염 원천에 효과가 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">냉각 오라</Color>
</Column>

Aurora의 힘이 깃든 천은 열을 밀어내므로 다음 상황에서 매우 유용합니다.

* 네더 탐험
* 블레이즈와의 전투
* 용암 근처에서의 작업

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 네더를 안전하게 여행할 때 필수적인 장비입니다.
* 접촉한 용암을 흑요석으로 바꾸는 <ItemLink id="shimmerweave_skates" />와 함께 사용하면 좋습니다.
* 화염 보호는 지속 효과이므로 별도 활성화가 필요하지 않습니다.
