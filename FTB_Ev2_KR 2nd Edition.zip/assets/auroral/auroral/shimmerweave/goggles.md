---
item_ids:
  - auroral:shimmerweave_goggles
navigation:
  title: "Shimmerweave Goggles"
  icon: auroral:shimmerweave_goggles
  parent: index.md
  position: 51
---

# <Color id="gold">Shimmerweave Goggles</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_goggles" scale="2" />

  어둠 속에 숨어 있는 위협을 드러내는 마법 고글입니다. 적대적 몹이 벽 너머에서도 빛나 보입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_goggles" />

대장장이 작업대에서 철 투구에 Shimmersteel Upgrade Template과 <ItemLink id="shimmerweave_fabric" />을 사용하여 강화합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">적대적 몹 탐지</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_goggles" />
  ### <Color id="aqua">발광 오라</Color>
</Row>

* **발광** — 32블록 이내의 모든 적대적 몹이 빛나며 벽 너머에서도 보입니다.
* 동굴 탐험과 야간 습격에 적합합니다.
* 완전한 어둠 속에서도 작동합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">팁</Color>
</Column>

* 야간 투시 포션이나 <ItemLink id="glow_leek" />와 함께 사용하면 시야를 더 넓게 확보할 수 있습니다.
* 어두운 동굴을 안전하게 탐험할 때 매우 유용합니다.
* 32블록 반경은 대부분의 전투 상황을 포괄합니다.
