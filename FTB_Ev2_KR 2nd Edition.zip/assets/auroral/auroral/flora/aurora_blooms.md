---
item_ids:
  - auroral:aurora_bloom
  - auroral:aurora_bloom_decorative
  - auroral:frozen_petals
navigation:
  title: "Aurora Bloom"
  icon: auroral:frozen_petals
  parent: index.md
  position: 30
---

# <Color id="gold">Aurora Bloom</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_bloom" scale="2" />

  오로라가 나타날 때 눈 위에 저절로 피어나는 마법의 꽃입니다. <ItemLink id="frozen_petals" />의 공급원이며, 모드의 주요 콘텐츠로 나아가는 출발점입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aurora Bloom 찾기</Color>
</Column>

오로라가 발생하면 추운 생물 군계의 지표면에 Aurora Bloom이 자연적으로 생성됩니다. **4단계**를 거쳐 완전히 자랍니다. 오로라가 끝나고 남은 꽃은 해가 뜰 때 시들어 사라집니다.

생성되고 살아남을 수 있는 표면은 다음과 같습니다.

* 눈 층(아래 블록도 눈 표면으로 적합해야 합니다. 눈이 녹았을 때 흙이나 돌 위에 꽃이 남지 않도록 하기 위한 조건입니다.)
* 눈 블록
* 가루눈(아래 설명 참고)
* 얼음, 꽁꽁 언 얼음, 푸른얼음(얼어붙은 바다 표면에서도 가능)
* <ItemLink id="shimmering_ice" />

<Row>
  <ItemImage id="aurora_bloom" />
  ### <Color id="aqua">눈을 품은 꽃</Color>
</Row>

꽃을 **눈 층** 위에 심거나 **가루눈** 속에서 생성하면 원래 눈의 종류가 기억됩니다. 꽃을 부수거나 꽃이 시들면 해당 자리에 원래 눈이 복원됩니다. 눈 층은 눈 층으로, 가루눈은 가루눈으로 돌아옵니다. 꽃이 눈에 파묻혀도 위쪽에 희미한 눈송이 입자가 나타나므로 눈이 더 쌓여도 위치를 찾을 수 있습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">채집</Color>
</Column>

완전히 성장한(3단계) Aurora Bloom을 부수면 다음 아이템이 나옵니다.

* <ItemLink id="frozen_petals" />(행운 마법 부여에 따라 1~4개)
* 다시 심을 수 있는 **살아 있는 Aurora Bloom** 자체
* 추가로 살아 있는 꽃이 나올 **15% 확률**

덜 자란 꽃을 부수면 아무것도 얻지 못합니다. 기다리는 편이 좋습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">보존된 꽃(섬세한 손길)</Color>
</Column>

완전히 성장한 Aurora Bloom에 **섬세한 손길** 도구를 사용하면 Frozen Petals 대신 **장식용 Aurora Bloom**을 얻습니다. 이 장식용 꽃은 다음과 같은 특성이 있습니다.

* 해가 떠도 시들지 않고 영구적으로 남습니다.
* 항상 3단계의 모습을 유지합니다.
* **화분**에 넣어 장식할 수 있습니다.
* 부수면 자기 자신이 나오므로 어디든 옮겨 심을 수 있습니다.

활성화된 오로라가 없을 때도 Aurora Bloom을 유지하는 유일한 방법입니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Frozen Petals 활용법</Color>
</Column>

* **어색한 포션** — 양조기에서 네더 사마귀처럼 물병과 함께 양조합니다.
* <ItemLink id="cold_brewing_stand" /> — Shimmersteel Ingot과 조합합니다.
* <ItemLink id="glow_leek_seeds" /> — 밀 씨앗과 조합합니다.
* <ItemLink id="frosted_cookies" /> — 마법처럼 반짝이는 달콤한 간식입니다.
* <ItemLink id="aurora_shard" /> — Glacial Basin에서 Aura 1단계를 소모하여 주입합니다.

<RecipeFor id="glow_leek_seeds" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Ender 변환</Color>
</Column>

<Row>
  <ItemImage id="aurora_ender_shard" />
  ### <Color id="aqua">엔더 진주로 우클릭</Color>
</Row>

**엔더 진주**를 들고 Aurora Bloom을 우클릭하면 같은 성장 단계의 <ItemLink id="ender_bloom" />으로 변합니다. 이때 진주가 소모됩니다. 전체 성장 과정은 [Ender Bloom](ender_bloom.md) 문서를 참고하세요.
