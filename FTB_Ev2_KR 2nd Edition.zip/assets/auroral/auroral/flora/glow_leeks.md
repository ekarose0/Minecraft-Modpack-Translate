---
item_ids:
  - auroral:glow_leek
  - auroral:glow_leek_seeds
  - auroral:candied_glow_leek
navigation:
  title: "Glow Leek"
  icon: auroral:glow_leek
  parent: index.md
  position: 31
---

# <Color id="gold">Glow Leek</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glow_leek" scale="2" />

  추운 곳에서 잘 자라는 발광 채소입니다. 먹으면 야간 투시와 발광 효과를 얻습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">씨앗</Color>
</Column>

<Row>
  <ItemImage id="glow_leek_seeds" />
  ### <Color id="aqua">Glow Leek Seeds</Color>
</Row>

<ItemLink id="frozen_petals" />과 **밀 씨앗**을 조합하여 제작합니다.

<RecipeFor id="glow_leek_seeds" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">재배</Color>
</Column>

Glow Leek는 <ItemLink id="shimmering_ice" /> 블록에서만 자랍니다. 빛이 필요하지 않으며 밤에도 계속 성장합니다.

완전히 성장한 작물을 부수면 다음 아이템을 얻습니다.

* **Glow Leek**(채소)
* **Glow Leek Seeds**(다시 심을 씨앗)

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">섭취 효과</Color>
</Column>

Glow Leek를 먹으면 다음 효과를 얻습니다.

* **야간 투시** — 어둠 속에서도 선명하게 볼 수 있습니다.
* **발광** — 다른 플레이어에게 위치가 드러납니다.

<Row>
  <ItemImage id="candied_glow_leek" />
  ### <Color id="aqua">Candied Glow Leek</Color>
</Row>

설탕을 입혀 먹으면 발광 효과 없이 야간 투시만 얻습니다.

<RecipeFor id="candied_glow_leek" />
