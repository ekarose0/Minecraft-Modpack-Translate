---
item_ids:
  - auroral:ender_bloom
  - auroral:aurora_ender_shard
navigation:
  title: "Ender Bloom"
  icon: auroral:aurora_ender_shard
  parent: index.md
  position: 33
---

# <Color id="gold">Ender Bloom</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="ender_bloom" scale="2" />

  Aurora Bloom에 엔더의 힘이 깃든 변종입니다. 보라색으로 불안정하게 흔들리며, 엔더 진주를 재생 가능하게 얻을 수 있습니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">만드는 방법</Color>
</Column>

Ender Bloom은 자연 생성되지 않습니다. 다음과 같이 만듭니다.

1. 오로라 이벤트 동안 <ItemLink id="aurora_bloom" />을 찾거나 키웁니다.
2. **엔더 진주**를 들고 꽃을 우클릭합니다.
3. 진주가 소모되면서 꽃이 같은 성장 단계의 Ender Bloom으로 변합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">지속성</Color>
</Column>

Aurora Bloom과 달리 Ender Bloom은 **영구적으로 유지**됩니다. 해가 떠도 시들지 않으며 오로라가 끝나도 남습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">성장 조건</Color>
</Column>

Ender Bloom은 다음 블록에 심었을 때만 성장 단계가 진행됩니다.

* <ItemLink id="shimmer_soil" />
* **엔드 돌**

다른 블록 위에서도 살아남지만 심은 시점의 성장 단계에서 더 자라지 않습니다. 위 두 블록이 아니라면 뼛가루도 효과가 없습니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">채집</Color>
</Column>

Ender Bloom은 **어느 성장 단계**에서 부수더라도 Ender Bloom 아이템 1개를 떨어뜨립니다. 다시 심으면 항상 0단계부터 시작합니다.

3단계에서 부수면 **추가로** 다음 아이템을 얻습니다.

* <ItemLink id="aurora_ender_shard" /> 1개
* Ender Bloom을 추가로 얻을 **5% 확률**

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aurora Ender Shard</Color>
</Column>

<Row>
  <ItemImage id="aurora_ender_shard" />
  ### <Color id="aqua">재생 가능한 엔더 진주</Color>
</Row>

Aurora Ender Shard 2개를 조합하면 엔더 진주 1개를 만들 수 있습니다. 성숙한 Ender Bloom 농장을 만들면 엔더 진주를 지속적으로 생산할 수 있습니다.

<RecipeFor id="ender_pearl_from_shards" />
