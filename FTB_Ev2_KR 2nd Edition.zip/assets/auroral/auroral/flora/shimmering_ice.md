---
item_ids:
  - auroral:shimmering_ice
navigation:
  title: "Shimmering Ice"
  icon: auroral:shimmering_ice
  parent: index.md
  position: 32
---

# <Color id="gold">Shimmering Ice</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmering_ice" scale="2" />

  Aurora의 힘이 스며든 얼음입니다. 은은하게 빛나고 녹지 않으며 주변 땅에 수분을 공급합니다. 추운 생물 군계 농장의 핵심 재료입니다.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">획득 방법</Color>
</Column>

* <ItemLink id="glacial_basin" />에서 일반 얼음에 Liquid Aura를 주입합니다.
* 오로라의 영향을 받은 얼어붙은 생물 군계에서 드물게 자연 생성됩니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">특성</Color>
</Column>

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">녹지 않음</Color>
</Row>

열과 빛에 완전히 견딥니다. 오래 유지해야 하는 장식용 건축물이나 이동 경로에 적합합니다.

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">발광</Color>
</Row>

밝기 8의 은은한 빛을 냅니다. 분위기를 유지하면서 몹 생성을 막는 데 도움이 됩니다.

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">수분 공급</Color>
</Row>

물처럼 **반경 4블록** 이내의 일반 경작지와 <ItemLink id="shimmer_soil" />에 수분을 공급합니다. 은은한 조명도 제공하므로 수로가 없는 지하 농장에 유용합니다.

<Row>
  <ItemImage id="glow_leek" />
  ### <Color id="aqua">Glow Leek 재배용 바닥</Color>
</Row>

<ItemLink id="glow_leek_seeds" />는 Shimmering Ice 위에만 심을 수 있습니다. 생체 발광 작물의 성장에는 이 얼음의 마법 특성이 필요합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Shimmer Soil과의 시너지</Color>
</Column>

Shimmering Ice를 Shimmersteel Hoe로 만든 <ItemLink id="shimmer_soil" />과 함께 사용하면 얼어붙은 생물 군계에 효율적인 농장을 만들 수 있습니다.

* Shimmering Ice는 수분과 **빛을 동시에** 공급합니다.
* Shimmer Soil에서는 작물이 더 빨리 자랍니다. **밤에는 3배, 오로라 동안에는 5배**입니다.
* 물 없이도 어디서나 작동합니다.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">활용법 요약</Color>
</Column>

* 물 없이 Shimmer Soil 농장에 수분 공급하기
* Glow Leek 재배하기(전용 재배 블록)
* 녹지 않는 영구적인 얼음길 만들기
* 은은한 조명으로 건축물 꾸미기
* 별도 조명을 설치하지 않고 지하 농장 운영하기
